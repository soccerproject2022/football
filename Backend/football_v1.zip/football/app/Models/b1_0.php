<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class b1 extends Model
{
    use HasFactory;
    protected $fillable = [
        'game_id',
        'date',
        'league',
        'host',
        'guest',
        'h_win',
        'draw',
        'g_win',
        'h_return',
        'd_return',
        'g_return',
        'jc_id',
        'h_img',
        'g_img',

    ];
}
