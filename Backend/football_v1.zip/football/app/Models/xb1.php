<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class b1 extends Model
{
    use HasFactory;
    protected $connection = 'mysql2';
    protected $fillable = [
        'game_id',
        'dates',
        'league',
        'host',
        'guest',
        'host_logo',
        'guest_logo',
        'league_cn',
        'host_cn',
        'guest_cn',
        'league_en',
        'host_en',
        'guest_en',
        'h_win',
        'draw',
        'g_win',
        'h_return',
        'd_return',
        'g_return',

    ];
}
