<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class b4_draw extends Model
{
    use HasFactory;
    protected $fillable = [
        'id',
        'game_id',
        'd1',
        'd2',
        'd3',
        'd4',
        'd5',

    ];
}
