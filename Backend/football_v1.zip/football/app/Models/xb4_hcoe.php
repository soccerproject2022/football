<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class b4_hcoe extends Model
{
    use HasFactory;
    protected $fillable = [
        'id',
        'hcoe',
        'hvalue',

    ];
}
