<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('a1', function (Blueprint $table) {
            $table->increments('game_id');
            $table->string('league', 50);
            $table->dateTimeTz('date', $precision = 0);
            $table->string('host', 50);
            $table->string('guest', 50);
            $table->float('h_win');
            $table->float('draw');
            $table->float('g_win');
            $table->float('h_return');
            $table->float('d_return');
            $table->float('g_return');
            $table->string('h_img');
            $table->string('g_img');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('a1');
    }
};
