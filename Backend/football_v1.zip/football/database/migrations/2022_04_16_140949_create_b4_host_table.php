<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('a4_host', function (Blueprint $table) {
            $table->increments('id');
            $table->string('game_id');
            $table->float('h1');
            $table->float('h2');
            $table->float('h3');
            $table->float('h4');
            $table->float('h5');
            $table->float('h6');
            $table->float('h7');
            $table->float('h8');
            $table->float('h9');
            $table->float('h10');
            $table->float('h11');
            $table->float('h12');
            $table->float('h13');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('a4_host');
    }
};
