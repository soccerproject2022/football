<div>
            <table cellpadding="7" cellspacing="0" style="width:80; text-align:center; color:#000000">
            <!--table class="table table-hover"-->    
                    <tr style="background-color:#797979; font-size:16px; color:#ffffff">
                        <td>game_id</th>    
                        <th scope="col">h1</th>
                        <th scope="col">h2</th>
                        <th scope="col">h3</th>
                        <th scope="col">h4</th>
                        <th scope="col">h5</th>
                        <th scope="col">h6</th>
                        <th scope="col">h7</th>
                        <th scope="col">h8</th>
                        <th scope="col">h9</th>
                        <th scope="col">h10</th>
                        <th scope="col">h11</th>
                        <th scope="col">h12</th>
                        <th scope="col">h13</th>
                    </tr>
                
                

                    @foreach($a4_hosts as $a4datum)
                    <tr frame="above">
                        <td style="background-color:#5D5D5D; font-size:16px; color:#ffffff">{{ $a4datum->game_id }}</td>
                        <td >{{ $a4datum->h1 }}</td>
                        <td>{{ $a4datum->h2 }}</td>
                        <td>{{ $a4datum->h3 }}</td>
                        <td>{{ $a4datum->h4 }}</td>
                        <td>{{ $a4datum->h5 }}</td>
                        <td>{{ $a4datum->h6 }}</td>
                        <td>{{ $a4datum->h7 }}</td>
                        <td>{{ $a4datum->h8 }}</td>
                        <td>{{ $a4datum->h9 }}</td>
                        <td>{{ $a4datum->h10 }}</td>
                        <td>{{ $a4datum->h11 }}</td>
                        <td>{{ $a4datum->h12 }}</td>
                        <td>{{ $a4datum->h13 }}</td>

                    
                    </tr>
                    @endforeach
                
            </table>
</div>