@extends('admin.admin_master')
@section('edita2')
<div class="col-lg-12">
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>{{ session('success') }}</strong>
<button type="button" class="class" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
</div>
@endif
            <div class="card-header card-header-border-bottom">
                <h2>Edit a2 data</h2>
            </div>
            <div class="card-body">
                <form action="{{ url('a2/update/'.$a2s->id) }}" method="POST" >
                @csrf
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >id</label>
                                <input type="hidden" name="id" class="form-control" >
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="host" disabled value="{{ $a2s->host }}">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="guest" disabled value="{{ $a2s->guest }}">
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主場勝數</label>
                                <input type="number" name="h_guess" class="form-control" placeholder="主場勝數" value="{{ $a2s->h_guess }}" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >和波機數</label>
                                <input type="number" name="d_guess" class="form-control" placeholder="和波機數" value="{{ $a2s->d_guess }}" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊勝數</label>
                                <input type="number" name="g_guess" class="form-control" placeholder="客隊勝數" value="{{ $a2s->g_guess }}" step=any>
                            </div>
                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection