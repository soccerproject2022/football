@extends('admin.admin_master')
@section('admin')


<div class="col-lg-12">

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>{{ session('success') }}</strong>
    <button type="button" class="class" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@endif

    
        <div class="card-header card-header-border-bottom">
            <h2>a8 database table</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">最佳球隊</th>
                        <th scope="col">預測結果</th>
                        <th scope="col">得分</th>
                        <th scope="col">T2015</th>
                        <th scope="col">T2016</th>
                        <th scope="col">T2017</th>
                        <th scope="col">T2018</th>
                        <th scope="col">T2019</th>
                        <th scope="col">T2020</th>
                        <th scope="col">T2021</th>
                        <th scope="col">p2015</th>
                        <th scope="col">p2016</th>
                        <th scope="col">p2017</th>
                        <th scope="col">p2018</th>
                        <th scope="col">p2019</th>
                        <th scope="col">p2020</th>
                        <th scope="col">p2021</th>
                        
                    </tr>
                </thead>
                <tbody>

                    @foreach($a8s as $a8datum)
                    <tr>
                        <td>{{ $a8datum->id }}</td>
                        <td>{{ $a8datum->best_team }}</td>
                        <td>{{ $a8datum->opt }}</td>
                        <td>{{ $a8datum->point }}</td>
                        <td>{{ $a8datum->T2015 }}</td>
                        <td>{{ $a8datum->T2016 }}</td>
                        <td>{{ $a8datum->T2017 }}</td>
                        <td>{{ $a8datum->T2018 }}</td>
                        <td>{{ $a8datum->T2019 }}</td>
                        <td>{{ $a8datum->T2020 }}</td>
                        <td>{{ $a8datum->T2021 }}</td>
                        <td>{{ $a8datum->p2015 }}</td>
                        <td>{{ $a8datum->p2016 }}</td>
                        <td>{{ $a8datum->p2017 }}</td>
                        <td>{{ $a8datum->p2018 }}</td>
                        <td>{{ $a8datum->p2019 }}</td>
                        <td>{{ $a8datum->p2020 }}</td>
                        <td>{{ $a8datum->p2021 }}</td>

                        
                        <td><a href="{{ url('a8/edit/'.$a8datum->game_id) }}" class="btn btn-info">Edit</a></td>
                        <td><a href="{{ url('a8/delete/'.$a8datum->game_id) }}" onclick="return confirm('Are you sure to delete?')" class="btn btn-danger">Delete</a></td>
                    
                    </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card card-default">
            <div class="card-header card-header-border-bottom">
                <h2></h2>
            </div>
            <div class="card-body">
                <form action="{{ route('create.a8') }}" method="POST" >
                @csrf
                    <div class="row">
                    <div class="col-sm-3">
                            <div class="form-group">
                                <label >game_id</label>
                                <input type="number" name="game_id" class="form-control" placeholder="game_id">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >最佳球隊</label>
                                <input type="text" name="best_team" class="form-control" placeholder="最佳球隊">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >預測結果</label>
                                <input type="text" name="opt" class="form-control" placeholder="預測結果">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >得分</label>
                                <input type="number" name="point" class="form-control" placeholder="得分" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >T2015</label>
                                <input type="number" name="T2015" class="form-control" placeholder="T2015" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >T2016</label>
                                <input type="number" name="T2016" class="form-control" placeholder="T2016" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >T2017</label>
                                <input type="number" name="T2017" class="form-control" placeholder="T2017" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >T2018</label>
                                <input type="number" name="T2018" class="form-control" placeholder="T2018" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >T2019</label>
                                <input type="number" name="T2019" class="form-control" placeholder="T2019" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >T2020</label>
                                <input type="number" name="T2020" class="form-control" placeholder="T2020" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >T2021</label>
                                <input type="number" name="T2021" class="form-control" placeholder="T2021" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >p2015</label>
                                <input type="number" name="p2015" class="form-control" placeholder="p2015" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >p2016</label>
                                <input type="number" name="p2016" class="form-control" placeholder="p2016" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >p2017</label>
                                <input type="number" name="p2017" class="form-control" placeholder="p2017" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >p2018</label>
                                <input type="number" name="p2018" class="form-control" placeholder="p2018" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >p2019</label>
                                <input type="number" name="p2019" class="form-control" placeholder="p2019" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >p2020</label>
                                <input type="number" name="p2020" class="form-control" placeholder="p2020" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >p2021</label>
                                <input type="number" name="p2021" class="form-control" placeholder="p2021" step=any >
                            </div>
                        </div>







                    </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Create</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection