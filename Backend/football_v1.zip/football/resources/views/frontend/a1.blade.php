


<div class="col-lg-12">

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>{{ session('success') }}</strong>
    <button type="button" class="class" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@endif

    
        <div class="card-header card-header-border-bottom">
            <h2>賽程表</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover " cellspacing=5 border=1 style="text-align:center; margin-top:100px; margin-left:50px;">
                <thead>
                    <tr>
                        <th scope="col" width="50">#</th>
                        <th scope="col" width="180">賽事類別</th>
                        <th scope="col" width="180">開賽時間</th>
                        <th scope="col"></th>
                        <th scope="col" width="180">主隊</th>
                        <th scope="col"></th>
                        <th scope="col" width="180">客隊</th>
                        <th scope="col">主勝</th>
                        <th scope="col">和率</th>
                        <th scope="col">客勝</th>
                        <th scope="col">主回率</th>
                        <th scope="col">和回率</th>
                        <th scope="col">客回率</th>
                        
                        
                    </tr>
                </thead>
                <tbody>

                    @foreach($a1s as $a1datum)
                    <tr>
                        <td>{{ $a1datum->jc_id }}</td>
                        <td>{{ $a1datum->league }}</td>
                        <td>{{ $a1datum->date }}</td>
                        <td><img src="{{ asset($a1datum->h_img) }}" style="width:40px"></td>
                        <td>{{ $a1datum->host }}</td>
                        <td><img src="{{ asset($a1datum->g_img) }}" style="width:40px"></td>
                        <td>{{ $a1datum->guest }}</td>
                        <td>{{ $a1datum->h_win }}</td>
                        <td>{{ $a1datum->draw }}</td>
                        <td>{{ $a1datum->g_win }}</td>
                        <td>{{ $a1datum->h_return }}</td>
                        <td>{{ $a1datum->d_return }}</td>
                        <td>{{ $a1datum->g_return }}</td>
                        
                        
                        
                    
                    </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>

