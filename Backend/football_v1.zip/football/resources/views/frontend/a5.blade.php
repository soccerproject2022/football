﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A5</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/Moses football/public/frontend/assets/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/Moses football/public/frontend/assets/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/Moses football/public/frontend/assets/files/page_a5/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/Moses football/public/frontend/assets/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/axQuery.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/globals.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axutils.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/annotation.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/doc.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/messagecenter.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/events.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/recording.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/action.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/expr.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/geometry.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/flyout.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/model.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/repeater.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/sto.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/utils.temp.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/variables.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/drag.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/move.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/visibility.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/style.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/adaptive.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/tree.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/init.temp.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/legacy.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/viewer.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/math.js"></script>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/Moses football/public/frontend/assets/data/document.js"></script>
    <script src="/Moses football/public/frontend/assets/files/page_a5/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/Moses football/public/frontend/assets/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/Moses football/public/frontend/assets/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/Moses football/public/frontend/assets/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Header (Rectangle) -->
      <div id="u0" class="ax_default box_2" data-label="Header">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
        </div>
      </div>

      <!-- footer (Group) -->
      <div id="u1" class="ax_default" data-label="footer" data-left="150" data-top="1510" data-width="1073" data-height="171">

        <!-- Unnamed (Rectangle) -->
        <div id="u2" class="ax_default shape">
          <img id="u2_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/u2.svg"/>
          <div id="u2_text" class="text ">
            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:700;font-style:normal;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">問題</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">查詢</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">意見</span></p>
          </div>
        </div>

        <!-- illegal_gambling_hotSpot (Hot Spot) -->
        <div id="u3" class="ax_default" data-label="illegal_gambling_hotSpot">
        </div>

        <!-- HKJC_hotSpot (Hot Spot) -->
        <div id="u4" class="ax_default" data-label="HKJC_hotSpot">
        </div>

        <!-- 意見 (Hot Spot) -->
        <div id="u5" class="ax_default" data-label="意見">
        </div>

        <!-- 查詢 (Hot Spot) -->
        <div id="u6" class="ax_default" data-label="查詢">
        </div>

        <!-- 問題 (Hot Spot) -->
        <div id="u7" class="ax_default" data-label="問題">
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u8" class="ax_default box_2 ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u8_div" class=""></div>
        <div id="u8_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
        </div>
      </div>

      <!-- Footer (Group) -->
      <div id="u9" class="ax_default ax_default_unplaced" data-label="Footer" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Rectangle) -->
        <div id="u10" class="ax_default shape ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u10_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
          <div id="u10_text" class="text ">
            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:700;font-style:normal;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">問題</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">查詢</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">意見</span></p>
          </div>
        </div>

        <!-- illegal_gambling_hotSpot (Hot Spot) -->
        <div id="u11" class="ax_default ax_default_unplaced" data-label="illegal_gambling_hotSpot" style="display:none; visibility: hidden">
        </div>

        <!-- HKJC_hotSpot (Hot Spot) -->
        <div id="u12" class="ax_default ax_default_unplaced" data-label="HKJC_hotSpot" style="display:none; visibility: hidden">
        </div>

        <!-- 意見 (Hot Spot) -->
        <div id="u13" class="ax_default ax_default_unplaced" data-label="意見" style="display:none; visibility: hidden">
        </div>

        <!-- 查詢 (Hot Spot) -->
        <div id="u14" class="ax_default ax_default_unplaced" data-label="查詢" style="display:none; visibility: hidden">
        </div>

        <!-- 問題 (Hot Spot) -->
        <div id="u15" class="ax_default ax_default_unplaced" data-label="問題" style="display:none; visibility: hidden">
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u17" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u18" class="ax_default placeholder">
          <img id="u18_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/u18.svg"/>
          <div id="u18_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u19" class="ax_default box_1">
          <div id="u19_div" class=""></div>
          <div id="u19_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u20" class="ax_default box_3">
          <div id="u20_div" class=""></div>
          <div id="u20_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u21" class="ax_default box_3">
          <div id="u21_div" class=""></div>
          <div id="u21_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u22" class="ax_default box_3">
          <div id="u22_div" class=""></div>
          <div id="u22_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u23" class="ax_default box_3">
          <div id="u23_div" class=""></div>
          <div id="u23_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u24" class="ax_default box_3">
          <div id="u24_div" class=""></div>
          <div id="u24_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u25" class="ax_default box_3">
          <div id="u25_div" class=""></div>
          <div id="u25_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u26" class="ax_default box_3">
          <div id="u26_div" class=""></div>
          <div id="u26_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u27" class="ax_default">
          <div id="u27_state0" class="panel_state" data-label="State 1" style="">
            <div id="u27_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u28" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u29" class="ax_default box_3">
                  <div id="u29_div" class=""></div>
                  <div id="u29_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u30" class="ax_default box_3">
                  <div id="u30_div" class=""></div>
                  <div id="u30_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u31" class="ax_default box_3">
                  <div id="u31_div" class=""></div>
                  <div id="u31_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u32" class="ax_default box_3">
                  <img id="u32_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/u32.svg"/>
                  <div id="u32_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u33" class="ax_default box_3">
                  <div id="u33_div" class=""></div>
                  <div id="u33_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u34" class="ax_default box_3">
                  <div id="u34_div" class=""></div>
                  <div id="u34_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u35" class="ax_default box_3">
                  <div id="u35_div" class=""></div>
                  <div id="u35_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u36" class="ax_default">
          <div id="u36_state0" class="panel_state" data-label="State 1" style="">
            <div id="u36_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u37" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u38" class="ax_default box_3">
                  <div id="u38_div" class=""></div>
                  <div id="u38_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u39" class="ax_default box_3">
                  <div id="u39_div" class=""></div>
                  <div id="u39_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u40" class="ax_default box_3">
                  <div id="u40_div" class=""></div>
                  <div id="u40_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u41" class="ax_default box_3">
                  <img id="u41_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/u41.svg"/>
                  <div id="u41_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u42" class="ax_default box_3">
                  <div id="u42_div" class=""></div>
                  <div id="u42_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u43" class="ax_default box_3">
                  <div id="u43_div" class=""></div>
                  <div id="u43_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u44" class="ax_default">
          <div id="u44_state0" class="panel_state" data-label="State 1" style="">
            <div id="u44_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u45" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u46" class="ax_default box_3">
                  <div id="u46_div" class=""></div>
                  <div id="u46_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u47" class="ax_default box_3">
                  <div id="u47_div" class=""></div>
                  <div id="u47_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u48" class="ax_default box_3">
                  <div id="u48_div" class=""></div>
                  <div id="u48_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u49" class="ax_default box_3">
                  <img id="u49_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/u49.svg"/>
                  <div id="u49_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u16" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u51" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u52" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u52_state0" class="panel_state" data-label="State 1" style="">
            <div id="u52_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u53" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u54" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u54_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u54_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u55" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u56" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u56_div" class=""></div>
                          <div id="u56_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u57" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u57_div" class=""></div>
                          <div id="u57_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u58" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u58_div" class=""></div>
                          <div id="u58_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u59" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u59_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                          <div id="u59_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u60" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u60_div" class=""></div>
                          <div id="u60_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u61" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u61_div" class=""></div>
                          <div id="u61_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u62" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u62_div" class=""></div>
                          <div id="u62_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u63" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u63_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                  <div id="u63_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u64" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u65" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u65_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u65_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u66" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u67" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u67_div" class=""></div>
                          <div id="u67_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u68" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u68_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                          <div id="u68_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u69" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u69_div" class=""></div>
                          <div id="u69_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u70" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u70_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                          <div id="u70_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u71" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u71_div" class=""></div>
                          <div id="u71_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u72" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u72_div" class=""></div>
                          <div id="u72_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u73" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u73_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                  <div id="u73_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u74" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u75" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u75_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u75_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u76" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u77" class="ax_default box_3">
                          <div id="u77_div" class=""></div>
                          <div id="u77_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u78" class="ax_default box_3">
                          <img id="u78_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/u78.svg"/>
                          <div id="u78_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u79" class="ax_default box_3">
                          <div id="u79_div" class=""></div>
                          <div id="u79_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u80" class="ax_default box_3">
                          <img id="u80_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/u80.svg"/>
                          <div id="u80_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u81" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u81_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                  <div id="u81_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u82" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u82_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                <div id="u82_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u83" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u83_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                <div id="u83_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u84" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u84_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                <div id="u84_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u85" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u85_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
                <div id="u85_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u86" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u86_img" class="img " src="/Moses football/public/frontend/assets/resources/images/transparent.gif"/>
          <div id="u86_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u87" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u87_div" class=""></div>
          <div id="u87_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u88" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u88_div" class=""></div>
          <div id="u88_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u50" style="display:none; visibility:hidden;"></div>

      <!-- Table (Dynamic Panel) -->
      <div id="u89" class="ax_default" data-label="Table">
        <div id="u89_state0" class="panel_state" data-label="Today" style="">
          <div id="u89_state0_content" class="panel_state_content">

            <!-- corner_table (Group) -->
            <div id="u90" class="ax_default" data-label="corner_table" data-left="0" data-top="0" data-width="913" data-height="662">

              <!-- corner_table_title (Group) -->
              <div id="u91" class="ax_default" data-label="corner_table_title" data-left="0" data-top="0" data-width="913" data-height="108">

                <!-- Unnamed (Rectangle) -->
                <div id="u92" class="ax_default box_1">
                  <div id="u92_div" class=""></div>
                  <div id="u92_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- h_corner (Rectangle) -->
                <div id="u93" class="ax_default box_1" data-label="h_corner">
                  <div id="u93_div" class=""></div>
                  <div id="u93_text" class="text ">
                    <p><span>主隊</span></p>
                  </div>
                </div>

                <!-- g_corner (Rectangle) -->
                <div id="u94" class="ax_default box_1" data-label="g_corner">
                  <div id="u94_div" class=""></div>
                  <div id="u94_text" class="text ">
                    <p><span>客隊</span></p>
                  </div>
                </div>

                <!-- t_corner (Rectangle) -->
                <div id="u95" class="ax_default box_1" data-label="t_corner">
                  <div id="u95_div" class=""></div>
                  <div id="u95_text" class="text ">
                    <p><span>總角球</span></p>
                  </div>
                </div>

                <!-- corner (Rectangle) -->
                <div id="u96" class="ax_default box_1" data-label="corner">
                  <div id="u96_div" class=""></div>
                  <div id="u96_text" class="text ">
                    <p><span>角球數</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table1 (Group) -->
              <div id="u97" class="ax_default" data-label="corner_value_table1" data-left="0" data-top="111" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u98" class="ax_default box_1" data-label="game_name">
                  <img id="u98_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u98_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u99" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u99_div" class=""></div>
                  <div id="u99_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u100" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u100_div" class=""></div>
                  <div id="u100_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u101" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u101_div" class=""></div>
                  <div id="u101_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table2 (Group) -->
              <div id="u102" class="ax_default" data-label="corner_value_table2" data-left="0" data-top="166" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u103" class="ax_default box_1" data-label="game_name">
                  <img id="u103_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u103_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u104" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u104_div" class=""></div>
                  <div id="u104_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u105" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u105_div" class=""></div>
                  <div id="u105_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u106" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u106_div" class=""></div>
                  <div id="u106_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table3 (Group) -->
              <div id="u107" class="ax_default" data-label="corner_value_table3" data-left="0" data-top="221" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u108" class="ax_default box_1" data-label="game_name">
                  <img id="u108_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u108_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u109" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u109_div" class=""></div>
                  <div id="u109_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u110" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u110_div" class=""></div>
                  <div id="u110_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u111" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u111_div" class=""></div>
                  <div id="u111_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table4 (Group) -->
              <div id="u112" class="ax_default" data-label="corner_value_table4" data-left="0" data-top="277" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u113" class="ax_default box_1" data-label="game_name">
                  <img id="u113_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u113_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u114" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u114_div" class=""></div>
                  <div id="u114_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u115" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u115_div" class=""></div>
                  <div id="u115_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u116" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u116_div" class=""></div>
                  <div id="u116_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table5 (Group) -->
              <div id="u117" class="ax_default" data-label="corner_value_table5" data-left="0" data-top="332" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u118" class="ax_default box_1" data-label="game_name">
                  <img id="u118_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u118_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u119" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u119_div" class=""></div>
                  <div id="u119_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u120" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u120_div" class=""></div>
                  <div id="u120_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u121" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u121_div" class=""></div>
                  <div id="u121_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table6 (Group) -->
              <div id="u122" class="ax_default" data-label="corner_value_table6" data-left="0" data-top="388" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u123" class="ax_default box_1" data-label="game_name">
                  <img id="u123_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u123_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u124" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u124_div" class=""></div>
                  <div id="u124_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u125" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u125_div" class=""></div>
                  <div id="u125_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u126" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u126_div" class=""></div>
                  <div id="u126_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table7 (Group) -->
              <div id="u127" class="ax_default" data-label="corner_value_table7" data-left="0" data-top="443" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u128" class="ax_default box_1" data-label="game_name">
                  <img id="u128_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u128_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u129" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u129_div" class=""></div>
                  <div id="u129_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u130" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u130_div" class=""></div>
                  <div id="u130_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u131" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u131_div" class=""></div>
                  <div id="u131_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table8 (Group) -->
              <div id="u132" class="ax_default" data-label="corner_value_table8" data-left="0" data-top="498" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u133" class="ax_default box_1" data-label="game_name">
                  <img id="u133_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u133_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u134" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u134_div" class=""></div>
                  <div id="u134_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u135" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u135_div" class=""></div>
                  <div id="u135_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u136" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u136_div" class=""></div>
                  <div id="u136_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table9 (Group) -->
              <div id="u137" class="ax_default" data-label="corner_value_table9" data-left="0" data-top="554" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u138" class="ax_default box_1" data-label="game_name">
                  <img id="u138_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u138_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u139" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u139_div" class=""></div>
                  <div id="u139_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u140" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u140_div" class=""></div>
                  <div id="u140_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u141" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u141_div" class=""></div>
                  <div id="u141_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_table10 (Group) -->
              <div id="u142" class="ax_default" data-label="corner_table10" data-left="0" data-top="609" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u143" class="ax_default box_1" data-label="game_name">
                  <img id="u143_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u143_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u144" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u144_div" class=""></div>
                  <div id="u144_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u145" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u145_div" class=""></div>
                  <div id="u145_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u146" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u146_div" class=""></div>
                  <div id="u146_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}0</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="u89_state1" class="panel_state" data-label="Tomorrow" style="visibility: hidden;">
          <div id="u89_state1_content" class="panel_state_content">

            <!-- corner_table (Group) -->
            <div id="u147" class="ax_default" data-label="corner_table" data-left="0" data-top="0" data-width="913" data-height="662">

              <!-- corner_table_title (Group) -->
              <div id="u148" class="ax_default" data-label="corner_table_title" data-left="0" data-top="0" data-width="913" data-height="108">

                <!-- Unnamed (Rectangle) -->
                <div id="u149" class="ax_default box_1">
                  <div id="u149_div" class=""></div>
                  <div id="u149_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- h_corner (Rectangle) -->
                <div id="u150" class="ax_default box_1" data-label="h_corner">
                  <div id="u150_div" class=""></div>
                  <div id="u150_text" class="text ">
                    <p><span>主隊</span></p>
                  </div>
                </div>

                <!-- g_corner (Rectangle) -->
                <div id="u151" class="ax_default box_1" data-label="g_corner">
                  <div id="u151_div" class=""></div>
                  <div id="u151_text" class="text ">
                    <p><span>客隊</span></p>
                  </div>
                </div>

                <!-- t_corner (Rectangle) -->
                <div id="u152" class="ax_default box_1" data-label="t_corner">
                  <div id="u152_div" class=""></div>
                  <div id="u152_text" class="text ">
                    <p><span>總角球</span></p>
                  </div>
                </div>

                <!-- corner (Rectangle) -->
                <div id="u153" class="ax_default box_1" data-label="corner">
                  <div id="u153_div" class=""></div>
                  <div id="u153_text" class="text ">
                    <p><span>角球數</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table1 (Group) -->
              <div id="u154" class="ax_default" data-label="corner_value_table1" data-left="0" data-top="111" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u155" class="ax_default box_1" data-label="game_name">
                  <img id="u155_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u155_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u156" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u156_div" class=""></div>
                  <div id="u156_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u157" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u157_div" class=""></div>
                  <div id="u157_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u158" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u158_div" class=""></div>
                  <div id="u158_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table2 (Group) -->
              <div id="u159" class="ax_default" data-label="corner_value_table2" data-left="0" data-top="166" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u160" class="ax_default box_1" data-label="game_name">
                  <img id="u160_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u160_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u161" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u161_div" class=""></div>
                  <div id="u161_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u162" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u162_div" class=""></div>
                  <div id="u162_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u163" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u163_div" class=""></div>
                  <div id="u163_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table3 (Group) -->
              <div id="u164" class="ax_default" data-label="corner_value_table3" data-left="0" data-top="221" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u165" class="ax_default box_1" data-label="game_name">
                  <img id="u165_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u165_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u166" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u166_div" class=""></div>
                  <div id="u166_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u167" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u167_div" class=""></div>
                  <div id="u167_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u168" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u168_div" class=""></div>
                  <div id="u168_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table4 (Group) -->
              <div id="u169" class="ax_default" data-label="corner_value_table4" data-left="0" data-top="277" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u170" class="ax_default box_1" data-label="game_name">
                  <img id="u170_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u170_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u171" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u171_div" class=""></div>
                  <div id="u171_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Shape) -->
                <div id="u172" class="ax_default box_1" data-label="value_g_corner">
                  <img id="u172_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/value_g_corner_u172.svg"/>
                  <div id="u172_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u173" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u173_div" class=""></div>
                  <div id="u173_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table5 (Group) -->
              <div id="u174" class="ax_default" data-label="corner_value_table5" data-left="0" data-top="332" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u175" class="ax_default box_1" data-label="game_name">
                  <img id="u175_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u175_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u176" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u176_div" class=""></div>
                  <div id="u176_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u177" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u177_div" class=""></div>
                  <div id="u177_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u178" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u178_div" class=""></div>
                  <div id="u178_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table6 (Group) -->
              <div id="u179" class="ax_default" data-label="corner_value_table6" data-left="0" data-top="388" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u180" class="ax_default box_1" data-label="game_name">
                  <img id="u180_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u180_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u181" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u181_div" class=""></div>
                  <div id="u181_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u182" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u182_div" class=""></div>
                  <div id="u182_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u183" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u183_div" class=""></div>
                  <div id="u183_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table7 (Group) -->
              <div id="u184" class="ax_default" data-label="corner_value_table7" data-left="0" data-top="443" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u185" class="ax_default box_1" data-label="game_name">
                  <img id="u185_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u185_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u186" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u186_div" class=""></div>
                  <div id="u186_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u187" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u187_div" class=""></div>
                  <div id="u187_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u188" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u188_div" class=""></div>
                  <div id="u188_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table8 (Group) -->
              <div id="u189" class="ax_default" data-label="corner_value_table8" data-left="0" data-top="498" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u190" class="ax_default box_1" data-label="game_name">
                  <img id="u190_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u190_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u191" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u191_div" class=""></div>
                  <div id="u191_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u192" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u192_div" class=""></div>
                  <div id="u192_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u193" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u193_div" class=""></div>
                  <div id="u193_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table9 (Group) -->
              <div id="u194" class="ax_default" data-label="corner_value_table9" data-left="0" data-top="554" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u195" class="ax_default box_1" data-label="game_name">
                  <img id="u195_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u195_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u196" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u196_div" class=""></div>
                  <div id="u196_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u197" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u197_div" class=""></div>
                  <div id="u197_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Shape) -->
                <div id="u198" class="ax_default box_1" data-label="value_t_corner">
                  <img id="u198_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/value_t_corner_u198.svg"/>
                  <div id="u198_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_table10 (Group) -->
              <div id="u199" class="ax_default" data-label="corner_table10" data-left="0" data-top="609" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u200" class="ax_default box_1" data-label="game_name">
                  <img id="u200_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u200_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u201" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u201_div" class=""></div>
                  <div id="u201_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u202" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u202_div" class=""></div>
                  <div id="u202_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u203" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u203_div" class=""></div>
                  <div id="u203_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}0</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="u89_state2" class="panel_state" data-label="After_tmr" style="visibility: hidden;">
          <div id="u89_state2_content" class="panel_state_content">

            <!-- corner_table (Group) -->
            <div id="u204" class="ax_default" data-label="corner_table" data-left="0" data-top="0" data-width="913" data-height="662">

              <!-- corner_table_title (Group) -->
              <div id="u205" class="ax_default" data-label="corner_table_title" data-left="0" data-top="0" data-width="913" data-height="108">

                <!-- Unnamed (Rectangle) -->
                <div id="u206" class="ax_default box_1">
                  <div id="u206_div" class=""></div>
                  <div id="u206_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- h_corner (Rectangle) -->
                <div id="u207" class="ax_default box_1" data-label="h_corner">
                  <div id="u207_div" class=""></div>
                  <div id="u207_text" class="text ">
                    <p><span>主隊</span></p>
                  </div>
                </div>

                <!-- g_corner (Rectangle) -->
                <div id="u208" class="ax_default box_1" data-label="g_corner">
                  <div id="u208_div" class=""></div>
                  <div id="u208_text" class="text ">
                    <p><span>客隊</span></p>
                  </div>
                </div>

                <!-- t_corner (Rectangle) -->
                <div id="u209" class="ax_default box_1" data-label="t_corner">
                  <div id="u209_div" class=""></div>
                  <div id="u209_text" class="text ">
                    <p><span>總角球</span></p>
                  </div>
                </div>

                <!-- corner (Rectangle) -->
                <div id="u210" class="ax_default box_1" data-label="corner">
                  <div id="u210_div" class=""></div>
                  <div id="u210_text" class="text ">
                    <p><span>角球數</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table1 (Group) -->
              <div id="u211" class="ax_default" data-label="corner_value_table1" data-left="0" data-top="111" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u212" class="ax_default box_1" data-label="game_name">
                  <img id="u212_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u212_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u213" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u213_div" class=""></div>
                  <div id="u213_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u214" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u214_div" class=""></div>
                  <div id="u214_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u215" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u215_div" class=""></div>
                  <div id="u215_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table2 (Group) -->
              <div id="u216" class="ax_default" data-label="corner_value_table2" data-left="0" data-top="166" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u217" class="ax_default box_1" data-label="game_name">
                  <img id="u217_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u217_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u218" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u218_div" class=""></div>
                  <div id="u218_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u219" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u219_div" class=""></div>
                  <div id="u219_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u220" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u220_div" class=""></div>
                  <div id="u220_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table3 (Group) -->
              <div id="u221" class="ax_default" data-label="corner_value_table3" data-left="0" data-top="221" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u222" class="ax_default box_1" data-label="game_name">
                  <img id="u222_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u222_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u223" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u223_div" class=""></div>
                  <div id="u223_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u224" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u224_div" class=""></div>
                  <div id="u224_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u225" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u225_div" class=""></div>
                  <div id="u225_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table4 (Group) -->
              <div id="u226" class="ax_default" data-label="corner_value_table4" data-left="0" data-top="277" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u227" class="ax_default box_1" data-label="game_name">
                  <img id="u227_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u227_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u228" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u228_div" class=""></div>
                  <div id="u228_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u229" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u229_div" class=""></div>
                  <div id="u229_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u230" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u230_div" class=""></div>
                  <div id="u230_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table5 (Group) -->
              <div id="u231" class="ax_default" data-label="corner_value_table5" data-left="0" data-top="332" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u232" class="ax_default box_1" data-label="game_name">
                  <img id="u232_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u232_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u233" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u233_div" class=""></div>
                  <div id="u233_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u234" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u234_div" class=""></div>
                  <div id="u234_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u235" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u235_div" class=""></div>
                  <div id="u235_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table6 (Group) -->
              <div id="u236" class="ax_default" data-label="corner_value_table6" data-left="0" data-top="388" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u237" class="ax_default box_1" data-label="game_name">
                  <img id="u237_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u237_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u238" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u238_div" class=""></div>
                  <div id="u238_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u239" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u239_div" class=""></div>
                  <div id="u239_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u240" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u240_div" class=""></div>
                  <div id="u240_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table7 (Group) -->
              <div id="u241" class="ax_default" data-label="corner_value_table7" data-left="0" data-top="443" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u242" class="ax_default box_1" data-label="game_name">
                  <img id="u242_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u98.svg"/>
                  <div id="u242_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u243" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u243_div" class=""></div>
                  <div id="u243_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u244" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u244_div" class=""></div>
                  <div id="u244_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u245" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u245_div" class=""></div>
                  <div id="u245_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table8 (Group) -->
              <div id="u246" class="ax_default" data-label="corner_value_table8" data-left="0" data-top="498" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u247" class="ax_default box_1" data-label="game_name">
                  <img id="u247_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u247_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u248" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u248_div" class=""></div>
                  <div id="u248_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u249" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u249_div" class=""></div>
                  <div id="u249_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u250" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u250_div" class=""></div>
                  <div id="u250_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_value_table9 (Group) -->
              <div id="u251" class="ax_default" data-label="corner_value_table9" data-left="0" data-top="554" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u252" class="ax_default box_1" data-label="game_name">
                  <img id="u252_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u252_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u253" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u253_div" class=""></div>
                  <div id="u253_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u254" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u254_div" class=""></div>
                  <div id="u254_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u255" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u255_div" class=""></div>
                  <div id="u255_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}</span></p>
                  </div>
                </div>
              </div>

              <!-- corner_table10 (Group) -->
              <div id="u256" class="ax_default" data-label="corner_table10" data-left="0" data-top="609" data-width="913" data-height="53">

                <!-- game_name (Shape) -->
                <div id="u257" class="ax_default box_1" data-label="game_name">
                  <img id="u257_img" class="img " src="/Moses football/public/frontend/assets/images/page_a5/game_name_u108.svg"/>
                  <div id="u257_text" class="text ">
                    <p><span>1</span></p>
                  </div>
                </div>

                <!-- value_h_corner (Rectangle) -->
                <div id="u258" class="ax_default box_1" data-label="value_h_corner">
                  <div id="u258_div" class=""></div>
                  <div id="u258_text" class="text ">
                    <p><span>{{ $a5s->h_corner }}</span></p>
                  </div>
                </div>

                <!-- value_g_corner (Rectangle) -->
                <div id="u259" class="ax_default box_1" data-label="value_g_corner">
                  <div id="u259_div" class=""></div>
                  <div id="u259_text" class="text ">
                    <p><span>{{ $a5s->g_corner }}</span></p>
                  </div>
                </div>

                <!-- value_t_corner (Rectangle) -->
                <div id="u260" class="ax_default box_1" data-label="value_t_corner">
                  <div id="u260_div" class=""></div>
                  <div id="u260_text" class="text ">
                    <p><span>{{ $a5s->total_corner }}0</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Date (Group) -->
      <div id="u261" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="28">

        <!-- After_tomorrow (Rectangle) -->
        <div id="u262" class="ax_default label" data-label="After_tomorrow">
          <div id="u262_div" class=""></div>
          <div id="u262_text" class="text ">
            <p><span>後日</span></p>
          </div>
        </div>

        <!-- Tomorrow (Rectangle) -->
        <div id="u263" class="ax_default label" data-label="Tomorrow">
          <div id="u263_div" class=""></div>
          <div id="u263_text" class="text ">
            <p><span>明日</span></p>
          </div>
        </div>

        <!-- Today (Rectangle) -->
        <div id="u264" class="ax_default label" data-label="Today">
          <div id="u264_div" class=""></div>
          <div id="u264_text" class="text ">
            <p><span>今日</span></p>
          </div>
        </div>

        <!-- Match_date (Rectangle) -->
        <div id="u265" class="ax_default label" data-label="Match_date">
          <div id="u265_div" class=""></div>
          <div id="u265_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;Lucida Grande &quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div>
      </div>
    </div>
    <script src="/Moses football/public/frontend/assets/resources/scripts/axure/ios.js"></script>
  </body>
</html>
