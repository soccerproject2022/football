﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A3</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/page_a3/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/page_a3/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- NAVIGATION BAR (Group) -->
      <div id="u533" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1364" data-height="210">

        <!-- Unnamed (Placeholder) -->
        <div id="u534" class="ax_default placeholder">
          <img id="u534_img" class="img " src="images/page_a3/u534.svg"/>
          <div id="u534_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u535" class="ax_default box_1">
          <div id="u535_div" class=""></div>
          <div id="u535_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u536" class="ax_default box_3">
          <div id="u536_div" class=""></div>
          <div id="u536_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u537" class="ax_default box_3">
          <div id="u537_div" class=""></div>
          <div id="u537_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u538" class="ax_default box_3">
          <div id="u538_div" class=""></div>
          <div id="u538_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u539" class="ax_default box_3">
          <div id="u539_div" class=""></div>
          <div id="u539_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u540" class="ax_default box_3">
          <div id="u540_div" class=""></div>
          <div id="u540_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u541" class="ax_default box_3">
          <div id="u541_div" class=""></div>
          <div id="u541_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u542" class="ax_default box_3">
          <div id="u542_div" class=""></div>
          <div id="u542_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u543" class="ax_default">
          <div id="u543_state0" class="panel_state" data-label="State 1" style="">
            <div id="u543_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u544" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u545" class="ax_default box_3">
                  <div id="u545_div" class=""></div>
                  <div id="u545_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u546" class="ax_default box_3">
                  <div id="u546_div" class=""></div>
                  <div id="u546_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u547" class="ax_default box_3">
                  <div id="u547_div" class=""></div>
                  <div id="u547_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u548" class="ax_default box_3">
                  <img id="u548_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u548_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u549" class="ax_default box_3">
                  <div id="u549_div" class=""></div>
                  <div id="u549_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u550" class="ax_default box_3">
                  <div id="u550_div" class=""></div>
                  <div id="u550_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u551" class="ax_default box_3">
                  <div id="u551_div" class=""></div>
                  <div id="u551_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u552" class="ax_default">
          <div id="u552_state0" class="panel_state" data-label="State 1" style="">
            <div id="u552_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u553" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="121" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u554" class="ax_default box_3">
                  <div id="u554_div" class=""></div>
                  <div id="u554_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u555" class="ax_default box_3">
                  <div id="u555_div" class=""></div>
                  <div id="u555_text" class="text ">
                    <p><span>AI模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u556" class="ax_default box_3">
                  <div id="u556_div" class=""></div>
                  <div id="u556_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u557" class="ax_default box_3">
                  <img id="u557_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u557_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u558" class="ax_default box_3">
                  <div id="u558_div" class=""></div>
                  <div id="u558_text" class="text ">
                    <p><span>AI模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u559" class="ax_default box_3">
                  <div id="u559_div" class=""></div>
                  <div id="u559_text" class="text ">
                    <p><span>AI模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u560" class="ax_default">
          <div id="u560_state0" class="panel_state" data-label="State 1" style="">
            <div id="u560_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u561" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="135" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u562" class="ax_default box_3">
                  <div id="u562_div" class=""></div>
                  <div id="u562_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u563" class="ax_default box_3">
                  <div id="u563_div" class=""></div>
                  <div id="u563_text" class="text ">
                    <p><span>&nbsp;Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u564" class="ax_default box_3">
                  <div id="u564_div" class=""></div>
                  <div id="u564_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u565" class="ax_default box_3">
                  <img id="u565_img" class="img " src="images/page_a4/u195.svg"/>
                  <div id="u565_text" class="text ">
                    <p><span>AI模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u566" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u566_state0" class="panel_state" data-label="State 1" style="">
          <div id="u566_state0_content" class="panel_state_content">

            <!-- 1ST SUB (Group) -->
            <div id="u567" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u568" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u568_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u568_state0_content" class="panel_state_content">

                    <!-- HOME_SUBMENU (Group) -->
                    <div id="u569" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u570" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u570_div" class=""></div>
                        <div id="u570_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u571" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u571_div" class=""></div>
                        <div id="u571_text" class="text ">
                          <p><span>&nbsp;簡介</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u572" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u572_div" class=""></div>
                        <div id="u572_text" class="text ">
                          <p><span>&nbsp;如何應用</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u573" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u573_img" class="img " src="resources/images/transparent.gif"/>
                        <div id="u573_text" class="text ">
                          <p><span>&nbsp; 為何我們</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u574" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u574_div" class=""></div>
                        <div id="u574_text" class="text ">
                          <p><span>&nbsp; 馬上註冊</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u575" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u575_div" class=""></div>
                        <div id="u575_text" class="text ">
                          <p><span>&nbsp; 用戶推薦</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u576" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u576_div" class=""></div>
                        <div id="u576_text" class="text ">
                          <p><span>&nbsp; 風險披露</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u577" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u577_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u577_text" class="text ">
                  <p><span>首頁</span></p>
                </div>
              </div>
            </div>

            <!-- 2ND SUB (Group) -->
            <div id="u578" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u579" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u579_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u579_text" class="text ">
                  <p><span>足球AI模組分析</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u580" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u580_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u580_state0_content" class="panel_state_content">

                    <!-- AI_SUBMENU (Group) -->
                    <div id="u581" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u582" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u582_div" class=""></div>
                        <div id="u582_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u583" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u583_img" class="img " src="resources/images/transparent.gif"/>
                        <div id="u583_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u584" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u584_div" class=""></div>
                        <div id="u584_text" class="text ">
                          <p><span>&nbsp;綜合網民數據結果</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u585" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u585_img" class="img " src="resources/images/transparent.gif"/>
                        <div id="u585_text" class="text ">
                          <p><span>&nbsp;值博率模組分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u586" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u586_div" class=""></div>
                        <div id="u586_text" class="text ">
                          <p><span>&nbsp; AI模組波膽分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u587" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u587_div" class=""></div>
                        <div id="u587_text" class="text ">
                          <p><span>&nbsp;AI模組分析大小角</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 3RD SUB (Group) -->
            <div id="u588" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u589" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u589_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u589_text" class="text ">
                  <p><span>Futra是日精選</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u590" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u590_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u590_state0_content" class="panel_state_content">

                    <!-- FUTRA_SUBMENU (Group) -->
                    <div id="u591" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u592" class="ax_default box_3">
                        <div id="u592_div" class=""></div>
                        <div id="u592_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u593" class="ax_default box_3">
                        <img id="u593_img" class="img " src="images/page_a4/u28.svg"/>
                        <div id="u593_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u594" class="ax_default box_3">
                        <div id="u594_div" class=""></div>
                        <div id="u594_text" class="text ">
                          <p><span>爆冷精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u595" class="ax_default box_3">
                        <img id="u595_img" class="img " src="images/page_a4/u30.svg"/>
                        <div id="u595_text" class="text ">
                          <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u596" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u596_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u596_text" class="text ">
                <p><span>為何我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u597" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u597_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u597_text" class="text ">
                <p><span>聯絡我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u598" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u598_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u598_text" class="text ">
                <p><span>會員中心</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u599" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u599_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u599_text" class="text ">
                <p><span>登入</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Top Menu_M (Group) -->
      <div id="u600" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Placeholder) -->
        <div id="u601" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u601_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u601_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u602" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u602_div" class=""></div>
          <div id="u602_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u603" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u603_div" class=""></div>
          <div id="u603_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u604" class="ax_default box_2">
        <div id="u604_div" class=""></div>
        <div id="u604_text" class="text ">
          <p><span>值博率模組分析</span></p>
        </div>
      </div>

      <!-- Unnamed (Group) -->
      <div id="u605" class="ax_default" data-left="281" data-top="162" data-width="870" data-height="202">

        <!-- Unnamed (Repeater) -->
        <div id="u606" class="ax_default">
          <script id="u606_script" type="axure-repeater-template">

            <!-- Unnamed (Group) -->
            <div id="u607" class="ax_default u607" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u608" class="ax_default box_1 u608">
                <img id="u608_img" class="img u608_img" src="images/page_a3/u608.svg"/>
                <div id="u608_text" class="text u608_text">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u609" class="ax_default box_1 u609">
                <div id="u609_div" class="u609_div"></div>
                <div id="u609_text" class="text u609_text">
                  <p><span>30%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u610" class="ax_default box_1 u610">
                <div id="u610_div" class="u610_div"></div>
                <div id="u610_text" class="text u610_text">
                  <p><span>11%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u611" class="ax_default box_1 u611">
                <div id="u611_div" class="u611_div"></div>
                <div id="u611_text" class="text u611_text">
                  <p><span>59%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u612" class="ax_default box_1 u612">
                <div id="u612_div" class="u612_div"></div>
                <div id="u612_text" class="text u612_text">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u613" class="ax_default box_1 u613">
                <img id="u613_img" class="img u613_img" src="images/page_a3/u613.svg"/>
                <div id="u613_text" class="text u613_text">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u614" class="ax_default box_1 u614">
                <div id="u614_div" class="u614_div"></div>
                <div id="u614_text" class="text u614_text">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u615" class="ax_default box_1 u615">
                <div id="u615_div" class="u615_div"></div>
                <div id="u615_text" class="text u615_text">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u616" class="ax_default box_1 u616">
                <div id="u616_div" class="u616_div"></div>
                <div id="u616_text" class="text u616_text">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u617" class="ax_default box_1 u617">
                <div id="u617_div" class="u617_div"></div>
                <div id="u617_text" class="text u617_text">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </script>
          <div id="u606-1" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u607-1" class="ax_default u607" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u608-1" class="ax_default box_1 u608" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u608-1_img" class="img u608_img" src="images/page_a3/u608.svg"/>
                <div id="u608-1_text" class="text u608_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u609-1" class="ax_default box_1 u609" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u609-1_div" class="u609_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u609-1_text" class="text u609_text" style="visibility: inherit">
                  <p><span>30%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u610-1" class="ax_default box_1 u610" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u610-1_div" class="u610_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u610-1_text" class="text u610_text" style="visibility: inherit">
                  <p><span>11%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u611-1" class="ax_default box_1 u611" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u611-1_div" class="u611_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u611-1_text" class="text u611_text" style="visibility: inherit">
                  <p><span>59%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u612-1" class="ax_default box_1 u612" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u612-1_div" class="u612_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u612-1_text" class="text u612_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u613-1" class="ax_default box_1 u613" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u613-1_img" class="img u613_img" src="images/page_a3/u613.svg"/>
                <div id="u613-1_text" class="text u613_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u614-1" class="ax_default box_1 u614" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u614-1_div" class="u614_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u614-1_text" class="text u614_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u615-1" class="ax_default box_1 u615" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u615-1_div" class="u615_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u615-1_text" class="text u615_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u616-1" class="ax_default box_1 u616" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u616-1_div" class="u616_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u616-1_text" class="text u616_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u617-1" class="ax_default box_1 u617" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u617-1_div" class="u617_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u617-1_text" class="text u617_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u606-2" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u607-2" class="ax_default u607" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u608-2" class="ax_default box_1 u608" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u608-2_img" class="img u608_img" src="images/page_a3/u608.svg"/>
                <div id="u608-2_text" class="text u608_text" style="visibility: inherit">
                  <p><span>PFC索契 VS&nbsp; 羅斯托夫</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u609-2" class="ax_default box_1 u609" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u609-2_div" class="u609_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u609-2_text" class="text u609_text" style="visibility: inherit">
                  <p><span>30%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u610-2" class="ax_default box_1 u610" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u610-2_div" class="u610_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u610-2_text" class="text u610_text" style="visibility: inherit">
                  <p><span>11%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u611-2" class="ax_default box_1 u611" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u611-2_div" class="u611_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u611-2_text" class="text u611_text" style="visibility: inherit">
                  <p><span>59%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u612-2" class="ax_default box_1 u612" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u612-2_div" class="u612_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u612-2_text" class="text u612_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u613-2" class="ax_default box_1 u613" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u613-2_img" class="img u613_img" src="images/page_a3/u613.svg"/>
                <div id="u613-2_text" class="text u613_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u614-2" class="ax_default box_1 u614" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u614-2_div" class="u614_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u614-2_text" class="text u614_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u615-2" class="ax_default box_1 u615" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u615-2_div" class="u615_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u615-2_text" class="text u615_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u616-2" class="ax_default box_1 u616" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u616-2_div" class="u616_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u616-2_text" class="text u616_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u617-2" class="ax_default box_1 u617" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u617-2_div" class="u617_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u617-2_text" class="text u617_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u606-3" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u607-3" class="ax_default u607" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u608-3" class="ax_default box_1 u608" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u608-3_img" class="img u608_img" src="images/page_a3/u608.svg"/>
                <div id="u608-3_text" class="text u608_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; 羅斯托夫</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u609-3" class="ax_default box_1 u609" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u609-3_div" class="u609_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u609-3_text" class="text u609_text" style="visibility: inherit">
                  <p><span>30%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u610-3" class="ax_default box_1 u610" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u610-3_div" class="u610_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u610-3_text" class="text u610_text" style="visibility: inherit">
                  <p><span>11%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u611-3" class="ax_default box_1 u611" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u611-3_div" class="u611_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u611-3_text" class="text u611_text" style="visibility: inherit">
                  <p><span>59%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u612-3" class="ax_default box_1 u612" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u612-3_div" class="u612_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u612-3_text" class="text u612_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u613-3" class="ax_default box_1 u613" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u613-3_img" class="img u613_img" src="images/page_a3/u613.svg"/>
                <div id="u613-3_text" class="text u613_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u614-3" class="ax_default box_1 u614" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u614-3_div" class="u614_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u614-3_text" class="text u614_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u615-3" class="ax_default box_1 u615" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u615-3_div" class="u615_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u615-3_text" class="text u615_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u616-3" class="ax_default box_1 u616" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u616-3_div" class="u616_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u616-3_text" class="text u616_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u617-3" class="ax_default box_1 u617" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u617-3_div" class="u617_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u617-3_text" class="text u617_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u606-4" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u607-4" class="ax_default u607" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u608-4" class="ax_default box_1 u608" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u608-4_img" class="img u608_img" src="images/page_a3/u608.svg"/>
                <div id="u608-4_text" class="text u608_text" style="visibility: inherit">
                  <p><span>PFC索契 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u609-4" class="ax_default box_1 u609" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u609-4_div" class="u609_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u609-4_text" class="text u609_text" style="visibility: inherit">
                  <p><span>30%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u610-4" class="ax_default box_1 u610" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u610-4_div" class="u610_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u610-4_text" class="text u610_text" style="visibility: inherit">
                  <p><span>11%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u611-4" class="ax_default box_1 u611" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u611-4_div" class="u611_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u611-4_text" class="text u611_text" style="visibility: inherit">
                  <p><span>59%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u612-4" class="ax_default box_1 u612" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u612-4_div" class="u612_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u612-4_text" class="text u612_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u613-4" class="ax_default box_1 u613" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u613-4_img" class="img u613_img" src="images/page_a3/u613.svg"/>
                <div id="u613-4_text" class="text u613_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u614-4" class="ax_default box_1 u614" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u614-4_div" class="u614_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u614-4_text" class="text u614_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u615-4" class="ax_default box_1 u615" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u615-4_div" class="u615_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u615-4_text" class="text u615_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u616-4" class="ax_default box_1 u616" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u616-4_div" class="u616_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u616-4_text" class="text u616_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u617-4" class="ax_default box_1 u617" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u617-4_div" class="u617_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u617-4_text" class="text u617_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u606-5" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u607-5" class="ax_default u607" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u608-5" class="ax_default box_1 u608" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u608-5_img" class="img u608_img" src="images/page_a3/u608.svg"/>
                <div id="u608-5_text" class="text u608_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u609-5" class="ax_default box_1 u609" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u609-5_div" class="u609_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u609-5_text" class="text u609_text" style="visibility: inherit">
                  <p><span>30%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u610-5" class="ax_default box_1 u610" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u610-5_div" class="u610_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u610-5_text" class="text u610_text" style="visibility: inherit">
                  <p><span>11%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u611-5" class="ax_default box_1 u611" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u611-5_div" class="u611_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u611-5_text" class="text u611_text" style="visibility: inherit">
                  <p><span>59%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u612-5" class="ax_default box_1 u612" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u612-5_div" class="u612_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u612-5_text" class="text u612_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u613-5" class="ax_default box_1 u613" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u613-5_img" class="img u613_img" src="images/page_a3/u613.svg"/>
                <div id="u613-5_text" class="text u613_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u614-5" class="ax_default box_1 u614" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u614-5_div" class="u614_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u614-5_text" class="text u614_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u615-5" class="ax_default box_1 u615" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u615-5_div" class="u615_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u615-5_text" class="text u615_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u616-5" class="ax_default box_1 u616" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u616-5_div" class="u616_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u616-5_text" class="text u616_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u617-5" class="ax_default box_1 u617" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u617-5_div" class="u617_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u617-5_text" class="text u617_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u618" class="ax_default box_1">
          <div id="u618_div" class=""></div>
          <div id="u618_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u619" class="ax_default box_1">
          <div id="u619_div" class=""></div>
          <div id="u619_text" class="text ">
            <p><span>主隊勝率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u620" class="ax_default box_1">
          <div id="u620_div" class=""></div>
          <div id="u620_text" class="text ">
            <p><span>和波機率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u621" class="ax_default box_1">
          <div id="u621_div" class=""></div>
          <div id="u621_text" class="text ">
            <p><span>客隊勝率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u622" class="ax_default box_1">
          <div id="u622_div" class=""></div>
          <div id="u622_text" class="text ">
            <p><span>勝率</span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u623" class="ax_default box_1">
        <div id="u623_div" class=""></div>
        <div id="u623_text" class="text ">
          <p><span>主勝回報率</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u624" class="ax_default box_1">
        <div id="u624_div" class=""></div>
        <div id="u624_text" class="text ">
          <p><span>和波回報率</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u625" class="ax_default box_1">
        <div id="u625_div" class=""></div>
        <div id="u625_text" class="text ">
          <p><span>客勝回報率</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u626" class="ax_default box_1">
        <div id="u626_div" class=""></div>
        <div id="u626_text" class="text ">
          <p><span>主勝值博率</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u627" class="ax_default box_1">
        <div id="u627_div" class=""></div>
        <div id="u627_text" class="text ">
          <p><span>和波值博率</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u628" class="ax_default box_1">
        <div id="u628_div" class=""></div>
        <div id="u628_text" class="text ">
          <p><span>客勝值博率</span></p>
        </div>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u629" class="ax_default box_1">
        <img id="u629_img" class="img " src="images/page_a3/u629.svg"/>
        <div id="u629_text" class="text ">
          <p><span>回報率</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u630" class="ax_default box_1">
        <div id="u630_div" class=""></div>
        <div id="u630_text" class="text ">
          <p><span>值博率</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u631" class="ax_default image">
        <img id="u631_img" class="img " src="images/page_a3/u631.png"/>
        <div id="u631_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Group) -->
      <div id="u632" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Repeater) -->
        <div id="u633" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <script id="u633_script" type="axure-repeater-template">

            <!-- Unnamed (Group) -->
            <div id="u634" class="ax_default u634" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u635" class="ax_default box_1 u635">
                <img id="u635_img" class="img u635_img" src="images/page_a3/u608.svg"/>
                <div id="u635_text" class="text u635_text">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u636" class="ax_default box_1 u636">
                <div id="u636_div" class="u636_div"></div>
                <div id="u636_text" class="text u636_text">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u637" class="ax_default box_1 u637">
                <div id="u637_div" class="u637_div"></div>
                <div id="u637_text" class="text u637_text">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u638" class="ax_default box_1 u638">
                <div id="u638_div" class="u638_div"></div>
                <div id="u638_text" class="text u638_text">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u639" class="ax_default box_1 u639">
                <div id="u639_div" class="u639_div"></div>
                <div id="u639_text" class="text u639_text">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u640" class="ax_default box_1 u640">
                <img id="u640_img" class="img u640_img" src="images/page_a3/u613.svg"/>
                <div id="u640_text" class="text u640_text">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u641" class="ax_default box_1 u641">
                <div id="u641_div" class="u641_div"></div>
                <div id="u641_text" class="text u641_text">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u642" class="ax_default box_1 u642">
                <div id="u642_div" class="u642_div"></div>
                <div id="u642_text" class="text u642_text">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u643" class="ax_default box_1 u643">
                <div id="u643_div" class="u643_div"></div>
                <div id="u643_text" class="text u643_text">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u644" class="ax_default box_1 u644">
                <div id="u644_div" class="u644_div"></div>
                <div id="u644_text" class="text u644_text">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </script>
          <div id="u633-1" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u634-1" class="ax_default u634" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u635-1" class="ax_default box_1 u635" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u635-1_img" class="img u635_img" src="images/page_a3/u608.svg"/>
                <div id="u635-1_text" class="text u635_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u636-1" class="ax_default box_1 u636" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u636-1_div" class="u636_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u636-1_text" class="text u636_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u637-1" class="ax_default box_1 u637" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u637-1_div" class="u637_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u637-1_text" class="text u637_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u638-1" class="ax_default box_1 u638" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u638-1_div" class="u638_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u638-1_text" class="text u638_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u639-1" class="ax_default box_1 u639" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u639-1_div" class="u639_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u639-1_text" class="text u639_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u640-1" class="ax_default box_1 u640" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u640-1_img" class="img u640_img" src="images/page_a3/u613.svg"/>
                <div id="u640-1_text" class="text u640_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u641-1" class="ax_default box_1 u641" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u641-1_div" class="u641_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u641-1_text" class="text u641_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u642-1" class="ax_default box_1 u642" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u642-1_div" class="u642_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u642-1_text" class="text u642_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u643-1" class="ax_default box_1 u643" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u643-1_div" class="u643_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u643-1_text" class="text u643_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u644-1" class="ax_default box_1 u644" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u644-1_div" class="u644_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u644-1_text" class="text u644_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u633-2" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u634-2" class="ax_default u634" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u635-2" class="ax_default box_1 u635" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u635-2_img" class="img u635_img" src="images/page_a3/u608.svg"/>
                <div id="u635-2_text" class="text u635_text" style="visibility: inherit">
                  <p><span>PFC索契 VS&nbsp; 羅斯托夫</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u636-2" class="ax_default box_1 u636" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u636-2_div" class="u636_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u636-2_text" class="text u636_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u637-2" class="ax_default box_1 u637" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u637-2_div" class="u637_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u637-2_text" class="text u637_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u638-2" class="ax_default box_1 u638" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u638-2_div" class="u638_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u638-2_text" class="text u638_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u639-2" class="ax_default box_1 u639" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u639-2_div" class="u639_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u639-2_text" class="text u639_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u640-2" class="ax_default box_1 u640" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u640-2_img" class="img u640_img" src="images/page_a3/u613.svg"/>
                <div id="u640-2_text" class="text u640_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u641-2" class="ax_default box_1 u641" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u641-2_div" class="u641_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u641-2_text" class="text u641_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u642-2" class="ax_default box_1 u642" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u642-2_div" class="u642_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u642-2_text" class="text u642_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u643-2" class="ax_default box_1 u643" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u643-2_div" class="u643_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u643-2_text" class="text u643_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u644-2" class="ax_default box_1 u644" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u644-2_div" class="u644_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u644-2_text" class="text u644_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u633-3" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u634-3" class="ax_default u634" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u635-3" class="ax_default box_1 u635" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u635-3_img" class="img u635_img" src="images/page_a3/u608.svg"/>
                <div id="u635-3_text" class="text u635_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; 羅斯托夫</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u636-3" class="ax_default box_1 u636" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u636-3_div" class="u636_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u636-3_text" class="text u636_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u637-3" class="ax_default box_1 u637" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u637-3_div" class="u637_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u637-3_text" class="text u637_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u638-3" class="ax_default box_1 u638" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u638-3_div" class="u638_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u638-3_text" class="text u638_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u639-3" class="ax_default box_1 u639" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u639-3_div" class="u639_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u639-3_text" class="text u639_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u640-3" class="ax_default box_1 u640" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u640-3_img" class="img u640_img" src="images/page_a3/u613.svg"/>
                <div id="u640-3_text" class="text u640_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u641-3" class="ax_default box_1 u641" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u641-3_div" class="u641_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u641-3_text" class="text u641_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u642-3" class="ax_default box_1 u642" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u642-3_div" class="u642_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u642-3_text" class="text u642_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u643-3" class="ax_default box_1 u643" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u643-3_div" class="u643_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u643-3_text" class="text u643_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u644-3" class="ax_default box_1 u644" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u644-3_div" class="u644_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u644-3_text" class="text u644_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u633-4" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u634-4" class="ax_default u634" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u635-4" class="ax_default box_1 u635" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u635-4_img" class="img u635_img" src="images/page_a3/u608.svg"/>
                <div id="u635-4_text" class="text u635_text" style="visibility: inherit">
                  <p><span>PFC索契 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u636-4" class="ax_default box_1 u636" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u636-4_div" class="u636_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u636-4_text" class="text u636_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u637-4" class="ax_default box_1 u637" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u637-4_div" class="u637_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u637-4_text" class="text u637_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u638-4" class="ax_default box_1 u638" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u638-4_div" class="u638_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u638-4_text" class="text u638_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u639-4" class="ax_default box_1 u639" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u639-4_div" class="u639_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u639-4_text" class="text u639_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u640-4" class="ax_default box_1 u640" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u640-4_img" class="img u640_img" src="images/page_a3/u613.svg"/>
                <div id="u640-4_text" class="text u640_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u641-4" class="ax_default box_1 u641" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u641-4_div" class="u641_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u641-4_text" class="text u641_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u642-4" class="ax_default box_1 u642" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u642-4_div" class="u642_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u642-4_text" class="text u642_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u643-4" class="ax_default box_1 u643" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u643-4_div" class="u643_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u643-4_text" class="text u643_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u644-4" class="ax_default box_1 u644" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u644-4_div" class="u644_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u644-4_text" class="text u644_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u633-5" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u634-5" class="ax_default u634" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u635-5" class="ax_default box_1 u635" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u635-5_img" class="img u635_img" src="images/page_a3/u608.svg"/>
                <div id="u635-5_text" class="text u635_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u636-5" class="ax_default box_1 u636" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u636-5_div" class="u636_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u636-5_text" class="text u636_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u637-5" class="ax_default box_1 u637" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u637-5_div" class="u637_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u637-5_text" class="text u637_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u638-5" class="ax_default box_1 u638" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u638-5_div" class="u638_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u638-5_text" class="text u638_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u639-5" class="ax_default box_1 u639" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u639-5_div" class="u639_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u639-5_text" class="text u639_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u640-5" class="ax_default box_1 u640" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u640-5_img" class="img u640_img" src="images/page_a3/u613.svg"/>
                <div id="u640-5_text" class="text u640_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u641-5" class="ax_default box_1 u641" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u641-5_div" class="u641_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u641-5_text" class="text u641_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u642-5" class="ax_default box_1 u642" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u642-5_div" class="u642_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u642-5_text" class="text u642_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u643-5" class="ax_default box_1 u643" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u643-5_div" class="u643_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u643-5_text" class="text u643_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u644-5" class="ax_default box_1 u644" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u644-5_div" class="u644_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u644-5_text" class="text u644_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u645" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u645_div" class=""></div>
          <div id="u645_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u646" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u646_div" class=""></div>
          <div id="u646_text" class="text ">
            <p><span>主勝回報率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u647" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u647_div" class=""></div>
          <div id="u647_text" class="text ">
            <p><span>和波回報率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u648" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u648_div" class=""></div>
          <div id="u648_text" class="text ">
            <p><span>客勝回報率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u649" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u649_div" class=""></div>
          <div id="u649_text" class="text ">
            <p><span>回報率</span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Group) -->
      <div id="u650" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Repeater) -->
        <div id="u651" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <script id="u651_script" type="axure-repeater-template">

            <!-- Unnamed (Group) -->
            <div id="u652" class="ax_default u652" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u653" class="ax_default box_1 u653">
                <img id="u653_img" class="img u653_img" src="images/page_a3/u608.svg"/>
                <div id="u653_text" class="text u653_text">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u654" class="ax_default box_1 u654">
                <div id="u654_div" class="u654_div"></div>
                <div id="u654_text" class="text u654_text">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u655" class="ax_default box_1 u655">
                <div id="u655_div" class="u655_div"></div>
                <div id="u655_text" class="text u655_text">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u656" class="ax_default box_1 u656">
                <div id="u656_div" class="u656_div"></div>
                <div id="u656_text" class="text u656_text">
                  <p><span>0.77</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u657" class="ax_default box_1 u657">
                <div id="u657_div" class="u657_div"></div>
                <div id="u657_text" class="text u657_text">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u658" class="ax_default box_1 u658">
                <img id="u658_img" class="img u658_img" src="images/page_a3/u613.svg"/>
                <div id="u658_text" class="text u658_text">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u659" class="ax_default box_1 u659">
                <div id="u659_div" class="u659_div"></div>
                <div id="u659_text" class="text u659_text">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u660" class="ax_default box_1 u660">
                <div id="u660_div" class="u660_div"></div>
                <div id="u660_text" class="text u660_text">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u661" class="ax_default box_1 u661">
                <div id="u661_div" class="u661_div"></div>
                <div id="u661_text" class="text u661_text">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u662" class="ax_default box_1 u662">
                <div id="u662_div" class="u662_div"></div>
                <div id="u662_text" class="text u662_text">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </script>
          <div id="u651-1" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u652-1" class="ax_default u652" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u653-1" class="ax_default box_1 u653" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u653-1_img" class="img u653_img" src="images/page_a3/u608.svg"/>
                <div id="u653-1_text" class="text u653_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u654-1" class="ax_default box_1 u654" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u654-1_div" class="u654_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u654-1_text" class="text u654_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u655-1" class="ax_default box_1 u655" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u655-1_div" class="u655_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u655-1_text" class="text u655_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u656-1" class="ax_default box_1 u656" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u656-1_div" class="u656_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u656-1_text" class="text u656_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u657-1" class="ax_default box_1 u657" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u657-1_div" class="u657_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u657-1_text" class="text u657_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u658-1" class="ax_default box_1 u658" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u658-1_img" class="img u658_img" src="images/page_a3/u613.svg"/>
                <div id="u658-1_text" class="text u658_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u659-1" class="ax_default box_1 u659" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u659-1_div" class="u659_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u659-1_text" class="text u659_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u660-1" class="ax_default box_1 u660" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u660-1_div" class="u660_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u660-1_text" class="text u660_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u661-1" class="ax_default box_1 u661" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u661-1_div" class="u661_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u661-1_text" class="text u661_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u662-1" class="ax_default box_1 u662" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u662-1_div" class="u662_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u662-1_text" class="text u662_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u651-2" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u652-2" class="ax_default u652" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u653-2" class="ax_default box_1 u653" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u653-2_img" class="img u653_img" src="images/page_a3/u608.svg"/>
                <div id="u653-2_text" class="text u653_text" style="visibility: inherit">
                  <p><span>PFC索契 VS&nbsp; 羅斯托夫</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u654-2" class="ax_default box_1 u654" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u654-2_div" class="u654_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u654-2_text" class="text u654_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u655-2" class="ax_default box_1 u655" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u655-2_div" class="u655_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u655-2_text" class="text u655_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u656-2" class="ax_default box_1 u656" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u656-2_div" class="u656_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u656-2_text" class="text u656_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u657-2" class="ax_default box_1 u657" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u657-2_div" class="u657_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u657-2_text" class="text u657_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u658-2" class="ax_default box_1 u658" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u658-2_img" class="img u658_img" src="images/page_a3/u613.svg"/>
                <div id="u658-2_text" class="text u658_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u659-2" class="ax_default box_1 u659" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u659-2_div" class="u659_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u659-2_text" class="text u659_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u660-2" class="ax_default box_1 u660" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u660-2_div" class="u660_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u660-2_text" class="text u660_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u661-2" class="ax_default box_1 u661" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u661-2_div" class="u661_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u661-2_text" class="text u661_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u662-2" class="ax_default box_1 u662" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u662-2_div" class="u662_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u662-2_text" class="text u662_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u651-3" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u652-3" class="ax_default u652" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u653-3" class="ax_default box_1 u653" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u653-3_img" class="img u653_img" src="images/page_a3/u608.svg"/>
                <div id="u653-3_text" class="text u653_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; 羅斯托夫</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u654-3" class="ax_default box_1 u654" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u654-3_div" class="u654_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u654-3_text" class="text u654_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u655-3" class="ax_default box_1 u655" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u655-3_div" class="u655_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u655-3_text" class="text u655_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u656-3" class="ax_default box_1 u656" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u656-3_div" class="u656_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u656-3_text" class="text u656_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u657-3" class="ax_default box_1 u657" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u657-3_div" class="u657_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u657-3_text" class="text u657_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u658-3" class="ax_default box_1 u658" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u658-3_img" class="img u658_img" src="images/page_a3/u613.svg"/>
                <div id="u658-3_text" class="text u658_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u659-3" class="ax_default box_1 u659" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u659-3_div" class="u659_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u659-3_text" class="text u659_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u660-3" class="ax_default box_1 u660" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u660-3_div" class="u660_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u660-3_text" class="text u660_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u661-3" class="ax_default box_1 u661" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u661-3_div" class="u661_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u661-3_text" class="text u661_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u662-3" class="ax_default box_1 u662" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u662-3_div" class="u662_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u662-3_text" class="text u662_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u651-4" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u652-4" class="ax_default u652" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u653-4" class="ax_default box_1 u653" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u653-4_img" class="img u653_img" src="images/page_a3/u608.svg"/>
                <div id="u653-4_text" class="text u653_text" style="visibility: inherit">
                  <p><span>PFC索契 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u654-4" class="ax_default box_1 u654" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u654-4_div" class="u654_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u654-4_text" class="text u654_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u655-4" class="ax_default box_1 u655" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u655-4_div" class="u655_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u655-4_text" class="text u655_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u656-4" class="ax_default box_1 u656" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u656-4_div" class="u656_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u656-4_text" class="text u656_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u657-4" class="ax_default box_1 u657" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u657-4_div" class="u657_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u657-4_text" class="text u657_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u658-4" class="ax_default box_1 u658" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u658-4_img" class="img u658_img" src="images/page_a3/u613.svg"/>
                <div id="u658-4_text" class="text u658_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u659-4" class="ax_default box_1 u659" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u659-4_div" class="u659_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u659-4_text" class="text u659_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u660-4" class="ax_default box_1 u660" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u660-4_div" class="u660_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u660-4_text" class="text u660_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u661-4" class="ax_default box_1 u661" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u661-4_div" class="u661_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u661-4_text" class="text u661_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u662-4" class="ax_default box_1 u662" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u662-4_div" class="u662_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u662-4_text" class="text u662_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u651-5" class="preeval" style="width: 870px; height: 29px;">

            <!-- Unnamed (Group) -->
            <div id="u652-5" class="ax_default u652" style="visibility: inherit" data-left="0" data-top="0" data-width="870" data-height="29">

              <!-- Unnamed (Shape) -->
              <div id="u653-5" class="ax_default box_1 u653" style="width: 163px; height: 28px; left: 0px; top: 0px;visibility: inherit">
                <img id="u653-5_img" class="img u653_img" src="images/page_a3/u608.svg"/>
                <div id="u653-5_text" class="text u653_text" style="visibility: inherit">
                  <p><span>羅斯托夫 VS&nbsp; PFC索契</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u654-5" class="ax_default box_1 u654" style="width: 78px; height: 28px; left: 164px; top: 1px;visibility: inherit">
                <div id="u654-5_div" class="u654_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u654-5_text" class="text u654_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u655-5" class="ax_default box_1 u655" style="width: 78px; height: 28px; left: 243px; top: 1px;visibility: inherit">
                <div id="u655-5_div" class="u655_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u655-5_text" class="text u655_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u656-5" class="ax_default box_1 u656" style="width: 78px; height: 28px; left: 322px; top: 1px;visibility: inherit">
                <div id="u656-5_div" class="u656_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u656-5_text" class="text u656_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u657-5" class="ax_default box_1 u657" style="width: 78px; height: 28px; left: 401px; top: 1px;visibility: inherit">
                <div id="u657-5_div" class="u657_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u657-5_text" class="text u657_text" style="visibility: inherit">
                  <p><span>200%</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u658-5" class="ax_default box_1 u658" style="width: 78px; height: 28px; left: 480px; top: 1px;visibility: inherit">
                <img id="u658-5_img" class="img u658_img" src="images/page_a3/u613.svg"/>
                <div id="u658-5_text" class="text u658_text" style="visibility: inherit">
                  <p><span>340%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u659-5" class="ax_default box_1 u659" style="width: 78px; height: 28px; left: 559px; top: 1px;visibility: inherit">
                <div id="u659-5_div" class="u659_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u659-5_text" class="text u659_text" style="visibility: inherit">
                  <p><span>300%</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u660-5" class="ax_default box_1 u660" style="width: 78px; height: 28px; left: 638px; top: 1px;visibility: inherit">
                <div id="u660-5_div" class="u660_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u660-5_text" class="text u660_text" style="visibility: inherit">
                  <p><span>-0.4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u661-5" class="ax_default box_1 u661" style="width: 78px; height: 28px; left: 713px; top: 1px;visibility: inherit">
                <div id="u661-5_div" class="u661_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u661-5_text" class="text u661_text" style="visibility: inherit">
                  <p><span>-0.63</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u662-5" class="ax_default box_1 u662" style="width: 78px; height: 28px; left: 792px; top: 1px;visibility: inherit">
                <div id="u662-5_div" class="u662_div" style="width: 78px; height: 28px;visibility: inherit"></div>
                <div id="u662-5_text" class="text u662_text" style="visibility: inherit">
                  <p><span>0.77</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u663" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u663_div" class=""></div>
          <div id="u663_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u664" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u664_div" class=""></div>
          <div id="u664_text" class="text ">
            <p><span>主隊值博率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u665" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u665_div" class=""></div>
          <div id="u665_text" class="text ">
            <p><span>和波值博率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u666" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u666_div" class=""></div>
          <div id="u666_text" class="text ">
            <p><span>客隊值博率</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u667" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u667_div" class=""></div>
          <div id="u667_text" class="text ">
            <p><span>值博率</span></p>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
