﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A4</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/football/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/files/page_a4/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/football/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/football/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/football/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/football/public/frontend/data/document.js"></script>
    <script src="/football/public/frontend/files/page_a4/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/football/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/football/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/football/public/frontend/resources/reload.html'; };
    </script>



  </head>
  <body>
    <div id="base" class="">

      <!-- Top Menu_M (Group) -->
      <div id="u0" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u1_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u2" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u3" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u3_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u3_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u4" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u5" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u5_div" class=""></div>
                          <div id="u5_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u6" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u6_div" class=""></div>
                          <div id="u6_text" class="text ">
                            <p><span>&nbsp;簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u7" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u7_div" class=""></div>
                          <div id="u7_text" class="text ">
                            <p><span>&nbsp;如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u8" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u8_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                          <div id="u8_text" class="text ">
                            <p><span>&nbsp; 為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u9" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u9_div" class=""></div>
                          <div id="u9_text" class="text ">
                            <p><span>&nbsp; 馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u10" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u10_div" class=""></div>
                          <div id="u10_text" class="text ">
                            <p><span>&nbsp; 用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u11" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u11_div" class=""></div>
                          <div id="u11_text" class="text ">
                            <p><span>&nbsp; 風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u12" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u12_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                  <div id="u12_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u13" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u14" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u14_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                  <div id="u14_text" class="text ">
                    <p><span>足球AI模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u15" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u15_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u15_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u16" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u17" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u17_div" class=""></div>
                          <div id="u17_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u18" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u18_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                          <div id="u18_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u19" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u19_div" class=""></div>
                          <div id="u19_text" class="text ">
                            <p><span>&nbsp;綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u20" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u20_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                          <div id="u20_text" class="text ">
                            <p><span>&nbsp;值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u21" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u21_div" class=""></div>
                          <div id="u21_text" class="text ">
                            <p><span>&nbsp; AI模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u22" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u22_div" class=""></div>
                          <div id="u22_text" class="text ">
                            <p><span>&nbsp;AI模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u23" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u24" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u24_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                  <div id="u24_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u25" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u25_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u25_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u26" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u27" class="ax_default box_3">
                          <div id="u27_div" class=""></div>
                          <div id="u27_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u28" class="ax_default box_3">
                          <img id="u28_img" class="img " src="/football/public/frontend/images/page_a4/u28.svg"/>
                          <div id="u28_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u29" class="ax_default box_3">
                          <div id="u29_div" class=""></div>
                          <div id="u29_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u30" class="ax_default box_3">
                          <img id="u30_img" class="img " src="/football/public/frontend/images/page_a4/u30.svg"/>
                          <div id="u30_text" class="text ">
                            <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u31" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u31_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u31_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u32" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u32_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u32_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u33" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u33_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u33_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u34" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u34_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u34_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Top Menu_M (Group) -->
        <div id="u35" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- Unnamed (Placeholder) -->
          <div id="u36" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u36_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
            <div id="u36_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u37" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u37_div" class=""></div>
            <div id="u37_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u38" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u38_div" class=""></div>
            <div id="u38_text" class="text ">
              <p><span>MENU</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- footer (Group) -->
      <div id="u39" class="ax_default" data-label="footer" data-left="150" data-top="1050" data-width="1073" data-height="171">

        <!-- Unnamed (Rectangle) -->
        <div id="u40" class="ax_default shape">
          <img id="u40_img" class="img " src="/football/public/frontend/images/page_a4/u40.svg"/>
          <div id="u40_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u41" class="ax_default paragraph">
          <div id="u41_div" class=""></div>
          <div id="u41_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u42" class="ax_default paragraph">
          <div id="u42_div" class=""></div>
          <div id="u42_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u43" class="ax_default paragraph">
          <div id="u43_div" class=""></div>
          <div id="u43_text" class="text ">
            <p><span>問題</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u44" class="ax_default paragraph">
          <div id="u44_div" class=""></div>
          <div id="u44_text" class="text ">
            <p><span>查詢</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u45" class="ax_default paragraph">
          <div id="u45_div" class=""></div>
          <div id="u45_text" class="text ">
            <p><span>意見</span></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u46" class="ax_default icon">
          <img id="u46_img" class="img " src="/football/public/frontend/images/page_a4/u46.svg"/>
          <div id="u46_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u47" class="ax_default icon">
          <img id="u47_img" class="img " src="/football/public/frontend/images/page_a4/u47.svg"/>
          <div id="u47_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      @if(isset($a1s))
      @foreach($a4_hosts as $a4datum)
      

      <!-- TACS (Group) -->
      <div id="u48" class="ax_default" data-label="TACS" data-left="924" data-top="519" data-width="400" data-height="480">

        <!-- TACS_total (Group) -->
        <div id="u49" class="ax_default" data-label="TACS_total" data-left="1004" data-top="967" data-width="320" data-height="32">

          <!-- bold_3b (Rectangle) -->
          <div id="u50" class="ax_default paragraph" data-label="bold_3b">
            <div id="u50_div" class=""></div>
            <div id="u50_text" class="text ">
              <p><span>59%</span></p>
            </div>
          </div>

          <!-- bold_2b (Rectangle) -->
          <div id="u51" class="ax_default paragraph" data-label="bold_2b">
            <div id="u51_div" class=""></div>
            <div id="u51_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>

          <!-- bold_1b (Rectangle) -->
          <div id="u52" class="ax_default paragraph" data-label="bold_1b">
            <div id="u52_div" class=""></div>
            <div id="u52_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>

          <!-- bold_0b (Rectangle) -->
          <div id="u53" class="ax_default paragraph" data-label="bold_0b">
            <div id="u53_div" class=""></div>
            <div id="u53_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>
        </div>

        <!-- TACS_DB (Group) -->
        <div id="u54" class="ax_default" data-label="TACS_DB" data-left="1004" data-top="551" data-width="320" data-height="416">

          <!-- TACS_Repeater (Repeater) -->
          <div id="u55" class="ax_default" data-label="TACS_Repeater">
            <script id="u55_script" type="axure-repeater-template" data-label="TACS_Repeater">

              <!-- bold_3a (Rectangle) -->
              <div id="u56" class="ax_default paragraph u56" data-label="bold_3a">
                <div id="u56_div" class="u56_div"></div>
                <div id="u56_text" class="text u56_text">
                  <p><span>4.8%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57" class="ax_default paragraph u57" data-label="bold_2a">
                <div id="u57_div" class="u57_div"></div>
                <div id="u57_text" class="text u57_text">
                  <p><span>18%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58" class="ax_default paragraph u58" data-label="bold_1a">
                <div id="u58_div" class="u58_div"></div>
                <div id="u58_text" class="text u58_text">
                  <p><span>16%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59" class="ax_default paragraph u59" data-label="bold_0a">
                <div id="u59_div" class="u59_div"></div>
                <div id="u59_text" class="text u59_text">
                  <p><span>15%</span></p>
                </div>
              </div>
            </script>
            <div id="u55-1" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-1" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-1_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-1_text" class="text u56_text" style="visibility: inherit">
                  <p><span>10.6%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-1" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-1_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-1_text" class="text u57_text" style="visibility: inherit">
                  <p><span>21%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-1" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-1_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-1_text" class="text u58_text" style="visibility: inherit">
                  <p><span>18%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-1" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-1_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-1_text" class="text u59_text" style="visibility: inherit">
                  <p><span>16%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-2" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-2" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-2_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-2_text" class="text u56_text" style="visibility: inherit">
                  <p><span>11.2%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-2" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-2_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-2_text" class="text u57_text" style="visibility: inherit">
                  <p><span>17%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-2" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-2_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-2_text" class="text u58_text" style="visibility: inherit">
                  <p><span>19%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-2" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-2_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-2_text" class="text u59_text" style="visibility: inherit">
                  <p><span>17%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-3" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-3" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-3_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-3_text" class="text u56_text" style="visibility: inherit">
                  <p><span>12.4%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-3" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-3_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-3_text" class="text u57_text" style="visibility: inherit">
                  <p><span>23%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-3" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-3_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-3_text" class="text u58_text" style="visibility: inherit">
                  <p><span>21%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-3" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-3_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-3_text" class="text u59_text" style="visibility: inherit">
                  <p><span>21%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-4" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-4" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-4_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-4_text" class="text u56_text" style="visibility: inherit">
                  <p><span>4.4%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-4" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-4_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-4_text" class="text u57_text" style="visibility: inherit">
                  <p><span>6%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-4" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-4_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-4_text" class="text u58_text" style="visibility: inherit">
                  <p><span>8%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-4" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-4_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-4_text" class="text u59_text" style="visibility: inherit">
                  <p><span>8%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-5" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-5" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-5_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-5_text" class="text u56_text" style="visibility: inherit">
                  <p><span>3.8%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-5" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-5_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-5_text" class="text u57_text" style="visibility: inherit">
                  <p><span>9.5%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-5" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-5_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-5_text" class="text u58_text" style="visibility: inherit">
                  <p><span>7%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-5" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-5_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-5_text" class="text u59_text" style="visibility: inherit">
                  <p><span>7.5%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-6" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-6" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-6_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-6_text" class="text u56_text" style="visibility: inherit">
                  <p><span>3.2%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-6" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-6_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-6_text" class="text u57_text" style="visibility: inherit">
                  <p><span>3.5%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-6" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-6_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-6_text" class="text u58_text" style="visibility: inherit">
                  <p><span>6%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-6" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-6_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-6_text" class="text u59_text" style="visibility: inherit">
                  <p><span>5.5%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-7" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-7" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-7_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-7_text" class="text u56_text" style="visibility: inherit">
                  <p><span>2.1%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-7" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-7_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-7_text" class="text u57_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-7" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-7_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-7_text" class="text u58_text" style="visibility: inherit">
                  <p><span>4%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-7" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-7_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-7_text" class="text u59_text" style="visibility: inherit">
                  <p><span>4%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-8" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-8" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-8_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-8_text" class="text u56_text" style="visibility: inherit">
                  <p><span>2.4%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-8" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-8_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-8_text" class="text u57_text" style="visibility: inherit">
                  <p><span>3.5%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-8" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-8_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-8_text" class="text u58_text" style="visibility: inherit">
                  <p><span>4%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-8" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-8_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-8_text" class="text u59_text" style="visibility: inherit">
                  <p><span>4.5%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-9" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-9" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-9_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-9_text" class="text u56_text" style="visibility: inherit">
                  <p><span>1.2%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-9" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-9_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-9_text" class="text u57_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-9" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-9_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-9_text" class="text u58_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-9" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-9_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-9_text" class="text u59_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-10" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-10" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-10_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-10_text" class="text u56_text" style="visibility: inherit">
                  <p><span>1.5%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-10" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-10_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-10_text" class="text u57_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-10" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-10_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-10_text" class="text u58_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-10" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-10_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-10_text" class="text u59_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-11" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-11" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-11_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-11_text" class="text u56_text" style="visibility: inherit">
                  <p><span>0.9%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-11" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-11_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-11_text" class="text u57_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-11" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-11_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-11_text" class="text u58_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-11" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-11_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-11_text" class="text u59_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-12" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-12" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-12_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-12_text" class="text u56_text" style="visibility: inherit">
                  <p><span>1.2%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-12" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-12_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-12_text" class="text u57_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-12" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-12_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-12_text" class="text u58_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-12" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-12_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-12_text" class="text u59_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>
            </div>
            <div id="u55-13" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u56-13" class="ax_default paragraph u56" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u56-13_div" class="u56_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u56-13_text" class="text u56_text" style="visibility: inherit">
                  <p><span>4.1%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u57-13" class="ax_default paragraph u57" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u57-13_div" class="u57_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u57-13_text" class="text u57_text" style="visibility: inherit">
                  <p><span>6%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u58-13" class="ax_default paragraph u58" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u58-13_div" class="u58_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u58-13_text" class="text u58_text" style="visibility: inherit">
                  <p><span>7%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u59-13" class="ax_default paragraph u59" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u59-13_div" class="u59_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u59-13_text" class="text u59_text" style="visibility: inherit">
                  <p><span>8%</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- TACS_Group (Group) -->
        <div id="u60" class="ax_default" data-label="TACS_Group" data-left="924" data-top="519" data-width="400" data-height="448">

          <!-- TAMR_Group (Group) -->
          <div id="u61" class="ax_default" data-label="TAMR_Group" data-left="924" data-top="551" data-width="80" data-height="416">

            <!-- Others (Rectangle) -->
            <div id="u62" class="ax_default paragraph" data-label="Others">
              <div id="u62_div" class=""></div>
              <div id="u62_text" class="text ">
                <p><span>其他</span></p>
              </div>
            </div>

            <!-- 2 - 5 (Rectangle) -->
            <div id="u63" class="ax_default paragraph" data-label="2 - 5">
              <div id="u63_div" class=""></div>
              <div id="u63_text" class="text ">
                <p><span>2 - 5</span></p>
              </div>
            </div>

            <!-- 1 - 5 (Rectangle) -->
            <div id="u64" class="ax_default paragraph" data-label="1 - 5">
              <div id="u64_div" class=""></div>
              <div id="u64_text" class="text ">
                <p><span>1 - 5</span></p>
              </div>
            </div>

            <!-- 0 - 5 (Rectangle) -->
            <div id="u65" class="ax_default paragraph" data-label="0 - 5">
              <div id="u65_div" class=""></div>
              <div id="u65_text" class="text ">
                <p><span>0 - 5</span></p>
              </div>
            </div>

            <!-- 2 - 4 (Rectangle) -->
            <div id="u66" class="ax_default paragraph" data-label="2 - 4">
              <div id="u66_div" class=""></div>
              <div id="u66_text" class="text ">
                <p><span>2 - 4</span></p>
              </div>
            </div>

            <!-- 1 - 4 (Rectangle) -->
            <div id="u67" class="ax_default paragraph" data-label="1 - 4">
              <div id="u67_div" class=""></div>
              <div id="u67_text" class="text ">
                <p><span>1 - 4</span></p>
              </div>
            </div>

            <!-- 0 - 4 (Rectangle) -->
            <div id="u68" class="ax_default paragraph" data-label="0 - 4">
              <div id="u68_div" class=""></div>
              <div id="u68_text" class="text ">
                <p><span>0 - 4</span></p>
              </div>
            </div>

            <!-- 2 - 3 (Rectangle) -->
            <div id="u69" class="ax_default paragraph" data-label="2 - 3">
              <div id="u69_div" class=""></div>
              <div id="u69_text" class="text ">
                <p><span>2 - 3</span></p>
              </div>
            </div>

            <!-- 1 - 3 (Rectangle) -->
            <div id="u70" class="ax_default paragraph" data-label="1 - 3">
              <div id="u70_div" class=""></div>
              <div id="u70_text" class="text ">
                <p><span>1 - 3</span></p>
              </div>
            </div>

            <!-- 0 - 3 (Rectangle) -->
            <div id="u71" class="ax_default paragraph" data-label="0 - 3">
              <div id="u71_div" class=""></div>
              <div id="u71_text" class="text ">
                <p><span>0 - 3</span></p>
              </div>
            </div>

            <!-- 1 - 2 (Rectangle) -->
            <div id="u72" class="ax_default paragraph" data-label="1 - 2">
              <div id="u72_div" class=""></div>
              <div id="u72_text" class="text ">
                <p><span>1 - 2</span></p>
              </div>
            </div>

            <!-- 0 - 2 (Rectangle) -->
            <div id="u73" class="ax_default paragraph" data-label="0 - 2">
              <div id="u73_div" class=""></div>
              <div id="u73_text" class="text ">
                <p><span>0 - 2</span></p>
              </div>
            </div>

            <!-- 0 - 1 (Rectangle) -->
            <div id="u74" class="ax_default paragraph" data-label="0 - 1">
              <div id="u74_div" class=""></div>
              <div id="u74_text" class="text ">
                <p><span>0 - 1</span></p>
              </div>
            </div>
          </div>

          <!-- CS_rtg (Rectangle) -->
          <div id="u75" class="ax_default box_3" data-label="CS_rtg">
            <div id="u75_div" class=""></div>
            <div id="u75_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- CS_r (Rectangle) -->
          <div id="u76" class="ax_default paragraph" data-label="CS_r">
            <div id="u76_div" class=""></div>
            <div id="u76_text" class="text ">
              <p><span>波膽機率</span></p>
            </div>
          </div>

          <!-- Series3 (Rectangle) -->
          <div id="u77" class="ax_default paragraph" data-label="Series3">
            <div id="u77_div" class=""></div>
            <div id="u77_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
            </div>
          </div>

          <!-- Series2 (Rectangle) -->
          <div id="u78" class="ax_default paragraph" data-label="Series2">
            <div id="u78_div" class=""></div>
            <div id="u78_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
            </div>
          </div>

          <!-- Series1 (Rectangle) -->
          <div id="u79" class="ax_default paragraph" data-label="Series1">
            <div id="u79_div" class=""></div>
            <div id="u79_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
            </div>
          </div>

          <!-- TACS_b (Rectangle) -->
          <div id="u80" class="ax_default paragraph" data-label="TACS_b">
            <div id="u80_div" class=""></div>
            <div id="u80_text" class="text ">
              <p><span>客隊波膽</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- DRCS (Group) -->
      <div id="u81" class="ax_default" data-label="DRCS" data-left="484" data-top="519" data-width="400" data-height="224">

        <!-- DRCS_total (Group) -->
        <div id="u82" class="ax_default" data-label="DRCS_total" data-left="564" data-top="711" data-width="320" data-height="32">

          <!-- bold_3b (Rectangle) -->
          <div id="u83" class="ax_default paragraph" data-label="bold_3b">
            <div id="u83_div" class=""></div>
            <div id="u83_text" class="text ">
              <p><span>11%</span></p>
            </div>
          </div>

          <!-- bold_2b (Rectangle) -->
          <div id="u84" class="ax_default paragraph" data-label="bold_2b">
            <div id="u84_div" class=""></div>
            <div id="u84_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>

          <!-- bold_1b (Rectangle) -->
          <div id="u85" class="ax_default paragraph" data-label="bold_1b">
            <div id="u85_div" class=""></div>
            <div id="u85_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>

          <!-- bold_0b (Rectangle) -->
          <div id="u86" class="ax_default paragraph" data-label="bold_0b">
            <div id="u86_div" class=""></div>
            <div id="u86_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>
        </div>

        <!-- DRCS_DB (Group) -->
        <div id="u87" class="ax_default" data-label="DRCS_DB" data-left="564" data-top="551" data-width="320" data-height="160">

          <!-- DRCS_Repeater (Repeater) -->
          <div id="u88" class="ax_default" data-label="DRCS_Repeater">
            <script id="u88_script" type="axure-repeater-template" data-label="DRCS_Repeater">

              <!-- bold_3a (Rectangle) -->
              <div id="u89" class="ax_default paragraph u89" data-label="bold_3a">
                <div id="u89_div" class="u89_div"></div>
                <div id="u89_text" class="text u89_text">
                  <p><span>4.8%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u90" class="ax_default paragraph u90" data-label="bold_2a">
                <div id="u90_div" class="u90_div"></div>
                <div id="u90_text" class="text u90_text">
                  <p><span>18%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u91" class="ax_default paragraph u91" data-label="bold_1a">
                <div id="u91_div" class="u91_div"></div>
                <div id="u91_text" class="text u91_text">
                  <p><span>16%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u92" class="ax_default paragraph u92" data-label="bold_0a">
                <div id="u92_div" class="u92_div"></div>
                <div id="u92_text" class="text u92_text">
                  <p><span>15%</span></p>
                </div>
              </div>
            </script>
            <div id="u88-1" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u89-1" class="ax_default paragraph u89" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u89-1_div" class="u89_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u89-1_text" class="text u89_text" style="visibility: inherit">
                  <p><span>3.0%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u90-1" class="ax_default paragraph u90" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u90-1_div" class="u90_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u90-1_text" class="text u90_text" style="visibility: inherit">
                  <p><span>28%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u91-1" class="ax_default paragraph u91" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u91-1_div" class="u91_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u91-1_text" class="text u91_text" style="visibility: inherit">
                  <p><span>27%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u92-1" class="ax_default paragraph u92" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u92-1_div" class="u92_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u92-1_text" class="text u92_text" style="visibility: inherit">
                  <p><span>25%</span></p>
                </div>
              </div>
            </div>
            <div id="u88-2" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u89-2" class="ax_default paragraph u89" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u89-2_div" class="u89_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u89-2_text" class="text u89_text" style="visibility: inherit">
                  <p><span>4.5%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u90-2" class="ax_default paragraph u90" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u90-2_div" class="u90_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u90-2_text" class="text u90_text" style="visibility: inherit">
                  <p><span>43%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u91-2" class="ax_default paragraph u91" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u91-2_div" class="u91_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u91-2_text" class="text u91_text" style="visibility: inherit">
                  <p><span>41%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u92-2" class="ax_default paragraph u92" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u92-2_div" class="u92_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u92-2_text" class="text u92_text" style="visibility: inherit">
                  <p><span>40%</span></p>
                </div>
              </div>
            </div>
            <div id="u88-3" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u89-3" class="ax_default paragraph u89" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u89-3_div" class="u89_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u89-3_text" class="text u89_text" style="visibility: inherit">
                  <p><span>2.0%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u90-3" class="ax_default paragraph u90" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u90-3_div" class="u90_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u90-3_text" class="text u90_text" style="visibility: inherit">
                  <p><span>15%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u91-3" class="ax_default paragraph u91" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u91-3_div" class="u91_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u91-3_text" class="text u91_text" style="visibility: inherit">
                  <p><span>18%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u92-3" class="ax_default paragraph u92" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u92-3_div" class="u92_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u92-3_text" class="text u92_text" style="visibility: inherit">
                  <p><span>20%</span></p>
                </div>
              </div>
            </div>
            <div id="u88-4" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u89-4" class="ax_default paragraph u89" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u89-4_div" class="u89_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u89-4_text" class="text u89_text" style="visibility: inherit">
                  <p><span>1.2%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u90-4" class="ax_default paragraph u90" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u90-4_div" class="u90_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u90-4_text" class="text u90_text" style="visibility: inherit">
                  <p><span>12%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u91-4" class="ax_default paragraph u91" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u91-4_div" class="u91_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u91-4_text" class="text u91_text" style="visibility: inherit">
                  <p><span>11%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u92-4" class="ax_default paragraph u92" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u92-4_div" class="u92_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u92-4_text" class="text u92_text" style="visibility: inherit">
                  <p><span>10%</span></p>
                </div>
              </div>
            </div>
            <div id="u88-5" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u89-5" class="ax_default paragraph u89" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u89-5_div" class="u89_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u89-5_text" class="text u89_text" style="visibility: inherit">
                  <p><span>0.3%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u90-5" class="ax_default paragraph u90" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u90-5_div" class="u90_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u90-5_text" class="text u90_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u91-5" class="ax_default paragraph u91" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u91-5_div" class="u91_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u91-5_text" class="text u91_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u92-5" class="ax_default paragraph u92" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u92-5_div" class="u92_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u92-5_text" class="text u92_text" style="visibility: inherit">
                  <p><span>5%</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- DRCS_Group (Group) -->
        <div id="u93" class="ax_default" data-label="DRCS_Group" data-left="484" data-top="519" data-width="400" data-height="192">

          <!-- DRMR_Group (Group) -->
          <div id="u94" class="ax_default" data-label="DRMR_Group" data-left="484" data-top="551" data-width="80" data-height="160">

            <!-- Others (Rectangle) -->
            <div id="u95" class="ax_default paragraph" data-label="Others">
              <div id="u95_div" class=""></div>
              <div id="u95_text" class="text ">
                <p><span>其他</span></p>
              </div>
            </div>

            <!-- 3 - 3 (Rectangle) -->
            <div id="u96" class="ax_default paragraph" data-label="3 - 3">
              <div id="u96_div" class=""></div>
              <div id="u96_text" class="text ">
                <p><span>3 - 3</span></p>
              </div>
            </div>

            <!-- 2 - 2 (Rectangle) -->
            <div id="u97" class="ax_default paragraph" data-label="2 - 2">
              <div id="u97_div" class=""></div>
              <div id="u97_text" class="text ">
                <p><span>2 - 2</span></p>
              </div>
            </div>

            <!-- 1 - 1 (Rectangle) -->
            <div id="u98" class="ax_default paragraph" data-label="1 - 1">
              <div id="u98_div" class=""></div>
              <div id="u98_text" class="text ">
                <p><span>1 - 1</span></p>
              </div>
            </div>

            <!-- 0 - 0 (Rectangle) -->
            <div id="u99" class="ax_default paragraph" data-label="0 - 0">
              <div id="u99_div" class=""></div>
              <div id="u99_text" class="text ">
                <p><span>0 - 0</span></p>
              </div>
            </div>
          </div>

          <!-- CS_rtg (Rectangle) -->
          <div id="u100" class="ax_default box_3" data-label="CS_rtg">
            <div id="u100_div" class=""></div>
            <div id="u100_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- CS_r (Rectangle) -->
          <div id="u101" class="ax_default paragraph" data-label="CS_r">
            <div id="u101_div" class=""></div>
            <div id="u101_text" class="text ">
              <p><span>波膽機率</span></p>
            </div>
          </div>

          <!-- Series3 (Rectangle) -->
          <div id="u102" class="ax_default paragraph" data-label="Series3">
            <div id="u102_div" class=""></div>
            <div id="u102_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
            </div>
          </div>

          <!-- Series2 (Rectangle) -->
          <div id="u103" class="ax_default paragraph" data-label="Series2">
            <div id="u103_div" class=""></div>
            <div id="u103_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
            </div>
          </div>

          <!-- Series1 (Rectangle) -->
          <div id="u104" class="ax_default paragraph" data-label="Series1">
            <div id="u104_div" class=""></div>
            <div id="u104_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
            </div>
          </div>

          <!-- DRCS_b (Rectangle) -->
          <div id="u105" class="ax_default paragraph" data-label="DRCS_b">
            <div id="u105_div" class=""></div>
            <div id="u105_text" class="text ">
              <p><span>和局</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- THCS (Group) -->
      <div id="u106" class="ax_default" data-label="THCS" data-left="42" data-top="519" data-width="400" data-height="480">

        <!-- THCS_total (Group) -->
        <div id="u107" class="ax_default" data-label="THCS_total" data-left="122" data-top="967" data-width="320" data-height="32">

          <!-- bold_3b (Rectangle) -->
          <div id="u108" class="ax_default paragraph" data-label="bold_3b">
            <div id="u108_div" class=""></div>
            <div id="u108_text" class="text ">
              <p><span>30%</span></p>
            </div>
          </div>

          <!-- bold_2b (Rectangle) -->
          <div id="u109" class="ax_default paragraph" data-label="bold_2b">
            <div id="u109_div" class=""></div>
            <div id="u109_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>

          <!-- bold_1b (Rectangle) -->
          <div id="u110" class="ax_default paragraph" data-label="bold_1b">
            <div id="u110_div" class=""></div>
            <div id="u110_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>

          <!-- bold_0b (Rectangle) -->
          <div id="u111" class="ax_default paragraph" data-label="bold_0b">
            <div id="u111_div" class=""></div>
            <div id="u111_text" class="text ">
              <p><span>100%</span></p>
            </div>
          </div>
        </div>

        <!-- THCS_DB (Group) -->
        <div id="u112" class="ax_default" data-label="THCS_DB" data-left="122" data-top="551" data-width="320" data-height="416">

          <!-- THCS_Repeater (Repeater) -->
          <div id="u113" class="ax_default" data-label="THCS_Repeater">
            <script id="u113_script" type="axure-repeater-template" data-label="THCS_Repeater">

              <!-- bold_3a (Rectangle) -->
              <div id="u114" class="ax_default paragraph u114" data-label="bold_3a">
                <div id="u114_div" class="u114_div"></div>
                <div id="u114_text" class="text u114_text">
                  <p><span>4.8%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115" class="ax_default paragraph u115" data-label="bold_2a">
                <div id="u115_div" class="u115_div"></div>
                <div id="u115_text" class="text u115_text">
                  <p><span>18%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116" class="ax_default paragraph u116" data-label="bold_1a">
                <div id="u116_div" class="u116_div"></div>
                <div id="u116_text" class="text u116_text">
                  <p><span>16%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117" class="ax_default paragraph u117" data-label="bold_0a">
                <div id="u117_div" class="u117_div"></div>
                <div id="u117_text" class="text u117_text">
                  <p><span>15%</span></p>
                </div>
              </div>
            </script>
            <div id="u113-1" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-1" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-1_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-1_text" class="text u114_text" style="visibility: inherit">
                  <p><span>4.8%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-1" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-1_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-1_text" class="text u115_text" style="visibility: inherit">
                  <p><span>18%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-1" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-1_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-1_text" class="text u116_text" style="visibility: inherit">
                  <p><span>16%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-1" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-1_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-1_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h1 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-2" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-2" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-2_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-2_text" class="text u114_text" style="visibility: inherit">
                  <p><span>6.0%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-2" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-2_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-2_text" class="text u115_text" style="visibility: inherit">
                  <p><span>22%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-2" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-2_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-2_text" class="text u116_text" style="visibility: inherit">
                  <p><span>20%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-2" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-2_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-2_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h2 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-3" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-3" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-3_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-3_text" class="text u114_text" style="visibility: inherit">
                  <p><span>7.2%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-3" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-3_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-3_text" class="text u115_text" style="visibility: inherit">
                  <p><span>26%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-3" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-3_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-3_text" class="text u116_text" style="visibility: inherit">
                  <p><span>24%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-3" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-3_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-3_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h3 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-4" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-4" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-4_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-4_text" class="text u114_text" style="visibility: inherit">
                  <p><span>1.5%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-4" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-4_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-4_text" class="text u115_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-4" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-4_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-4_text" class="text u116_text" style="visibility: inherit">
                  <p><span>5%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-4" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-4_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-4_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h4 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-5" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-5" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-5_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-5_text" class="text u114_text" style="visibility: inherit">
                  <p><span>2.6%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-5" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-5_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-5_text" class="text u115_text" style="visibility: inherit">
                  <p><span>10.5%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-5" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-5_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-5_text" class="text u116_text" style="visibility: inherit">
                  <p><span>8.5%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-5" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-5_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-5_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h5 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-6" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-6" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-6_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-6_text" class="text u114_text" style="visibility: inherit">
                  <p><span>1.4%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-6" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-6_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-6_text" class="text u115_text" style="visibility: inherit">
                  <p><span>2.5%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-6" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-6_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-6_text" class="text u116_text" style="visibility: inherit">
                  <p><span>4.5%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-6" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-6_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-6_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h6 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-7" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-7" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-7_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-7_text" class="text u114_text" style="visibility: inherit">
                  <p><span>0.9%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-7" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-7_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-7_text" class="text u115_text" style="visibility: inherit">
                  <p><span>1%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-7" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-7_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-7_text" class="text u116_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-7" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-7_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-7_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h7 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-8" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-8" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-8_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-8_text" class="text u114_text" style="visibility: inherit">
                  <p><span>1.1%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-8" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-8_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-8_text" class="text u115_text" style="visibility: inherit">
                  <p><span>3.5%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-8" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-8_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-8_text" class="text u116_text" style="visibility: inherit">
                  <p><span>3.5%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-8" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-8_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-8_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h8 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-9" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-9" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-9_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-9_text" class="text u114_text" style="visibility: inherit">
                  <p><span>0.8%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-9" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-9_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-9_text" class="text u115_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-9" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-9_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-9_text" class="text u116_text" style="visibility: inherit">
                  <p><span>2.5%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-9" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-9_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-9_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h9 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-10" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-10" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-10_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-10_text" class="text u114_text" style="visibility: inherit">
                  <p><span>0.6%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-10" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-10_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-10_text" class="text u115_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-10" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-10_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-10_text" class="text u116_text" style="visibility: inherit">
                  <p><span>2%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-10" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-10_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-10_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h10 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-11" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-11" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-11_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-11_text" class="text u114_text" style="visibility: inherit">
                  <p><span>0.9%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-11" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-11_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-11_text" class="text u115_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-11" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-11_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-11_text" class="text u116_text" style="visibility: inherit">
                  <p><span>3%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-11" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-11_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-11_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h11 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-12" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-12" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-12_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-12_text" class="text u114_text" style="visibility: inherit">
                  <p><span>0.3%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-12" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-12_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-12_text" class="text u115_text" style="visibility: inherit">
                  <p><span>1%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-12" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-12_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-12_text" class="text u116_text" style="visibility: inherit">
                  <p><span>1%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-12" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-12_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-12_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h12 }}%</span></p>
                </div>
              </div>
            </div>
            <div id="u113-13" class="preeval" style="width: 320px; height: 32px;">

              <!-- bold_3a (Rectangle) -->
              <div id="u114-13" class="ax_default paragraph u114" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                <div id="u114-13_div" class="u114_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u114-13_text" class="text u114_text" style="visibility: inherit">
                  <p><span>2.1%</span></p>
                </div>
              </div>

              <!-- bold_2a (Rectangle) -->
              <div id="u115-13" class="ax_default paragraph u115" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                <div id="u115-13_div" class="u115_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u115-13_text" class="text u115_text" style="visibility: inherit">
                  <p><span>5%</span></p>
                </div>
              </div>

              <!-- bold_1a (Rectangle) -->
              <div id="u116-13" class="ax_default paragraph u116" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                <div id="u116-13_div" class="u116_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u116-13_text" class="text u116_text" style="visibility: inherit">
                  <p><span>7%</span></p>
                </div>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u117-13" class="ax_default paragraph u117" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                <div id="u117-13_div" class="u117_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                <div id="u117-13_text" class="text u117_text" style="visibility: inherit">
                  <p><span>{{ $a4datum->h13 }}%</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- THCS_Group (Group) -->
        <div id="u118" class="ax_default" data-label="THCS_Group" data-left="42" data-top="519" data-width="400" data-height="448">

          <!-- THMR_Group (Group) -->
          <div id="u119" class="ax_default" data-label="THMR_Group" data-left="42" data-top="551" data-width="80" data-height="416">

            <!-- Others (Rectangle) -->
            <div id="u120" class="ax_default paragraph" data-label="Others">
              <div id="u120_div" class=""></div>
              <div id="u120_text" class="text ">
                <p><span>其他</span></p>
              </div>
            </div>

            <!-- 5 - 2 (Rectangle) -->
            <div id="u121" class="ax_default paragraph" data-label="5 - 2">
              <div id="u121_div" class=""></div>
              <div id="u121_text" class="text ">
                <p><span>5 - 2</span></p>
              </div>
            </div>

            <!-- 5 - 1 (Rectangle) -->
            <div id="u122" class="ax_default paragraph" data-label="5 - 1">
              <div id="u122_div" class=""></div>
              <div id="u122_text" class="text ">
                <p><span>5 - 1</span></p>
              </div>
            </div>

            <!-- 5 - 0 (Rectangle) -->
            <div id="u123" class="ax_default paragraph" data-label="5 - 0">
              <div id="u123_div" class=""></div>
              <div id="u123_text" class="text ">
                <p><span>5 - 0</span></p>
              </div>
            </div>

            <!-- 4 - 2 (Rectangle) -->
            <div id="u124" class="ax_default paragraph" data-label="4 - 2">
              <div id="u124_div" class=""></div>
              <div id="u124_text" class="text ">
                <p><span>4 - 2</span></p>
              </div>
            </div>

            <!-- 4 - 1 (Rectangle) -->
            <div id="u125" class="ax_default paragraph" data-label="4 - 1">
              <div id="u125_div" class=""></div>
              <div id="u125_text" class="text ">
                <p><span>4 - 1</span></p>
              </div>
            </div>

            <!-- 4 - 0 (Rectangle) -->
            <div id="u126" class="ax_default paragraph" data-label="4 - 0">
              <div id="u126_div" class=""></div>
              <div id="u126_text" class="text ">
                <p><span>4 - 0</span></p>
              </div>
            </div>

            <!-- 3 - 2 (Rectangle) -->
            <div id="u127" class="ax_default paragraph" data-label="3 - 2">
              <div id="u127_div" class=""></div>
              <div id="u127_text" class="text ">
                <p><span>3 - 2</span></p>
              </div>
            </div>

            <!-- 3 - 1 (Rectangle) -->
            <div id="u128" class="ax_default paragraph" data-label="3 - 1">
              <div id="u128_div" class=""></div>
              <div id="u128_text" class="text ">
                <p><span>3 - 1</span></p>
              </div>
            </div>

            <!-- 3 - 0 (Rectangle) -->
            <div id="u129" class="ax_default paragraph" data-label="3 - 0">
              <div id="u129_div" class=""></div>
              <div id="u129_text" class="text ">
                <p><span>3 - 0</span></p>
              </div>
            </div>

            <!-- 2 - 1 (Rectangle) -->
            <div id="u130" class="ax_default paragraph" data-label="2 - 1">
              <div id="u130_div" class=""></div>
              <div id="u130_text" class="text ">
                <p><span>2 - 1</span></p>
              </div>
            </div>

            <!-- 2 - 0 (Rectangle) -->
            <div id="u131" class="ax_default paragraph" data-label="2 - 0">
              <div id="u131_div" class=""></div>
              <div id="u131_text" class="text ">
                <p><span>2 - 0</span></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u132" class="ax_default paragraph">
              <div id="u132_div" class=""></div>
              <div id="u132_text" class="text ">
                <p><span>1 - 0</span></p>
              </div>
            </div>
          </div>

          <!-- CS_rtg (Rectangle) -->
          <div id="u133" class="ax_default box_3" data-label="CS_rtg">
            <div id="u133_div" class=""></div>
            <div id="u133_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- CS_r (Rectangle) -->
          <div id="u134" class="ax_default paragraph" data-label="CS_r">
            <div id="u134_div" class=""></div>
            <div id="u134_text" class="text ">
              <p><span>波膽機率</span></p>
            </div>
          </div>

          <!-- Series3 (Rectangle) -->
          <div id="u135" class="ax_default paragraph" data-label="Series3">
            <div id="u135_div" class=""></div>
            <div id="u135_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
            </div>
          </div>

          <!-- Series2 (Rectangle) -->
          <div id="u136" class="ax_default paragraph" data-label="Series2">
            <div id="u136_div" class=""></div>
            <div id="u136_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
            </div>
          </div>

          <!-- Series1 (Rectangle) -->
          <div id="u137" class="ax_default paragraph" data-label="Series1">
            <div id="u137_div" class=""></div>
            <div id="u137_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
            </div>
          </div>

          <!-- THCS_b (Rectangle) -->
          <div id="u138" class="ax_default paragraph" data-label="THCS_b">
            <div id="u138_div" class=""></div>
            <div id="u138_text" class="text ">
              <p><span>主隊波膽</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- CS_text (Rectangle) -->
      <div id="u139" class="ax_default paragraph" data-label="CS_text">
        <div id="u139_div" class=""></div>
        <div id="u139_text" class="text ">
          <p><span>以下波膽，大小球及總入球使用了XXXX場(</span><span>俄羅斯超級聯賽</span><span>)賽事，主隊(</span><span>羅斯托夫</span><span>)近XX場主場賽事及客隊(</span><span>PFC索契</span><span>)的XX場作客賽場作統計及大數據方法分析，只供參考！</span></p>
        </div>
      </div>

      <!-- CS_title (Rectangle) -->
      <div id="u140" class="ax_default heading_3" data-label="CS_title">
        <div id="u140_div" class=""></div>
        <div id="u140_text" class="text ">
          <p><span>波膽</span><span>數據預測</span></p>
        </div>
      </div>

      <!-- Rate_Group (Group) -->
      <div id="u141" class="ax_default" data-label="Rate_Group" data-left="150" data-top="340" data-width="1072" data-height="40">

        <!-- Rate_bar (Rectangle) -->
        <div id="u142" class="ax_default box_1" data-label="Rate_bar">
          <div id="u142_div" class=""></div>
          <div id="u142_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TAW (Group) -->
        <div id="u143" class="ax_default" data-label="TAW" data-left="632" data-top="340" data-width="590" data-height="40">

          <!-- TAW_D (Rectangle) -->
          <div id="u144" class="ax_default box_1" data-label="TAW_D">
            <div id="u144_div" class=""></div>
            <div id="u144_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_Dt (Rectangle) -->
          <div id="u145" class="ax_default box_1" data-label="TAW_Dt">
            <img id="u145_img" class="img " src="/football/public/frontend/images/page_a4/taw_dt_u145.svg"/>
            <div id="u145_text" class="text ">
              <p><span>客勝</span><span> 55%</span></p>
            </div>
          </div>
        </div>

        <!-- THW (Group) -->
        <div id="u146" class="ax_default" data-label="THW" data-left="150" data-top="340" data-width="257" data-height="40">

          <!-- THW_D (Rectangle) -->
          <div id="u147" class="ax_default box_1" data-label="THW_D">
            <div id="u147_div" class=""></div>
            <div id="u147_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_Dt (Rectangle) -->
          <div id="u148" class="ax_default box_1" data-label="THW_Dt">
            <img id="u148_img" class="img " src="/football/public/frontend/images/page_a4/thw_dt_u148.svg"/>
            <div id="u148_text" class="text ">
              <p><span>主勝</span><span> 24%</span></p>
            </div>
          </div>
        </div>

        <!-- DRAW (Group) -->
        <div id="u149" class="ax_default" data-label="DRAW" data-left="407" data-top="340" data-width="225" data-height="40">

          <!-- DRAW_D (Rectangle) -->
          <div id="u150" class="ax_default box_1" data-label="DRAW_D">
            <div id="u150_div" class=""></div>
            <div id="u150_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DRAW_Dt (Rectangle) -->
          <div id="u151" class="ax_default box_1" data-label="DRAW_Dt">
            <img id="u151_img" class="img " src="/football/public/frontend/images/page_a4/draw_dt_u151.svg"/>
            <div id="u151_text" class="text ">
              <p><span>和波 21%</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Logo_Group (Group) -->
      <div id="u152" class="ax_default" data-label="Logo_Group" data-left="375" data-top="130" data-width="623" data-height="146">

        <!-- TA_G (Image) -->
        <div id="u153" class="ax_default image" data-label="TA_G">
          <img id="u153_img" class="img " src="{{ asset($a1s->h_img) }}"/>
          <div id="u153_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TH_G (Image) -->
        <div id="u154" class="ax_default image" data-label="TH_G">
          <img id="u154_img" class="img " src="{{ asset($a1s->g_img) }}"/>
          <div id="u154_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u155" class="ax_default box_2" data-label="Team_Away">
          <div id="u155_div" class=""></div>
          <div id="u155_text" class="text ">
            <p><span>客隊</span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u156" class="ax_default box_2" data-label="Team_Home">
          <div id="u156_div" class=""></div>
          <div id="u156_text" class="text ">
            <p><span>主隊</span></p>
          </div>
        </div>

        <!-- Status (Rectangle) -->
        <div id="u157" class="ax_default box_2" data-label="Status">
          <div id="u157_div" class=""></div>
          <div id="u157_text" class="text ">
            <p><span>未開賽</span></p>
          </div>
        </div>

        <!-- Number (Rectangle) -->
        <div id="u158" class="ax_default box_2" data-label="Number">
          <div id="u158_div" class=""></div>
          <div id="u158_text" class="text ">
            <p><span>36</span></p>
          </div>
        </div>

        <!-- HKJC (Rectangle) -->
        <div id="u159" class="ax_default box_2" data-label="HKJC">
          <div id="u159_div" class=""></div>
          <div id="u159_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足智彩賽事編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u160" class="ax_default box_2" data-label="Date_Time">
          <div id="u160_div" class=""></div>
          <div id="u160_text" class="text ">
            <p><span>2022-03-25 01:45</span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u161" class="ax_default box_2" data-label="Match">
          <div id="u161_div" class=""></div>
          <div id="u161_text" class="text ">
            <p><span>俄羅斯超級聯賽</span></p>
          </div>
        </div>
      </div>

      @endforeach
      @endif

      <!-- Header (Rectangle) -->
      <div id="u162" class="ax_default box_2" data-label="Header">
        <div id="u162_div" class=""></div>
        <div id="u162_text" class="text ">
          <p><span>AI</span><span>模組波膽分析</span></p>
        </div>
      </div>

      <!-- NAVIGATION BAR (Group) -->
      <div id="u163" class="ax_default" data-label="NAVIGATION BAR" data-left="1" data-top="0" data-width="1364" data-height="210">

        <!-- Unnamed (Placeholder) -->
        <div id="u164" class="ax_default placeholder">
          <img id="u164_img" class="img " src="/football/public/frontend/images/page_a4/u164.svg"/>
          <div id="u164_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u165" class="ax_default box_1">
          <div id="u165_div" class=""></div>
          <div id="u165_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u166" class="ax_default box_3">
          <div id="u166_div" class=""></div>
          <div id="u166_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u167" class="ax_default box_3">
          <div id="u167_div" class=""></div>
          <div id="u167_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u168" class="ax_default box_3">
          <div id="u168_div" class=""></div>
          <div id="u168_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u169" class="ax_default box_3">
          <div id="u169_div" class=""></div>
          <div id="u169_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u170" class="ax_default box_3">
          <div id="u170_div" class=""></div>
          <div id="u170_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u171" class="ax_default box_3">
          <div id="u171_div" class=""></div>
          <div id="u171_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u172" class="ax_default box_3">
          <div id="u172_div" class=""></div>
          <div id="u172_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u173" class="ax_default">
          <div id="u173_state0" class="panel_state" data-label="State 1" style="">
            <div id="u173_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u174" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u175" class="ax_default box_3">
                  <div id="u175_div" class=""></div>
                  <div id="u175_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u176" class="ax_default box_3">
                  <div id="u176_div" class=""></div>
                  <div id="u176_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u177" class="ax_default box_3">
                  <div id="u177_div" class=""></div>
                  <div id="u177_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u178" class="ax_default box_3">
                  <img id="u178_img" class="img " src="/football/public/frontend/images/page_a4/u178.svg"/>
                  <div id="u178_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u179" class="ax_default box_3">
                  <div id="u179_div" class=""></div>
                  <div id="u179_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u180" class="ax_default box_3">
                  <div id="u180_div" class=""></div>
                  <div id="u180_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u181" class="ax_default box_3">
                  <div id="u181_div" class=""></div>
                  <div id="u181_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u182" class="ax_default">
          <div id="u182_state0" class="panel_state" data-label="State 1" style="">
            <div id="u182_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u183" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="121" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u184" class="ax_default box_3">
                  <div id="u184_div" class=""></div>
                  <div id="u184_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u185" class="ax_default box_3">
                  <div id="u185_div" class=""></div>
                  <div id="u185_text" class="text ">
                    <p><span>AI模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u186" class="ax_default box_3">
                  <div id="u186_div" class=""></div>
                  <div id="u186_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u187" class="ax_default box_3">
                  <img id="u187_img" class="img " src="/football/public/frontend/images/page_a4/u178.svg"/>
                  <div id="u187_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u188" class="ax_default box_3">
                  <div id="u188_div" class=""></div>
                  <div id="u188_text" class="text ">
                    <p><span>AI模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u189" class="ax_default box_3">
                  <div id="u189_div" class=""></div>
                  <div id="u189_text" class="text ">
                    <p><span>AI模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u190" class="ax_default">
          <div id="u190_state0" class="panel_state" data-label="State 1" style="">
            <div id="u190_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u191" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="135" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u192" class="ax_default box_3">
                  <div id="u192_div" class=""></div>
                  <div id="u192_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u193" class="ax_default box_3">
                  <div id="u193_div" class=""></div>
                  <div id="u193_text" class="text ">
                    <p><span>&nbsp;Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u194" class="ax_default box_3">
                  <div id="u194_div" class=""></div>
                  <div id="u194_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u195" class="ax_default box_3">
                  <img id="u195_img" class="img " src="/football/public/frontend/images/page_a4/u195.svg"/>
                  <div id="u195_text" class="text ">
                    <p><span>AI模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
