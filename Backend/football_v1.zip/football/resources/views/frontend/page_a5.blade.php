﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A5</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/page_a5/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/page_a5/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u668" class="ax_default box_2">
        <div id="u668_div" class=""></div>
        <div id="u668_text" class="text ">
          <p><span style="font-family:&quot;Rockwell-Regular&quot;, &quot;Rockwell&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
        </div>
      </div>

      <!-- Unnamed (Group) -->
      <div id="u669" class="ax_default" data-left="423" data-top="621" data-width="514" data-height="1302">

        <!-- Unnamed (Repeater) -->
        <div id="u670" class="ax_default">
          <script id="u670_script" type="axure-repeater-template">

            <!-- Unnamed (Group) -->
            <div id="u671" class="ax_default u671" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672" class="ax_default box_3 u672">
                <div id="u672_div" class="u672_div"></div>
                <div id="u672_text" class="text u672_text">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673" class="ax_default box_3 u673">
                <div id="u673_div" class="u673_div"></div>
                <div id="u673_text" class="text u673_text">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674" class="ax_default box_3 u674">
                <div id="u674_div" class="u674_div"></div>
                <div id="u674_text" class="text u674_text">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675" class="ax_default box_3 u675">
                <img id="u675_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675_text" class="text u675_text">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676" class="ax_default box_3 u676">
                <div id="u676_div" class="u676_div"></div>
                <div id="u676_text" class="text u676_text">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677" class="ax_default box_3 u677">
                <div id="u677_div" class="u677_div"></div>
                <div id="u677_text" class="text u677_text">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678" class="ax_default box_3 u678">
                <div id="u678_div" class="u678_div"></div>
                <div id="u678_text" class="text u678_text">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679" class="ax_default box_3 u679">
                <div id="u679_div" class="u679_div"></div>
                <div id="u679_text" class="text u679_text">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680" class="ax_default box_3 u680">
                <div id="u680_div" class="u680_div"></div>
                <div id="u680_text" class="text u680_text">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681" class="ax_default box_3 u681">
                <div id="u681_div" class="u681_div"></div>
                <div id="u681_text" class="text u681_text">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682" class="ax_default box_3 u682">
                <div id="u682_div" class="u682_div"></div>
                <div id="u682_text" class="text u682_text">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683" class="ax_default box_3 u683">
                <img id="u683_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683_text" class="text u683_text">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684" class="ax_default box_3 u684">
                <div id="u684_div" class="u684_div"></div>
                <div id="u684_text" class="text u684_text">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </script>
          <div id="u670-1" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-1" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-1" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-1_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-1_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-1" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-1_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-1_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-1" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-1_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-1_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-1" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-1_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-1_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-1" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-1_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-1_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-1" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-1_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-1_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-1" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-1_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-1_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-1" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-1_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-1_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-1" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-1_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-1_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-1" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-1_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-1_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-1" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-1_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-1_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-1" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-1_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-1_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-1" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-1_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-1_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-2" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-2" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-2" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-2_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-2_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-2" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-2_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-2_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-2" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-2_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-2_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-2" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-2_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-2_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-2" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-2_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-2_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-2" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-2_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-2_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-2" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-2_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-2_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-2" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-2_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-2_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-2" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-2_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-2_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-2" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-2_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-2_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-2" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-2_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-2_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-2" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-2_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-2_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-2" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-2_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-2_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-3" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-3" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-3" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-3_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-3_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-3" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-3_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-3_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-3" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-3_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-3_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-3" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-3_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-3_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-3" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-3_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-3_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-3" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-3_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-3_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-3" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-3_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-3_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-3" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-3_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-3_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-3" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-3_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-3_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-3" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-3_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-3_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-3" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-3_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-3_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-3" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-3_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-3_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-3" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-3_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-3_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-4" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-4" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-4" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-4_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-4_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-4" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-4_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-4_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-4" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-4_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-4_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-4" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-4_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-4_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-4" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-4_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-4_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-4" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-4_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-4_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-4" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-4_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-4_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-4" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-4_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-4_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-4" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-4_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-4_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-4" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-4_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-4_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-4" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-4_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-4_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-4" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-4_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-4_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-4" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-4_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-4_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-5" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-5" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-5" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-5_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-5_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-5" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-5_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-5_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-5" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-5_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-5_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-5" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-5_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-5_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-5" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-5_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-5_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-5" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-5_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-5_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-5" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-5_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-5_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-5" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-5_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-5_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-5" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-5_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-5_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-5" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-5_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-5_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-5" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-5_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-5_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-5" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-5_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-5_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-5" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-5_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-5_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-6" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-6" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-6" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-6_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-6_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-6" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-6_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-6_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-6" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-6_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-6_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-6" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-6_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-6_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-6" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-6_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-6_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-6" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-6_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-6_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-6" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-6_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-6_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-6" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-6_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-6_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-6" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-6_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-6_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-6" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-6_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-6_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-6" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-6_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-6_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-6" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-6_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-6_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-6" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-6_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-6_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-7" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-7" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-7" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-7_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-7_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-7" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-7_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-7_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-7" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-7_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-7_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-7" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-7_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-7_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-7" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-7_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-7_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-7" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-7_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-7_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-7" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-7_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-7_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-7" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-7_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-7_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-7" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-7_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-7_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-7" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-7_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-7_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-7" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-7_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-7_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-7" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-7_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-7_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-7" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-7_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-7_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-8" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-8" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-8" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-8_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-8_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-8" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-8_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-8_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-8" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-8_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-8_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-8" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-8_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-8_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-8" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-8_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-8_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-8" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-8_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-8_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-8" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-8_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-8_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-8" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-8_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-8_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-8" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-8_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-8_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-8" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-8_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-8_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-8" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-8_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-8_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-8" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-8_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-8_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-8" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-8_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-8_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-9" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-9" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-9" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-9_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-9_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-9" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-9_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-9_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-9" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-9_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-9_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-9" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-9_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-9_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-9" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-9_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-9_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-9" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-9_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-9_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-9" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-9_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-9_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-9" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-9_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-9_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-9" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-9_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-9_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-9" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-9_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-9_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-9" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-9_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-9_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-9" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-9_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-9_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-9" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-9_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-9_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u670-10" class="preeval" style="width: 514px; height: 126px;">

            <!-- Unnamed (Group) -->
            <div id="u671-10" class="ax_default u671" style="visibility: inherit" data-left="0" data-top="0" data-width="514" data-height="126">

              <!-- Unnamed (Rectangle) -->
              <div id="u672-10" class="ax_default box_3 u672" style="width: 78px; height: 42px; left: 196px; top: 0px;visibility: inherit">
                <div id="u672-10_div" class="u672_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u672-10_text" class="text u672_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u673-10" class="ax_default box_3 u673" style="width: 78px; height: 42px; left: 196px; top: 42px;visibility: inherit">
                <div id="u673-10_div" class="u673_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u673-10_text" class="text u673_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u674-10" class="ax_default box_3 u674" style="width: 78px; height: 42px; left: 196px; top: 84px;visibility: inherit">
                <div id="u674-10_div" class="u674_div" style="width: 78px; height: 42px;visibility: inherit"></div>
                <div id="u674-10_text" class="text u674_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u675-10" class="ax_default box_3 u675" style="width: 196px; height: 126px; left: 0px; top: 0px;visibility: inherit">
                <img id="u675-10_img" class="img u675_img" src="images/page_a5/u675.svg"/>
                <div id="u675-10_text" class="text u675_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u676-10" class="ax_default box_3 u676" style="width: 80px; height: 42px; left: 274px; top: 42px;visibility: inherit">
                <div id="u676-10_div" class="u676_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u676-10_text" class="text u676_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u677-10" class="ax_default box_3 u677" style="width: 80px; height: 42px; left: 274px; top: 0px;visibility: inherit">
                <div id="u677-10_div" class="u677_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u677-10_text" class="text u677_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u678-10" class="ax_default box_3 u678" style="width: 80px; height: 42px; left: 274px; top: 84px;visibility: inherit">
                <div id="u678-10_div" class="u678_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u678-10_text" class="text u678_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u679-10" class="ax_default box_3 u679" style="width: 80px; height: 42px; left: 354px; top: 0px;visibility: inherit">
                <div id="u679-10_div" class="u679_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u679-10_text" class="text u679_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u680-10" class="ax_default box_3 u680" style="width: 80px; height: 42px; left: 354px; top: 42px;visibility: inherit">
                <div id="u680-10_div" class="u680_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u680-10_text" class="text u680_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u681-10" class="ax_default box_3 u681" style="width: 80px; height: 42px; left: 354px; top: 84px;visibility: inherit">
                <div id="u681-10_div" class="u681_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u681-10_text" class="text u681_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u682-10" class="ax_default box_3 u682" style="width: 80px; height: 42px; left: 434px; top: 0px;visibility: inherit">
                <div id="u682-10_div" class="u682_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u682-10_text" class="text u682_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u683-10" class="ax_default box_3 u683" style="width: 80px; height: 42px; left: 434px; top: 42px;visibility: inherit">
                <img id="u683-10_img" class="img u683_img" src="images/page_a5/u683.svg"/>
                <div id="u683-10_text" class="text u683_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u684-10" class="ax_default box_3 u684" style="width: 80px; height: 42px; left: 434px; top: 84px;visibility: inherit">
                <div id="u684-10_div" class="u684_div" style="width: 80px; height: 42px;visibility: inherit"></div>
                <div id="u684-10_text" class="text u684_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Group) -->
        <div id="u685" class="ax_default" data-left="423" data-top="621" data-width="514" data-height="42">

          <!-- Unnamed (Rectangle) -->
          <div id="u686" class="ax_default box_3">
            <div id="u686_div" class=""></div>
            <div id="u686_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u687" class="ax_default box_3">
            <div id="u687_div" class=""></div>
            <div id="u687_text" class="text ">
              <p><span>角球數</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u688" class="ax_default box_3">
            <div id="u688_div" class=""></div>
            <div id="u688_text" class="text ">
              <p><span>最小範圍</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u689" class="ax_default box_3">
            <div id="u689_div" class=""></div>
            <div id="u689_text" class="text ">
              <p><span>最大範圍</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u690" class="ax_default image">
        <img id="u690_img" class="img " src="images/page_a5/u690.png"/>
        <div id="u690_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- footer (Group) -->
      <div id="u691" class="ax_default" data-label="footer" data-left="149" data-top="2025" data-width="1073" data-height="171">

        <!-- Unnamed (Rectangle) -->
        <div id="u692" class="ax_default shape">
          <img id="u692_img" class="img " src="images/page_a4/u40.svg"/>
          <div id="u692_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u693" class="ax_default paragraph">
          <div id="u693_div" class=""></div>
          <div id="u693_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u694" class="ax_default paragraph">
          <div id="u694_div" class=""></div>
          <div id="u694_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u695" class="ax_default paragraph">
          <div id="u695_div" class=""></div>
          <div id="u695_text" class="text ">
            <p><span>問題</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u696" class="ax_default paragraph">
          <div id="u696_div" class=""></div>
          <div id="u696_text" class="text ">
            <p><span>查詢</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u697" class="ax_default paragraph">
          <div id="u697_div" class=""></div>
          <div id="u697_text" class="text ">
            <p><span>意見</span></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u698" class="ax_default icon">
          <img id="u698_img" class="img " src="images/page_a4/u46.svg"/>
          <div id="u698_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u699" class="ax_default icon">
          <img id="u699_img" class="img " src="images/page_a4/u47.svg"/>
          <div id="u699_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u700" class="ax_default box_2 ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u700_div" class=""></div>
        <div id="u700_text" class="text ">
          <p><span style="font-family:&quot;Rockwell-Regular&quot;, &quot;Rockwell&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
        </div>
      </div>

      <!-- Unnamed (Group) -->
      <div id="u701" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Repeater) -->
        <div id="u702" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <script id="u702_script" type="axure-repeater-template">

            <!-- Unnamed (Group) -->
            <div id="u703" class="ax_default u703" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704" class="ax_default box_3 u704">
                <div id="u704_div" class="u704_div"></div>
                <div id="u704_text" class="text u704_text">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705" class="ax_default box_3 u705">
                <div id="u705_div" class="u705_div"></div>
                <div id="u705_text" class="text u705_text">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706" class="ax_default box_3 u706">
                <div id="u706_div" class="u706_div"></div>
                <div id="u706_text" class="text u706_text">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707" class="ax_default box_3 u707">
                <img id="u707_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707_text" class="text u707_text">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708" class="ax_default box_3 u708">
                <div id="u708_div" class="u708_div"></div>
                <div id="u708_text" class="text u708_text">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709" class="ax_default box_3 u709">
                <div id="u709_div" class="u709_div"></div>
                <div id="u709_text" class="text u709_text">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710" class="ax_default box_3 u710">
                <div id="u710_div" class="u710_div"></div>
                <div id="u710_text" class="text u710_text">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711" class="ax_default box_3 u711">
                <div id="u711_div" class="u711_div"></div>
                <div id="u711_text" class="text u711_text">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712" class="ax_default box_3 u712">
                <div id="u712_div" class="u712_div"></div>
                <div id="u712_text" class="text u712_text">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713" class="ax_default box_3 u713">
                <div id="u713_div" class="u713_div"></div>
                <div id="u713_text" class="text u713_text">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714" class="ax_default box_3 u714">
                <div id="u714_div" class="u714_div"></div>
                <div id="u714_text" class="text u714_text">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715" class="ax_default box_3 u715">
                <img id="u715_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715_text" class="text u715_text">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716" class="ax_default box_3 u716">
                <div id="u716_div" class="u716_div"></div>
                <div id="u716_text" class="text u716_text">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </script>
          <div id="u702-1" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-1" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-1" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-1_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-1_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-1" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-1_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-1_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-1" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-1_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-1_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-1" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-1_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-1_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-1" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-1_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-1_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-1" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-1_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-1_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-1" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-1_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-1_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-1" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-1_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-1_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-1" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-1_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-1_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-1" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-1_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-1_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-1" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-1_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-1_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-1" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-1_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-1_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-1" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-1_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-1_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-2" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-2" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-2" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-2_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-2_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-2" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-2_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-2_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-2" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-2_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-2_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-2" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-2_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-2_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-2" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-2_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-2_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-2" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-2_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-2_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-2" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-2_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-2_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-2" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-2_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-2_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-2" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-2_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-2_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-2" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-2_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-2_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-2" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-2_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-2_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-2" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-2_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-2_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-2" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-2_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-2_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-3" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-3" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-3" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-3_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-3_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-3" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-3_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-3_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-3" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-3_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-3_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-3" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-3_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-3_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-3" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-3_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-3_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-3" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-3_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-3_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-3" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-3_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-3_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-3" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-3_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-3_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-3" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-3_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-3_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-3" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-3_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-3_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-3" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-3_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-3_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-3" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-3_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-3_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-3" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-3_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-3_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-4" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-4" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-4" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-4_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-4_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-4" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-4_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-4_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-4" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-4_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-4_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-4" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-4_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-4_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-4" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-4_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-4_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-4" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-4_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-4_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-4" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-4_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-4_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-4" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-4_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-4_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-4" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-4_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-4_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-4" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-4_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-4_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-4" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-4_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-4_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-4" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-4_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-4_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-4" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-4_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-4_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-5" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-5" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-5" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-5_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-5_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-5" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-5_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-5_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-5" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-5_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-5_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-5" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-5_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-5_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-5" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-5_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-5_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-5" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-5_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-5_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-5" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-5_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-5_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-5" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-5_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-5_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-5" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-5_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-5_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-5" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-5_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-5_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-5" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-5_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-5_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-5" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-5_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-5_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-5" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-5_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-5_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-6" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-6" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-6" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-6_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-6_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-6" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-6_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-6_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-6" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-6_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-6_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-6" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-6_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-6_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-6" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-6_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-6_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-6" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-6_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-6_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-6" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-6_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-6_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-6" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-6_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-6_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-6" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-6_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-6_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-6" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-6_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-6_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-6" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-6_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-6_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-6" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-6_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-6_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-6" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-6_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-6_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-7" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-7" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-7" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-7_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-7_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-7" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-7_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-7_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-7" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-7_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-7_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-7" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-7_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-7_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-7" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-7_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-7_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-7" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-7_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-7_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-7" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-7_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-7_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-7" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-7_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-7_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-7" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-7_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-7_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-7" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-7_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-7_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-7" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-7_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-7_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-7" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-7_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-7_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-7" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-7_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-7_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-8" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-8" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-8" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-8_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-8_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-8" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-8_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-8_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-8" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-8_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-8_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-8" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-8_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-8_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-8" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-8_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-8_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-8" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-8_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-8_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-8" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-8_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-8_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-8" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-8_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-8_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-8" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-8_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-8_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-8" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-8_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-8_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-8" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-8_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-8_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-8" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-8_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-8_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-8" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-8_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-8_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-9" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-9" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-9" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-9_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-9_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-9" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-9_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-9_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-9" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-9_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-9_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-9" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-9_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-9_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-9" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-9_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-9_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-9" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-9_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-9_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-9" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-9_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-9_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-9" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-9_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-9_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-9" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-9_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-9_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-9" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-9_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-9_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-9" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-9_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-9_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-9" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-9_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-9_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-9" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-9_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-9_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
          <div id="u702-10" class="preeval" style="width: 367px; height: 93px;">

            <!-- Unnamed (Group) -->
            <div id="u703-10" class="ax_default u703" style="visibility: inherit" data-left="0" data-top="0" data-width="367" data-height="93">

              <!-- Unnamed (Rectangle) -->
              <div id="u704-10" class="ax_default box_3 u704" style="width: 56px; height: 31px; left: 140px; top: 0px;visibility: inherit">
                <div id="u704-10_div" class="u704_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u704-10_text" class="text u704_text" style="visibility: inherit">
                  <p><span>主隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u705-10" class="ax_default box_3 u705" style="width: 56px; height: 31px; left: 140px; top: 31px;visibility: inherit">
                <div id="u705-10_div" class="u705_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u705-10_text" class="text u705_text" style="visibility: inherit">
                  <p><span>客隊</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u706-10" class="ax_default box_3 u706" style="width: 56px; height: 31px; left: 140px; top: 62px;visibility: inherit">
                <div id="u706-10_div" class="u706_div" style="width: 56px; height: 31px;visibility: inherit"></div>
                <div id="u706-10_text" class="text u706_text" style="visibility: inherit">
                  <p><span>總角球</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u707-10" class="ax_default box_3 u707" style="width: 140px; height: 93px; left: 0px; top: 0px;visibility: inherit">
                <img id="u707-10_img" class="img u707_img" src="images/page_a5/u707.svg"/>
                <div id="u707-10_text" class="text u707_text" style="visibility: inherit">
                  <p><span>辛尼特 VS 烏法</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u708-10" class="ax_default box_3 u708" style="width: 57px; height: 31px; left: 196px; top: 31px;visibility: inherit">
                <div id="u708-10_div" class="u708_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u708-10_text" class="text u708_text" style="visibility: inherit">
                  <p><span>8</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u709-10" class="ax_default box_3 u709" style="width: 57px; height: 31px; left: 196px; top: 0px;visibility: inherit">
                <div id="u709-10_div" class="u709_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u709-10_text" class="text u709_text" style="visibility: inherit">
                  <p><span>5</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u710-10" class="ax_default box_3 u710" style="width: 57px; height: 31px; left: 196px; top: 62px;visibility: inherit">
                <div id="u710-10_div" class="u710_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u710-10_text" class="text u710_text" style="visibility: inherit">
                  <p><span>13</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u711-10" class="ax_default box_3 u711" style="width: 57px; height: 31px; left: 253px; top: 0px;visibility: inherit">
                <div id="u711-10_div" class="u711_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u711-10_text" class="text u711_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u712-10" class="ax_default box_3 u712" style="width: 57px; height: 31px; left: 253px; top: 31px;visibility: inherit">
                <div id="u712-10_div" class="u712_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u712-10_text" class="text u712_text" style="visibility: inherit">
                  <p><span>2</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u713-10" class="ax_default box_3 u713" style="width: 57px; height: 31px; left: 253px; top: 62px;visibility: inherit">
                <div id="u713-10_div" class="u713_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u713-10_text" class="text u713_text" style="visibility: inherit">
                  <p><span>4</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u714-10" class="ax_default box_3 u714" style="width: 57px; height: 31px; left: 310px; top: 0px;visibility: inherit">
                <div id="u714-10_div" class="u714_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u714-10_text" class="text u714_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u715-10" class="ax_default box_3 u715" style="width: 57px; height: 31px; left: 310px; top: 31px;visibility: inherit">
                <img id="u715-10_img" class="img u715_img" src="images/page_a5/u715.svg"/>
                <div id="u715-10_text" class="text u715_text" style="visibility: inherit">
                  <p><span>10</span></p>
                </div>
              </div>

              <!-- Unnamed (Rectangle) -->
              <div id="u716-10" class="ax_default box_3 u716" style="width: 57px; height: 31px; left: 310px; top: 62px;visibility: inherit">
                <div id="u716-10_div" class="u716_div" style="width: 57px; height: 31px;visibility: inherit"></div>
                <div id="u716-10_text" class="text u716_text" style="visibility: inherit">
                  <p><span>20</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Group) -->
        <div id="u717" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- Unnamed (Rectangle) -->
          <div id="u718" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u718_div" class=""></div>
            <div id="u718_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u719" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u719_div" class=""></div>
            <div id="u719_text" class="text ">
              <p><span>角球數</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u720" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u720_div" class=""></div>
            <div id="u720_text" class="text ">
              <p><span>最小範圍</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u721" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u721_div" class=""></div>
            <div id="u721_text" class="text ">
              <p><span>最大範圍</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u722" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
        <img id="u722_img" class="img " src="resources/images/transparent.gif"/>
        <div id="u722_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- footer (Group) -->
      <div id="u723" class="ax_default ax_default_unplaced" data-label="footer" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Rectangle) -->
        <div id="u724" class="ax_default shape ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u724_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u724_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#FFFFFF;">香港賽馬會網站</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#5D5D5D;">*外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#FFFFFF;">非法賭博</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#5D5D5D;">已收錄 57152 賽事賠率數據</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#FFFFFF;">問題 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">· </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#FFFFFF;">查詢 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">· </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u725" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u725_div" class=""></div>
          <div id="u725_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u726" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u726_div" class=""></div>
          <div id="u726_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u727" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u727_div" class=""></div>
          <div id="u727_text" class="text ">
            <p><span>問題</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u728" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u728_div" class=""></div>
          <div id="u728_text" class="text ">
            <p><span>查詢</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u729" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u729_div" class=""></div>
          <div id="u729_text" class="text ">
            <p><span>意見</span></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u730" class="ax_default icon ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u730_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u730_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u731" class="ax_default icon ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u731_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u731_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- NAVIGATION BAR (Group) -->
      <div id="u732" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1364" data-height="210">

        <!-- Unnamed (Placeholder) -->
        <div id="u733" class="ax_default placeholder">
          <img id="u733_img" class="img " src="images/page_a3/u534.svg"/>
          <div id="u733_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u734" class="ax_default box_1">
          <div id="u734_div" class=""></div>
          <div id="u734_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u735" class="ax_default box_3">
          <div id="u735_div" class=""></div>
          <div id="u735_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u736" class="ax_default box_3">
          <div id="u736_div" class=""></div>
          <div id="u736_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u737" class="ax_default box_3">
          <div id="u737_div" class=""></div>
          <div id="u737_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u738" class="ax_default box_3">
          <div id="u738_div" class=""></div>
          <div id="u738_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u739" class="ax_default box_3">
          <div id="u739_div" class=""></div>
          <div id="u739_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u740" class="ax_default box_3">
          <div id="u740_div" class=""></div>
          <div id="u740_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u741" class="ax_default box_3">
          <div id="u741_div" class=""></div>
          <div id="u741_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u742" class="ax_default">
          <div id="u742_state0" class="panel_state" data-label="State 1" style="">
            <div id="u742_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u743" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u744" class="ax_default box_3">
                  <div id="u744_div" class=""></div>
                  <div id="u744_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u745" class="ax_default box_3">
                  <div id="u745_div" class=""></div>
                  <div id="u745_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u746" class="ax_default box_3">
                  <div id="u746_div" class=""></div>
                  <div id="u746_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u747" class="ax_default box_3">
                  <img id="u747_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u747_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u748" class="ax_default box_3">
                  <div id="u748_div" class=""></div>
                  <div id="u748_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u749" class="ax_default box_3">
                  <div id="u749_div" class=""></div>
                  <div id="u749_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u750" class="ax_default box_3">
                  <div id="u750_div" class=""></div>
                  <div id="u750_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u751" class="ax_default">
          <div id="u751_state0" class="panel_state" data-label="State 1" style="">
            <div id="u751_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u752" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="121" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u753" class="ax_default box_3">
                  <div id="u753_div" class=""></div>
                  <div id="u753_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u754" class="ax_default box_3">
                  <div id="u754_div" class=""></div>
                  <div id="u754_text" class="text ">
                    <p><span>AI模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u755" class="ax_default box_3">
                  <div id="u755_div" class=""></div>
                  <div id="u755_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u756" class="ax_default box_3">
                  <img id="u756_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u756_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u757" class="ax_default box_3">
                  <div id="u757_div" class=""></div>
                  <div id="u757_text" class="text ">
                    <p><span>AI模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u758" class="ax_default box_3">
                  <div id="u758_div" class=""></div>
                  <div id="u758_text" class="text ">
                    <p><span>AI模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u759" class="ax_default">
          <div id="u759_state0" class="panel_state" data-label="State 1" style="">
            <div id="u759_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u760" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="135" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u761" class="ax_default box_3">
                  <div id="u761_div" class=""></div>
                  <div id="u761_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u762" class="ax_default box_3">
                  <div id="u762_div" class=""></div>
                  <div id="u762_text" class="text ">
                    <p><span>&nbsp;Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u763" class="ax_default box_3">
                  <div id="u763_div" class=""></div>
                  <div id="u763_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u764" class="ax_default box_3">
                  <img id="u764_img" class="img " src="images/page_a4/u195.svg"/>
                  <div id="u764_text" class="text ">
                    <p><span>AI模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u765" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u765_state0" class="panel_state" data-label="State 1" style="">
          <div id="u765_state0_content" class="panel_state_content">

            <!-- 1ST SUB (Group) -->
            <div id="u766" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u767" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u767_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u767_state0_content" class="panel_state_content">

                    <!-- HOME_SUBMENU (Group) -->
                    <div id="u768" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u769" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u769_div" class=""></div>
                        <div id="u769_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u770" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u770_div" class=""></div>
                        <div id="u770_text" class="text ">
                          <p><span>&nbsp;簡介</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u771" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u771_div" class=""></div>
                        <div id="u771_text" class="text ">
                          <p><span>&nbsp;如何應用</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u772" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u772_img" class="img " src="resources/images/transparent.gif"/>
                        <div id="u772_text" class="text ">
                          <p><span>&nbsp; 為何我們</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u773" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u773_div" class=""></div>
                        <div id="u773_text" class="text ">
                          <p><span>&nbsp; 馬上註冊</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u774" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u774_div" class=""></div>
                        <div id="u774_text" class="text ">
                          <p><span>&nbsp; 用戶推薦</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u775" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u775_div" class=""></div>
                        <div id="u775_text" class="text ">
                          <p><span>&nbsp; 風險披露</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u776" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u776_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u776_text" class="text ">
                  <p><span>首頁</span></p>
                </div>
              </div>
            </div>

            <!-- 2ND SUB (Group) -->
            <div id="u777" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u778" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u778_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u778_text" class="text ">
                  <p><span>足球AI模組分析</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u779" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u779_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u779_state0_content" class="panel_state_content">

                    <!-- AI_SUBMENU (Group) -->
                    <div id="u780" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u781" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u781_div" class=""></div>
                        <div id="u781_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u782" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u782_img" class="img " src="resources/images/transparent.gif"/>
                        <div id="u782_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u783" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u783_div" class=""></div>
                        <div id="u783_text" class="text ">
                          <p><span>&nbsp;綜合網民數據結果</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u784" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u784_img" class="img " src="resources/images/transparent.gif"/>
                        <div id="u784_text" class="text ">
                          <p><span>&nbsp;值博率模組分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u785" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u785_div" class=""></div>
                        <div id="u785_text" class="text ">
                          <p><span>&nbsp; AI模組波膽分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u786" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u786_div" class=""></div>
                        <div id="u786_text" class="text ">
                          <p><span>&nbsp;AI模組分析大小角</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 3RD SUB (Group) -->
            <div id="u787" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u788" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u788_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u788_text" class="text ">
                  <p><span>Futra是日精選</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u789" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u789_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u789_state0_content" class="panel_state_content">

                    <!-- FUTRA_SUBMENU (Group) -->
                    <div id="u790" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u791" class="ax_default box_3">
                        <div id="u791_div" class=""></div>
                        <div id="u791_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u792" class="ax_default box_3">
                        <img id="u792_img" class="img " src="images/page_a4/u28.svg"/>
                        <div id="u792_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u793" class="ax_default box_3">
                        <div id="u793_div" class=""></div>
                        <div id="u793_text" class="text ">
                          <p><span>爆冷精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u794" class="ax_default box_3">
                        <img id="u794_img" class="img " src="images/page_a4/u30.svg"/>
                        <div id="u794_text" class="text ">
                          <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u795" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u795_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u795_text" class="text ">
                <p><span>為何我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u796" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u796_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u796_text" class="text ">
                <p><span>聯絡我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u797" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u797_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u797_text" class="text ">
                <p><span>會員中心</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u798" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u798_img" class="img " src="resources/images/transparent.gif"/>
              <div id="u798_text" class="text ">
                <p><span>登入</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Top Menu_M (Group) -->
      <div id="u799" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Placeholder) -->
        <div id="u800" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u800_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u800_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u801" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u801_div" class=""></div>
          <div id="u801_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u802" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u802_div" class=""></div>
          <div id="u802_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
