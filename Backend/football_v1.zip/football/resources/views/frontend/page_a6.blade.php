﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A6</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/page_a6/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/page_a6/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- footer (Group) -->
      <div id="u803" class="ax_default ax_default_unplaced" data-label="footer" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Rectangle) -->
        <div id="u804" class="ax_default shape ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u804_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u804_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u805" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u805_div" class=""></div>
          <div id="u805_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u806" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u806_div" class=""></div>
          <div id="u806_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Group) -->
        <div id="u807" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- Unnamed (Rectangle) -->
          <div id="u808" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u808_div" class=""></div>
            <div id="u808_text" class="text ">
              <p><span>問題</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u809" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u809_div" class=""></div>
            <div id="u809_text" class="text ">
              <p><span>查詢</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u810" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u810_div" class=""></div>
            <div id="u810_text" class="text ">
              <p><span>意見</span></p>
            </div>
          </div>

          <!-- Unnamed (Shape) -->
          <div id="u811" class="ax_default icon ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u811_img" class="img " src="resources/images/transparent.gif"/>
            <div id="u811_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Shape) -->
          <div id="u812" class="ax_default icon ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u812_img" class="img " src="resources/images/transparent.gif"/>
            <div id="u812_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Button_Group (Group) -->
      <div id="u813" class="ax_default ax_default_unplaced" data-label="Button_Group" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">
      </div>

      <!-- Unnamed (Image) -->
      <div id="u814" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
        <img id="u814_img" class="img " src="resources/images/transparent.gif"/>
        <div id="u814_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Picked_db_M (Group) -->
      <div id="u815" class="ax_default ax_default_unplaced" data-label="Picked_db_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Picked_Repeater (Repeater) -->
        <div id="u816" class="ax_default ax_default_unplaced" data-label="Picked_Repeater" style="display:none; visibility: hidden">
          <script id="u816_script" type="axure-repeater-template" data-label="Picked_Repeater">

            <!-- Predict_menu (Droplist) -->
            <div id="u817" class="ax_default droplist u817" data-label="Predict_menu">
              <div id="u817_div" class="u817_div"></div>
              <select id="u817_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818" class="ax_default paragraph u818" data-label="bold_0a">
              <div id="u818_div" class="u818_div"></div>
              <div id="u818_text" class="text u818_text">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">&nbsp;羅斯托夫 VS</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;"> PFC</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">索契</span></p>
              </div>
            </div>
          </script>
          <div id="u816-1" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-1" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-1_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-1_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-1" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-1_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-1_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-2" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-2" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-2_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-2_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-2" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-2_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-2_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-3" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-3" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-3_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-3_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-3" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-3_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-3_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-4" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-4" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-4_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-4_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-4" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-4_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-4_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-5" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-5" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-5_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-5_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-5" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-5_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-5_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-6" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-6" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-6_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-6_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-6" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-6_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-6_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-7" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-7" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-7_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-7_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-7" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-7_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-7_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-8" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-8" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-8_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-8_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-8" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-8_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-8_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-9" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-9" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-9_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-9_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-9" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-9_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-9_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u816-10" class="preeval" style="width: 310px; height: 37px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u817-10" class="ax_default droplist u817" data-label="Predict_menu" style="width: 123px; height: 36px; left: 187px; top: 1px;visibility: inherit">
              <div id="u817-10_div" class="u817_div" style="width: 123px; height: 36px;visibility: inherit"></div>
              <select id="u817-10_input" class="u817_input">
                <option class="u817_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u817_input_option" value="主勝">主勝</option>
                <option class="u817_input_option" value="客勝">客勝</option>
                <option class="u817_input_option" value="和局">和局</option>
                <option class="u817_input_option" value="總角球大">總角球大</option>
                <option class="u817_input_option" value="總角球小">總角球小</option>
                <option class="u817_input_option" value="總入球大">總入球大</option>
                <option class="u817_input_option" value="總入球小">總入球小</option>
                <option class="u817_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u817_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u817_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u817_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u817_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u817_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u817_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u817_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u818-10" class="ax_default paragraph u818" data-label="bold_0a" style="width: 187px; height: 36px; left: 0px; top: 1px;visibility: inherit">
              <div id="u818-10_div" class="u818_div" style="width: 187px; height: 36px;visibility: inherit"></div>
              <div id="u818-10_text" class="text u818_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Table_Group_M (Group) -->
      <div id="u819" class="ax_default ax_default_unplaced" data-label="Table_Group_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Items_Group (Group) -->
        <div id="u820" class="ax_default ax_default_unplaced" data-label="Items_Group" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- 10 (Rectangle) -->
          <div id="u821" class="ax_default paragraph ax_default_unplaced" data-label="10" style="display:none; visibility: hidden">
            <div id="u821_div" class=""></div>
            <div id="u821_text" class="text ">
              <p><span>10</span></p>
            </div>
          </div>

          <!-- 9 (Rectangle) -->
          <div id="u822" class="ax_default paragraph ax_default_unplaced" data-label="9" style="display:none; visibility: hidden">
            <div id="u822_div" class=""></div>
            <div id="u822_text" class="text ">
              <p><span>9</span></p>
            </div>
          </div>

          <!-- 8 (Rectangle) -->
          <div id="u823" class="ax_default paragraph ax_default_unplaced" data-label="8" style="display:none; visibility: hidden">
            <div id="u823_div" class=""></div>
            <div id="u823_text" class="text ">
              <p><span>8</span></p>
            </div>
          </div>

          <!-- 7 (Rectangle) -->
          <div id="u824" class="ax_default paragraph ax_default_unplaced" data-label="7" style="display:none; visibility: hidden">
            <div id="u824_div" class=""></div>
            <div id="u824_text" class="text ">
              <p><span>7</span></p>
            </div>
          </div>

          <!-- 6 (Rectangle) -->
          <div id="u825" class="ax_default paragraph ax_default_unplaced" data-label="6" style="display:none; visibility: hidden">
            <div id="u825_div" class=""></div>
            <div id="u825_text" class="text ">
              <p><span>6</span></p>
            </div>
          </div>

          <!-- 5 (Rectangle) -->
          <div id="u826" class="ax_default paragraph ax_default_unplaced" data-label="5" style="display:none; visibility: hidden">
            <div id="u826_div" class=""></div>
            <div id="u826_text" class="text ">
              <p><span>5</span></p>
            </div>
          </div>

          <!-- 4 (Rectangle) -->
          <div id="u827" class="ax_default paragraph ax_default_unplaced" data-label="4" style="display:none; visibility: hidden">
            <div id="u827_div" class=""></div>
            <div id="u827_text" class="text ">
              <p><span>4</span></p>
            </div>
          </div>

          <!-- 3 (Rectangle) -->
          <div id="u828" class="ax_default paragraph ax_default_unplaced" data-label="3" style="display:none; visibility: hidden">
            <div id="u828_div" class=""></div>
            <div id="u828_text" class="text ">
              <p><span>3</span></p>
            </div>
          </div>

          <!-- 2 (Rectangle) -->
          <div id="u829" class="ax_default paragraph ax_default_unplaced" data-label="2" style="display:none; visibility: hidden">
            <div id="u829_div" class=""></div>
            <div id="u829_text" class="text ">
              <p><span>2</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u830" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u830_div" class=""></div>
            <div id="u830_text" class="text ">
              <p><span>1</span></p>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u831" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u831_div" class=""></div>
          <div id="u831_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u832" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u832_div" class=""></div>
          <div id="u832_text" class="text ">
            <p><span>預測結果</span></p>
          </div>
        </div>

        <!-- 比賽場次 (Rectangle) -->
        <div id="u833" class="ax_default paragraph ax_default_unplaced" data-label="比賽場次" style="display:none; visibility: hidden">
          <div id="u833_div" class=""></div>
          <div id="u833_text" class="text ">
            <p><span>比賽場次</span></p>
          </div>
        </div>

        <!-- Items (Rectangle) -->
        <div id="u834" class="ax_default paragraph ax_default_unplaced" data-label="Items" style="display:none; visibility: hidden">
          <div id="u834_div" class=""></div>
          <div id="u834_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u835" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
        <img id="u835_img" class="img " src="resources/images/transparent.gif"/>
        <div id="u835_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Picked_M (Rectangle) -->
      <div id="u836" class="ax_default box_2 ax_default_unplaced" data-label="Picked_M" style="display:none; visibility: hidden">
        <div id="u836_div" class=""></div>
        <div id="u836_text" class="text ">
          <p><span style="font-family:&quot;Rockwell-Regular&quot;, &quot;Rockwell&quot;, sans-serif;">Futra 是日</span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">精選</span><span style="font-family:&quot;Rockwell-Regular&quot;, &quot;Rockwell&quot;, sans-serif;"> – </span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">羅斯托夫</span></p>
        </div>
      </div>

      <!-- Top Menu_M (Group) -->
      <div id="u837" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u838" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u838_state0" class="panel_state" data-label="State 1" style="">
            <div id="u838_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u839" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u840" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u840_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u840_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u841" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u842" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u842_div" class=""></div>
                          <div id="u842_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u843" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u843_div" class=""></div>
                          <div id="u843_text" class="text ">
                            <p><span>&nbsp;簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u844" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u844_div" class=""></div>
                          <div id="u844_text" class="text ">
                            <p><span>&nbsp;如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u845" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u845_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u845_text" class="text ">
                            <p><span>&nbsp; 為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u846" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u846_div" class=""></div>
                          <div id="u846_text" class="text ">
                            <p><span>&nbsp; 馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u847" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u847_div" class=""></div>
                          <div id="u847_text" class="text ">
                            <p><span>&nbsp; 用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u848" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u848_div" class=""></div>
                          <div id="u848_text" class="text ">
                            <p><span>&nbsp; 風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u849" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u849_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u849_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u850" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u851" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u851_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u851_text" class="text ">
                    <p><span>足球AI模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u852" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u852_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u852_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u853" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u854" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u854_div" class=""></div>
                          <div id="u854_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u855" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u855_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u855_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u856" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u856_div" class=""></div>
                          <div id="u856_text" class="text ">
                            <p><span>&nbsp;綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u857" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u857_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u857_text" class="text ">
                            <p><span>&nbsp;值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u858" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u858_div" class=""></div>
                          <div id="u858_text" class="text ">
                            <p><span>&nbsp; AI模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u859" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u859_div" class=""></div>
                          <div id="u859_text" class="text ">
                            <p><span>&nbsp;AI模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u860" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u861" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u861_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u861_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u862" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u862_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u862_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u863" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u864" class="ax_default box_3">
                          <div id="u864_div" class=""></div>
                          <div id="u864_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u865" class="ax_default box_3">
                          <img id="u865_img" class="img " src="images/page_a4/u28.svg"/>
                          <div id="u865_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u866" class="ax_default box_3">
                          <div id="u866_div" class=""></div>
                          <div id="u866_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u867" class="ax_default box_3">
                          <img id="u867_img" class="img " src="images/page_a4/u30.svg"/>
                          <div id="u867_text" class="text ">
                            <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u868" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u868_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u868_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u869" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u869_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u869_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u870" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u870_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u870_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u871" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u871_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u871_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Top Menu_M (Group) -->
        <div id="u872" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- Unnamed (Placeholder) -->
          <div id="u873" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u873_img" class="img " src="resources/images/transparent.gif"/>
            <div id="u873_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u874" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u874_div" class=""></div>
            <div id="u874_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u875" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u875_div" class=""></div>
            <div id="u875_text" class="text ">
              <p><span>MENU</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- footer (Group) -->
      <div id="u876" class="ax_default" data-label="footer" data-left="150" data-top="651" data-width="1073" data-height="171">

        <!-- Unnamed (Rectangle) -->
        <div id="u877" class="ax_default shape">
          <img id="u877_img" class="img " src="images/page_a4/u40.svg"/>
          <div id="u877_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u878" class="ax_default paragraph">
          <div id="u878_div" class=""></div>
          <div id="u878_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u879" class="ax_default paragraph">
          <div id="u879_div" class=""></div>
          <div id="u879_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u880" class="ax_default paragraph">
          <div id="u880_div" class=""></div>
          <div id="u880_text" class="text ">
            <p><span>問題</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u881" class="ax_default paragraph">
          <div id="u881_div" class=""></div>
          <div id="u881_text" class="text ">
            <p><span>查詢</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u882" class="ax_default paragraph">
          <div id="u882_div" class=""></div>
          <div id="u882_text" class="text ">
            <p><span>意見</span></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u883" class="ax_default icon">
          <img id="u883_img" class="img " src="images/page_a4/u46.svg"/>
          <div id="u883_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u884" class="ax_default icon">
          <img id="u884_img" class="img " src="images/page_a4/u47.svg"/>
          <div id="u884_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Button_Group (Group) -->
      <div id="u885" class="ax_default" data-label="Button_Group" data-left="0" data-top="0" data-width="0" data-height="0">
      </div>

      <!-- Unnamed (Image) -->
      <div id="u886" class="ax_default image">
        <img id="u886_img" class="img " src="images/page_a6/u886.svg"/>
        <div id="u886_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Table_Group (Group) -->
      <div id="u887" class="ax_default" data-label="Table_Group" data-left="151" data-top="173" data-width="525" data-height="441">

        <!-- Table_base (Rectangle) -->
        <div id="u888" class="ax_default box_2" data-label="Table_base">
          <div id="u888_div" class=""></div>
          <div id="u888_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Picked_db (Group) -->
        <div id="u889" class="ax_default" data-label="Picked_db" data-left="246" data-top="213" data-width="430" data-height="400">

          <!-- Picked_Repeater (Repeater) -->
          <div id="u890" class="ax_default" data-label="Picked_Repeater">
            <script id="u890_script" type="axure-repeater-template" data-label="Picked_Repeater">

              <!-- Predict_menu (Droplist) -->
              <div id="u891" class="ax_default droplist u891" data-label="Predict_menu">
                <div id="u891_div" class="u891_div"></div>
                <select id="u891_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892" class="ax_default paragraph u892" data-label="bold_0a">
                <div id="u892_div" class="u892_div"></div>
                <div id="u892_text" class="text u892_text">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">&nbsp;羅斯托夫 VS</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;"> PFC</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">索契</span></p>
                </div>
              </div>
            </script>
            <div id="u890-1" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-1" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-1_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-1_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-1" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-1_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-1_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-2" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-2" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-2_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-2_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-2" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-2_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-2_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-3" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-3" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-3_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-3_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-3" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-3_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-3_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-4" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-4" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-4_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-4_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-4" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-4_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-4_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-5" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-5" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-5_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-5_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-5" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-5_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-5_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-6" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-6" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-6_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-6_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-6" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-6_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-6_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-7" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-7" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-7_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-7_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-7" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-7_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-7_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-8" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-8" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-8_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-8_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-8" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-8_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-8_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-9" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-9" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-9_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-9_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-9" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-9_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-9_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
            <div id="u890-10" class="preeval" style="width: 430px; height: 40px;">

              <!-- Predict_menu (Droplist) -->
              <div id="u891-10" class="ax_default droplist u891" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
                <div id="u891-10_div" class="u891_div" style="width: 170px; height: 40px;visibility: inherit"></div>
                <select id="u891-10_input" class="u891_input">
                  <option class="u891_input_option" value="預測結果選擇">預測結果選擇</option>
                  <option class="u891_input_option" value="主勝">主勝</option>
                  <option class="u891_input_option" value="客勝">客勝</option>
                  <option class="u891_input_option" value="和局">和局</option>
                  <option class="u891_input_option" value="總角球大">總角球大</option>
                  <option class="u891_input_option" value="總角球小">總角球小</option>
                  <option class="u891_input_option" value="總入球大">總入球大</option>
                  <option class="u891_input_option" value="總入球小">總入球小</option>
                  <option class="u891_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                  <option class="u891_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                  <option class="u891_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                  <option class="u891_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                  <option class="u891_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                  <option class="u891_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                  <option class="u891_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
                </select>
              </div>

              <!-- bold_0a (Rectangle) -->
              <div id="u892-10" class="ax_default paragraph u892" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
                <div id="u892-10_div" class="u892_div" style="width: 260px; height: 40px;visibility: inherit"></div>
                <div id="u892-10_text" class="text u892_text" style="visibility: inherit">
                  <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">羅斯托夫&nbsp; VS PFC索契</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Table (Group) -->
        <div id="u893" class="ax_default" data-label="Table" data-left="151" data-top="173" data-width="525" data-height="441">

          <!-- Items_Group (Group) -->
          <div id="u894" class="ax_default" data-label="Items_Group" data-left="151" data-top="214" data-width="95" data-height="400">

            <!-- 10 (Rectangle) -->
            <div id="u895" class="ax_default paragraph" data-label="10">
              <div id="u895_div" class=""></div>
              <div id="u895_text" class="text ">
                <p><span>10</span></p>
              </div>
            </div>

            <!-- 9 (Rectangle) -->
            <div id="u896" class="ax_default paragraph" data-label="9">
              <div id="u896_div" class=""></div>
              <div id="u896_text" class="text ">
                <p><span>9</span></p>
              </div>
            </div>

            <!-- 8 (Rectangle) -->
            <div id="u897" class="ax_default paragraph" data-label="8">
              <div id="u897_div" class=""></div>
              <div id="u897_text" class="text ">
                <p><span>8</span></p>
              </div>
            </div>

            <!-- 7 (Rectangle) -->
            <div id="u898" class="ax_default paragraph" data-label="7">
              <div id="u898_div" class=""></div>
              <div id="u898_text" class="text ">
                <p><span>7</span></p>
              </div>
            </div>

            <!-- 6 (Rectangle) -->
            <div id="u899" class="ax_default paragraph" data-label="6">
              <div id="u899_div" class=""></div>
              <div id="u899_text" class="text ">
                <p><span>6</span></p>
              </div>
            </div>

            <!-- 5 (Rectangle) -->
            <div id="u900" class="ax_default paragraph" data-label="5">
              <div id="u900_div" class=""></div>
              <div id="u900_text" class="text ">
                <p><span>5</span></p>
              </div>
            </div>

            <!-- 4 (Rectangle) -->
            <div id="u901" class="ax_default paragraph" data-label="4">
              <div id="u901_div" class=""></div>
              <div id="u901_text" class="text ">
                <p><span>4</span></p>
              </div>
            </div>

            <!-- 3 (Rectangle) -->
            <div id="u902" class="ax_default paragraph" data-label="3">
              <div id="u902_div" class=""></div>
              <div id="u902_text" class="text ">
                <p><span>3</span></p>
              </div>
            </div>

            <!-- 2 (Rectangle) -->
            <div id="u903" class="ax_default paragraph" data-label="2">
              <div id="u903_div" class=""></div>
              <div id="u903_text" class="text ">
                <p><span>2</span></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u904" class="ax_default paragraph">
              <div id="u904_div" class=""></div>
              <div id="u904_text" class="text ">
                <p><span>1</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u905" class="ax_default box_3">
            <div id="u905_div" class=""></div>
            <div id="u905_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u906" class="ax_default paragraph">
            <div id="u906_div" class=""></div>
            <div id="u906_text" class="text ">
              <p><span>預測結果</span></p>
            </div>
          </div>

          <!-- 比賽場次 (Rectangle) -->
          <div id="u907" class="ax_default paragraph" data-label="比賽場次">
            <div id="u907_div" class=""></div>
            <div id="u907_text" class="text ">
              <p><span>比賽場次</span></p>
            </div>
          </div>

          <!-- Items (Rectangle) -->
          <div id="u908" class="ax_default paragraph" data-label="Items">
            <div id="u908_div" class=""></div>
            <div id="u908_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u909" class="ax_default image">
        <img id="u909_img" class="img " src="images/page_a4/ta_g_u153.png"/>
        <div id="u909_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Picked (Rectangle) -->
      <div id="u910" class="ax_default box_2" data-label="Picked">
        <div id="u910_div" class=""></div>
        <div id="u910_text" class="text ">
          <p><span style="font-family:&quot;Rockwell-Regular&quot;, &quot;Rockwell&quot;, sans-serif;">Futra </span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">是日精選</span><span style="font-family:&quot;Rockwell-Regular&quot;, &quot;Rockwell&quot;, sans-serif;"> – </span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">羅斯托夫</span></p>
        </div>
      </div>

      <!-- NAVIGATION BAR (Group) -->
      <div id="u911" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1364" data-height="210">

        <!-- Unnamed (Placeholder) -->
        <div id="u912" class="ax_default placeholder">
          <img id="u912_img" class="img " src="images/page_a3/u534.svg"/>
          <div id="u912_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u913" class="ax_default box_1">
          <div id="u913_div" class=""></div>
          <div id="u913_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u914" class="ax_default box_3">
          <div id="u914_div" class=""></div>
          <div id="u914_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u915" class="ax_default box_3">
          <div id="u915_div" class=""></div>
          <div id="u915_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u916" class="ax_default box_3">
          <div id="u916_div" class=""></div>
          <div id="u916_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u917" class="ax_default box_3">
          <div id="u917_div" class=""></div>
          <div id="u917_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u918" class="ax_default box_3">
          <div id="u918_div" class=""></div>
          <div id="u918_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u919" class="ax_default box_3">
          <div id="u919_div" class=""></div>
          <div id="u919_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u920" class="ax_default box_3">
          <div id="u920_div" class=""></div>
          <div id="u920_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u921" class="ax_default">
          <div id="u921_state0" class="panel_state" data-label="State 1" style="">
            <div id="u921_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u922" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u923" class="ax_default box_3">
                  <div id="u923_div" class=""></div>
                  <div id="u923_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u924" class="ax_default box_3">
                  <div id="u924_div" class=""></div>
                  <div id="u924_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u925" class="ax_default box_3">
                  <div id="u925_div" class=""></div>
                  <div id="u925_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u926" class="ax_default box_3">
                  <img id="u926_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u926_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u927" class="ax_default box_3">
                  <div id="u927_div" class=""></div>
                  <div id="u927_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u928" class="ax_default box_3">
                  <div id="u928_div" class=""></div>
                  <div id="u928_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u929" class="ax_default box_3">
                  <div id="u929_div" class=""></div>
                  <div id="u929_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u930" class="ax_default">
          <div id="u930_state0" class="panel_state" data-label="State 1" style="">
            <div id="u930_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u931" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="121" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u932" class="ax_default box_3">
                  <div id="u932_div" class=""></div>
                  <div id="u932_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u933" class="ax_default box_3">
                  <div id="u933_div" class=""></div>
                  <div id="u933_text" class="text ">
                    <p><span>AI模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u934" class="ax_default box_3">
                  <div id="u934_div" class=""></div>
                  <div id="u934_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u935" class="ax_default box_3">
                  <img id="u935_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u935_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u936" class="ax_default box_3">
                  <div id="u936_div" class=""></div>
                  <div id="u936_text" class="text ">
                    <p><span>AI模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u937" class="ax_default box_3">
                  <div id="u937_div" class=""></div>
                  <div id="u937_text" class="text ">
                    <p><span>AI模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u938" class="ax_default">
          <div id="u938_state0" class="panel_state" data-label="State 1" style="">
            <div id="u938_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u939" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="135" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u940" class="ax_default box_3">
                  <div id="u940_div" class=""></div>
                  <div id="u940_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u941" class="ax_default box_3">
                  <div id="u941_div" class=""></div>
                  <div id="u941_text" class="text ">
                    <p><span>&nbsp;Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u942" class="ax_default box_3">
                  <div id="u942_div" class=""></div>
                  <div id="u942_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u943" class="ax_default box_3">
                  <img id="u943_img" class="img " src="images/page_a4/u195.svg"/>
                  <div id="u943_text" class="text ">
                    <p><span>AI模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
