﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A7</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/page_a7/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/page_a7/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- footer (Group) -->
      <div id="u944" class="ax_default ax_default_unplaced" data-label="footer" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Rectangle) -->
        <div id="u945" class="ax_default shape ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u945_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u945_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u946" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u946_div" class=""></div>
          <div id="u946_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u947" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u947_div" class=""></div>
          <div id="u947_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Group) -->
        <div id="u948" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- Unnamed (Rectangle) -->
          <div id="u949" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u949_div" class=""></div>
            <div id="u949_text" class="text ">
              <p><span>問題</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u950" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u950_div" class=""></div>
            <div id="u950_text" class="text ">
              <p><span>查詢</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u951" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u951_div" class=""></div>
            <div id="u951_text" class="text ">
              <p><span>意見</span></p>
            </div>
          </div>

          <!-- Unnamed (Shape) -->
          <div id="u952" class="ax_default icon ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u952_img" class="img " src="resources/images/transparent.gif"/>
            <div id="u952_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Shape) -->
          <div id="u953" class="ax_default icon ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u953_img" class="img " src="resources/images/transparent.gif"/>
            <div id="u953_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>
        </div>
      </div>

      <!-- 足球AI模組分析 (Rectangle) -->
      <div id="u954" class="ax_default box_3 ax_default_unplaced" data-label="足球AI模組分析" style="display:none; visibility: hidden">
        <div id="u954_div" class=""></div>
        <div id="u954_text" class="text ">
          <p><span>足球AI模組分析 &gt;&gt;&gt;</span></p>
        </div>
      </div>

      <!-- Unnamed (Hot Spot) -->
      <div id="u955" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
      </div>

      <!-- Unnamed (Image) -->
      <div id="u956" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
        <img id="u956_img" class="img " src="resources/images/transparent.gif"/>
        <div id="u956_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- 爆冷精選_DB (Group) -->
      <div id="u957" class="ax_default ax_default_unplaced" data-label="爆冷精選_DB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- 爆冷精選_Repeater (Repeater) -->
        <div id="u958" class="ax_default ax_default_unplaced" data-label="爆冷精選_Repeater" style="display:none; visibility: hidden">
          <script id="u958_script" type="axure-repeater-template" data-label="爆冷精選_Repeater">

            <!-- Predict_menu (Droplist) -->
            <div id="u959" class="ax_default droplist u959" data-label="Predict_menu">
              <div id="u959_div" class="u959_div"></div>
              <select id="u959_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960" class="ax_default paragraph u960" data-label="bold_0a">
              <div id="u960_div" class="u960_div"></div>
              <div id="u960_text" class="text u960_text">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;"> PFC</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">索契</span></p>
              </div>
            </div>
          </script>
          <div id="u958-1" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-1" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-1_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-1_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-1" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-1_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-1_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-2" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-2" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-2_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-2_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-2" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-2_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-2_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-3" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-3" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-3_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-3_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-3" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-3_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-3_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-4" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-4" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-4_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-4_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-4" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-4_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-4_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-5" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-5" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-5_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-5_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-5" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-5_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-5_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-6" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-6" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-6_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-6_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-6" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-6_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-6_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-7" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-7" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-7_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-7_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-7" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-7_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-7_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-8" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-8" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-8_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-8_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-8" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-8_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-8_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-9" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-9" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-9_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-9_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-9" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-9_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-9_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u958-10" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u959-10" class="ax_default droplist u959" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u959-10_div" class="u959_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u959-10_input" class="u959_input">
                <option class="u959_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u959_input_option" value="主勝">主勝</option>
                <option class="u959_input_option" value="客勝">客勝</option>
                <option class="u959_input_option" value="和局">和局</option>
                <option class="u959_input_option" value="總角球大">總角球大</option>
                <option class="u959_input_option" value="總角球小">總角球小</option>
                <option class="u959_input_option" value="總入球大">總入球大</option>
                <option class="u959_input_option" value="總入球小">總入球小</option>
                <option class="u959_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u959_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u959_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u959_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u959_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u959_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u959_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u959_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u960-10" class="ax_default paragraph u960" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u960-10_div" class="u960_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u960-10_text" class="text u960_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Table_Group (Group) -->
      <div id="u961" class="ax_default ax_default_unplaced" data-label="Table_Group" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Items_Group (Group) -->
        <div id="u962" class="ax_default ax_default_unplaced" data-label="Items_Group" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- 10 (Rectangle) -->
          <div id="u963" class="ax_default paragraph ax_default_unplaced" data-label="10" style="display:none; visibility: hidden">
            <div id="u963_div" class=""></div>
            <div id="u963_text" class="text ">
              <p><span>10</span></p>
            </div>
          </div>

          <!-- 9 (Rectangle) -->
          <div id="u964" class="ax_default paragraph ax_default_unplaced" data-label="9" style="display:none; visibility: hidden">
            <div id="u964_div" class=""></div>
            <div id="u964_text" class="text ">
              <p><span>9</span></p>
            </div>
          </div>

          <!-- 8 (Rectangle) -->
          <div id="u965" class="ax_default paragraph ax_default_unplaced" data-label="8" style="display:none; visibility: hidden">
            <div id="u965_div" class=""></div>
            <div id="u965_text" class="text ">
              <p><span>8</span></p>
            </div>
          </div>

          <!-- 7 (Rectangle) -->
          <div id="u966" class="ax_default paragraph ax_default_unplaced" data-label="7" style="display:none; visibility: hidden">
            <div id="u966_div" class=""></div>
            <div id="u966_text" class="text ">
              <p><span>7</span></p>
            </div>
          </div>

          <!-- 6 (Rectangle) -->
          <div id="u967" class="ax_default paragraph ax_default_unplaced" data-label="6" style="display:none; visibility: hidden">
            <div id="u967_div" class=""></div>
            <div id="u967_text" class="text ">
              <p><span>6</span></p>
            </div>
          </div>

          <!-- 5 (Rectangle) -->
          <div id="u968" class="ax_default paragraph ax_default_unplaced" data-label="5" style="display:none; visibility: hidden">
            <div id="u968_div" class=""></div>
            <div id="u968_text" class="text ">
              <p><span>5</span></p>
            </div>
          </div>

          <!-- 4 (Rectangle) -->
          <div id="u969" class="ax_default paragraph ax_default_unplaced" data-label="4" style="display:none; visibility: hidden">
            <div id="u969_div" class=""></div>
            <div id="u969_text" class="text ">
              <p><span>4</span></p>
            </div>
          </div>

          <!-- 3 (Rectangle) -->
          <div id="u970" class="ax_default paragraph ax_default_unplaced" data-label="3" style="display:none; visibility: hidden">
            <div id="u970_div" class=""></div>
            <div id="u970_text" class="text ">
              <p><span>3</span></p>
            </div>
          </div>

          <!-- 2 (Rectangle) -->
          <div id="u971" class="ax_default paragraph ax_default_unplaced" data-label="2" style="display:none; visibility: hidden">
            <div id="u971_div" class=""></div>
            <div id="u971_text" class="text ">
              <p><span>2</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u972" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u972_div" class=""></div>
            <div id="u972_text" class="text ">
              <p><span>1</span></p>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u973" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u973_div" class=""></div>
          <div id="u973_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u974" class="ax_default paragraph ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u974_div" class=""></div>
          <div id="u974_text" class="text ">
            <p><span>預測結果</span></p>
          </div>
        </div>

        <!-- 比賽場次 (Rectangle) -->
        <div id="u975" class="ax_default paragraph ax_default_unplaced" data-label="比賽場次" style="display:none; visibility: hidden">
          <div id="u975_div" class=""></div>
          <div id="u975_text" class="text ">
            <p><span>比賽場次</span></p>
          </div>
        </div>

        <!-- Items (Rectangle) -->
        <div id="u976" class="ax_default paragraph ax_default_unplaced" data-label="Items" style="display:none; visibility: hidden">
          <div id="u976_div" class=""></div>
          <div id="u976_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u977" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
        <img id="u977_img" class="img " src="resources/images/transparent.gif"/>
        <div id="u977_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u978" class="ax_default box_2 ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u978_div" class=""></div>
        <div id="u978_text" class="text ">
          <p><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">羅斯托夫 PFC索契</span></p>
        </div>
      </div>

      <!-- Top Menu_M (Group) -->
      <div id="u979" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u980" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u980_state0" class="panel_state" data-label="State 1" style="">
            <div id="u980_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u981" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u982" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u982_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u982_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u983" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u984" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u984_div" class=""></div>
                          <div id="u984_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u985" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u985_div" class=""></div>
                          <div id="u985_text" class="text ">
                            <p><span>&nbsp;簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u986" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u986_div" class=""></div>
                          <div id="u986_text" class="text ">
                            <p><span>&nbsp;如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u987" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u987_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u987_text" class="text ">
                            <p><span>&nbsp; 為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u988" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u988_div" class=""></div>
                          <div id="u988_text" class="text ">
                            <p><span>&nbsp; 馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u989" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u989_div" class=""></div>
                          <div id="u989_text" class="text ">
                            <p><span>&nbsp; 用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u990" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u990_div" class=""></div>
                          <div id="u990_text" class="text ">
                            <p><span>&nbsp; 風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u991" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u991_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u991_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u992" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u993" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u993_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u993_text" class="text ">
                    <p><span>足球AI模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u994" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u994_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u994_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u995" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u996" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u996_div" class=""></div>
                          <div id="u996_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u997" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u997_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u997_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u998" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u998_div" class=""></div>
                          <div id="u998_text" class="text ">
                            <p><span>&nbsp;綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u999" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u999_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u999_text" class="text ">
                            <p><span>&nbsp;值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1000" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1000_div" class=""></div>
                          <div id="u1000_text" class="text ">
                            <p><span>&nbsp; AI模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1001" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1001_div" class=""></div>
                          <div id="u1001_text" class="text ">
                            <p><span>&nbsp;AI模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u1002" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u1003" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u1003_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u1003_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u1004" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u1004_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u1004_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u1005" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1006" class="ax_default box_3">
                          <div id="u1006_div" class=""></div>
                          <div id="u1006_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1007" class="ax_default box_3">
                          <img id="u1007_img" class="img " src="images/page_a4/u28.svg"/>
                          <div id="u1007_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1008" class="ax_default box_3">
                          <div id="u1008_div" class=""></div>
                          <div id="u1008_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1009" class="ax_default box_3">
                          <img id="u1009_img" class="img " src="images/page_a4/u30.svg"/>
                          <div id="u1009_text" class="text ">
                            <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1010" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1010_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1010_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1011" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1011_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1011_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1012" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1012_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1012_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1013" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1013_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1013_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Top Menu_M (Group) -->
        <div id="u1014" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- Unnamed (Placeholder) -->
          <div id="u1015" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u1015_img" class="img " src="resources/images/transparent.gif"/>
            <div id="u1015_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u1016" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u1016_div" class=""></div>
            <div id="u1016_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u1017" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u1017_div" class=""></div>
            <div id="u1017_text" class="text ">
              <p><span>MENU</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u1018" class="ax_default box_2 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u1018_div" class=""></div>
            <div id="u1018_text" class="text ">
              <p><span style="font-family:&quot;PingFangTC-Medium&quot;, &quot;PingFang TC Medium&quot;, &quot;PingFang TC&quot;, sans-serif;font-weight:500;">AI模組爆冷精選</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- footer (Group) -->
      <div id="u1019" class="ax_default" data-label="footer" data-left="150" data-top="651" data-width="1073" data-height="171">

        <!-- Unnamed (Rectangle) -->
        <div id="u1020" class="ax_default shape">
          <img id="u1020_img" class="img " src="images/page_a4/u40.svg"/>
          <div id="u1020_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1021" class="ax_default paragraph">
          <div id="u1021_div" class=""></div>
          <div id="u1021_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1022" class="ax_default paragraph">
          <div id="u1022_div" class=""></div>
          <div id="u1022_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1023" class="ax_default paragraph">
          <div id="u1023_div" class=""></div>
          <div id="u1023_text" class="text ">
            <p><span>問題</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1024" class="ax_default paragraph">
          <div id="u1024_div" class=""></div>
          <div id="u1024_text" class="text ">
            <p><span>查詢</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1025" class="ax_default paragraph">
          <div id="u1025_div" class=""></div>
          <div id="u1025_text" class="text ">
            <p><span>意見</span></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u1026" class="ax_default icon">
          <img id="u1026_img" class="img " src="images/page_a4/u46.svg"/>
          <div id="u1026_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u1027" class="ax_default icon">
          <img id="u1027_img" class="img " src="images/page_a4/u47.svg"/>
          <div id="u1027_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Button_Group (Group) -->
      <div id="u1028" class="ax_default" data-label="Button_Group" data-left="698" data-top="574" data-width="525" data-height="40">

        <!-- 足球AI模組分析 (Rectangle) -->
        <div id="u1029" class="ax_default box_3" data-label="足球AI模組分析">
          <div id="u1029_div" class=""></div>
          <div id="u1029_text" class="text ">
            <p><span>足球AI模組分析 &gt;&gt;&gt;</span></p>
          </div>
        </div>

        <!-- Unnamed (Hot Spot) -->
        <div id="u1030" class="ax_default">
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u1031" class="ax_default image">
        <img id="u1031_img" class="img " src="images/page_a7/u1031.png"/>
        <div id="u1031_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- 爆冷精選_DB (Group) -->
      <div id="u1032" class="ax_default" data-label="爆冷精選_DB" data-left="246" data-top="213" data-width="430" data-height="400">

        <!-- 爆冷精選_Repeater (Repeater) -->
        <div id="u1033" class="ax_default" data-label="爆冷精選_Repeater">
          <script id="u1033_script" type="axure-repeater-template" data-label="爆冷精選_Repeater">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034" class="ax_default droplist u1034" data-label="Predict_menu">
              <div id="u1034_div" class="u1034_div"></div>
              <select id="u1034_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035" class="ax_default paragraph u1035" data-label="bold_0a">
              <div id="u1035_div" class="u1035_div"></div>
              <div id="u1035_text" class="text u1035_text">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;"> PFC</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">索契</span></p>
              </div>
            </div>
          </script>
          <div id="u1033-1" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-1" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-1_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-1_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-1" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-1_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-1_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-2" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-2" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-2_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-2_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-2" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-2_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-2_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-3" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-3" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-3_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-3_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-3" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-3_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-3_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-4" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-4" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-4_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-4_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-4" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-4_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-4_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-5" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-5" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-5_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-5_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-5" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-5_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-5_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-6" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-6" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-6_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-6_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-6" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-6_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-6_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-7" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-7" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-7_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-7_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-7" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-7_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-7_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-8" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-8" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-8_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-8_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-8" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-8_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-8_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-9" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-9" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-9_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-9_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-9" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-9_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-9_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u1033-10" class="preeval" style="width: 430px; height: 40px;">

            <!-- Predict_menu (Droplist) -->
            <div id="u1034-10" class="ax_default droplist u1034" data-label="Predict_menu" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u1034-10_div" class="u1034_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <select id="u1034-10_input" class="u1034_input">
                <option class="u1034_input_option" value="預測結果選擇">預測結果選擇</option>
                <option class="u1034_input_option" value="主勝">主勝</option>
                <option class="u1034_input_option" value="客勝">客勝</option>
                <option class="u1034_input_option" value="和局">和局</option>
                <option class="u1034_input_option" value="總角球大">總角球大</option>
                <option class="u1034_input_option" value="總角球小">總角球小</option>
                <option class="u1034_input_option" value="總入球大">總入球大</option>
                <option class="u1034_input_option" value="總入球小">總入球小</option>
                <option class="u1034_input_option" value="讓球主客和(主隊勝)">讓球主客和(主隊勝)</option>
                <option class="u1034_input_option" value="讓球主客和(和局)">讓球主客和(和局)</option>
                <option class="u1034_input_option" value="讓球主客和(客隊勝)">讓球主客和(客隊勝)</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 0 )">波膽 ( 0 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 0 )">波膽 ( 1 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 0 )">波膽 ( 2 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 1 )">波膽 ( 2 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 0 )">波膽 ( 3 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 1 )">波膽 ( 3 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 3 - 2 )">波膽 ( 3 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 0 )">波膽 ( 4 - 0 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 1 )">波膽 ( 4 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 4 - 2 )">波膽 ( 4 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 1 )">波膽 ( 5 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 5 - 2 )">波膽 ( 5 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 1 )">波膽 ( 0 - 1 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 2 )">波膽 ( 0 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 2 )">波膽 ( 1 - 2 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 3 )">波膽 ( 0 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 3 )">波膽 ( 1 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 3 )">波膽 ( 2 - 3 )</option>
                <option class="u1034_input_option" value="波膽 ( 0 - 4 )">波膽 ( 0 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 4 )">波膽 ( 1 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 4 )">波膽 ( 2 - 4 )</option>
                <option class="u1034_input_option" value="波膽 ( 1 - 5 )">波膽 ( 1 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 2 - 5 )">波膽 ( 2 - 5 )</option>
                <option class="u1034_input_option" value="波膽 ( 主隊其他 )">波膽 ( 主隊其他 )</option>
                <option class="u1034_input_option" value="波膽 ( 客隊其他 )">波膽 ( 客隊其他 )</option>
              </select>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u1035-10" class="ax_default paragraph u1035" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u1035-10_div" class="u1035_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u1035-10_text" class="text u1035_text" style="visibility: inherit">
                <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">俄羅斯超級聯賽羅斯托夫 PFC索契</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Table_Group (Group) -->
      <div id="u1036" class="ax_default" data-label="Table_Group" data-left="151" data-top="173" data-width="525" data-height="441">

        <!-- Items_Group (Group) -->
        <div id="u1037" class="ax_default" data-label="Items_Group" data-left="151" data-top="214" data-width="95" data-height="400">

          <!-- 10 (Rectangle) -->
          <div id="u1038" class="ax_default paragraph" data-label="10">
            <div id="u1038_div" class=""></div>
            <div id="u1038_text" class="text ">
              <p><span>10</span></p>
            </div>
          </div>

          <!-- 9 (Rectangle) -->
          <div id="u1039" class="ax_default paragraph" data-label="9">
            <div id="u1039_div" class=""></div>
            <div id="u1039_text" class="text ">
              <p><span>9</span></p>
            </div>
          </div>

          <!-- 8 (Rectangle) -->
          <div id="u1040" class="ax_default paragraph" data-label="8">
            <div id="u1040_div" class=""></div>
            <div id="u1040_text" class="text ">
              <p><span>8</span></p>
            </div>
          </div>

          <!-- 7 (Rectangle) -->
          <div id="u1041" class="ax_default paragraph" data-label="7">
            <div id="u1041_div" class=""></div>
            <div id="u1041_text" class="text ">
              <p><span>7</span></p>
            </div>
          </div>

          <!-- 6 (Rectangle) -->
          <div id="u1042" class="ax_default paragraph" data-label="6">
            <div id="u1042_div" class=""></div>
            <div id="u1042_text" class="text ">
              <p><span>6</span></p>
            </div>
          </div>

          <!-- 5 (Rectangle) -->
          <div id="u1043" class="ax_default paragraph" data-label="5">
            <div id="u1043_div" class=""></div>
            <div id="u1043_text" class="text ">
              <p><span>5</span></p>
            </div>
          </div>

          <!-- 4 (Rectangle) -->
          <div id="u1044" class="ax_default paragraph" data-label="4">
            <div id="u1044_div" class=""></div>
            <div id="u1044_text" class="text ">
              <p><span>4</span></p>
            </div>
          </div>

          <!-- 3 (Rectangle) -->
          <div id="u1045" class="ax_default paragraph" data-label="3">
            <div id="u1045_div" class=""></div>
            <div id="u1045_text" class="text ">
              <p><span>3</span></p>
            </div>
          </div>

          <!-- 2 (Rectangle) -->
          <div id="u1046" class="ax_default paragraph" data-label="2">
            <div id="u1046_div" class=""></div>
            <div id="u1046_text" class="text ">
              <p><span>2</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u1047" class="ax_default paragraph">
            <div id="u1047_div" class=""></div>
            <div id="u1047_text" class="text ">
              <p><span>1</span></p>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1048" class="ax_default box_3">
          <div id="u1048_div" class=""></div>
          <div id="u1048_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1049" class="ax_default paragraph">
          <div id="u1049_div" class=""></div>
          <div id="u1049_text" class="text ">
            <p><span>預測結果</span></p>
          </div>
        </div>

        <!-- 比賽場次 (Rectangle) -->
        <div id="u1050" class="ax_default paragraph" data-label="比賽場次">
          <div id="u1050_div" class=""></div>
          <div id="u1050_text" class="text ">
            <p><span>比賽場次</span></p>
          </div>
        </div>

        <!-- Items (Rectangle) -->
        <div id="u1051" class="ax_default paragraph" data-label="Items">
          <div id="u1051_div" class=""></div>
          <div id="u1051_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u1052" class="ax_default image">
        <img id="u1052_img" class="img " src="images/page_a4/ta_g_u153.png"/>
        <div id="u1052_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u1053" class="ax_default box_2">
        <div id="u1053_div" class=""></div>
        <div id="u1053_text" class="text ">
          <p><span style="font-family:&quot;PingFangTC-Regular&quot;, &quot;PingFang TC&quot;, sans-serif;">AI</span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">模組爆冷精選</span><span style="font-family:&quot;Rockwell-Regular&quot;, &quot;Rockwell&quot;, sans-serif;"> – </span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">羅斯托夫 PFC索契</span></p>
        </div>
      </div>

      <!-- NAVIGATION BAR (Group) -->
      <div id="u1054" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1364" data-height="210">

        <!-- Unnamed (Placeholder) -->
        <div id="u1055" class="ax_default placeholder">
          <img id="u1055_img" class="img " src="images/page_a3/u534.svg"/>
          <div id="u1055_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1056" class="ax_default box_1">
          <div id="u1056_div" class=""></div>
          <div id="u1056_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1057" class="ax_default box_3">
          <div id="u1057_div" class=""></div>
          <div id="u1057_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1058" class="ax_default box_3">
          <div id="u1058_div" class=""></div>
          <div id="u1058_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1059" class="ax_default box_3">
          <div id="u1059_div" class=""></div>
          <div id="u1059_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1060" class="ax_default box_3">
          <div id="u1060_div" class=""></div>
          <div id="u1060_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1061" class="ax_default box_3">
          <div id="u1061_div" class=""></div>
          <div id="u1061_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1062" class="ax_default box_3">
          <div id="u1062_div" class=""></div>
          <div id="u1062_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1063" class="ax_default box_3">
          <div id="u1063_div" class=""></div>
          <div id="u1063_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1064" class="ax_default">
          <div id="u1064_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1064_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u1065" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u1066" class="ax_default box_3">
                  <div id="u1066_div" class=""></div>
                  <div id="u1066_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1067" class="ax_default box_3">
                  <div id="u1067_div" class=""></div>
                  <div id="u1067_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1068" class="ax_default box_3">
                  <div id="u1068_div" class=""></div>
                  <div id="u1068_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1069" class="ax_default box_3">
                  <img id="u1069_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u1069_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1070" class="ax_default box_3">
                  <div id="u1070_div" class=""></div>
                  <div id="u1070_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1071" class="ax_default box_3">
                  <div id="u1071_div" class=""></div>
                  <div id="u1071_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1072" class="ax_default box_3">
                  <div id="u1072_div" class=""></div>
                  <div id="u1072_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1073" class="ax_default">
          <div id="u1073_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1073_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u1074" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="121" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u1075" class="ax_default box_3">
                  <div id="u1075_div" class=""></div>
                  <div id="u1075_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1076" class="ax_default box_3">
                  <div id="u1076_div" class=""></div>
                  <div id="u1076_text" class="text ">
                    <p><span>AI模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1077" class="ax_default box_3">
                  <div id="u1077_div" class=""></div>
                  <div id="u1077_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1078" class="ax_default box_3">
                  <img id="u1078_img" class="img " src="images/page_a4/u178.svg"/>
                  <div id="u1078_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1079" class="ax_default box_3">
                  <div id="u1079_div" class=""></div>
                  <div id="u1079_text" class="text ">
                    <p><span>AI模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1080" class="ax_default box_3">
                  <div id="u1080_div" class=""></div>
                  <div id="u1080_text" class="text ">
                    <p><span>AI模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1081" class="ax_default">
          <div id="u1081_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1081_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u1082" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="135" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u1083" class="ax_default box_3">
                  <div id="u1083_div" class=""></div>
                  <div id="u1083_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1084" class="ax_default box_3">
                  <div id="u1084_div" class=""></div>
                  <div id="u1084_text" class="text ">
                    <p><span>&nbsp;Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1085" class="ax_default box_3">
                  <div id="u1085_div" class=""></div>
                  <div id="u1085_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1086" class="ax_default box_3">
                  <img id="u1086_img" class="img " src="images/page_a4/u195.svg"/>
                  <div id="u1086_text" class="text ">
                    <p><span>AI模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
