<!DOCTYPE html>
<html>

    

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/football/public/frontend/files/page_a8/abc.css">
    
    
</head>


<body>
Test Gauge Page
<h1>Gauge</h1>
<div id="gauge" class="gauge"></div>
<div class="rtg"></div>

</body>

<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/radar.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<script src="https://cdn.amcharts.com/lib/5/locales/de_DE.js"></script>
<script src="https://cdn.amcharts.com/lib/5/geodata/germanyLow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/fonts/notosans-sc.js"></script>
<script src="/football/public/frontend/files/page_a8/script.js"></script>


</html>