<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\FrontendController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        return view('admin.index');
    })->name('dashboard');
});

Route::get('/user/logout', [HomeController::class, 'Logout'])->name('user.logout');

// route for a1 frontend
Route::get('/a1tob1', 'App\Http\Controllers\FrontendController@IntoB1');

// route for a1 
Route::get('/a1/load', [HomeController::class, 'LoadA1'])->name('load.a1');
Route::post('/a1/create', [HomeController::class, 'CreateA1'])->name('create.a1');
Route::get('/a1/edit/{game_id}', [HomeController::class, 'EditA1']);
Route::post('/a1/update/{game_id}', [HomeController::class, 'UpdateA1']);
Route::get('/a1/delete/{game_id}', [HomeController::class, 'DeleteA1']);

// route for a2 backend
Route::get('/a2/load', [HomeController::class, 'LoadA2'])->name('load.a2');
Route::post('/a2/create', [HomeController::class, 'CreateA2'])->name('create.a2');
Route::get('/a2/delete/{id}', [HomeController::class, 'DeleteA2']);
Route::get('/a2/edit/{id}', [HomeController::class, 'EditA2']);
Route::post('/a2/update/{id}', [HomeController::class, 'UpdateA2']);

// routes for a5 backend
Route::get('/a5/load', [HomeController::class, 'LoadA5'])->name('load.a5');
Route::post('/a5/create', [HomeController::class, 'CreateA5'])->name('create.a5');
Route::get('/a5/delete/{id}', [HomeController::class, 'DeleteA5']);
Route::get('/a5/edit/{id}', [HomeController::class, 'EditA5']);
Route::post('/a5/update/{id}', [HomeController::class, 'UpdateA5']);

// routes for a8 backend
Route::get('/a8/load', [HomeController::class, 'LoadA8'])->name('load.a8');
Route::post('/a8/create', [HomeController::class, 'CreateA8'])->name('create.a8');
Route::get('/a8/delete/{id}', [HomeController::class, 'DeleteA8']);
Route::get('/a8/edit/{id}', [HomeController::class, 'EditA8']);
Route::post('/a8/update/{id}', [HomeController::class, 'UpdateA8']);

//Frontend show first_page
Route::get('/page_first', 'App\Http\Controllers\FrontendController@ShowFirst');

//Frontend show a1
Route::get('/page_a1', 'App\Http\Controllers\FrontendController@ShowA1');
Route::get('/page_a1/{game_id}', 'App\Http\Controllers\FrontendController@ShowA1id');

//Frontend show a2
Route::get('/page_a2', 'App\Http\Controllers\FrontendController@ShowA2');
Route::get('/page_a2/{game_id}', 'App\Http\Controllers\FrontendController@ShowA2id');

//Frontend show a3
Route::get('/page_a3', 'App\Http\Controllers\FrontendController@ShowA3');

//Frontend show a4
Route::get('/page_a4', 'App\Http\Controllers\FrontendController@ShowA4');
Route::get('/page_a4/{game_id}', 'App\Http\Controllers\FrontendController@ShowA4id');

//Frontend show a5
Route::get('/page_a5', 'App\Http\Controllers\FrontendController@ShowA5');

//Frontend show a6
Route::get('/page_a6', 'App\Http\Controllers\FrontendController@ShowA6');

//Frontend show a7
Route::get('/page_a7', 'App\Http\Controllers\FrontendController@ShowA7');
Route::get('/page_a7/{game_id}', 'App\Http\Controllers\FrontendController@ShowA7id');

//Frontend show a8
Route::get('/page_a8', 'App\Http\Controllers\FrontendController@ShowA8');
Route::get('/page_a8/{game_id}', 'App\Http\Controllers\FrontendController@ShowA8id');

//Frontend show test
Route::get('/test', 'App\Http\Controllers\FrontendController@Test');
