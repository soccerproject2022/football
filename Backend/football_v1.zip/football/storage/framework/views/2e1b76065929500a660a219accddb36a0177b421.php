﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A2</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/football/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/files/page_a2/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/football/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/football/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/football/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/football/public/frontend/data/document.js"></script>
    <script src="/football/public/frontend/files/page_a2/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/football/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/football/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/football/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- footer (Group) -->
      <div id="u414" class="ax_default" data-label="footer" data-left="150" data-top="1389" data-width="1073" data-height="171">

        <!-- Unnamed (Rectangle) -->
        <div id="u415" class="ax_default shape">
          <img id="u415_img" class="img " src="/football/public/frontend/images/page_a4/u40.svg"/>
          <div id="u415_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u416" class="ax_default paragraph">
          <div id="u416_div" class=""></div>
          <div id="u416_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u417" class="ax_default paragraph">
          <div id="u417_div" class=""></div>
          <div id="u417_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u418" class="ax_default paragraph">
          <div id="u418_div" class=""></div>
          <div id="u418_text" class="text ">
            <p><span>問題</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u419" class="ax_default paragraph">
          <div id="u419_div" class=""></div>
          <div id="u419_text" class="text ">
            <p><span>查詢</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u420" class="ax_default paragraph">
          <div id="u420_div" class=""></div>
          <div id="u420_text" class="text ">
            <p><span>意見</span></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u421" class="ax_default icon">
          <img id="u421_img" class="img " src="/football/public/frontend/images/page_a4/u46.svg"/>
          <div id="u421_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u422" class="ax_default icon">
          <img id="u422_img" class="img " src="/football/public/frontend/images/page_a4/u47.svg"/>
          <div id="u422_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u423" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u423_state0" class="panel_state" data-label="State 1" style="">
          <div id="u423_state0_content" class="panel_state_content">

            <!-- 1ST SUB (Group) -->
            <div id="u424" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u425" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u425_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u425_state0_content" class="panel_state_content">

                    <!-- HOME_SUBMENU (Group) -->
                    <div id="u426" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u427" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u427_div" class=""></div>
                        <div id="u427_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u428" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u428_div" class=""></div>
                        <div id="u428_text" class="text ">
                          <p><span>&nbsp;簡介</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u429" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u429_div" class=""></div>
                        <div id="u429_text" class="text ">
                          <p><span>&nbsp;如何應用</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u430" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u430_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                        <div id="u430_text" class="text ">
                          <p><span>&nbsp; 為何我們</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u431" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u431_div" class=""></div>
                        <div id="u431_text" class="text ">
                          <p><span>&nbsp; 馬上註冊</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u432" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u432_div" class=""></div>
                        <div id="u432_text" class="text ">
                          <p><span>&nbsp; 用戶推薦</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u433" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u433_div" class=""></div>
                        <div id="u433_text" class="text ">
                          <p><span>&nbsp; 風險披露</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u434" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u434_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u434_text" class="text ">
                  <p><span>首頁</span></p>
                </div>
              </div>
            </div>

            <!-- 2ND SUB (Group) -->
            <div id="u435" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u436" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u436_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u436_text" class="text ">
                  <p><span>足球AI模組分析</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u437" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u437_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u437_state0_content" class="panel_state_content">

                    <!-- AI_SUBMENU (Group) -->
                    <div id="u438" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u439" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u439_div" class=""></div>
                        <div id="u439_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u440" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u440_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                        <div id="u440_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u441" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u441_div" class=""></div>
                        <div id="u441_text" class="text ">
                          <p><span>&nbsp;綜合網民數據結果</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u442" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u442_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                        <div id="u442_text" class="text ">
                          <p><span>&nbsp;值博率模組分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u443" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u443_div" class=""></div>
                        <div id="u443_text" class="text ">
                          <p><span>&nbsp; AI模組波膽分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u444" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u444_div" class=""></div>
                        <div id="u444_text" class="text ">
                          <p><span>&nbsp;AI模組分析大小角</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 3RD SUB (Group) -->
            <div id="u445" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u446" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u446_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u446_text" class="text ">
                  <p><span>Futra是日精選</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u447" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u447_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u447_state0_content" class="panel_state_content">

                    <!-- FUTRA_SUBMENU (Group) -->
                    <div id="u448" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u449" class="ax_default box_3">
                        <div id="u449_div" class=""></div>
                        <div id="u449_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u450" class="ax_default box_3">
                        <img id="u450_img" class="img " src="/football/public/frontend/images/page_a4/u28.svg"/>
                        <div id="u450_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u451" class="ax_default box_3">
                        <div id="u451_div" class=""></div>
                        <div id="u451_text" class="text ">
                          <p><span>爆冷精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u452" class="ax_default box_3">
                        <img id="u452_img" class="img " src="/football/public/frontend/images/page_a4/u30.svg"/>
                        <div id="u452_text" class="text ">
                          <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u453" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u453_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u453_text" class="text ">
                <p><span>為何我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u454" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u454_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u454_text" class="text ">
                <p><span>聯絡我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u455" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u455_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u455_text" class="text ">
                <p><span>會員中心</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u456" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u456_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u456_text" class="text ">
                <p><span>登入</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Top Menu_M (Group) -->
      <div id="u457" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Placeholder) -->
        <div id="u458" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u458_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
          <div id="u458_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u459" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u459_div" class=""></div>
          <div id="u459_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u460" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u460_div" class=""></div>
          <div id="u460_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>

      <!-- Update_time (Rectangle)
      <div id="u461" class="ax_default label" data-label="Update_time">
        <div id="u461_div" class=""></div>
        <div id="u461_text" class="text ">
          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;"></span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;"></span></p>
        </div>
      </div> -->

      
      <?php if(isset($a2s)): ?>
      <?php if(isset($a1s)): ?>
      <!-- Logo_Group (Group) -->
      <div id="u492" class="ax_default" data-label="Logo_Group" data-left="375" data-top="130" data-width="623" data-height="146">

        <!-- TA_G (Image) -->
        <div id="u493" class="ax_default image" data-label="TA_G">
          <img id="u493_img" class="img " src="<?php echo e(asset($a1s->g_img)); ?>"/>
          <div id="u493_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TH_G (Image) -->
        <div id="u494" class="ax_default image" data-label="TH_G">
          <img id="u494_img" class="img " src="<?php echo e(asset($a1s->h_img)); ?>"/>
          <div id="u494_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u495" class="ax_default box_2" data-label="Team_Away">
          <div id="u495_div" class=""></div>
          <div id="u495_text" class="text ">
            <p><span><?php echo e($a1s->guest); ?></span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u496" class="ax_default box_2" data-label="Team_Home">
          <div id="u496_div" class=""></div>
          <div id="u496_text" class="text ">
            <p><span><?php echo e($a1s->host); ?></span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u497" class="ax_default box_2" data-label="Date_Time">
          <div id="u497_div" class=""></div>
          <div id="u497_text" class="text ">
            <p><span><?php echo e(Carbon\Carbon::parse($a1s->date)->diffForHumans()); ?>開波</span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u498" class="ax_default box_2" data-label="Match">
          <div id="u498_div" class=""></div>
          <div id="u498_text" class="text ">
            <p><span><?php echo e($a1s->league); ?></span></p>
          </div>
        </div>
      </div>

      <!-- Rate_table (Group) -->
      <div id="u462" class="ax_default" data-label="Rate_table" data-left="332" data-top="440" data-width="716" data-height="80">

        <!-- TAW_rtg (Rectangle) -->
        <div id="u463" class="ax_default box_2" data-label="TAW_rtg">
          <div id="u463_div" class=""></div>
          <div id="u463_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TAW_rprv (Rectangle) -->
        <div id="u464" class="ax_default paragraph" data-label="TAW_rprv">
          <div id="u464_div" class=""></div>
          <div id="u464_text" class="text ">
            <p><span><?php echo e($a1s->g_win); ?>%</span></p>
          </div>
        </div>

        <!-- TAW_rpr (Rectangle) -->
        <div id="u465" class="ax_default paragraph" data-label="TAW_rpr">
          <div id="u465_div" class=""></div>
          <div id="u465_text" class="text ">
            <p><span>客隊勝率</span></p>
          </div>
        </div>

        <!-- TAW_rv (Rectangle) -->
        <div id="u466" class="ax_default paragraph" data-label="TAW_rv">
          <div id="u466_div" class=""></div>
          <div id="u466_text" class="text ">
            <p><span><?php echo e($a2s->g_winp); ?></span></p>
          </div>
        </div>

        <!-- TAW_r (Rectangle) -->
        <div id="u467" class="ax_default paragraph" data-label="TAW_r">
          <div id="u467_div" class=""></div>
          <div id="u467_text" class="text ">
            <p><span>客隊票數</span></p>
          </div>
        </div>

        <!-- DR_rtg (Rectangle) -->
        <div id="u468" class="ax_default box_2" data-label="DR_rtg">
          <div id="u468_div" class=""></div>
          <div id="u468_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- DR_rprv (Rectangle) -->
        <div id="u469" class="ax_default paragraph" data-label="DR_rprv">
          <div id="u469_div" class=""></div>
          <div id="u469_text" class="text ">
            <p><span><?php echo e($a1s->draw); ?>%</span></p>
          </div>
        </div>

        <!-- DR_rpr (Rectangle) -->
        <div id="u470" class="ax_default paragraph" data-label="DR_rpr">
          <div id="u470_div" class=""></div>
          <div id="u470_text" class="text ">
            <p><span>和波機率</span></p>
          </div>
        </div>

        <!-- DR_rv (Rectangle) -->
        <div id="u471" class="ax_default paragraph" data-label="DR_rv">
          <div id="u471_div" class=""></div>
          <div id="u471_text" class="text ">
            <p><span><?php echo e($a2s->draw_p); ?></span></p>
          </div>
        </div>

        <!-- DR_r (Rectangle) -->
        <div id="u472" class="ax_default paragraph" data-label="DR_r">
          <div id="u472_div" class=""></div>
          <div id="u472_text" class="text ">
            <p><span>和波票數</span></p>
          </div>
        </div>

        <!-- THW_rtg (Rectangle) -->
        <div id="u473" class="ax_default box_2" data-label="THW_rtg">
          <div id="u473_div" class=""></div>
          <div id="u473_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- THW_rprv (Rectangle) -->
        <div id="u474" class="ax_default paragraph" data-label="THW_rprv">
          <div id="u474_div" class=""></div>
          <div id="u474_text" class="text ">
            <p><span><?php echo e($a1s->h_win); ?>%</span></p>
          </div>
        </div>

        <!-- THW_rpr (Rectangle) -->
        <div id="u475" class="ax_default paragraph" data-label="THW_rpr">
          <div id="u475_div" class=""></div>
          <div id="u475_text" class="text ">
            <p><span>主隊勝率</span></p>
          </div>
        </div>

        <!-- THW_rv (Rectangle) -->
        <div id="u476" class="ax_default paragraph" data-label="THW_rv">
          <div id="u476_div" class=""></div>
          <div id="u476_text" class="text ">
            <p><span><?php echo e($a2s->h_winp); ?></span></p>
          </div>
        </div>

        <!-- THW_r (Rectangle) -->
        <div id="u477" class="ax_default paragraph" data-label="THW_r">
          <div id="u477_div" class=""></div>
          <div id="u477_text" class="text ">
            <p><span>主隊票數</span></p>
          </div>
        </div>
      </div>

      <?php endif; ?>
      <?php endif; ?>

      <!-- Rate_Group (Group) -->
      <div id="u478" class="ax_default" data-label="Rate_Group" data-left="150" data-top="300" data-width="1072" data-height="80">

        <!-- Rate_bar (Rectangle) -->
        <div id="u479" class="ax_default box_1" data-label="Rate_bar">
          <div id="u479_div" class=""></div>
          <div id="u479_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TAW (Group) -->
        <div id="u480" class="ax_default" data-label="TAW" data-left="632" data-top="300" data-width="590" data-height="80">

          <!-- TAW_D (Rectangle) -->
          <div id="u481" class="ax_default box_1" data-label="TAW_D">
            <div id="u481_div" class=""></div>
            <div id="u481_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_Dt (Rectangle) -->
          <div id="u482" class="ax_default box_1" data-label="TAW_Dt">
            <img id="u482_img" class="img " src="/football/public/frontend/images/page_a4/taw_dt_u145.svg"/>
            <div id="u482_text" class="text ">
              <p><span>客勝</span><span> 55%</span></p>
            </div>
          </div>

          <!-- TAW_U (Rectangle) -->
          <div id="u483" class="ax_default box_1" data-label="TAW_U">
            <img id="u483_img" class="img " src="/football/public/frontend/images/page_a2/taw_u_u483.svg"/>
            <div id="u483_text" class="text ">
              <p><span>7000</span></p>
            </div>
          </div>
        </div>

        <!-- THW (Group) -->
        <div id="u484" class="ax_default" data-label="THW" data-left="150" data-top="300" data-width="257" data-height="80">

          <!-- THW_D (Rectangle) -->
          <div id="u485" class="ax_default box_1" data-label="THW_D">
            <div id="u485_div" class=""></div>
            <div id="u485_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_Dt (Rectangle) -->
          <div id="u486" class="ax_default box_1" data-label="THW_Dt">
            <img id="u486_img" class="img " src="/football/public/frontend/images/page_a4/thw_dt_u148.svg"/>
            <div id="u486_text" class="text ">
              <p><span>主勝</span><span> 24%</span></p>
            </div>
          </div>

          <!-- THW_U (Rectangle) -->
          <div id="u487" class="ax_default box_1" data-label="THW_U">
            <img id="u487_img" class="img " src="/football/public/frontend/images/page_a2/thw_u_u487.svg"/>
            <div id="u487_text" class="text ">
              <p><span>3000</span></p>
            </div>
          </div>
        </div>

        <!-- DRAW (Group) -->
        <div id="u488" class="ax_default" data-label="DRAW" data-left="407" data-top="300" data-width="225" data-height="80">

          <!-- DRAW_D (Rectangle) -->
          <div id="u489" class="ax_default box_1" data-label="DRAW_D">
            <div id="u489_div" class=""></div>
            <div id="u489_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DRAW_Dt (Rectangle) -->
          <div id="u490" class="ax_default box_1" data-label="DRAW_Dt">
            <img id="u490_img" class="img " src="/football/public/frontend/images/page_a4/draw_dt_u151.svg"/>
            <div id="u490_text" class="text ">
              <p><span>和波 21%</span></p>
            </div>
          </div>

          <!-- DRAW_U (Rectangle) -->
          <div id="u491" class="ax_default box_1" data-label="DRAW_U">
            <img id="u491_img" class="img " src="/football/public/frontend/images/page_a2/draw_u_u491.svg"/>
            <div id="u491_text" class="text ">
              <p><span>2600</span></p>
            </div>
          </div>
        </div>
      </div>


      <!-- Header (Rectangle) -->
      <div id="u499" class="ax_default heading_1" data-label="Header">
        <div id="u499_div" class=""></div>
        <div id="u499_text" class="text ">
          <p><span>綜合網民數據結果 ► 主 • 和 • 客 投票機率</span></p>
        </div>
      </div>

      <!-- NAVIGATION BAR (Group) -->
      <div id="u500" class="ax_default" data-label="NAVIGATION BAR" data-left="1" data-top="0" data-width="1364" data-height="210">

        <!-- Unnamed (Placeholder) -->
        <div id="u501" class="ax_default placeholder">
          <img id="u501_img" class="img " src="/football/public/frontend/images/page_a4/u164.svg"/>
          <div id="u501_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u502" class="ax_default box_1">
          <div id="u502_div" class=""></div>
          <div id="u502_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u503" class="ax_default box_3">
          <div id="u503_div" class=""></div>
          <div id="u503_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u504" class="ax_default box_3">
          <div id="u504_div" class=""></div>
          <div id="u504_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u505" class="ax_default box_3">
          <div id="u505_div" class=""></div>
          <div id="u505_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u506" class="ax_default box_3">
          <div id="u506_div" class=""></div>
          <div id="u506_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u507" class="ax_default box_3">
          <div id="u507_div" class=""></div>
          <div id="u507_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u508" class="ax_default box_3">
          <div id="u508_div" class=""></div>
          <div id="u508_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u509" class="ax_default box_3">
          <div id="u509_div" class=""></div>
          <div id="u509_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u510" class="ax_default">
          <div id="u510_state0" class="panel_state" data-label="State 1" style="">
            <div id="u510_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u511" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u512" class="ax_default box_3">
                  <div id="u512_div" class=""></div>
                  <div id="u512_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u513" class="ax_default box_3">
                  <div id="u513_div" class=""></div>
                  <div id="u513_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u514" class="ax_default box_3">
                  <div id="u514_div" class=""></div>
                  <div id="u514_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u515" class="ax_default box_3">
                  <img id="u515_img" class="img " src="/football/public/frontend/images/page_a4/u178.svg"/>
                  <div id="u515_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u516" class="ax_default box_3">
                  <div id="u516_div" class=""></div>
                  <div id="u516_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u517" class="ax_default box_3">
                  <div id="u517_div" class=""></div>
                  <div id="u517_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u518" class="ax_default box_3">
                  <div id="u518_div" class=""></div>
                  <div id="u518_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u519" class="ax_default">
          <div id="u519_state0" class="panel_state" data-label="State 1" style="">
            <div id="u519_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u520" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="121" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u521" class="ax_default box_3">
                  <div id="u521_div" class=""></div>
                  <div id="u521_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u522" class="ax_default box_3">
                  <div id="u522_div" class=""></div>
                  <div id="u522_text" class="text ">
                    <p><span>AI模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u523" class="ax_default box_3">
                  <div id="u523_div" class=""></div>
                  <div id="u523_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u524" class="ax_default box_3">
                  <img id="u524_img" class="img " src="/football/public/frontend/images/page_a4/u178.svg"/>
                  <div id="u524_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u525" class="ax_default box_3">
                  <div id="u525_div" class=""></div>
                  <div id="u525_text" class="text ">
                    <p><span>AI模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u526" class="ax_default box_3">
                  <div id="u526_div" class=""></div>
                  <div id="u526_text" class="text ">
                    <p><span>AI模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u527" class="ax_default">
          <div id="u527_state0" class="panel_state" data-label="State 1" style="">
            <div id="u527_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u528" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="135" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u529" class="ax_default box_3">
                  <div id="u529_div" class=""></div>
                  <div id="u529_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u530" class="ax_default box_3">
                  <div id="u530_div" class=""></div>
                  <div id="u530_text" class="text ">
                    <p><span>&nbsp;Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u531" class="ax_default box_3">
                  <div id="u531_div" class=""></div>
                  <div id="u531_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u532" class="ax_default box_3">
                  <img id="u532_img" class="img " src="/football/public/frontend/images/page_a4/u195.svg"/>
                  <div id="u532_text" class="text ">
                    <p><span>AI模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="/football/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/football/resources/views/frontend/page_a2.blade.php ENDPATH**/ ?>