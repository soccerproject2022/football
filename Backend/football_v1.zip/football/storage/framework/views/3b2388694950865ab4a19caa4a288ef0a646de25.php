
<?php $__env->startSection('edita1'); ?>
<div class="col-lg-12">
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong><?php echo e(session('success')); ?></strong>
<button type="button" class="class" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>
            <div class="card-header card-header-border-bottom">
                <h2>Edit a1 data</h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('a1/update/'.$a1s->game_id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >game_id</label>
                                <input type="hidden" name="game_id" class="form-control" >
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >聯賽</label>
                                <input type="text" name="league" class="form-control" placeholder="聯賽" value="<?php echo e($a1s->league); ?>">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >球賽編號</label>
                                <input type="text" name="jc_id" class="form-control" placeholder="球賽編號" value="<?php echo e($a1s->jc_id); ?>">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >日期時間</label>
                                <input type="datetime-local" name="date" class="form-control"  value="<?php echo e($a1s->date); ?>">
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="主隊" value="<?php echo e($a1s->host); ?>">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="客隊" value="<?php echo e($a1s->guest); ?>">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主勝</label>
                                <input type="number" name="h_win" class="form-control" placeholder="主勝率"  value="<?php echo e($a1s->h_win); ?>" step=any />
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >和率</label>
                                <input type="number" name="draw" class="form-control" placeholder="和率"  value="<?php echo e($a1s->draw); ?>" step=any />
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客勝</label>
                                <input type="number" name="g_win" class="form-control" placeholder="客勝率"  value="<?php echo e($a1s->g_win); ?>" step=any />
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主回率</label>
                                <input type="number" name="h_return" class="form-control" placeholder="主回率"  value="<?php echo e($a1s->h_return); ?>" step=any />
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >和回率</label>
                                <input type="number" name="d_return" class="form-control" placeholder="和回率"  value="<?php echo e($a1s->d_return); ?>" step=any />
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label>客回</label>
                                <input type="number" name="g_return" class="form-control" placeholder="客回"  value="<?php echo e($a1s->g_return); ?>" step=any />
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label ></label>
                                
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊圖</label>
                                <img src="<?php echo e(asset($a1s->h_img)); ?>" style="width:40px">
                                <input type="file" name="h_img" class="form-control" >
                                <?php $__errorArgs = ['h_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label for="city">客隊圖</label>
                                <img src="<?php echo e(asset($a1s->g_img)); ?>" style="width:40px">
                                <input type="file" name="g_img" class="form-control" >
                                <?php $__errorArgs = ['g_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/football/resources/views/admin/a1/edit.blade.php ENDPATH**/ ?>