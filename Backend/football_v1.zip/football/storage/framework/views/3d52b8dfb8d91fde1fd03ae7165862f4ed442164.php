
<?php $__env->startSection('edita2'); ?>
<div class="col-lg-12">
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong><?php echo e(session('success')); ?></strong>
<button type="button" class="class" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>
            <div class="card-header card-header-border-bottom">
                <h2>Edit a2 data</h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('a2/update/'.$a2s->id)); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >id</label>
                                <input type="hidden" name="id" class="form-control" >
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="host" disabled value="<?php echo e($a2s->host); ?>">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="guest" disabled value="<?php echo e($a2s->guest); ?>">
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主場勝數</label>
                                <input type="number" name="h_guess" class="form-control" placeholder="主場勝數" value="<?php echo e($a2s->h_guess); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >和波機數</label>
                                <input type="number" name="d_guess" class="form-control" placeholder="和波機數" value="<?php echo e($a2s->d_guess); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊勝數</label>
                                <input type="number" name="g_guess" class="form-control" placeholder="客隊勝數" value="<?php echo e($a2s->g_guess); ?>" step=any>
                            </div>
                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/football/resources/views/admin/a2/edit.blade.php ENDPATH**/ ?>