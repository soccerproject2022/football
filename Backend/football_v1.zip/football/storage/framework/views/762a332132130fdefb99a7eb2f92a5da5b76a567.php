


<div class="col-lg-12">

<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
    <button type="button" class="class" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

    
        <div class="card-header card-header-border-bottom">
            <h2>賽程表</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover " cellspacing=5 border=1 style="text-align:center; margin-top:100px; margin-left:50px;">
                <thead>
                    <tr>
                        <th scope="col" width="50">#</th>
                        <th scope="col" width="180">賽事類別</th>
                        <th scope="col" width="180">開賽時間</th>
                        <th scope="col"></th>
                        <th scope="col" width="180">主隊</th>
                        <th scope="col"></th>
                        <th scope="col" width="180">客隊</th>
                        <th scope="col">主勝</th>
                        <th scope="col">和率</th>
                        <th scope="col">客勝</th>
                        <th scope="col">主回率</th>
                        <th scope="col">和回率</th>
                        <th scope="col">客回率</th>
                        
                        
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $a1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a1datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($a1datum->jc_id); ?></td>
                        <td><?php echo e($a1datum->league); ?></td>
                        <td><?php echo e($a1datum->date); ?></td>
                        <td><img src="<?php echo e(asset($a1datum->h_img)); ?>" style="width:40px"></td>
                        <td><?php echo e($a1datum->host); ?></td>
                        <td><img src="<?php echo e(asset($a1datum->g_img)); ?>" style="width:40px"></td>
                        <td><?php echo e($a1datum->guest); ?></td>
                        <td><?php echo e($a1datum->h_win); ?></td>
                        <td><?php echo e($a1datum->draw); ?></td>
                        <td><?php echo e($a1datum->g_win); ?></td>
                        <td><?php echo e($a1datum->h_return); ?></td>
                        <td><?php echo e($a1datum->d_return); ?></td>
                        <td><?php echo e($a1datum->g_return); ?></td>
                        
                        
                        
                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>

<?php /**PATH /Applications/MAMP/htdocs/football/resources/views/frontend/a1.blade.php ENDPATH**/ ?>