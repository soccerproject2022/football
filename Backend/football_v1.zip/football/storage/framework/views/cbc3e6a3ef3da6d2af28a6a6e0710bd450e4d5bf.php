﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A1</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/football/public/frontendresources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/files/page_a1/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/football/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/football/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/football/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/football/public/frontend/data/document.js"></script>
    <script src="/football/public/frontend/files/page_a1/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/football/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/football/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/football/public/frontend/resources/reload.html'; };
    </script>
    
    
    
  </head>
  <body>
    <div id="base" class="">




      <!-- footer (Group) -->
      <div id="u334" class="ax_default" data-label="footer" data-left="150" data-top="1389" data-width="1073" data-height="171">

        <!-- Unnamed (Rectangle) -->
        <div id="u335" class="ax_default shape">
          <img id="u335_img" class="img " src="/football/public/frontend/images/page_a4/u40.svg"/>
          <div id="u335_text" class="text ">
            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">問題</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">查詢</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#FFFFFF;"> </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">· </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#FFFFFF;">意見</span></p><p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;">&nbsp;· </span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u336" class="ax_default paragraph">
          <div id="u336_div" class=""></div>
          <div id="u336_text" class="text ">
            <p><span>香港賽馬會網站</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u337" class="ax_default paragraph">
          <div id="u337_div" class=""></div>
          <div id="u337_text" class="text ">
            <p><span>非法賭博</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u338" class="ax_default paragraph">
          <div id="u338_div" class=""></div>
          <div id="u338_text" class="text ">
            <p><span>問題</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u339" class="ax_default paragraph">
          <div id="u339_div" class=""></div>
          <div id="u339_text" class="text ">
            <p><span>查詢</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u340" class="ax_default paragraph">
          <div id="u340_div" class=""></div>
          <div id="u340_text" class="text ">
            <p><span>意見</span></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u341" class="ax_default icon">
          <img id="u341_img" class="img " src="/football/public/frontend/images/page_a4/u46.svg"/>
          <div id="u341_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Shape) -->
        <div id="u342" class="ax_default icon">
          <img id="u342_img" class="img " src="/football/public/frontend/images/page_a4/u47.svg"/>
          <div id="u342_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>



      <!-- Predict_bar (Group) -->
      <div id="u359" class="ax_default" data-label="Predict_bar" data-left="324" data-top="281" data-width="728" data-height="162">

        <!-- Unnamed (Image) -->
        <div id="u360" class="ax_default image">
          <img id="u360_img" class="img " src="/football/public/frontend/images/page_a1/u360.svg"/>
          <div id="u360_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TAP_label (Rectangle) -->
        <div id="u361" class="ax_default label" data-label="TAP_label">
          <div id="u361_div" class=""></div>
          <div id="u361_text" class="text ">
            <p><span></span></p><p><span><br></span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u362" class="ax_default box_2">
          <div id="u362_div" class=""></div>
          <div id="u362_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TA_bar (Rectangle) -->
        <div id="u363" class="ax_default box_2" data-label="TA_bar">
          <div id="u363_div" class=""></div>
          <div id="u363_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TA_label (Rectangle) -->
        <div id="u364" class="ax_default label" data-label="TA_label">
          <div id="u364_div" class=""></div>
          <div id="u364_text" class="text ">
            <p><span></span></p>
          </div>
        </div>

        <!-- DRP_label (Rectangle) -->
        <div id="u365" class="ax_default label" data-label="DRP_label">
          <div id="u365_div" class=""></div>
          <div id="u365_text" class="text ">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u366" class="ax_default box_2">
          <div id="u366_div" class=""></div>
          <div id="u366_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- DR_bar (Rectangle) -->
        <div id="u367" class="ax_default box_2" data-label="DR_bar">
          <div id="u367_div" class=""></div>
          <div id="u367_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- DR_label (Rectangle) -->
        <div id="u368" class="ax_default label" data-label="DR_label">
          <div id="u368_div" class=""></div>
          <div id="u368_text" class="text ">
            <p><span>和</span></p>
          </div>
        </div>

        <!-- THP_label (Rectangle) -->
        <div id="u369" class="ax_default label" data-label="THP_label">
          <div id="u369_div" class=""></div>
          <div id="u369_text" class="text ">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u370" class="ax_default box_2">
          <div id="u370_div" class=""></div>
          <div id="u370_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TH_bar (Rectangle) -->
        <div id="u371" class="ax_default box_2" data-label="TH_bar">
          <div id="u371_div" class=""></div>
          <div id="u371_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TH_label (Rectangle) -->
        <div id="u372" class="ax_default label" data-label="TH_label">
          <div id="u372_div" class=""></div>
          <div id="u372_text" class="text ">
            <p><span></span></p>
          </div>
        </div>
        
      </div>
      
      
      <!-- Logo_Group (Group) -->
      <div id="u373" class="ax_default" data-label="Logo_Group" data-left="375" data-top="130" data-width="623" data-height="146">
      

      <?php if(isset($a1s)): ?>    

        <!-- TA_G (Image) -->
        <div id="u374" class="ax_default image" data-label="TA_G">
          <img id="u374_img" class="img " src="<?php echo e(asset($a1s->g_img)); ?>"/>
          <div id="u374_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TH_G (Image) -->
        <div id="u375" class="ax_default image" data-label="TH_G">
          <img id="u375_img" class="img " src="<?php echo e(asset($a1s->h_img)); ?>"/>
          <div id="u375_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u376" class="ax_default box_2" data-label="Team_Away">
          <div id="u376_div" class=""></div>
          <div id="u376_text" class="text ">
            <p><span><?php echo e($a1s->guest); ?></span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u377" class="ax_default box_2" data-label="Team_Home">
          <div id="u377_div" class=""></div>
          <div id="u377_text" class="text ">
            <p><span><?php echo e($a1s->host); ?></span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u378" class="ax_default box_2" data-label="Date_Time">
          <div id="u378_div" class=""></div>
          <div id="u378_text" class="text ">
            <p><span><?php echo e(Carbon\Carbon::parse($a1s->date)->diffForHumans()); ?></span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u379" class="ax_default box_2" data-label="Match">
          <div id="u379_div" class=""></div>
          <div id="u379_text" class="text ">
            <p><span><?php echo e($a1s->league); ?></span></p>
          </div>
        </div>
      </div>
      

      <!-- Rate_table (Group) -->
      <div id="u343" class="ax_default" data-label="Rate_table" data-left="332" data-top="470" data-width="716" data-height="80">
      
        <!-- TAW_rtg (Rectangle) -->
        <div id="u344" class="ax_default box_2" data-label="TAW_rtg">
          <div id="u344_div" class=""></div>
          <div id="u344_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- TAW_rprv (Rectangle) -->
        <div id="u345" class="ax_default paragraph" data-label="TAW_rprv">
          <div id="u345_div" class=""></div>
          <div id="u345_text" class="text ">
            <p><span><?php echo e($a1s->g_return); ?>%</span></p>
          </div>
        </div>

        <!-- TAW_rpr (Rectangle) -->
        <div id="u346" class="ax_default paragraph" data-label="TAW_rpr">
          <div id="u346_div" class=""></div>
          <div id="u346_text" class="text ">
            <p><span>客勝回報率</span></p>
          </div>
        </div>

        <!-- TAW_rv (Rectangle) -->
        <div id="u347" class="ax_default paragraph" data-label="TAW_rv">
          <div id="u347_div" class=""></div>
          <div id="u347_text" class="text ">
            <p><span><?php echo e($a1s->g_win); ?>%</span></p>
          </div>
        </div>

        <!-- TAW_r (Rectangle) -->
        <div id="u348" class="ax_default paragraph" data-label="TAW_r">
          <div id="u348_div" class=""></div>
          <div id="u348_text" class="text ">
            <p><span>客隊勝率</span></p>
          </div>
        </div>

        <!-- DR_rtg (Rectangle) -->
        <div id="u349" class="ax_default box_2" data-label="DR_rtg">
          <div id="u349_div" class=""></div>
          <div id="u349_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- DR_rprv (Rectangle) -->
        <div id="u350" class="ax_default paragraph" data-label="DR_rprv">
          <div id="u350_div" class=""></div>
          <div id="u350_text" class="text ">
            <p><span><?php echo e($a1s->d_return); ?>%</span></p>
          </div>
        </div>

        <!-- DR_rpr (Rectangle) -->
        <div id="u351" class="ax_default paragraph" data-label="DR_rpr">
          <div id="u351_div" class=""></div>
          <div id="u351_text" class="text ">
            <p><span>和波回報率</span></p>
          </div>
        </div>

        <!-- DR_rv (Rectangle) -->
        <div id="u352" class="ax_default paragraph" data-label="DR_rv">
          <div id="u352_div" class=""></div>
          <div id="u352_text" class="text ">
            <p><span><?php echo e($a1s->draw); ?>%</span></p>
          </div>
        </div>

        <!-- DR_r (Rectangle) -->
        <div id="u353" class="ax_default paragraph" data-label="DR_r">
          <div id="u353_div" class=""></div>
          <div id="u353_text" class="text ">
            <p><span>和波機率</span></p>
          </div>
        </div>

        <!-- THW_rtg (Rectangle) -->
        <div id="u354" class="ax_default box_2" data-label="THW_rtg">
          <div id="u354_div" class=""></div>
          <div id="u354_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- THW_rprv (Rectangle) -->
        <div id="u355" class="ax_default paragraph" data-label="THW_rprv">
          <div id="u355_div" class=""></div>
          <div id="u355_text" class="text ">
            <p><span><?php echo e($a1s->h_return); ?>%</span></p>
          </div>
        </div>

        <!-- THW_rpr (Rectangle) -->
        <div id="u356" class="ax_default paragraph" data-label="THW_rpr">
          <div id="u356_div" class=""></div>
          <div id="u356_text" class="text ">
            <p><span>主勝回報率</span></p>
          </div>
        </div>
        
        <!-- THW_rv (Rectangle) -->
        
        <div id="u357" class="ax_default paragraph" data-label="THW_rv">
          <div id="u357_div" class=""></div>
          <div id="u357_text" class="text ">
            <p><span><?php echo e($a1s->h_win); ?>%</span></p>
          </div>
        </div>
        
        
        
        <!-- THW_r (Rectangle) -->
        <div id="u358" class="ax_default paragraph" data-label="THW_r">
          <div id="u358_div" class=""></div>
          <div id="u358_text" class="text ">
            <p><span>主隊勝率</span></p>
          </div>
        </div>
      </div>
      <?php endif; ?>
      
      <!-- Header (Rectangle) -->
      <div id="u380" class="ax_default heading_1" data-label="Header">
        <div id="u380_div" class=""></div>
        <div id="u380_text" class="text ">
          <p><span>AI</span><span>模組賽果預測 – 各隊 主 / 和 / 客 機率</span></p>
        </div>
      </div>
      
      <!-- NAVIGATION BAR (Group) -->
      <div id="u381" class="ax_default" data-label="NAVIGATION BAR" data-left="1" data-top="0" data-width="1364" data-height="210">

        <!-- Unnamed (Placeholder) -->
        <div id="u382" class="ax_default placeholder">
          <img id="u382_img" class="img " src="/football/public/frontend/images/page_a4/u164.svg"/>
          <div id="u382_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u383" class="ax_default box_1">
          <div id="u383_div" class=""></div>
          <div id="u383_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u384" class="ax_default box_3">
          <div id="u384_div" class=""></div>
          <div id="u384_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u385" class="ax_default box_3">
          <div id="u385_div" class=""></div>
          <div id="u385_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u386" class="ax_default box_3">
          <div id="u386_div" class=""></div>
          <div id="u386_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u387" class="ax_default box_3">
          <div id="u387_div" class=""></div>
          <div id="u387_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u388" class="ax_default box_3">
          <div id="u388_div" class=""></div>
          <div id="u388_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u389" class="ax_default box_3">
          <div id="u389_div" class=""></div>
          <div id="u389_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u390" class="ax_default box_3">
          <div id="u390_div" class=""></div>
          <div id="u390_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u391" class="ax_default">
          <div id="u391_state0" class="panel_state" data-label="State 1" style="">
            <div id="u391_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u392" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u393" class="ax_default box_3">
                  <div id="u393_div" class=""></div>
                  <div id="u393_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u394" class="ax_default box_3">
                  <div id="u394_div" class=""></div>
                  <div id="u394_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u395" class="ax_default box_3">
                  <div id="u395_div" class=""></div>
                  <div id="u395_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u396" class="ax_default box_3">
                  <img id="u396_img" class="img " src="/football/public/frontend/images/page_a4/u178.svg"/>
                  <div id="u396_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u397" class="ax_default box_3">
                  <div id="u397_div" class=""></div>
                  <div id="u397_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u398" class="ax_default box_3">
                  <div id="u398_div" class=""></div>
                  <div id="u398_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u399" class="ax_default box_3">
                  <div id="u399_div" class=""></div>
                  <div id="u399_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u400" class="ax_default">
          <div id="u400_state0" class="panel_state" data-label="State 1" style="">
            <div id="u400_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u401" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="121" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u402" class="ax_default box_3">
                  <div id="u402_div" class=""></div>
                  <div id="u402_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u403" class="ax_default box_3">
                  <div id="u403_div" class=""></div>
                  <div id="u403_text" class="text ">
                    <p><span>AI模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u404" class="ax_default box_3">
                  <div id="u404_div" class=""></div>
                  <div id="u404_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u405" class="ax_default box_3">
                  <img id="u405_img" class="img " src="/football/public/frontend/images/page_a4/u178.svg"/>
                  <div id="u405_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u406" class="ax_default box_3">
                  <div id="u406_div" class=""></div>
                  <div id="u406_text" class="text ">
                    <p><span>AI模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u407" class="ax_default box_3">
                  <div id="u407_div" class=""></div>
                  <div id="u407_text" class="text ">
                    <p><span>AI模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u408" class="ax_default">
          <div id="u408_state0" class="panel_state" data-label="State 1" style="">
            <div id="u408_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u409" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="135" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u410" class="ax_default box_3">
                  <div id="u410_div" class=""></div>
                  <div id="u410_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u411" class="ax_default box_3">
                  <div id="u411_div" class=""></div>
                  <div id="u411_text" class="text ">
                    <p><span>&nbsp;Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u412" class="ax_default box_3">
                  <div id="u412_div" class=""></div>
                  <div id="u412_text" class="text ">
                    <p><span>&nbsp;&nbsp; &nbsp; 爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u413" class="ax_default box_3">
                  <img id="u413_img" class="img " src="/football/public/frontend/images/page_a4/u195.svg"/>
                  <div id="u413_text" class="text ">
                    <p><span>AI模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Top Menu_M (Group) -->
    <div id="u330" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

      <!-- Unnamed (Placeholder) -->
        <div id="u331" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u331_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
          <div id="u331_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u332" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u332_div" class=""></div>
        <div id="u332_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
        <div id="u333" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u333_div" class=""></div>
          <div id="u333_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>

    </div>
    
      <!-- Unnamed (Dynamic Panel) -->
      <div id="u296" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u296_state0" class="panel_state" data-label="State 1" style="">
          <div id="u296_state0_content" class="panel_state_content">

            <!-- 1ST SUB (Group) -->
            <div id="u297" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u298" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u298_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u298_state0_content" class="panel_state_content">

                    <!-- HOME_SUBMENU (Group) -->
                    <div id="u299" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u300" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u300_div" class=""></div>
                        <div id="u300_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u301" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u301_div" class=""></div>
                        <div id="u301_text" class="text ">
                          <p><span>&nbsp;簡介</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u302" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u302_div" class=""></div>
                        <div id="u302_text" class="text ">
                          <p><span>&nbsp;如何應用</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u303" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u303_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                        <div id="u303_text" class="text ">
                          <p><span>&nbsp; 為何我們</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u304" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u304_div" class=""></div>
                        <div id="u304_text" class="text ">
                          <p><span>&nbsp; 馬上註冊</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u305" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u305_div" class=""></div>
                        <div id="u305_text" class="text ">
                          <p><span>&nbsp; 用戶推薦</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u306" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u306_div" class=""></div>
                        <div id="u306_text" class="text ">
                          <p><span>&nbsp; 風險披露</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u307" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u307_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u307_text" class="text ">
                  <p><span>首頁</span></p>
                </div>
              </div>
            </div>

            <!-- 2ND SUB (Group) -->
            <div id="u308" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u309" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u309_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u309_text" class="text ">
                  <p><span>足球AI模組分析</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u310" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u310_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u310_state0_content" class="panel_state_content">

                    <!-- AI_SUBMENU (Group) -->
                    <div id="u311" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u312" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u312_div" class=""></div>
                        <div id="u312_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u313" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u313_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                        <div id="u313_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u314" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u314_div" class=""></div>
                        <div id="u314_text" class="text ">
                          <p><span>&nbsp;綜合網民數據結果</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u315" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <img id="u315_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                        <div id="u315_text" class="text ">
                          <p><span>&nbsp;值博率模組分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u316" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u316_div" class=""></div>
                        <div id="u316_text" class="text ">
                          <p><span>&nbsp; AI模組波膽分析</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u317" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                        <div id="u317_div" class=""></div>
                        <div id="u317_text" class="text ">
                          <p><span>&nbsp;AI模組分析大小角</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 3RD SUB (Group) -->
            <div id="u318" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

              <!-- Unnamed (Shape) -->
              <div id="u319" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u319_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u319_text" class="text ">
                  <p><span>Futra是日精選</span></p>
                </div>
              </div>

              <!-- Unnamed (Dynamic Panel) -->
              <div id="u320" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                <div id="u320_state0" class="panel_state" data-label="State 1" style="">
                  <div id="u320_state0_content" class="panel_state_content">

                    <!-- FUTRA_SUBMENU (Group) -->
                    <div id="u321" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                      <!-- Unnamed (Rectangle) -->
                      <div id="u322" class="ax_default box_3">
                        <div id="u322_div" class=""></div>
                        <div id="u322_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u323" class="ax_default box_3">
                        <img id="u323_img" class="img " src="/football/public/frontend/images/page_a4/u28.svg"/>
                        <div id="u323_text" class="text ">
                          <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Rectangle) -->
                      <div id="u324" class="ax_default box_3">
                        <div id="u324_div" class=""></div>
                        <div id="u324_text" class="text ">
                          <p><span>爆冷精選</span></p>
                        </div>
                      </div>

                      <!-- Unnamed (Shape) -->
                      <div id="u325" class="ax_default box_3">
                        <img id="u325_img" class="img " src="/football/public/frontend/images/page_a4/u30.svg"/>
                        <div id="u325_text" class="text ">
                          <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u326" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u326_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u326_text" class="text ">
                <p><span>為何我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u327" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u327_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u327_text" class="text ">
                <p><span>聯絡我們</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u328" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u328_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u328_text" class="text ">
                <p><span>會員中心</span></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u329" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
              <img id="u329_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
              <div id="u329_text" class="text ">
                <p><span>登入</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="/football/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/football0/resources/views/frontend/page_a1.blade.php ENDPATH**/ ?>