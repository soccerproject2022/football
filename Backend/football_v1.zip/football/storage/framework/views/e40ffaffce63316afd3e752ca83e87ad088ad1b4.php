<table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col">game id</th>
                        <th scope="col">聯賽</th>
                        <th scope="col">日期時間</th>
                        <th scope="col">主</th>
                        <th scope="col">客</th>
                        <th scope="col">主勝</th>
                        <th scope="col">和率</th>
                        <th scope="col">客勝</th>
                        <th scope="col">主回率</th>
                        <th scope="col">和回率</th>
                        <th scope="col">客回率</th>
                        <th scope="col">主隊圖</th>
                        <th scope="col">客隊圖</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $a1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a1datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($a1datum->game_id); ?></td>
                        <td><?php echo e($a1datum->league); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($a1datum->date)->diffForHumans()); ?></td>
                        <td><?php echo e($a1datum->host); ?></td>
                        <td><?php echo e($a1datum->guest); ?></td>
                        <td><?php echo e($a1datum->h_win); ?></td>
                        <td><?php echo e($a1datum->draw); ?></td>
                        <td><?php echo e($a1datum->g_win); ?></td>
                        <td><?php echo e($a1datum->h_return); ?></td>
                        <td><?php echo e($a1datum->d_return); ?></td>
                        <td><?php echo e($a1datum->g_return); ?></td>
                        <td><img src="<?php echo e(asset($a1datum->h_img)); ?>" style="width:40px"></td>
                        <td><img src="<?php echo e(asset($a1datum->g_img)); ?>" style="width:40px"></td>
                        <td><a href="<?php echo e(url('a1/edit/'.$a1datum->game_id)); ?>" class="btn btn-info">Edit</a></td>
                        <td><a href="<?php echo e(url('a1/delete'.$a1datum->game_id)); ?>" class="btn btn-danger">Delete</a></td>
                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table><?php /**PATH /Applications/MAMP/htdocs/football/resources/views/frontend/test.blade.php ENDPATH**/ ?>