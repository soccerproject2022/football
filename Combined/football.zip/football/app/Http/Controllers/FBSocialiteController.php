<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Laravel\Socialite\Facades\Socialite;

class FBSocialiteController extends Controller
{
    public function fbLogin(Request $request)
    {
        $redirect_url = Socialite::driver('facebook')->redirect();
        //    ->scopes(['email'])  
        //    ->redirect()->getTargetUrl();
        //return response()->json(['target' => [$redirect_url]], 302);
    }

    public function fbLoginCallback(Request $request)
    {
        try {
        
            $user = Socialite::driver('facebook')->user();
         
            $finduser = User::where('fb_id', $user->id)->first();
        
            if($finduser){
         
                Auth::login($finduser);
        
                return redirect()->intended('dashboard');
         
            }else{
                $newUser = User::create([
                    'name' => $user->name,
                    'email' => $user->email,
                    'fb_id'=> $user->id,
                    'password' => encrypt('123456dummy')
                ]);
        
                Auth::login($newUser);
        
                return redirect()->intended('dashboard');
            }
        
        } catch (Exception $e) {
            dd($e->getMessage());
        }
    }
}
