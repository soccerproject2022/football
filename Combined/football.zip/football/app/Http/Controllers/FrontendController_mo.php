<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;


class FrontendController extends Controller
{
    public function ShowA1(){
        $b1s = DB::table('11')->where('game_id', 1)->first();
        return view ('frontend/page_a1', compact('b1s'));
        
    } 
// Function for A1->B1
    public function IntoB1(){
        $a1s = DB::table('b1s')->get();
        return view ('frontend/a1', compact('a1s'));
    }
}