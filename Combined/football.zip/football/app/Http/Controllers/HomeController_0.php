<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\a1;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class HomeController extends Controller
{
    public function Logout(){
        Auth::logout();
        return Redirect()->route('login')->with('success', 'User Logout');
    }

    public function LoadA1(){
        
        $a1s = DB::table('a1')->get();
        return view('admin.a1.index', compact('a1s'));
    }

    public function EditA1($id){
        $a1s = DB::table('a1')->where('game_id', $id)->first();
        return view('admin.a1.edit', compact('a1s'));
    }

    public function UpdateA1(Request $request, $id){
        $validateData = $request->validate([
            'date' =>  'required',
        ],
        [
            'date.required'=> '請輸入日期',
        ]);
        if ($request->h_img !=null | $request->g_img !=null){
            $h_img = $request->file('h_img');
            $g_img = $request->file('g_img');
            $hname_gen = hexdec(uniqid());
            $gname_gen = hexdec(uniqid());
            $himg_ext = strtolower($h_img->getClientOriginalExtension());
            $gimg_ext = strtolower($g_img->getClientOriginalExtension());
            $himg_name = $hname_gen. '.'. $himg_ext;
            $gimg_name = $gname_gen. '.'. $gimg_ext;
            $up_location = 'image/club/';
            $last_himg = $up_location.$himg_name;
            $last_gimg = $up_location.$gimg_name;
            $h_img->move($up_location,$himg_name );
            $g_img->move($up_location,$gimg_name );
            $updateA1 = DB::table('a1')->where('game_id', $id)->update([
                'h_img'=>$last_himg,
                'g_img'=>$last_gimg,
            ]);
        }
        
        DB::table('a1')->where('game_id', $id)->update([
            'league'=>$request->league,
            'date'=>$request->date,
            'host'=>$request->host,
            'guest'=>$request->guest,
            'h_win'=>$request->h_win,
            'draw'=>$request->draw,
            'g_win'=>$request->g_win,
            'h_return'=>$request->h_return,
            'd_return'=>$request->d_return,
            'g_return'=>$request->g_return,

            'updated_at'=> Carbon::now()
        ]);
        $a1s = DB::table('a1')->get();
        return view('admin.a1.index', compact('a1s'))->with('success', 'data updated successfully');
    }

    public function CreateA1(Request $request){
        $validateData = $request->validate([
            'h_img' =>  'required|mimes:jpg,jpeg,png',
            'g_img' =>  'required|mimes:jpg,jpeg,png',
        ],
        [
            'h_img.required'=> '請加入圖片',
            'g_img.required'=> '請加入圖片'
        ]);
        $h_img = $request->file('h_img');
        $g_img = $request->file('g_img');
        $hname_gen = hexdec(uniqid());
        $gname_gen = hexdec(uniqid());
        $himg_ext = strtolower($h_img->getClientOriginalExtension());
        $gimg_ext = strtolower($g_img->getClientOriginalExtension());
        $himg_name = $hname_gen. '.'. $himg_ext;
        $gimg_name = $gname_gen. '.'. $gimg_ext;
        /*$up_location = 'image/club/';*/
        $up_location = 'image/club/';
        $last_himg = $up_location.$himg_name;
        $last_gimg = $up_location.$gimg_name;
        $h_img->move($up_location,$himg_name );
        $g_img->move($up_location,$gimg_name );
        DB::table('a1')->insert([
            'league'=>$request->league,
            'date'=>$request->date,
            'host'=>$request->host,
            'guest'=>$request->guest,
            'h_win'=>$request->h_win,
            'draw'=>$request->draw,
            'g_win'=>$request->g_win,
            'h_return'=>$request->h_return,
            'd_return'=>$request->d_return,
            'g_return'=>$request->g_return,
            'h_img'=>$last_himg,
            'g_img'=>$last_gimg,
            'created_at'=> Carbon::now()
        ]);

        return Redirect()->back()->with('success', 'data created successfully');
    }
}
