<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class a1 extends Model
{
    use HasFactory;
    protected $fillable = [
        'game_id',
        'league',
        'date',
        'host',
        'guest',
        'h_win',
        'draw',
        'g_win',
        'h_return',
        'd_return',
        'g_return',
        'h_img',
        'g_img',
        'jc_id',
    ];
}
