<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class a5 extends Model
{
    use HasFactory;
    protected $fillable = [
        'home',
        'guest',
        'id',
        'game_id',
        'h_corner',
        'g_corner',
        'total_corner',
        'h_min',
        'g_min',
        'total_min',
        'h_max',
        'g_max',
        'total_max',
       
    ];
}
