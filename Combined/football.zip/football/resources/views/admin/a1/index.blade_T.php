
    
        <div class="card-header card-header-border-bottom">
            <h2>a1 database table</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col">game id</th>
                        <th scope="col">聯賽</th>
                        <th scope="col">日期時間</th>
                        <th scope="col">主</th>
                        <th scope="col">客</th>
                        <th scope="col">主勝</th>
                        <th scope="col">和率</th>
                        <th scope="col">客勝</th>
                        <th scope="col">主回率</th>
                        <th scope="col">和回率</th>
                        <th scope="col">客回率</th>
                        <th scope="col">主隊圖</th>
                        <th scope="col">客隊圖</th>
                    </tr>
                </thead>
                <tbody>

                    @foreach($a1s as $a1datum)
                    <tr>
                        <td>{{ $a1datum->game_id }}</td>
                        <td>{{ $a1datum->league }}</td>
                        <td>{{ Carbon\Carbon::parse($a1datum->date)->diffForHumans() }}</td>
                        <td>{{ $a1datum->host }}</td>
                        <td>{{ $a1datum->guest }}</td>
                        <td>{{ $a1datum->h_win }}</td>
                        <td>{{ $a1datum->draw }}</td>
                        <td>{{ $a1datum->g_win }}</td>
                        <td>{{ $a1datum->h_return }}</td>
                        <td>{{ $a1datum->d_return }}</td>
                        <td>{{ $a1datum->g_return }}</td>
                        <td><img src="{{ asset($a1datum->h_img) }}" style="width:40px"></td>
                        <td><img src="{{ asset($a1datum->g_img) }}" style="width:40px"></td>
                        <td><a href="{{ url('a1/edit/'.$a1datum->game_id) }}" class="btn btn-info">Edit</a></td>
                        <td><a href="{{ url('a1/delete'.$a1datum->game_id) }}" class="btn btn-danger">Delete</a></td>
                    
                    </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card card-default">
            <div class="card-header card-header-border-bottom">
                <h2></h2>
            </div>
            <div class="card-body">
                <form action="{{ route('create.a1') }}" method="POST" enctype="multipart/form-data">
                @csrf
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >聯賽</label>
                                <input type="text" name="league" class="form-control" placeholder="聯賽">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >日期時間</label>
                                <input type="datetime-local" name="date" class="form-control" placeholder="日期時間">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="主隊">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="客隊">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >主勝</label>
                                <input type="number" name="h_win" class="form-control" placeholder="主勝率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >和率</label>
                                <input type="number" name="draw" class="form-control" placeholder="和率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >客勝</label>
                                <input type="number" name="g_win" class="form-control" placeholder="客勝率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >主回率</label>
                                <input type="number" name="h_return" class="form-control" placeholder="主回率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >和回率</label>
                                <input type="number" name="d_return" class="form-control" placeholder="和回率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>客回</label>
                                <input type="number" name="g_return" class="form-control" placeholder="客回" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >主隊圖</label>
                                <input type="file" name="g_img" class="form-control" >
                                @error('h_img')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="city">客隊圖</label>
                                <input type="file" name="h_img" class="form-control" >
                                @error('g_img')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Create</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
