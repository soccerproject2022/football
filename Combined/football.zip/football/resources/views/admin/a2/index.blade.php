@extends('admin.admin_master')
@section('admin')


<div class="col-lg-12">

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>{{ session('success') }}</strong>
    <button type="button" class="class" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@endif

    
        <div class="card-header card-header-border-bottom">
            <h2>a2 database table</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col">game_id</th>
                        <th scope="col">主隊</th>
                        <th scope="col">客隊</th>
                        <th scope="col">主隊勝數</th>
                        <th scope="col">和波機數</th>
                        <th scope="col">客隊勝數</th>
                        
                    </tr>
                </thead>
                <tbody>

                    @foreach($a2s as $a2datum)
                    <tr>
                        <td>{{ $a2datum->game_id }}</td>
                        <td>{{ $a2datum->host }}</td>
                        <td>{{ $a2datum->guest }}</td>
                        <td>{{ $a2datum->h_guess }}</td>
                        <td>{{ $a2datum->d_guess }}</td>
                        <td>{{ $a2datum->g_guess }}</td>
                        
                        <td><a href="{{ url('a2/edit/'.$a2datum->game_id) }}" class="btn btn-info">Edit</a></td>
                        <td><a href="{{ url('a2/delete/'.$a2datum->game_id) }}" onclick="return confirm('Are you sure to delete?')" class="btn btn-danger">Delete</a></td>
                    
                    </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card card-default">
            <div class="card-header card-header-border-bottom">
                <h2></h2>
            </div>
            <div class="card-body">
                <form action="{{ route('create.a2') }}" method="POST" >
                @csrf
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="exampleFormControlSelect2">選擇 game_id</label>
                                <select class="form-control" id="exampleFormControlSelect2" name="game_id">
                                    <option disabled selected="">-- 選擇 game_id --</option>
                                    @foreach($a2gameid as $gameid)
                                    <option value="{{ $gameid->game_id }}" {{ (isset($gameid->game_id)|| old('id'))? "selected":"" }}>{{ $gameid->host }}| vs | {{ $gameid->guest }}</option>
                                    @endforeach
                                </select>
                                
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >主隊勝數</label>
                                <input type="number" name="h_guess" class="form-control" placeholder="主場勝數" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >和波機數</label>
                                <input type="number" name="d_guess" class="form-control" placeholder="和波機數" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >客隊勝數</label>
                                <input type="number" name="g_guess" class="form-control" placeholder="客隊勝數" step=any >
                            </div>
                        </div>
                        
                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Create</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection