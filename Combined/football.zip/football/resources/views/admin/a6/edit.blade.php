@extends('admin.admin_master')
@section('edita2')
<div class="col-lg-12">
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>{{ session('success') }}</strong>
<button type="button" class="class" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
</div>
@endif
            <div class="card-header card-header-border-bottom">
                <h2>Edit a6 data</h2>
            </div>
            <div class="card-body">
                <form action="{{ url('a6/update/'.$a6s->id) }}" method="POST" >
                @csrf
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >id</label>
                                <input type="hidden" name="id" class="form-control" >
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="host" disabled value="{{ $a6s->host }}">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="guest" disabled value="{{ $a6s->guest }}">
                            </div>
                        </div>
                        
                        <div class="col-sm-2">
                            <div class="form-group">
                            <label for="exampleFormControlSelect4">預測結果</label>
                                <select class="form-control" id="exampleFormControlSelect4" name="guess_opt">
                                    <option disabled selected="">-- guess_opt --</option>
                                    @foreach($a6opt as $opt)
                                    <option value="{{ $opt->opt }}" {{ (isset($opt->opt)|| old('opt'))? "selected":"" }}>
                                        {{ $opt->opt }}   </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection