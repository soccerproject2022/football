@extends('admin.admin_master')
@section('admin')


<div class="col-lg-12">

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>{{ session('success') }}</strong>
    <button type="button" class="class" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@endif

    
        <div class="card-header card-header-border-bottom">
            <h2>a6 database table</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">主隊</th>
                        <th scope="col">客隊</th>
                        <th scope="col">預測結果</th>
                        
                    </tr>
                </thead>
                <tbody>

                    @foreach($a6s as $a6datum)
                    <tr>
                        <td>{{ $a6datum->game_id }}</td>
                        <td>{{ $a6datum->host }}</td>
                        <td>{{ $a6datum->guest }}</td>
                        <td>{{ $a6datum->guess_opt }}</td>


                        <td><a href="{{ url('a6/edit/'.$a6datum->game_id) }}" class="btn btn-info">Edit</a></td>
                        <td><a href="{{ url('a6/delete/'.$a6datum->game_id) }}" onclick="return confirm('Are you sure to delete?')" class="btn btn-danger">Delete</a></td>
                    
                    </tr>
                    @endforeach
                </tbody>
            </table>
           
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card card-default">
            <div class="card-header card-header-border-bottom">
                <h2></h2>
            </div>
            <div class="card-body">
                <form action="{{ route('create.a6') }}" method="POST">
                @csrf
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="exampleFormControlSelect2">選擇 game_id</label>
                                <select class="form-control" id="exampleFormControlSelect2" name="game_id">
                                    <option disabled selected="">-- 選擇 game_id --</option>
                                    @foreach($a6gameid as $gameid)
                                    <option value="{{ $gameid->game_id }}" {{ (isset($gameid->game_id)|| old('id'))? "selected":"" }}>{{ $gameid->host }}| vs | {{ $gameid->guest }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                            <label for="exampleFormControlSelect3">選擇預測結果</label>
                                <select class="form-control" id="exampleFormControlSelect3" name="guess_opt">
                                    <option disabled selected="">-- 選擇 guess_opt --</option>
                                    @foreach($a6opt as $opt)
                                    <option value="{{ $opt->opt }}" {{ (isset($opt->opt)|| old('opt'))? "selected":"" }}>
                                        {{ $opt->opt }}   </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        
                        
                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Create</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection