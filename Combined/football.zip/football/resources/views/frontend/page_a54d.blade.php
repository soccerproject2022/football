﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A5</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a5/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a5/data.js"></script>
    <script src="/footballui/public/frontend/files/page_a8/canvasjs.min.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>

<!--Chart1-->
<script>
 
 @if(isset($b516s,$b517s,$b518s,$b519s,$b520s))

  window.onload = function () {
  
    var chart1 = new CanvasJS.Chart("chart1", {
    animationEnabled: true,
    theme: "dark2",
    title:{
    text: "{{ $b516s->host }} vs {{ $b516s->guest }}"
  },
    toolTip:{
    enabled: false,
    shared:false
  },  



    data: [{
    type: "line",
    showInLegend: true,
    name: "主隊",
    markerType: "circle",
    color: "red",
    dataPoints: [
      { x: 5, y: {{ $b516s->h2 }}, label:"1" },
      { x: 10, y: {{ $b516s->h2 }}, label:"2" },
      { x: 15, y: {{ $b516s->h3 }}, label:"3" },
      { x: 20, y: {{ $b516s->h4 }}, label:"4" },
      { x: 25, y: {{ $b516s->h5 }}, label:"5" },
      { x: 30, y: {{ $b516s->h6 }}, label:"6" },
      { x: 35, y: {{ $b516s->h7 }}, label:"7" },
      { x: 40, y: {{ $b516s->h8 }}, label:"8" },
      { x: 45, y: {{ $b516s->h9 }}, label:"9" },
      { x: 50, y: {{ $b516s->h10 }}, label:"10" },
      { x: 55, y: {{ $b516s->h11 }}, label:"11" },
      { x: 60, y: {{ $b516s->h12 }}, label:"12" },
      { x: 65, y: {{ $b516s->h13 }}, label:"13" },
      { x: 70, y: {{ $b516s->h14 }}, label:"14" },
      { x: 75, y: {{ $b516s->h15 }}, label:"15" },
      { x: 80, y: {{ $b516s->h16 }}, label:"16" },
      { x: 85, y: {{ $b516s->h17 }}, label:"17" },
      { x: 90, y: {{ $b516s->h18 }}, label:"18" },
      { x: 95, y: {{ $b516s->h19 }}, label:"19" },
      { x: 100, y: {{ $b516s->h20 }}, label:"20" }
     
    ]
  },
  {
    type: "line",
    showInLegend: true,
    name: "客隊",
    markerType: "circle",
    color: "green",
    dataPoints: [
      { x: 5, y: {{ $b516s->g1 }}, label:"1" },
      { x: 10, y: {{ $b516s->g2 }}, label:"2" },
      { x: 15, y: {{ $b516s->g3 }}, label:"3" },
      { x: 20, y: {{ $b516s->g4 }}, label:"4" },
      { x: 25, y: {{ $b516s->g5 }}, label:"5" },
      { x: 30, y: {{ $b516s->g6 }}, label:"6" },
      { x: 35, y: {{ $b516s->g7 }}, label:"7" },
      { x: 40, y: {{ $b516s->g8 }}, label:"8" },
      { x: 45, y: {{ $b516s->g9 }}, label:"9" },
      { x: 50, y: {{ $b516s->g10 }}, label:"10" },
      { x: 55, y: {{ $b516s->g11 }}, label:"11" },
      { x: 60, y: {{ $b516s->g12 }}, label:"12" },
      { x: 65, y: {{ $b516s->g13 }}, label:"13" },
      { x: 70, y: {{ $b516s->g14 }}, label:"14" },
      { x: 75, y: {{ $b516s->g15 }}, label:"15" },
      { x: 80, y: {{ $b516s->g16 }}, label:"16" },
      { x: 85, y: {{ $b516s->g17 }}, label:"17" },
      { x: 90, y: {{ $b516s->g18 }}, label:"18" },
      { x: 95, y: {{ $b516s->g19 }}, label:"19" },
      { x: 100, y: {{ $b516s->g20 }}, label:"20" }
      
    ]
  },

  {
    type: "line",
    showInLegend: true,
    name: "總角球",
    markerType: "circle",
    color: "blue",
    dataPoints: [
      { x: 5, y: {{ $b516s->t1 }}, label:"1" },
      { x: 10, y: {{ $b516s->t2 }}, label:"2" },
      { x: 15, y: {{ $b516s->t3 }}, label:"3" },
      { x: 20, y: {{ $b516s->t4 }}, label:"4" },
      { x: 25, y: {{ $b516s->t5 }}, label:"5" },
      { x: 30, y: {{ $b516s->t6 }}, label:"6" },
      { x: 35, y: {{ $b516s->t7 }}, label:"7" },
      { x: 40, y: {{ $b516s->t8 }}, label:"8" },
      { x: 45, y: {{ $b516s->t9 }}, label:"9" },
      { x: 50, y: {{ $b516s->t10 }}, label:"10" },
      { x: 55, y: {{ $b516s->t11 }}, label:"11" },
      { x: 60, y: {{ $b516s->t12 }}, label:"12" },
      { x: 65, y: {{ $b516s->t13 }}, label:"13" },
      { x: 70, y: {{ $b516s->t14 }}, label:"14" },
      { x: 75, y: {{ $b516s->t15 }}, label:"15" },
      { x: 80, y: {{ $b516s->t16 }}, label:"16" },
      { x: 85, y: {{ $b516s->t17 }}, label:"17" },
      { x: 90, y: {{ $b516s->t18 }}, label:"18" },
      { x: 95, y: {{ $b516s->t19 }}, label:"19" },
      { x: 100, y: {{ $b516s->t20 }}, label:"20" }
      
    ]
  }]
  });
    
  

//chart2
  
    var chart2 = new CanvasJS.Chart("chart2", {
    animationEnabled: true,
    theme: "dark2",
    title:{
    text: "{{ $b517s->host }} vs {{ $b517s->guest }}"
  },
    toolTip:{
    enabled: false,
    shared:false
  },  



    data: [{
    type: "line",
    showInLegend: true,
    name: "主隊",
    markerType: "circle",
    color: "red",
    dataPoints: [
      { x: 5, y: {{ $b517s->h1 }}, label:"1" },
      { x: 10, y: {{ $b517s->h2 }}, label:"2" },
      { x: 15, y: {{ $b517s->h3 }}, label:"3" },
      { x: 20, y: {{ $b517s->h4 }}, label:"4" },
      { x: 25, y: {{ $b517s->h5 }}, label:"5" },
      { x: 30, y: {{ $b517s->h6 }}, label:"6" },
      { x: 35, y: {{ $b517s->h7 }}, label:"7" },
      { x: 40, y: {{ $b517s->h8 }}, label:"8" },
      { x: 45, y: {{ $b517s->h9 }}, label:"9" },
      { x: 50, y: {{ $b517s->h10 }}, label:"10" },
      { x: 55, y: {{ $b517s->h11 }}, label:"11" },
      { x: 60, y: {{ $b517s->h12 }}, label:"12" },
      { x: 65, y: {{ $b517s->h13 }}, label:"13" },
      { x: 70, y: {{ $b517s->h14 }}, label:"14" },
      { x: 75, y: {{ $b517s->h15 }}, label:"15" },
      { x: 80, y: {{ $b517s->h16 }}, label:"16" },
      { x: 85, y: {{ $b517s->h17 }}, label:"17" },
      { x: 90, y: {{ $b517s->h18 }}, label:"18" },
      { x: 95, y: {{ $b517s->h19 }}, label:"19" },
      { x: 100, y: {{ $b517s->h20 }}, label:"20" }
     
    ]
  },
  {
    type: "line",
    showInLegend: true,
    name: "客隊",
    markerType: "circle",
    color: "green",
    dataPoints: [
      { x: 5, y: {{ $b517s->g1 }}, label:"1" },
      { x: 10, y: {{ $b517s->g2 }}, label:"2" },
      { x: 15, y: {{ $b517s->g3 }}, label:"3" },
      { x: 20, y: {{ $b517s->g4 }}, label:"4" },
      { x: 25, y: {{ $b517s->g5 }}, label:"5" },
      { x: 30, y: {{ $b517s->g6 }}, label:"6" },
      { x: 35, y: {{ $b517s->g7 }}, label:"7" },
      { x: 40, y: {{ $b517s->g8 }}, label:"8" },
      { x: 45, y: {{ $b517s->g9 }}, label:"9" },
      { x: 50, y: {{ $b517s->g10 }}, label:"10" },
      { x: 55, y: {{ $b517s->g11 }}, label:"11" },
      { x: 60, y: {{ $b517s->g12 }}, label:"12" },
      { x: 65, y: {{ $b517s->g13 }}, label:"13" },
      { x: 70, y: {{ $b517s->g14 }}, label:"14" },
      { x: 75, y: {{ $b517s->g15 }}, label:"15" },
      { x: 80, y: {{ $b517s->g16 }}, label:"16" },
      { x: 85, y: {{ $b517s->g17 }}, label:"17" },
      { x: 90, y: {{ $b517s->g18 }}, label:"18" },
      { x: 95, y: {{ $b517s->g19 }}, label:"19" },
      { x: 100, y: {{ $b517s->g20 }}, label:"20" }
      
    ]
  },

  {
    type: "line",
    showInLegend: true,
    name: "總角球",
    markerType: "circle",
    color: "blue",
    dataPoints: [
      { x: 5, y: {{ $b517s->t1 }}, label:"1" },
      { x: 10, y: {{ $b517s->t2 }}, label:"2" },
      { x: 15, y: {{ $b517s->t3 }}, label:"3" },
      { x: 20, y: {{ $b517s->t4 }}, label:"4" },
      { x: 25, y: {{ $b517s->t5 }}, label:"5" },
      { x: 30, y: {{ $b517s->t6 }}, label:"6" },
      { x: 35, y: {{ $b517s->t7 }}, label:"7" },
      { x: 40, y: {{ $b517s->t8 }}, label:"8" },
      { x: 45, y: {{ $b517s->t9 }}, label:"9" },
      { x: 50, y: {{ $b517s->t10 }}, label:"10" },
      { x: 55, y: {{ $b517s->t11 }}, label:"11" },
      { x: 60, y: {{ $b517s->t12 }}, label:"12" },
      { x: 65, y: {{ $b517s->t13 }}, label:"13" },
      { x: 70, y: {{ $b517s->t14 }}, label:"14" },
      { x: 75, y: {{ $b517s->t15 }}, label:"15" },
      { x: 80, y: {{ $b517s->t16 }}, label:"16" },
      { x: 85, y: {{ $b517s->t17 }}, label:"17" },
      { x: 90, y: {{ $b517s->t18 }}, label:"18" },
      { x: 95, y: {{ $b517s->t19 }}, label:"19" },
      { x: 100, y: {{ $b517s->t20 }}, label:"20" }
      
    ]
  }]
  });

//chart3

var chart3 = new CanvasJS.Chart("chart3", {
    animationEnabled: true,
    theme: "dark2",
    title:{
    text: "{{ $b518s->host }} vs {{ $b518s->guest }}"
  },
    toolTip:{
    enabled: false,
    shared:false
  },  



    data: [{
    type: "line",
    showInLegend: true,
    name: "主隊",
    markerType: "circle",
    color: "red",
    dataPoints: [
      { x: 5, y: {{ $b518s->h1 }}, label:"1" },
      { x: 10, y: {{ $b518s->h2 }}, label:"2" },
      { x: 15, y: {{ $b518s->h3 }}, label:"3" },
      { x: 20, y: {{ $b518s->h4 }}, label:"4" },
      { x: 25, y: {{ $b518s->h5 }}, label:"5" },
      { x: 30, y: {{ $b518s->h6 }}, label:"6" },
      { x: 35, y: {{ $b518s->h7 }}, label:"7" },
      { x: 40, y: {{ $b518s->h8 }}, label:"8" },
      { x: 45, y: {{ $b518s->h9 }}, label:"9" },
      { x: 50, y: {{ $b518s->h10 }}, label:"10" },
      { x: 55, y: {{ $b518s->h11 }}, label:"11" },
      { x: 60, y: {{ $b518s->h12 }}, label:"12" },
      { x: 65, y: {{ $b518s->h13 }}, label:"13" },
      { x: 70, y: {{ $b518s->h14 }}, label:"14" },
      { x: 75, y: {{ $b518s->h15 }}, label:"15" },
      { x: 80, y: {{ $b518s->h16 }}, label:"16" },
      { x: 85, y: {{ $b518s->h17 }}, label:"17" },
      { x: 90, y: {{ $b518s->h18 }}, label:"18" },
      { x: 95, y: {{ $b518s->h19 }}, label:"19" },
      { x: 100, y: {{ $b518s->h20 }}, label:"20" }
     
    ]
  },
  {
    type: "line",
    showInLegend: true,
    name: "客隊",
    markerType: "circle",
    color: "green",
    dataPoints: [
      { x: 5, y: {{ $b518s->g1 }}, label:"1" },
      { x: 10, y: {{ $b518s->g2 }}, label:"2" },
      { x: 15, y: {{ $b518s->g3 }}, label:"3" },
      { x: 20, y: {{ $b518s->g4 }}, label:"4" },
      { x: 25, y: {{ $b518s->g5 }}, label:"5" },
      { x: 30, y: {{ $b518s->g6 }}, label:"6" },
      { x: 35, y: {{ $b518s->g7 }}, label:"7" },
      { x: 40, y: {{ $b518s->g8 }}, label:"8" },
      { x: 45, y: {{ $b518s->g9 }}, label:"9" },
      { x: 50, y: {{ $b518s->g10 }}, label:"10" },
      { x: 55, y: {{ $b518s->g11 }}, label:"11" },
      { x: 60, y: {{ $b518s->g12 }}, label:"12" },
      { x: 65, y: {{ $b518s->g13 }}, label:"13" },
      { x: 70, y: {{ $b518s->g14 }}, label:"14" },
      { x: 75, y: {{ $b518s->g15 }}, label:"15" },
      { x: 80, y: {{ $b518s->g16 }}, label:"16" },
      { x: 85, y: {{ $b518s->g17 }}, label:"17" },
      { x: 90, y: {{ $b518s->g18 }}, label:"18" },
      { x: 95, y: {{ $b518s->g19 }}, label:"19" },
      { x: 100, y: {{ $b518s->g20 }}, label:"20" }
      
    ]
  },

  {
    type: "line",
    showInLegend: true,
    name: "總角球",
    markerType: "circle",
    color: "blue",
    dataPoints: [
      { x: 5, y: {{ $b518s->t1 }}, label:"1" },
      { x: 10, y: {{ $b518s->t2 }}, label:"2" },
      { x: 15, y: {{ $b518s->t3 }}, label:"3" },
      { x: 20, y: {{ $b518s->t4 }}, label:"4" },
      { x: 25, y: {{ $b518s->t5 }}, label:"5" },
      { x: 30, y: {{ $b518s->t6 }}, label:"6" },
      { x: 35, y: {{ $b518s->t7 }}, label:"7" },
      { x: 40, y: {{ $b518s->t8 }}, label:"8" },
      { x: 45, y: {{ $b518s->t9 }}, label:"9" },
      { x: 50, y: {{ $b518s->t10 }}, label:"10" },
      { x: 55, y: {{ $b518s->t11 }}, label:"11" },
      { x: 60, y: {{ $b518s->t12 }}, label:"12" },
      { x: 65, y: {{ $b518s->t13 }}, label:"13" },
      { x: 70, y: {{ $b518s->t14 }}, label:"14" },
      { x: 75, y: {{ $b518s->t15 }}, label:"15" },
      { x: 80, y: {{ $b518s->t16 }}, label:"16" },
      { x: 85, y: {{ $b518s->t17 }}, label:"17" },
      { x: 90, y: {{ $b518s->t18 }}, label:"18" },
      { x: 95, y: {{ $b518s->t19 }}, label:"19" },
      { x: 100, y: {{ $b518s->t20 }}, label:"20" }
      
    ]
  }]
  });

  //chart4

  var chart4 = new CanvasJS.Chart("chart4", {
    animationEnabled: true,
    theme: "dark2",
    title:{
    text: "{{ $b519s->host }} vs {{ $b519s->guest }}"
  },
    toolTip:{
    enabled: false,
    shared:false
  },  



    data: [{
    type: "line",
    showInLegend: true,
    name: "主隊",
    markerType: "circle",
    color: "red",
    dataPoints: [
      { x: 5, y: {{ $b519s->h1 }}, label:"1" },
      { x: 10, y: {{ $b519s->h2 }}, label:"2" },
      { x: 15, y: {{ $b519s->h3 }}, label:"3" },
      { x: 20, y: {{ $b519s->h4 }}, label:"4" },
      { x: 25, y: {{ $b519s->h5 }}, label:"5" },
      { x: 30, y: {{ $b519s->h6 }}, label:"6" },
      { x: 35, y: {{ $b519s->h7 }}, label:"7" },
      { x: 40, y: {{ $b519s->h8 }}, label:"8" },
      { x: 45, y: {{ $b519s->h9 }}, label:"9" },
      { x: 50, y: {{ $b519s->h10 }}, label:"10" },
      { x: 55, y: {{ $b519s->h11 }}, label:"11" },
      { x: 60, y: {{ $b519s->h12 }}, label:"12" },
      { x: 65, y: {{ $b519s->h13 }}, label:"13" },
      { x: 70, y: {{ $b519s->h14 }}, label:"14" },
      { x: 75, y: {{ $b519s->h15 }}, label:"15" },
      { x: 80, y: {{ $b519s->h16 }}, label:"16" },
      { x: 85, y: {{ $b519s->h17 }}, label:"17" },
      { x: 90, y: {{ $b519s->h18 }}, label:"18" },
      { x: 95, y: {{ $b519s->h19 }}, label:"19" },
      { x: 100, y: {{ $b519s->h20 }}, label:"20" }
     
    ]
  },
  {
    type: "line",
    showInLegend: true,
    name: "客隊",
    markerType: "circle",
    color: "green",
    dataPoints: [
      { x: 5, y: {{ $b519s->g1 }}, label:"1" },
      { x: 10, y: {{ $b519s->g2 }}, label:"2" },
      { x: 15, y: {{ $b519s->g3 }}, label:"3" },
      { x: 20, y: {{ $b519s->g4 }}, label:"4" },
      { x: 25, y: {{ $b519s->g5 }}, label:"5" },
      { x: 30, y: {{ $b519s->g6 }}, label:"6" },
      { x: 35, y: {{ $b519s->g7 }}, label:"7" },
      { x: 40, y: {{ $b519s->g8 }}, label:"8" },
      { x: 45, y: {{ $b519s->g9 }}, label:"9" },
      { x: 50, y: {{ $b519s->g10 }}, label:"10" },
      { x: 55, y: {{ $b519s->g11 }}, label:"11" },
      { x: 60, y: {{ $b519s->g12 }}, label:"12" },
      { x: 65, y: {{ $b519s->g13 }}, label:"13" },
      { x: 70, y: {{ $b519s->g14 }}, label:"14" },
      { x: 75, y: {{ $b519s->g15 }}, label:"15" },
      { x: 80, y: {{ $b519s->g16 }}, label:"16" },
      { x: 85, y: {{ $b519s->g17 }}, label:"17" },
      { x: 90, y: {{ $b519s->g18 }}, label:"18" },
      { x: 95, y: {{ $b519s->g19 }}, label:"19" },
      { x: 100, y: {{ $b519s->g20 }}, label:"20" }
      
    ]
  },

  {
    type: "line",
    showInLegend: true,
    name: "總角球",
    markerType: "circle",
    color: "blue",
    dataPoints: [
      { x: 5, y: {{ $b519s->t1 }}, label:"1" },
      { x: 10, y: {{ $b519s->t2 }}, label:"2" },
      { x: 15, y: {{ $b519s->t3 }}, label:"3" },
      { x: 20, y: {{ $b519s->t4 }}, label:"4" },
      { x: 25, y: {{ $b519s->t5 }}, label:"5" },
      { x: 30, y: {{ $b519s->t6 }}, label:"6" },
      { x: 35, y: {{ $b519s->t7 }}, label:"7" },
      { x: 40, y: {{ $b519s->t8 }}, label:"8" },
      { x: 45, y: {{ $b519s->t9 }}, label:"9" },
      { x: 50, y: {{ $b519s->t10 }}, label:"10" },
      { x: 55, y: {{ $b519s->t11 }}, label:"11" },
      { x: 60, y: {{ $b519s->t12 }}, label:"12" },
      { x: 65, y: {{ $b519s->t13 }}, label:"13" },
      { x: 70, y: {{ $b519s->t14 }}, label:"14" },
      { x: 75, y: {{ $b519s->t15 }}, label:"15" },
      { x: 80, y: {{ $b519s->t16 }}, label:"16" },
      { x: 85, y: {{ $b519s->t17 }}, label:"17" },
      { x: 90, y: {{ $b519s->t18 }}, label:"18" },
      { x: 95, y: {{ $b519s->t19 }}, label:"19" },
      { x: 100, y: {{ $b519s->t20 }}, label:"20" }
      
    ]
  }]
  });

  //chart5

  var chart5 = new CanvasJS.Chart("chart5", {
    animationEnabled: true,
    theme: "dark2",
    title:{
    text: "{{ $b520s->host }} vs {{ $b520s->guest }}"
  },
    toolTip:{
    enabled: false,
    shared:false
  },  



    data: [{
    type: "line",
    showInLegend: true,
    name: "主隊",
    markerType: "circle",
    color: "red",
    dataPoints: [
      { x: 5, y: {{ $b520s->h1 }}, label:"1" },
      { x: 10, y: {{ $b520s->h2 }}, label:"2" },
      { x: 15, y: {{ $b520s->h3 }}, label:"3" },
      { x: 20, y: {{ $b520s->h4 }}, label:"4" },
      { x: 25, y: {{ $b520s->h5 }}, label:"5" },
      { x: 30, y: {{ $b520s->h6 }}, label:"6" },
      { x: 35, y: {{ $b520s->h7 }}, label:"7" },
      { x: 40, y: {{ $b520s->h8 }}, label:"8" },
      { x: 45, y: {{ $b520s->h9 }}, label:"9" },
      { x: 50, y: {{ $b520s->h10 }}, label:"10" },
      { x: 55, y: {{ $b520s->h11 }}, label:"11" },
      { x: 60, y: {{ $b520s->h12 }}, label:"12" },
      { x: 65, y: {{ $b520s->h13 }}, label:"13" },
      { x: 70, y: {{ $b520s->h14 }}, label:"14" },
      { x: 75, y: {{ $b520s->h15 }}, label:"15" },
      { x: 80, y: {{ $b520s->h16 }}, label:"16" },
      { x: 85, y: {{ $b520s->h17 }}, label:"17" },
      { x: 90, y: {{ $b520s->h18 }}, label:"18" },
      { x: 95, y: {{ $b520s->h19 }}, label:"19" },
      { x: 100, y: {{ $b520s->h20 }}, label:"20" }
     
    ]
  },
  {
    type: "line",
    showInLegend: true,
    name: "客隊",
    markerType: "circle",
    color: "green",
    dataPoints: [
      { x: 5, y: {{ $b520s->g1 }}, label:"1" },
      { x: 10, y: {{ $b520s->g2 }}, label:"2" },
      { x: 15, y: {{ $b520s->g3 }}, label:"3" },
      { x: 20, y: {{ $b520s->g4 }}, label:"4" },
      { x: 25, y: {{ $b520s->g5 }}, label:"5" },
      { x: 30, y: {{ $b520s->g6 }}, label:"6" },
      { x: 35, y: {{ $b520s->g7 }}, label:"7" },
      { x: 40, y: {{ $b520s->g8 }}, label:"8" },
      { x: 45, y: {{ $b520s->g9 }}, label:"9" },
      { x: 50, y: {{ $b520s->g10 }}, label:"10" },
      { x: 55, y: {{ $b520s->g11 }}, label:"11" },
      { x: 60, y: {{ $b520s->g12 }}, label:"12" },
      { x: 65, y: {{ $b520s->g13 }}, label:"13" },
      { x: 70, y: {{ $b520s->g14 }}, label:"14" },
      { x: 75, y: {{ $b520s->g15 }}, label:"15" },
      { x: 80, y: {{ $b520s->g16 }}, label:"16" },
      { x: 85, y: {{ $b520s->g17 }}, label:"17" },
      { x: 90, y: {{ $b520s->g18 }}, label:"18" },
      { x: 95, y: {{ $b520s->g19 }}, label:"19" },
      { x: 100, y: {{ $b520s->g20 }}, label:"20" }
      
    ]
  },

  {
    type: "line",
    showInLegend: true,
    name: "總角球",
    markerType: "circle",
    color: "blue",
    dataPoints: [
      { x: 5, y: {{ $b520s->t1 }}, label:"1" },
      { x: 10, y: {{ $b520s->t2 }}, label:"2" },
      { x: 15, y: {{ $b520s->t3 }}, label:"3" },
      { x: 20, y: {{ $b520s->t4 }}, label:"4" },
      { x: 25, y: {{ $b520s->t5 }}, label:"5" },
      { x: 30, y: {{ $b520s->t6 }}, label:"6" },
      { x: 35, y: {{ $b520s->t7 }}, label:"7" },
      { x: 40, y: {{ $b520s->t8 }}, label:"8" },
      { x: 45, y: {{ $b520s->t9 }}, label:"9" },
      { x: 50, y: {{ $b520s->t10 }}, label:"10" },
      { x: 55, y: {{ $b520s->t11 }}, label:"11" },
      { x: 60, y: {{ $b520s->t12 }}, label:"12" },
      { x: 65, y: {{ $b520s->t13 }}, label:"13" },
      { x: 70, y: {{ $b520s->t14 }}, label:"14" },
      { x: 75, y: {{ $b520s->t15 }}, label:"15" },
      { x: 80, y: {{ $b520s->t16 }}, label:"16" },
      { x: 85, y: {{ $b520s->t17 }}, label:"17" },
      { x: 90, y: {{ $b520s->t18 }}, label:"18" },
      { x: 95, y: {{ $b520s->t19 }}, label:"19" },
      { x: 100, y: {{ $b520s->t20 }}, label:"20" }
      
    ]
  }]
  });

    chart1.render();
    chart2.render();
    chart3.render();
    chart4.render();
    chart5.render();
  }

  @endif
 
</script>



  </head>
  <body>
    <div id="base" class="">

      <!-- Header (Rectangle) -->
      <div id="u0" class="ax_default box_2" data-label="Header">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u1" class="ax_default box_2 ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u1_div" class=""></div>
        <div id="u1_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u3" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u4" class="ax_default placeholder">
          <img id="u4_img" class="img " src="/footballui/public/frontend/images/page_a5/u4.svg"/>
          <div id="u4_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u5" class="ax_default box_1">
          <div id="u5_div" class=""></div>
          <div id="u5_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u6" class="ax_default box_3">
          <div id="u6_div" class=""></div>
          <div id="u6_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u7" class="ax_default box_3">
          <div id="u7_div" class=""></div>
          <div id="u7_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u8" class="ax_default box_3">
          <div id="u8_div" class=""></div>
          <div id="u8_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u9" class="ax_default box_3">
          <div id="u9_div" class=""></div>
          <div id="u9_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u10" class="ax_default box_3">
          <div id="u10_div" class=""></div>
          <div id="u10_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u11" class="ax_default box_3">
          <div id="u11_div" class=""></div>
          <div id="u11_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u12" class="ax_default box_3">
          <div id="u12_div" class=""></div>
          <div id="u12_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u13" class="ax_default">
          <div id="u13_state0" class="panel_state" data-label="State 1" style="">
            <div id="u13_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u14" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u15" class="ax_default box_3">
                  <div id="u15_div" class=""></div>
                  <div id="u15_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u16" class="ax_default box_3">
                  <div id="u16_div" class=""></div>
                  <div id="u16_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u17" class="ax_default box_3">
                  <div id="u17_div" class=""></div>
                  <div id="u17_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u18" class="ax_default box_3">
                  <img id="u18_img" class="img " src="/footballui/public/frontend/images/page_a5/u18.svg"/>
                  <div id="u18_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u19" class="ax_default box_3">
                  <div id="u19_div" class=""></div>
                  <div id="u19_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u20" class="ax_default box_3">
                  <div id="u20_div" class=""></div>
                  <div id="u20_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u21" class="ax_default box_3">
                  <div id="u21_div" class=""></div>
                  <div id="u21_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u22" class="ax_default">
          <div id="u22_state0" class="panel_state" data-label="State 1" style="">
            <div id="u22_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u23" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u24" class="ax_default box_3">
                  <div id="u24_div" class=""></div>
                  <div id="u24_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u25" class="ax_default box_3">
                  <div id="u25_div" class=""></div>
                  <div id="u25_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u26" class="ax_default box_3">
                  <div id="u26_div" class=""></div>
                  <div id="u26_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u27" class="ax_default box_3">
                  <img id="u27_img" class="img " src="/footballui/public/frontend/images/page_a5/u27.svg"/>
                  <div id="u27_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u28" class="ax_default box_3">
                  <div id="u28_div" class=""></div>
                  <div id="u28_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u29" class="ax_default box_3">
                  <div id="u29_div" class=""></div>
                  <div id="u29_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u30" class="ax_default">
          <div id="u30_state0" class="panel_state" data-label="State 1" style="">
            <div id="u30_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u31" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u32" class="ax_default box_3">
                  <div id="u32_div" class=""></div>
                  <div id="u32_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u33" class="ax_default box_3">
                  <div id="u33_div" class=""></div>
                  <div id="u33_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u34" class="ax_default box_3">
                  <div id="u34_div" class=""></div>
                  <div id="u34_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u35" class="ax_default box_3">
                  <img id="u35_img" class="img " src="/footballui/public/frontend/images/page_a5/u35.svg"/>
                  <div id="u35_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u2" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u37" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u38" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u38_state0" class="panel_state" data-label="State 1" style="">
            <div id="u38_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u39" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u40" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u40_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u40_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u41" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u42" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u42_div" class=""></div>
                          <div id="u42_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u43" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u43_div" class=""></div>
                          <div id="u43_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u44" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u44_div" class=""></div>
                          <div id="u44_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u45" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u45_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u45_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u46" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u46_div" class=""></div>
                          <div id="u46_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u47" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u47_div" class=""></div>
                          <div id="u47_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u48" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u48_div" class=""></div>
                          <div id="u48_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u49" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u49_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u49_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u50" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u51" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u51_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u51_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u52" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u53" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u53_div" class=""></div>
                          <div id="u53_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u54" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u54_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u54_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u55" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u55_div" class=""></div>
                          <div id="u55_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u56" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u56_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u56_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u57" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u57_div" class=""></div>
                          <div id="u57_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u58" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u58_div" class=""></div>
                          <div id="u58_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u59" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u59_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u59_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u60" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u61" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u61_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u61_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u62" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u63" class="ax_default box_3">
                          <div id="u63_div" class=""></div>
                          <div id="u63_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u64" class="ax_default box_3">
                          <img id="u64_img" class="img " src="/footballui/public/frontend/images/page_a5/u64.svg"/>
                          <div id="u64_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u65" class="ax_default box_3">
                          <div id="u65_div" class=""></div>
                          <div id="u65_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u66" class="ax_default box_3">
                          <img id="u66_img" class="img " src="/footballui/public/frontend/images/page_a5/u66.svg"/>
                          <div id="u66_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u67" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u67_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u67_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u68" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u68_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u68_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u69" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u69_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u69_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u70" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u70_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u70_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u71" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u71_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u71_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u72" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u72_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u72_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u73" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u73_div" class=""></div>
          <div id="u73_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u74" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u74_div" class=""></div>
          <div id="u74_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u36" style="display:none; visibility:hidden;"></div>

      <!-- Date (Group) 
      <div id="u75" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="28">

         After_tomorrow (Rectangle) 
        <div id="u76" class="ax_default label" data-label="After_tomorrow">
          <div id="u76_div" class=""></div>
          <div id="u76_text" class="text ">
            <p><span>後日</span></p>
          </div>
        </div>

         Tomorrow (Rectangle) 
        <div id="u77" class="ax_default label" data-label="Tomorrow">
          <div id="u77_div" class=""></div>
          <div id="u77_text" class="text ">
            <p><span>明日</span></p>
          </div>
        </div>

         Today (Rectangle) 
        <div id="u78" class="ax_default label" data-label="Today">
          <div id="u78_div" class=""></div>
          <div id="u78_text" class="text ">
            <p><span>今日</span></p>
          </div>
        </div>

         Match_date (Rectangle) 
        <div id="u79" class="ax_default label" data-label="Match_date">
          <div id="u79_div" class=""></div>
          <div id="u79_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;Lucida Grande &quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div> -->
      </div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>

    <div id="chart1" class="chart1"></div>
    <div id="chart2" class="chart2"></div>
    <div id="chart3" class="chart3"></div>
    <div id="chart4" class="chart4"></div>
    <div id="chart5" class="chart5"></div>

    <div class="pagination">
  <a onclick="window.location='/footballui/public/page_a5';">&laquo;</a>
  <a  onclick="window.location='/footballui/public/page_a5';">1</a>
  <a onclick="window.location='/footballui/public/page_a52b';">2</a>
  <a onclick="window.location='/footballui/public/page_a53c';">3</a>
  <a class="active" onclick="window.location='/footballui/public/page_a54d';">4</a>
  <a onclick="window.location='/footballui/public/page_a55e';">5</a>
  <a onclick="window.location='/footballui/public/page_a56f';">6</a>
  <a onclick="window.location='/footballui/public/page_a56g';">&raquo;</a>
</div>

  </body>
</html>
