﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A6</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a6/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a6/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Button_Group (Group) -->
      <div id="u0" class="ax_default ax_default_unplaced" data-label="Button_Group" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">
      </div>

      <!-- Unnamed (Image) -->
      <div id="u1" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
        <img id="u1_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
        <div id="u1_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Top Menu_M (Group) -->
      <div id="u2" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u3" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u3_state0" class="panel_state" data-label="State 1" style="">
            <div id="u3_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u4" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u5" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u5_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u5_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u6" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u7" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u7_div" class=""></div>
                          <div id="u7_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u8" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u8_div" class=""></div>
                          <div id="u8_text" class="text ">
                            <p><span>&nbsp;簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u9" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u9_div" class=""></div>
                          <div id="u9_text" class="text ">
                            <p><span>&nbsp;如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u10" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u10_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u10_text" class="text ">
                            <p><span>&nbsp; 為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u11" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u11_div" class=""></div>
                          <div id="u11_text" class="text ">
                            <p><span>&nbsp; 馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u12" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u12_div" class=""></div>
                          <div id="u12_text" class="text ">
                            <p><span>&nbsp; 用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u13" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u13_div" class=""></div>
                          <div id="u13_text" class="text ">
                            <p><span>&nbsp; 風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u14" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u14_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u14_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u15" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u16" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u16_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u16_text" class="text ">
                    <p><span>足球AI模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u17" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u17_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u17_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u18" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u19" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u19_div" class=""></div>
                          <div id="u19_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u20" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u20_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u20_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; AI模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u21" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u21_div" class=""></div>
                          <div id="u21_text" class="text ">
                            <p><span>&nbsp;綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u22" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u22_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u22_text" class="text ">
                            <p><span>&nbsp;值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u23" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u23_div" class=""></div>
                          <div id="u23_text" class="text ">
                            <p><span>&nbsp; AI模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u24" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u24_div" class=""></div>
                          <div id="u24_text" class="text ">
                            <p><span>&nbsp;AI模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u25" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Shape) -->
                <div id="u26" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u26_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u26_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u27" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u27_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u27_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u28" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u29" class="ax_default box_3">
                          <div id="u29_div" class=""></div>
                          <div id="u29_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u30" class="ax_default box_3">
                          <img id="u30_img" class="img " src="/footballui/public/frontend/images/page_a6/u30.svg"/>
                          <div id="u30_text" class="text ">
                            <p><span>&nbsp;&nbsp; &nbsp; Futra是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u31" class="ax_default box_3">
                          <div id="u31_div" class=""></div>
                          <div id="u31_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u32" class="ax_default box_3">
                          <img id="u32_img" class="img " src="/footballui/public/frontend/images/page_a6/u32.svg"/>
                          <div id="u32_text" class="text ">
                            <p><span>&nbsp;&nbsp;&nbsp; AI模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u33" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u33_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u33_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u34" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u34_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u34_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u35" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u35_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u35_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u36" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u36_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u36_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Top Menu_M (Group) -->
        <div id="u37" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

          <!-- Unnamed (Placeholder) -->
          <div id="u38" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
            <img id="u38_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
            <div id="u38_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u39" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u39_div" class=""></div>
            <div id="u39_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u40" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
            <div id="u40_div" class=""></div>
            <div id="u40_text" class="text ">
              <p><span>MENU</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Picked_M (Rectangle) -->
      <div id="u41" class="ax_default box_2 ax_default_unplaced" data-label="Picked_M" style="display:none; visibility: hidden">
        <div id="u41_div" class=""></div>
        <div id="u41_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;">Futra 是日</span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">精選</span></p>
        </div>
      </div>

      <!-- footer (Group) 
      <div id="u42" class="ax_default" data-label="footer" data-left="150" data-top="680" data-width="1073" data-height="171">

        Unnamed (Rectangle) 
        <div id="u43" class="ax_default shape">
          <img id="u43_img" class="img " src="/footballui/public/frontend/images/page_a6/u43.svg"/>
          <div id="u43_text" class="text ">
            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">問題</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">查詢</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">意見</span></p>
          </div>
        </div>

     illegal_gambling_hotSpot (Hot Spot) 
        <div id="u44" class="ax_default" data-label="illegal_gambling_hotSpot">
        </div>

         HKJC_hotSpot (Hot Spot) 
        <div id="u45" class="ax_default" data-label="HKJC_hotSpot">
        </div>

         意見 (Hot Spot) 
        <div id="u46" class="ax_default" data-label="意見">
        </div>

         查詢 (Hot Spot) 
        <div id="u47" class="ax_default" data-label="查詢">
        </div>

         問題 (Hot Spot) 
        <div id="u48" class="ax_default" data-label="問題">
        </div>
      </div>

-->

      <!-- Button_Group (Group) -->
      <div id="u49" class="ax_default" data-label="Button_Group" data-left="0" data-top="0" data-width="0" data-height="0">
      </div>

      @foreach($b6s as $b6datum)
      <!-- Picked_db1 (Group) -->
      <div id="u50" class="ax_default" data-label="Picked_db1" data-left="483" data-top="226" data-width="430" data-height="40">

        <!-- game_name (Rectangle) -->
        <div id="u51" class="ax_default paragraph" data-label="game_name">
          <div id="u51_div" class=""></div>
          <div id="u51_text" class="text ">
            <p><span>{{ $b6datum->host }} vs {{ $b6datum->guest }}</span></p>
          </div>
        </div>

        <!-- result (Rectangle) -->
        <div id="u52" class="ax_default box_1" data-label="result">
          <div id="u52_div" class=""></div>
          <div id="u52_text" class="text ">
            <p><span>{{ $b6datum->opt }}</span></p>
          </div>
        </div>
      </div>

      @endforeach

      <!-- Table (Group) -->
      <div id="u53" class="ax_default" data-label="Table" data-left="483" data-top="185" data-width="430" data-height="40">

        <!-- Items_Group (Group) -->
        <div id="u54" class="ax_default" data-label="Items_Group" data-left="0" data-top="0" data-width="0" data-height="0">
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u55" class="ax_default box_3">
          <div id="u55_div" class=""></div>
          <div id="u55_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u56" class="ax_default paragraph">
          <div id="u56_div" class=""></div>
          <div id="u56_text" class="text ">
            <p><span>預測結果</span></p>
          </div>
        </div>

        <!-- 比賽場次 (Rectangle) -->
        <div id="u57" class="ax_default paragraph" data-label="比賽場次">
          <div id="u57_div" class=""></div>
          <div id="u57_text" class="text ">
            <p><span>比賽場次</span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u58" class="ax_default image">
        <img id="u58_img" class="img " src="/footballui/public/frontend/images/page_a6/u58.png"/>
        <div id="u58_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Picked (Rectangle) -->
      <div id="u59" class="ax_default box_2" data-label="Picked">
        <div id="u59_div" class=""></div>
        <div id="u59_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;">Futra </span><span style="font-family:&quot;STSongti-TC-Regular&quot;, &quot;Songti TC&quot;, sans-serif;">是日精選</span></p>
        </div>
      </div>

      <!-- Footer (Group) 
      <div id="u60" class="ax_default ax_default_unplaced" data-label="Footer" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        Unnamed (Rectangle) 
        <div id="u61" class="ax_default shape ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u61_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u61_text" class="text ">
            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">© 2022 </span><span style="font-family:'Bungee Inline';font-weight:900;color:#5D5D5D;">G10OAL! </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">足球比賽數據網站</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">重要事項：頁面所示的賠率及其他數據謹供參考，所有賠率資料以</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">香港賽馬會網站</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">為準。</span></p><p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;">*</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">外圍莊家賠率只供參考比較之用，請不要參與外圍投注，詳情參閱「 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">非法賭博</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 」。</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">已收錄</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#5D5D5D;"> 57152 </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#5D5D5D;">賽事賠率數據</span></p><p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">問題</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">查詢</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;font-weight:400;color:#061E3D;"> · </span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-weight:400;color:#061E3D;">意見</span></p>
          </div>
        </div>



        illegal_gambling_hotSpot (Hot Spot) 
        <div id="u62" class="ax_default ax_default_unplaced" data-label="illegal_gambling_hotSpot" style="display:none; visibility: hidden">
        </div>

         HKJC_hotSpot (Hot Spot) 
        <div id="u63" class="ax_default ax_default_unplaced" data-label="HKJC_hotSpot" style="display:none; visibility: hidden">
        </div>

         意見 (Hot Spot) 
        <div id="u64" class="ax_default ax_default_unplaced" data-label="意見" style="display:none; visibility: hidden">
        </div>

         查詢 (Hot Spot) 
        <div id="u65" class="ax_default ax_default_unplaced" data-label="查詢" style="display:none; visibility: hidden">
        </div>

         問題 (Hot Spot) 
        <div id="u66" class="ax_default ax_default_unplaced" data-label="問題" style="display:none; visibility: hidden">
        </div>
      </div>

      -->

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u68" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u69" class="ax_default placeholder">
          <img id="u69_img" class="img " src="/footballui/public/frontend/images/page_a6/u69.svg"/>
          <div id="u69_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u70" class="ax_default box_1">
          <div id="u70_div" class=""></div>
          <div id="u70_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u71" class="ax_default box_3">
          <div id="u71_div" class=""></div>
          <div id="u71_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u72" class="ax_default box_3">
          <div id="u72_div" class=""></div>
          <div id="u72_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u73" class="ax_default box_3">
          <div id="u73_div" class=""></div>
          <div id="u73_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u74" class="ax_default box_3">
          <div id="u74_div" class=""></div>
          <div id="u74_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u75" class="ax_default box_3">
          <div id="u75_div" class=""></div>
          <div id="u75_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u76" class="ax_default box_3">
          <div id="u76_div" class=""></div>
          <div id="u76_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u77" class="ax_default box_3">
          <div id="u77_div" class=""></div>
          <div id="u77_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u78" class="ax_default">
          <div id="u78_state0" class="panel_state" data-label="State 1" style="">
            <div id="u78_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u79" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u80" class="ax_default box_3">
                  <div id="u80_div" class=""></div>
                  <div id="u80_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u81" class="ax_default box_3">
                  <div id="u81_div" class=""></div>
                  <div id="u81_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u82" class="ax_default box_3">
                  <div id="u82_div" class=""></div>
                  <div id="u82_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u83" class="ax_default box_3">
                  <img id="u83_img" class="img " src="/footballui/public/frontend/images/page_a6/u83.svg"/>
                  <div id="u83_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u84" class="ax_default box_3">
                  <div id="u84_div" class=""></div>
                  <div id="u84_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u85" class="ax_default box_3">
                  <div id="u85_div" class=""></div>
                  <div id="u85_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u86" class="ax_default box_3">
                  <div id="u86_div" class=""></div>
                  <div id="u86_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u87" class="ax_default">
          <div id="u87_state0" class="panel_state" data-label="State 1" style="">
            <div id="u87_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u88" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u89" class="ax_default box_3">
                  <div id="u89_div" class=""></div>
                  <div id="u89_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u90" class="ax_default box_3">
                  <div id="u90_div" class=""></div>
                  <div id="u90_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u91" class="ax_default box_3">
                  <div id="u91_div" class=""></div>
                  <div id="u91_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u92" class="ax_default box_3">
                  <img id="u92_img" class="img " src="/footballui/public/frontend/images/page_a6/u92.svg"/>
                  <div id="u92_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u93" class="ax_default box_3">
                  <div id="u93_div" class=""></div>
                  <div id="u93_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u94" class="ax_default box_3">
                  <div id="u94_div" class=""></div>
                  <div id="u94_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u95" class="ax_default">
          <div id="u95_state0" class="panel_state" data-label="State 1" style="">
            <div id="u95_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u96" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u97" class="ax_default box_3">
                  <div id="u97_div" class=""></div>
                  <div id="u97_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u98" class="ax_default box_3">
                  <div id="u98_div" class=""></div>
                  <div id="u98_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u99" class="ax_default box_3">
                  <div id="u99_div" class=""></div>
                  <div id="u99_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u100" class="ax_default box_3">
                  <img id="u100_img" class="img " src="/footballui/public/frontend/images/page_a6/u100.svg"/>
                  <div id="u100_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u67" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u102" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u103" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u103_state0" class="panel_state" data-label="State 1" style="">
            <div id="u103_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u104" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u105" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u105_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u105_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u106" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u107" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u107_div" class=""></div>
                          <div id="u107_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u108" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u108_div" class=""></div>
                          <div id="u108_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u109" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u109_div" class=""></div>
                          <div id="u109_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u110" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u110_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u110_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u111" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u111_div" class=""></div>
                          <div id="u111_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u112" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u112_div" class=""></div>
                          <div id="u112_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u113" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u113_div" class=""></div>
                          <div id="u113_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u114" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u114_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u114_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u115" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u116" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u116_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u116_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u117" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u118" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u118_div" class=""></div>
                          <div id="u118_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u119" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u119_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u119_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u120" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u120_div" class=""></div>
                          <div id="u120_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u121" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u121_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u121_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u122" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u122_div" class=""></div>
                          <div id="u122_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u123" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u123_div" class=""></div>
                          <div id="u123_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u124" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u124_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u124_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u125" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u126" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u126_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u126_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u127" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u128" class="ax_default box_3">
                          <div id="u128_div" class=""></div>
                          <div id="u128_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u129" class="ax_default box_3">
                          <img id="u129_img" class="img " src="/footballui/public/frontend/images/page_a6/u30.svg"/>
                          <div id="u129_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u130" class="ax_default box_3">
                          <div id="u130_div" class=""></div>
                          <div id="u130_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u131" class="ax_default box_3">
                          <img id="u131_img" class="img " src="/footballui/public/frontend/images/page_a6/u32.svg"/>
                          <div id="u131_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u132" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u132_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u132_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u133" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u133_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u133_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u134" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u134_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u134_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u135" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u135_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u135_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u136" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u136_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u136_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u137" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u137_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u137_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u138" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u138_div" class=""></div>
          <div id="u138_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u139" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u139_div" class=""></div>
          <div id="u139_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u101" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
