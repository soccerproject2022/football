<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\GoogleController;
use App\Http\Controllers\FBSocialiteController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('frontend.login');
});



Route::get('/user/logout', [HomeController::class, 'Logout'])->name('user.logout');


// route for Google Login
Route::get('auth/google', [GoogleController::class, 'redirectToGoogle']);
Route::get('auth/google/callback', [GoogleController::class, 'handleGoogleCallback']);

// route for facebook login
Route::get('/auth/facebook-login', [FBSocialiteController::class, 'fbLogin']);
Route::get('/facebook/authCallback', [FBSocialiteController::class, 'fbLoginCallback']);

// route for a1 frontend
Route::get('/a1tob1', 'App\Http\Controllers\FrontendController@IntoB1');

Route::middleware(['role'])->group(function(){
    
    Route::middleware([
        'auth:sanctum',
        config('jetstream.auth_session'),
        'verified'
    ])->group(function () {
        Route::get('/dashboard', function () {
            return view('admin.index');
        })->name('dashboard');
    });

    // route for a1 
    Route::get('/a1/load', [HomeController::class, 'LoadA1'])->name('load.a1');
    Route::post('/a1/create', [HomeController::class, 'CreateA1'])->name('create.a1');
    Route::get('/a1/edit/{game_id}', [HomeController::class, 'EditA1']);
    Route::post('/a1/update/{game_id}', [HomeController::class, 'UpdateA1']);
    Route::get('/a1/delete/{game_id}', [HomeController::class, 'DeleteA1']);
    Route::delete('DeleteAll', [HomeController::class, 'deleteAll'])->name('DeleteAll');

    // route for a2 backend
    Route::get('/a2/load', [HomeController::class, 'LoadA2'])->name('load.a2');
    Route::post('/a2/create', [HomeController::class, 'CreateA2'])->name('create.a2');
    Route::get('/a2/delete/{id}', [HomeController::class, 'DeleteA2']);
    Route::get('/a2/edit/{id}', [HomeController::class, 'EditA2']);
    Route::post('/a2/update/{id}', [HomeController::class, 'UpdateA2']);

    // route for a3 backend
    Route::get('/a2/load', [HomeController::class, 'LoadA2'])->name('load.a2');
    Route::post('/a2/create', [HomeController::class, 'CreateA2'])->name('create.a2');
    Route::get('/a2/delete/{id}', [HomeController::class, 'DeleteA2']);
    Route::get('/a2/edit/{id}', [HomeController::class, 'EditA2']);
    Route::post('/a2/update/{id}', [HomeController::class, 'UpdateA2']);

    // routes for a5 backend
    Route::get('/a5/load', [HomeController::class, 'LoadA5'])->name('load.a5');
    Route::post('/a5/create', [HomeController::class, 'CreateA5'])->name('create.a5');
    Route::get('/a5/delete/{id}', [HomeController::class, 'DeleteA5']);
    Route::get('/a5/edit/{id}', [HomeController::class, 'EditA5']);
    Route::post('/a5/update/{id}', [HomeController::class, 'UpdateA5']);

    // routes for a6 backend
    Route::get('/a6/load', [HomeController::class, 'LoadA6'])->name('load.a6');
    Route::post('/a6/create', [HomeController::class, 'CreateA6'])->name('create.a6');
    Route::get('/a6/delete/{id}', [HomeController::class, 'DeleteA6']);
    Route::get('/a6/edit/{id}', [HomeController::class, 'EditA6']);
    Route::post('/a6/update/{id}', [HomeController::class, 'UpdateA6']);

    // routes for a7 backend
    Route::get('/a7/load', [HomeController::class, 'LoadA7'])->name('load.a7');
    Route::post('/a7/create', [HomeController::class, 'CreateA7'])->name('create.a7');
    Route::get('/a7/delete/{id}', [HomeController::class, 'DeleteA7']);
    Route::get('/a7/edit/{id}', [HomeController::class, 'EditA7']);
    Route::post('/a7/update/{id}', [HomeController::class, 'UpdateA7']);

    // routes for a8 backend
    Route::get('/a8/load', [HomeController::class, 'LoadA8'])->name('load.a8');
    Route::post('/a8/create', [HomeController::class, 'CreateA8'])->name('create.a8');
    Route::get('/a8/delete/{id}', [HomeController::class, 'DeleteA8']);
    Route::get('/a8/edit/{id}', [HomeController::class, 'EditA8']);
    Route::post('/a8/update/{id}', [HomeController::class, 'UpdateA8']);


});


//Frontend show first_page
Route::get('/page_first', 'App\Http\Controllers\FrontendController@ShowFirst');

//Frontend show Login
Route::get('/login_f', 'App\Http\Controllers\FrontendController@Login')->name('login_front');

//Frontend show Register
Route::get('/register_f', 'App\Http\Controllers\FrontendController@Register')->name('register_front');



//Frontend show a1
Route::get('/page_a1', 'App\Http\Controllers\FrontendController@ShowA1');
Route::get('/page_a1d2', 'App\Http\Controllers\FrontendController@ShowA1d2');
Route::get('/page_a1d3', 'App\Http\Controllers\FrontendController@ShowA1d3');


//Frontend show a2
Route::get('/page_a2', 'App\Http\Controllers\FrontendController@ShowA2');
Route::get('/page_a2d2', 'App\Http\Controllers\FrontendController@ShowA2d2');
Route::get('/page_a2d3', 'App\Http\Controllers\FrontendController@ShowA2d3');


//Frontend show a3
Route::get('/page_a3', 'App\Http\Controllers\FrontendController@ShowA3');
Route::get('/page_a32b', 'App\Http\Controllers\FrontendController@ShowA32');
Route::get('/page_a33c', 'App\Http\Controllers\FrontendController@ShowA33');
Route::get('/page_a34d', 'App\Http\Controllers\FrontendController@ShowA34');
Route::get('/page_a35e', 'App\Http\Controllers\FrontendController@ShowA35');
Route::get('/page_a36f', 'App\Http\Controllers\FrontendController@ShowA36');
Route::get('/page_a3/{game_id}', 'App\Http\Controllers\FrontendController@ShowA3id');

Route::middleware(['auth'])->group(function(){
    //Frontend show a4
    Route::get('/page_a4', 'App\Http\Controllers\FrontendController@ShowA4');
    Route::get('/page_a4d2', 'App\Http\Controllers\FrontendController@ShowA4d2');
    Route::get('/page_a4d3', 'App\Http\Controllers\FrontendController@ShowA4d3');

    //Frontend show a5
Route::get('/page_a5', 'App\Http\Controllers\FrontendController@ShowA5');
Route::get('/page_a5d2', 'App\Http\Controllers\FrontendController@ShowA5d2');
Route::get('/page_a5d3', 'App\Http\Controllers\FrontendController@ShowA5d3');

    //Frontend show a6
    Route::get('/page_a6', 'App\Http\Controllers\FrontendController@ShowA6');
    Route::get('/page_a6/{game_id}', 'App\Http\Controllers\FrontendController@ShowA6id');

    //Frontend show a7
    Route::get('/page_a7', 'App\Http\Controllers\FrontendController@ShowA7');
    Route::get('/page_a7/{game_id}', 'App\Http\Controllers\FrontendController@ShowA7id');

    //Frontend show a8
    Route::get('/page_a8', 'App\Http\Controllers\FrontendController@ShowA8');
    Route::get('/page_a8/{game_id}', 'App\Http\Controllers\FrontendController@ShowA8id');
});




//Frontend show test
Route::get('/test/{game_id}', 'App\Http\Controllers\FrontendController@Test');

//Frontend show testt
Route::get('/testt', function () {
    return view('test');
});