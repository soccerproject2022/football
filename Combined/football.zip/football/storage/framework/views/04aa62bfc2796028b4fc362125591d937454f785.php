
<?php $__env->startSection('admin'); ?>



<div class="col-lg-12">

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
        <button type="button" class="class" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>


    <div class="card-header card-header-border-bottom">
        <h2>a1 database table</h2>
    </div>
    <div class="card-body">
        <p class="mb-5"></a></p>
        <button style="margin-bottom: 10px" class="btn btn-primary delete_all" data-url="<?php echo e(url('DeleteAll')); ?>">Delete All Selected</button>
        <!-- <div class="top-scroll" style="width: 900px; overflow-x: scroll; overflow-y:hidden; overflow-y:hidden;">
            <div class="div1" style="width:1200px; "></div>
        </div>
        <div class="ttable"
            style="overflow-x: scroll; overflow-y:hidden; width: 900px;">
            <div class="scroll-content" style="width:1200px; overflow: auto; "> -->
                <table class="table table-hover" style="display:block; overflow-x: auto;">

                    <thead>
                        <tr>
                            <th width="50px"><input type="checkbox" id="master"></th>
                            <th scope="col">game id</th>
                            <th scope="col">聯賽</th>
                            <th scope="col">球賽編號</th>
                            <th scope="col">日期時間</th>
                            <th scope="col">主</th>
                            <th scope="col">客</th>
                            <th scope="col">主勝</th>
                            <th scope="col">和率</th>
                            <th scope="col">客勝</th>
                            <th scope="col">主回率</th>
                            <th scope="col">和回率</th>
                            <th scope="col">客回率</th>
                            <th scope="col">主隊圖</th>
                            <th scope="col">客隊圖</th>
                            <th scope="col">主隊勝數</th>
                            <th scope="col">和波機數</th>
                            <th scope="col">客隊勝數</th>
                            <th scope="col">主隊最小範圍</th>
                            <th scope="col">客隊最小範圍</th>
                            <th scope="col">總最小範圍</th>
                            <th scope="col">主隊最大範圍</th>
                            <th scope="col">客隊最大範圍</th>
                            <th scope="col">總最大範圍</th>
                            <th scope="col">次序</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $a1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a1datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($a1datum->game_id); ?>"></td>
                            <td><?php echo e($a1datum->game_id); ?></td>
                            <td><?php echo e($a1datum->league); ?></td>
                            <td><?php echo e($a1datum->jc_id); ?></td>
                            <td><?php echo e(($a1datum->date)); ?></td>
                            <td><?php echo e($a1datum->host); ?></td>
                            <td><?php echo e($a1datum->guest); ?></td>
                            <td><?php echo e($a1datum->h_win); ?></td>
                            <td><?php echo e($a1datum->draw); ?></td>
                            <td><?php echo e($a1datum->g_win); ?></td>
                            <td><?php echo e($a1datum->h_return); ?></td>
                            <td><?php echo e($a1datum->d_return); ?></td>
                            <td><?php echo e($a1datum->g_return); ?></td>
                            <td><img src="<?php echo e(asset($a1datum->h_img)); ?>" style="width:40px"></td>
                            <td><img src="<?php echo e(asset($a1datum->g_img)); ?>" style="width:40px"></td>


                            <td><?php echo e($a1datum->h_guess); ?></td>
                            <td><?php echo e($a1datum->d_guess); ?></td>
                            <td><?php echo e($a1datum->g_guess); ?></td>
                            <td><?php echo e($a1datum->h_min); ?></td>
                            <td><?php echo e($a1datum->g_min); ?></td>
                            <td><?php echo e($a1datum->total_min); ?></td>
                            <td><?php echo e($a1datum->h_max); ?></td>
                            <td><?php echo e($a1datum->g_max); ?></td>
                            <td><?php echo e($a1datum->total_max); ?></td>
                            <td><?php echo e($a1datum->order); ?></td>

                            <td><a href="<?php echo e(url('a1/edit/'.$a1datum->game_id)); ?>" class="btn btn-info">Edit</a></td>
                            <td><a href="<?php echo e(url('a1/delete/'.$a1datum->game_id)); ?>"
                                    onclick="return confirm('Are you sure to delete?')"
                                    class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            <!-- </div>
        </div> -->
    </div>
</div>




<div class="col-lg-12">
    <div class="card">
        <div class="card card-default">
            <div class="card-header card-header-border-bottom">
                <h2></h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('create.a1')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-sm-3">
                            <h3> A1</h3>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>聯賽</label>
                                <input type="text" name="league" class="form-control" placeholder="聯賽">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>球賽編號</label>
                                <input type="text" name="jc_id" class="form-control" placeholder="球賽編號">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>日期時間</label>
                                <input type="datetime-local" name="date" class="form-control" placeholder="日期時間">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="主隊">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="客隊">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>主勝</label>
                                <input type="number" name="h_win" class="form-control" placeholder="主勝率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>和率</label>
                                <input type="number" name="draw" class="form-control" placeholder="和率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>客勝</label>
                                <input type="number" name="g_win" class="form-control" placeholder="客勝率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>主回率</label>
                                <input type="number" name="h_return" class="form-control" placeholder="主回率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>和回率</label>
                                <input type="number" name="d_return" class="form-control" placeholder="和回率" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>客回</label>
                                <input type="number" name="g_return" class="form-control" placeholder="客回" step=any />
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>主隊圖</label>
                                <input type="file" name="g_img" class="form-control">
                                <?php $__errorArgs = ['h_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="city">客隊圖</label>
                                <input type="file" name="h_img" class="form-control">
                                <?php $__errorArgs = ['g_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-sm-3">
                            <h3> A2</h3>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>主隊勝數</label>
                                <input type="number" name="h_guess" class="form-control" placeholder="主場勝數" step=any>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>和波機數</label>
                                <input type="number" name="d_guess" class="form-control" placeholder="和波機數" step=any>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>客隊勝數</label>
                                <input type="number" name="g_guess" class="form-control" placeholder="客隊勝數" step=any>
                            </div>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-sm-3">
                            <h3> A5</h3>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>主隊最小範圍</label>
                                <input type="number" name="h_min" class="form-control" placeholder="主隊最小範圍" step=any>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>客隊最小範圍</label>
                                <input type="number" name="g_min" class="form-control" placeholder="客隊最小範圍" step=any>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>總最小範圍</label>
                                <input type="number" name="total_min" class="form-control" placeholder="總最小範圍" step=any>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>主隊最大範圍</label>
                                <input type="number" name="h_max" class="form-control" placeholder="主隊最大範圍" step=any>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>客隊最大範圍</label>
                                <input type="number" name="g_max" class="form-control" placeholder="客隊最大範圍" step=any>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>總最大範圍</label>
                                <input type="number" name="total_max" class="form-control" placeholder="總最大範圍" step=any>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>次序</label>
                                <input type="number" name="order" class="form-control" placeholder="次序" step=any>
                            </div>
                        </div>

                    </div>




                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Create</button>
                    </div>


                </form>
            </div>
        </div>


    </div>
</div>

<!-- <script type="text/javascript">
$(function() {
    $(".top-scroll").scroll(function() {
        $(".ttable").scrollLeft($(".top-scroll").scrollLeft());
    });
    $(".ttable").scroll(function() {
        $(".top-scroll").scrollLeft($(".ttable").scrollLeft());
    });
});
</script> -->

<script type="text/javascript">
$(document).ready(function() {
    $('#master').on('click', function(e) {
        if ($(this).is(':checked', true)) {
            $(".sub_chk").prop('checked', true);
        } else {
            $(".sub_chk").prop('checked', false);
        }
    });


    $('.delete_all').on('click', function(e) {


        var allVals = [];
        $(".sub_chk:checked").each(function() {
            allVals.push($(this).attr('data-id'));
        });


        if (allVals.length <= 0) {
            alert("Please select row.");
        } else {


            var check = confirm("Are you sure you want to delete this row?");
            if (check == true) {


                var join_selected_values = allVals.join(",");


                $.ajax({
                    url: $(this).data('url'),
                    type: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: 'ids=' + join_selected_values,
                    success: function(data) {
                        if (data['success']) {
                            $(".sub_chk:checked").each(function() {
                                $(this).parents("tr").remove();
                            });
                            alert(data['success']);
                        } else if (data['error']) {
                            alert(data['error']);
                        } else {
                            alert('Whoops Something went wrong!!');
                        }
                    },
                    error: function(data) {
                        alert(data.responseText);
                    }
                });


                $.each(allVals, function(index, value) {
                    $('table tr').filter("[data-row-id='" + value + "']").remove();
                });
            }
        }
    });


    $('[data-toggle=confirmation]').confirmation({
        rootSelector: '[data-toggle=confirmation]',
        onConfirm: function(event, element) {
            element.trigger('confirm');
        }
    });


    $(document).on('confirm', function(e) {
        var ele = e.target;
        e.preventDefault();


        $.ajax({
            url: ele.href,
            type: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(data) {
                if (data['success']) {
                    $("#" + data['tr']).slideUp("slow");
                    alert(data['success']);
                } else if (data['error']) {
                    alert(data['error']);
                } else {
                    alert('Whoops Something went wrong!!');
                }
            },
            error: function(data) {
                alert(data.responseText);
            }
        });


        return false;
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\football\resources\views/admin/a1/index.blade.php ENDPATH**/ ?>