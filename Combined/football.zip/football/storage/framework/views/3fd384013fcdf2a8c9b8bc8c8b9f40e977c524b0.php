

<?php $__env->startSection('admin'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\football\resources\views/admin/index.blade.php ENDPATH**/ ?>