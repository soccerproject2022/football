﻿      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u50" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Rectangle) -->
        <div id="u51" class="ax_default box_1">
          <div id="u51_div" class=""></div>
          <div id="u51_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u52" class="ax_default box_3">
          <div id="u52_div" class=""></div>
          <div id="u52_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u53" class="ax_default box_3">
          <div id="u53_div" class=""></div>
          <div id="u53_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u54" class="ax_default box_3">
          <div id="u54_div" class=""></div>
          <div id="u54_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u55" class="ax_default box_3">
          <div id="u55_div" class=""></div>
          <div id="u55_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u56" class="ax_default box_3">
          <div id="u56_div" class=""></div>
          <div id="u56_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u57" class="ax_default box_3">
          <div id="u57_div" class=""></div>
          <div id="u57_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u58" class="ax_default box_3">
          <div id="u58_div" class=""></div>
          <div id="u58_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u59" class="ax_default">
          <div id="u59_state0" class="panel_state" data-label="State 1" style="">
            <div id="u59_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u60" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u61" class="ax_default box_3">
                  <div id="u61_div" class=""></div>
                  <div id="u61_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u62" class="ax_default box_3">
                  <div id="u62_div" class=""></div>
                  <div id="u62_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u63" class="ax_default box_3">
                  <div id="u63_div" class=""></div>
                  <div id="u63_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u64" class="ax_default box_3">
                  <img id="u64_img" class="img " src="/footballui/public/frontend/images/top_menu/u64.svg"/>
                  <div id="u64_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u65" class="ax_default box_3">
                  <div id="u65_div" class=""></div>
                  <div id="u65_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u66" class="ax_default box_3">
                  <div id="u66_div" class=""></div>
                  <div id="u66_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u67" class="ax_default box_3">
                  <div id="u67_div" class=""></div>
                  <div id="u67_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u68" class="ax_default">
          <div id="u68_state0" class="panel_state" data-label="State 1" style="">
            <div id="u68_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u69" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u70" class="ax_default box_3">
                  <div id="u70_div" class=""></div>
                  <div id="u70_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u71" class="ax_default box_3">
                  <div id="u71_div" class=""></div>
                  <div id="u71_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u72" class="ax_default box_3">
                  <div id="u72_div" class=""></div>
                  <div id="u72_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u73" class="ax_default box_3">
                  <img id="u73_img" class="img " src="/footballui/public/frontend/images/top_menu/u73.svg"/>
                  <div id="u73_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u74" class="ax_default box_3">
                  <div id="u74_div" class=""></div>
                  <div id="u74_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u75" class="ax_default box_3">
                  <div id="u75_div" class=""></div>
                  <div id="u75_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u76" class="ax_default">
          <div id="u76_state0" class="panel_state" data-label="State 1" style="">
            <div id="u76_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u77" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u78" class="ax_default box_3">
                  <div id="u78_div" class=""></div>
                  <div id="u78_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u79" class="ax_default box_3">
                  <div id="u79_div" class=""></div>
                  <div id="u79_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u80" class="ax_default box_3">
                  <div id="u80_div" class=""></div>
                  <div id="u80_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u81" class="ax_default box_3">
                  <img id="u81_img" class="img " src="/footballui/public/frontend/images/top_menu/u81.svg"/>
                  <div id="u81_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Image) -->
        <div id="u82" class="ax_default image">
          <img id="u82_img" class="img " src="/footballui/public/frontend/images/top_menu/u82.jpg"/>
          <div id="u82_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>
      <div id="u49" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u84" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u85" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u85_state0" class="panel_state" data-label="State 1" style="">
            <div id="u85_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u86" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u87" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u87_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u87_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u88" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u89" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u89_div" class=""></div>
                          <div id="u89_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u90" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u90_div" class=""></div>
                          <div id="u90_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u91" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u91_div" class=""></div>
                          <div id="u91_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u92" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u92_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u92_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u93" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u93_div" class=""></div>
                          <div id="u93_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u94" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u94_div" class=""></div>
                          <div id="u94_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u95" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u95_div" class=""></div>
                          <div id="u95_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u96" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u96_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u96_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u97" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u98" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u98_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u98_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u99" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u100" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u100_div" class=""></div>
                          <div id="u100_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u101" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u101_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u101_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u102" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u102_div" class=""></div>
                          <div id="u102_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u103" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u103_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u103_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u104" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u104_div" class=""></div>
                          <div id="u104_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u105" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u105_div" class=""></div>
                          <div id="u105_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u106" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u106_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u106_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u107" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u108" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u108_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u108_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u109" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u110" class="ax_default box_3">
                          <div id="u110_div" class=""></div>
                          <div id="u110_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u111" class="ax_default box_3">
                          <img id="u111_img" class="img " src="/footballui/public/frontend/images/top_menu/u111.svg"/>
                          <div id="u111_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u112" class="ax_default box_3">
                          <div id="u112_div" class=""></div>
                          <div id="u112_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u113" class="ax_default box_3">
                          <img id="u113_img" class="img " src="/footballui/public/frontend/images/top_menu/u113.svg"/>
                          <div id="u113_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u114" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u114_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u114_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u115" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u115_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u115_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u116" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u116_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u116_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u117" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u117_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u117_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u118" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u118_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u118_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u119" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u119_div" class=""></div>
          <div id="u119_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u120" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u120_div" class=""></div>
          <div id="u120_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>

        <!-- Unnamed (Image) -->
        <div id="u121" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u121_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u121_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>
      <div id="u83" style="display:none; visibility:hidden;"></div>
      <link href="/footballui/public/frontend/files/top_menu/styles.css" type="text/css" rel="stylesheet"/> 
      <script src="/footballui/public/frontend/files/top_menu/data.js"></script>



<?php /**PATH C:\xampp\htdocs\football\resources\views/frontend/top_menu.blade.php ENDPATH**/ ?>