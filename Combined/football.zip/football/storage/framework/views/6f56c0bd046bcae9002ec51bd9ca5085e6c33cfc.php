﻿<!DOCTYPE html>
<html>
  <head>
    <title>Login</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/football/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/football/public/frontend/files/login/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/football/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/football/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/football/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/football/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/football/public/frontend/data/document.js"></script>
    <script src="/football/public/frontend/files/login/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/football/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/football/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/football/public/frontend/resources/reload.html'; };
    </script>

<!-- Login -->

<!-- GOOGLE FONTS -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500|Poppins:400,500,600,700|Roboto:400,500" rel="stylesheet" />
        <link href="https://cdn.materialdesignicons.com/3.0.39/css/materialdesignicons.min.css" rel="stylesheet" />

        <!-- PLUGINS CSS STYLE -->
        
        <link href="<?php echo e(asset('backend/assets/plugins/nprogress/nprogress.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('backend/assets/plugins/flag-icons/css/flag-icon.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('backend/assets/plugins/jvectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('backend/assets/plugins/ladda/ladda.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('backend/assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('backend/assets/plugins/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />

        <!-- SLEEK CSS -->
        <link id="sleek-css" rel="stylesheet" href="<?php echo e(asset('backend/assets/css/sleek.css')); ?>" />



        <!-- FAVICON -->
        <link href="<?php echo e(asset('backend/assets/img/favicon.png')); ?>" rel="shortcut icon" />

       
        <script src="<?php echo e(asset('backend/assets/plugins/nprogress/nprogress.js')); ?>"></script>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >


  </head>
  <body>
    <div id="base" class="">

      <!-- Header (Rectangle) -->
      <div id="u0" class="ax_default box_2" data-label="Header">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;"></span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">會員登入</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u1" class="ax_default box_2 ax_default_unplaced" style="display:none; visibility: hidden">
        <div id="u1_div" class=""></div>
        <div id="u1_text" class="text ">
          <p><span style="font-family:&quot;Rockwell Normal&quot;, &quot;Rockwell&quot;, sans-serif;"></span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">會員登入</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u3" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u4" class="ax_default placeholder">
          <img id="u4_img" class="img " src="/football/public/frontend/images/login/u4.svg"/>
          <div id="u4_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u5" class="ax_default box_1">
          <div id="u5_div" class=""></div>
          <div id="u5_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u6" class="ax_default box_3">
          <div id="u6_div" class=""></div>
          <div id="u6_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u7" class="ax_default box_3">
          <div id="u7_div" class=""></div>
          <div id="u7_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u8" class="ax_default box_3">
          <div id="u8_div" class=""></div>
          <div id="u8_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u9" class="ax_default box_3">
          <div id="u9_div" class=""></div>
          <div id="u9_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u10" class="ax_default box_3">
          <div id="u10_div" class=""></div>
          <div id="u10_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u11" class="ax_default box_3">
          <div id="u11_div" class=""></div>
          <div id="u11_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u12" class="ax_default box_3">
          <div id="u12_div" class=""></div>
          <div id="u12_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u13" class="ax_default">
          <div id="u13_state0" class="panel_state" data-label="State 1" style="">
            <div id="u13_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u14" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u15" class="ax_default box_3">
                  <div id="u15_div" class=""></div>
                  <div id="u15_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u16" class="ax_default box_3">
                  <div id="u16_div" class=""></div>
                  <div id="u16_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u17" class="ax_default box_3">
                  <div id="u17_div" class=""></div>
                  <div id="u17_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u18" class="ax_default box_3">
                  <img id="u18_img" class="img " src="/football/public/frontend/images/login/u18.svg"/>
                  <div id="u18_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u19" class="ax_default box_3">
                  <div id="u19_div" class=""></div>
                  <div id="u19_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u20" class="ax_default box_3">
                  <div id="u20_div" class=""></div>
                  <div id="u20_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u21" class="ax_default box_3">
                  <div id="u21_div" class=""></div>
                  <div id="u21_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u22" class="ax_default">
          <div id="u22_state0" class="panel_state" data-label="State 1" style="">
            <div id="u22_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u23" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u24" class="ax_default box_3">
                  <div id="u24_div" class=""></div>
                  <div id="u24_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u25" class="ax_default box_3">
                  <div id="u25_div" class=""></div>
                  <div id="u25_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u26" class="ax_default box_3">
                  <div id="u26_div" class=""></div>
                  <div id="u26_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u27" class="ax_default box_3">
                  <img id="u27_img" class="img " src="/football/public/frontend/images/login/u27.svg"/>
                  <div id="u27_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u28" class="ax_default box_3">
                  <div id="u28_div" class=""></div>
                  <div id="u28_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u29" class="ax_default box_3">
                  <div id="u29_div" class=""></div>
                  <div id="u29_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u30" class="ax_default">
          <div id="u30_state0" class="panel_state" data-label="State 1" style="">
            <div id="u30_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u31" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u32" class="ax_default box_3">
                  <div id="u32_div" class=""></div>
                  <div id="u32_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u33" class="ax_default box_3">
                  <div id="u33_div" class=""></div>
                  <div id="u33_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u34" class="ax_default box_3">
                  <div id="u34_div" class=""></div>
                  <div id="u34_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u35" class="ax_default box_3">
                  <img id="u35_img" class="img " src="/football/public/frontend/images/login/u35.svg"/>
                  <div id="u35_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u2" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u37" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u38" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u38_state0" class="panel_state" data-label="State 1" style="">
            <div id="u38_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u39" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u40" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u40_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u40_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u41" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u42" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u42_div" class=""></div>
                          <div id="u42_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u43" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u43_div" class=""></div>
                          <div id="u43_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u44" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u44_div" class=""></div>
                          <div id="u44_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u45" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u45_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                          <div id="u45_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u46" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u46_div" class=""></div>
                          <div id="u46_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u47" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u47_div" class=""></div>
                          <div id="u47_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u48" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u48_div" class=""></div>
                          <div id="u48_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u49" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u49_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                  <div id="u49_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u50" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u51" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u51_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u51_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u52" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u53" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u53_div" class=""></div>
                          <div id="u53_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u54" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u54_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                          <div id="u54_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u55" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u55_div" class=""></div>
                          <div id="u55_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u56" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u56_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                          <div id="u56_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u57" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u57_div" class=""></div>
                          <div id="u57_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u58" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u58_div" class=""></div>
                          <div id="u58_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u59" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u59_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                  <div id="u59_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u60" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u61" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u61_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u61_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u62" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u63" class="ax_default box_3">
                          <div id="u63_div" class=""></div>
                          <div id="u63_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u64" class="ax_default box_3">
                          <img id="u64_img" class="img " src="/football/public/frontend/images/login/u64.svg"/>
                          <div id="u64_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u65" class="ax_default box_3">
                          <div id="u65_div" class=""></div>
                          <div id="u65_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u66" class="ax_default box_3">
                          <img id="u66_img" class="img " src="/football/public/frontend/images/login/u66.svg"/>
                          <div id="u66_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u67" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u67_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                  <div id="u67_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u68" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u68_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u68_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u69" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u69_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u69_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u70" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u70_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u70_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u71" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u71_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
                <div id="u71_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u72" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u72_img" class="img " src="/football/public/frontend/resources/images/transparent.gif"/>
          <div id="u72_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u73" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u73_div" class=""></div>
          <div id="u73_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u74" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u74_div" class=""></div>
          <div id="u74_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u36" style="display:none; visibility:hidden;"></div>

      <!-- Date (Group) 
      <div id="u75" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="28">

         After_tomorrow (Rectangle) 
        <div id="u76" class="ax_default label" data-label="After_tomorrow">
          <div id="u76_div" class=""></div>
          <div id="u76_text" class="text ">
            <p><span>後日</span></p>
          </div>
        </div>

         Tomorrow (Rectangle) 
        <div id="u77" class="ax_default label" data-label="Tomorrow">
          <div id="u77_div" class=""></div>
          <div id="u77_text" class="text ">
            <p><span>明日</span></p>
          </div>
        </div>

        Today (Rectangle) 
        <div id="u78" class="ax_default label" data-label="Today">
          <div id="u78_div" class=""></div>
          <div id="u78_text" class="text ">
            <p><span>今日</span></p>
          </div>
        </div>

        Match_date (Rectangle) 
        <div id="u79" class="ax_default label" data-label="Match_date">
          <div id="u79_div" class=""></div>
          <div id="u79_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;Lucida Grande &quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div> 

      </div> -->
    </div>

<div style="position: absolute; top: 60px; left: 470px; width: 500px;">

    <div class="container d-flex flex-column justify-content-between vh-100">

    <div class="row justify-content-center mt-5">

   
 
    <div class="card-body p-5">

<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">

        <div class="form-group col-md-12 mb-4">
            <input type="email" name="email"  class="form-control input-lg"  aria-describedby="emailHelp" placeholder="Email">
        </div>

        <div class="form-group col-md-12 ">
            <input type="password" name="password"  class="form-control input-lg" placeholder="Password">
        </div>

        <div class="col-md-12">
            <div class="d-flex my-2 justify-content-between">
                <div class="d-inline-block mr-3">
                    <label class="control control-checkbox">Remember me
  <input type="checkbox" />
  <div class="control-indicator"></div>
</label>

                </div>
                <p><a class="text-blue" href="<?php echo e(route('password.request')); ?>">Forgot Your Password?</a></p>
            </div>
            <button type="submit" class="btn btn-lg btn-primary btn-block mb-4">Sign In</button>
            <p>Don't have an account yet ?
                <a class="text-blue" href="<?php echo e(route('register_front')); ?>">Sign Up</a>
            </p>
        </div>
    </div>
    <div class="flex items-center justify-end mt-4">
<a href="<?php echo e(url('auth/google')); ?>">
<img src="<?php echo e(asset('frontend\images\btn_google_signin_dark_normal_web.png')); ?>" style="margin-left: 3em; width: 200px">
</a>
<a href="<?php echo e(url('auth/facebook-login')); ?>">
<img src="<?php echo e(asset('frontend\images\login-with-facebook-button2.png')); ?>" style="margin-left: 3em; width: 200px">
</a>
</div>
</form>
</div>
</div>
</div>
</div>



    

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
 <?php if(Session::has('message')): ?>
 var type = "<?php echo e(Session::get('alert-type','info')); ?>"
 switch(type){
    case 'info':
    toastr.info(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'success':
    toastr.success(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'warning':
    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'error':
    toastr.error(" <?php echo e(Session::get('message')); ?> ");
    break; 
 }
 <?php endif; ?> 
</script>





    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\football\resources\views/frontend/login.blade.php ENDPATH**/ ?>