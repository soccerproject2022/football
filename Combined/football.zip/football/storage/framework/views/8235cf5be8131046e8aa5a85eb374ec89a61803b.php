
<?php $__env->startSection('admin'); ?>


<div class="col-lg-12">

<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
    <button type="button" class="class" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

    
        <div class="card-header card-header-border-bottom">
            <h2>a5 database table</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">主隊</th>
                        <th scope="col">客隊</th>
                        <th scope="col">主隊最小範圍</th>
                        <th scope="col">客隊最小範圍</th>
                        <th scope="col">總最小範圍</th>
                        <th scope="col">主隊最大範圍</th>
                        <th scope="col">客隊最大範圍</th>
                        <th scope="col">總最大範圍</th>
                        <th scope="col">次序</th>
                        
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $a5s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a5datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($a5datum->game_id); ?></td>
                        <td><?php echo e($a5datum->host); ?></td>
                        <td><?php echo e($a5datum->guest); ?></td>
                        <td><?php echo e($a5datum->h_min); ?></td>
                        <td><?php echo e($a5datum->g_min); ?></td>
                        <td><?php echo e($a5datum->total_min); ?></td>
                        <td><?php echo e($a5datum->h_max); ?></td>
                        <td><?php echo e($a5datum->g_max); ?></td>
                        <td><?php echo e($a5datum->total_max); ?></td>
                        <td><?php echo e($a5datum->order); ?></td>

                        <td><a href="<?php echo e(url('a5/edit/'.$a5datum->game_id)); ?>" class="btn btn-info">Edit</a></td>
                        <td><a href="<?php echo e(url('a5/delete/'.$a5datum->game_id)); ?>" onclick="return confirm('Are you sure to delete?')" class="btn btn-danger">Delete</a></td>
                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
           
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card card-default">
            <div class="card-header card-header-border-bottom">
                <h2></h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('create.a5')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="exampleFormControlSelect2">選擇 game_id</label>
                                <select class="form-control" id="exampleFormControlSelect2" name="game_id">
                                    <option disabled selected="">-- 選擇 game_id --</option>
                                    <?php $__currentLoopData = $a5gameid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gameid->game_id); ?>" <?php echo e((isset($gameid->game_id)|| old('id'))? "selected":""); ?>><?php echo e($gameid->host); ?>| vs | <?php echo e($gameid->guest); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >主隊最小範圍</label>
                                <input type="number" name="h_min" class="form-control" placeholder="主隊最小範圍" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >客隊最小範圍</label>
                                <input type="number" name="g_min" class="form-control" placeholder="客隊最小範圍" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >總最小範圍</label>
                                <input type="number" name="total_min" class="form-control" placeholder="總最小範圍" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >主隊最大範圍</label>
                                <input type="number" name="h_max" class="form-control" placeholder="主隊最大範圍" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >客隊最大範圍</label>
                                <input type="number" name="g_max" class="form-control" placeholder="客隊最大範圍" step=any >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >總最大範圍</label>
                                <input type="number" name="total_max" class="form-control" placeholder="總最大範圍" step=any >
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label >次序</label>
                                <input type="number" name="order" class="form-control" placeholder="次序" step=any >
                            </div>
                        </div>
                        
                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Create</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\football\resources\views/admin/a5/index.blade.php ENDPATH**/ ?>