﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A3</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a3/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a3/data.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/locales/de_DE.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/geodata/germanyLow.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/fonts/notosans-sc.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>


  
  <script>
  <?php if(isset($b3s,$b32s,$b33s,$b34s,$b35s)): ?>
  

  am5.ready(function() {


var root = am5.Root.new("heat");



root.setThemes([
  am5themes_Animated.new(root)
]);



var chart = root.container.children.push(am5xy.XYChart.new(root, {
  panX: false,
  panY: false,
  wheelX: "none",
  wheelY: "none",
  layout: root.verticalLayout
}));



var yRenderer = am5xy.AxisRendererY.new(root, {
  visible: false,
  minGridDistance: 20,
  inversed: true
});

yRenderer.grid.template.set("visible", false);

var yAxis = chart.yAxes.push(am5xy.CategoryAxis.new(root, {
  maxDeviation: 0,
  renderer: yRenderer,
  categoryField: "game"
}));

var xRenderer = am5xy.AxisRendererX.new(root, {
  visible: false,
  minGridDistance: 30,
  opposite:true
});

xRenderer.grid.template.set("visible", false);

var xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
  renderer: xRenderer,
  categoryField: "team"
}));



var series = chart.series.push(am5xy.ColumnSeries.new(root, {
  calculateAggregates: true,
  stroke: am5.color(0xffffff),
  clustered: false,
  xAxis: xAxis,
  yAxis: yAxis,
  categoryXField: "team",
  categoryYField: "game",
  valueField: "value"
}));

series.columns.template.setAll({
    strokeOpacity: 1,
  strokeWidth: 2,
  width: am5.percent(100),
  height: am5.percent(100)
});

series.columns.template.events.on("pointerover", function(event) {
  var di = event.target.dataItem;
  if (di) {
    heatLegend.showValue(di.get("value", 0));
  }
});

series.events.on("datavalidated", function() {
  heatLegend.set("startValue", series.getPrivate("valueHigh"));
  heatLegend.set("endValue", series.getPrivate("valueLow"));
});

series.bullets.push(function () {
  return am5.Bullet.new(root, {
    locationY: 0.5,
    sprite: am5.Label.new(root, {
      text: "{value}",
      fill: root.interfaceColors.get("alternativeText"),
      centerY: am5.p50,
      centerX: am5.p50,
      populateText: true

    })
  });
});


series.set("heatRules", [{
  target: series.columns.template,
  min: am5.color(0xcfca36),
  max: am5.color(0xfe131a),
  dataField: "value",
  key: "fill"
}]);



var heatLegend = chart.bottomAxesContainer.children.push(am5.HeatLegend.new(root, {
  orientation: "horizontal",
  endColor: am5.color(0xcfca36),
  startColor: am5.color(0xfe131a)
}));



var data = [{
  team: "主勝",
  game: "<?php echo e($b3s->host); ?> VS <?php echo e($b3s->guest); ?>",
  value: <?php echo e($b3s->h_gp); ?>

}, {
  team: "和波",
  game: "<?php echo e($b3s->host); ?> VS <?php echo e($b3s->guest); ?>",
  value: <?php echo e($b3s->d_gp); ?>

}, {
  team: "客勝",
  game: "<?php echo e($b3s->host); ?> VS <?php echo e($b3s->guest); ?>",
  value: <?php echo e($b3s->g_gp); ?>

}, {
  team: "主勝",
  game: "<?php echo e($b32s->host); ?> VS <?php echo e($b32s->guest); ?>",
  value: <?php echo e($b32s->h_gp); ?>

}, {
  team: "和波",
  game: "<?php echo e($b32s->host); ?> VS <?php echo e($b32s->guest); ?>",
  value: <?php echo e($b32s->d_gp); ?>

}, {
  team: "客勝",
  game: "<?php echo e($b32s->host); ?> VS <?php echo e($b32s->guest); ?>",
  value: <?php echo e($b32s->g_gp); ?>

},
{
  team: "主勝",
  game: "<?php echo e($b33s->host); ?> VS <?php echo e($b33s->guest); ?>",
  value: <?php echo e($b33s->h_gp); ?>

}, {
  team: "和波",
  game: "<?php echo e($b33s->host); ?> VS <?php echo e($b33s->guest); ?>",
  value: <?php echo e($b33s->d_gp); ?>

}, {
  team: "客勝",
  game: "<?php echo e($b33s->host); ?> VS <?php echo e($b33s->guest); ?>",
  value: <?php echo e($b33s->g_gp); ?>

},
{
  team: "主勝",
  game: "<?php echo e($b34s->host); ?> VS <?php echo e($b34s->guest); ?>",
  value: <?php echo e($b34s->h_gp); ?>

}, {
  team: "和波",
  game: "<?php echo e($b34s->host); ?> VS <?php echo e($b34s->guest); ?>",
  value: <?php echo e($b34s->d_gp); ?>

}, {
  team: "客勝",
  game: "<?php echo e($b34s->host); ?> VS <?php echo e($b34s->guest); ?>",
  value: <?php echo e($b34s->g_gp); ?>

},
{
  team: "主勝",
  game: "<?php echo e($b35s->host); ?> VS <?php echo e($b35s->guest); ?>",
  value: <?php echo e($b35s->h_gp); ?>

}, {
  team: "和波",
  game: "<?php echo e($b35s->host); ?> VS <?php echo e($b35s->guest); ?>",
  value: <?php echo e($b35s->d_gp); ?>

}, {
  team: "客勝",
  game: "<?php echo e($b35s->host); ?> VS <?php echo e($b35s->guest); ?>",
  value: <?php echo e($b35s->g_gp); ?>

}
]

series.data.setAll(data);

yAxis.data.setAll([
  { game: "<?php echo e($b3s->host); ?> VS <?php echo e($b3s->guest); ?>" },
  { game: "<?php echo e($b32s->host); ?> VS <?php echo e($b32s->guest); ?>" },
  { game: "<?php echo e($b33s->host); ?> VS <?php echo e($b33s->guest); ?>" },
  { game: "<?php echo e($b34s->host); ?> VS <?php echo e($b34s->guest); ?>" },
  { game: "<?php echo e($b35s->host); ?> VS <?php echo e($b35s->guest); ?>" },
  
]);

xAxis.data.setAll([
  { team: "主勝" },
  { team: "和波" },
  { team: "客勝" }
 
]);


chart.appear(1000, 100);

}); 




<?php endif; ?>

</script>





  </head>
  <body>
    <div id="base" class="">

      <!-- Header (Rectangle) -->
      <div id="u0" class="ax_default box_2" data-label="Header">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text ">
          <p><span>值博率模組分析</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u2" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u3" class="ax_default placeholder">
          <img id="u3_img" class="img " src="/footballui/public/frontend/images/page_a3/u3.svg"/>
          <div id="u3_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u4" class="ax_default box_1">
          <div id="u4_div" class=""></div>
          <div id="u4_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u5" class="ax_default box_3">
          <div id="u5_div" class=""></div>
          <div id="u5_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u6" class="ax_default box_3">
          <div id="u6_div" class=""></div>
          <div id="u6_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u7" class="ax_default box_3">
          <div id="u7_div" class=""></div>
          <div id="u7_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u8" class="ax_default box_3">
          <div id="u8_div" class=""></div>
          <div id="u8_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u9" class="ax_default box_3">
          <div id="u9_div" class=""></div>
          <div id="u9_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u10" class="ax_default box_3">
          <div id="u10_div" class=""></div>
          <div id="u10_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u11" class="ax_default box_3">
          <div id="u11_div" class=""></div>
          <div id="u11_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u12" class="ax_default">
          <div id="u12_state0" class="panel_state" data-label="State 1" style="">
            <div id="u12_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u13" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u14" class="ax_default box_3">
                  <div id="u14_div" class=""></div>
                  <div id="u14_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u15" class="ax_default box_3">
                  <div id="u15_div" class=""></div>
                  <div id="u15_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u16" class="ax_default box_3">
                  <div id="u16_div" class=""></div>
                  <div id="u16_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u17" class="ax_default box_3">
                  <img id="u17_img" class="img " src="/footballui/public/frontend/images/page_a3/u17.svg"/>
                  <div id="u17_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u18" class="ax_default box_3">
                  <div id="u18_div" class=""></div>
                  <div id="u18_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u19" class="ax_default box_3">
                  <div id="u19_div" class=""></div>
                  <div id="u19_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u20" class="ax_default box_3">
                  <div id="u20_div" class=""></div>
                  <div id="u20_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u21" class="ax_default">
          <div id="u21_state0" class="panel_state" data-label="State 1" style="">
            <div id="u21_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u22" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u23" class="ax_default box_3">
                  <div id="u23_div" class=""></div>
                  <div id="u23_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u24" class="ax_default box_3">
                  <div id="u24_div" class=""></div>
                  <div id="u24_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u25" class="ax_default box_3">
                  <div id="u25_div" class=""></div>
                  <div id="u25_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u26" class="ax_default box_3">
                  <img id="u26_img" class="img " src="/footballui/public/frontend/images/page_a3/u26.svg"/>
                  <div id="u26_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u27" class="ax_default box_3">
                  <div id="u27_div" class=""></div>
                  <div id="u27_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u28" class="ax_default box_3">
                  <div id="u28_div" class=""></div>
                  <div id="u28_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u29" class="ax_default">
          <div id="u29_state0" class="panel_state" data-label="State 1" style="">
            <div id="u29_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u30" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u31" class="ax_default box_3">
                  <div id="u31_div" class=""></div>
                  <div id="u31_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u32" class="ax_default box_3">
                  <div id="u32_div" class=""></div>
                  <div id="u32_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u33" class="ax_default box_3">
                  <div id="u33_div" class=""></div>
                  <div id="u33_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u34" class="ax_default box_3">
                  <img id="u34_img" class="img " src="/footballui/public/frontend/images/page_a3/u34.svg"/>
                  <div id="u34_text" class="text ">
                    <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u1" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u36" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u37" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u37_state0" class="panel_state" data-label="State 1" style="">
            <div id="u37_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u38" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u39" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u39_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u39_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u40" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u41" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u41_div" class=""></div>
                          <div id="u41_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u42" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u42_div" class=""></div>
                          <div id="u42_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u43" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u43_div" class=""></div>
                          <div id="u43_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u44" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u44_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u44_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u45" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u45_div" class=""></div>
                          <div id="u45_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u46" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u46_div" class=""></div>
                          <div id="u46_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u47" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u47_div" class=""></div>
                          <div id="u47_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u48" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u48_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u48_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u49" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u50" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u50_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u50_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u51" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u52" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u52_div" class=""></div>
                          <div id="u52_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u53" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u53_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u53_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u54" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u54_div" class=""></div>
                          <div id="u54_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u55" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u55_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u55_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u56" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u56_div" class=""></div>
                          <div id="u56_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u57" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u57_div" class=""></div>
                          <div id="u57_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u58" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u58_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u58_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u59" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u60" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u60_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u60_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u61" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u62" class="ax_default box_3">
                          <div id="u62_div" class=""></div>
                          <div id="u62_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u63" class="ax_default box_3">
                          <img id="u63_img" class="img " src="/footballui/public/frontend/images/page_a3/u63.svg"/>
                          <div id="u63_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u64" class="ax_default box_3">
                          <div id="u64_div" class=""></div>
                          <div id="u64_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u65" class="ax_default box_3">
                          <img id="u65_img" class="img " src="/footballui/public/frontend/images/page_a3/u65.svg"/>
                          <div id="u65_text" class="text ">
                            <p><span style="font-family:&quot;Arial Normal&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u66" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u66_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u66_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u67" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u67_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u67_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u68" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u68_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u68_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u69" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u69_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u69_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u70" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u70_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u70_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u71" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u71_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u71_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u72" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u72_div" class=""></div>
          <div id="u72_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u73" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u73_div" class=""></div>
          <div id="u73_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u35" style="display:none; visibility:hidden;"></div>

      <?php if(isset($b3s,$b32s,$b33s,$b34s,$b35s)): ?> 

      <!-- Logo_Group1 (Group) -->
      <div id="u74" class="ax_default" data-label="Logo_Group1" data-left="372" data-top="583" data-width="651" data-height="224">

        <!-- g_logo (Image) -->
        <div id="u75" class="ax_default image" data-label="g_logo">
          <img id="u75_img" class="img " src="<?php echo e(asset($b35s->g_img)); ?>"/>
          <div id="u75_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- h_logo (Image) -->
        <div id="u76" class="ax_default image" data-label="h_logo">
          <img id="u76_img" class="img " src="<?php echo e(asset($b35s->h_img)); ?>"/>
          <div id="u76_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u77" class="ax_default box_2" data-label="Team_Away">
          <div id="u77_div" class=""></div>
          <div id="u77_text" class="text ">
            <p><span><?php echo e($b35s->guest); ?></span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u78" class="ax_default box_2" data-label="Team_Home">
          <div id="u78_div" class=""></div>
          <div id="u78_text" class="text ">
            <p><span><?php echo e($b35s->host); ?></span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u79" class="ax_default box_2" data-label="Date_Time">
          <div id="u79_div" class=""></div>
          <div id="u79_text" class="text ">
            <p><span><?php echo e(Carbon\Carbon::parse($b35s->date)->diffForHumans()); ?>開波</span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u80" class="ax_default box_2" data-label="Match">
          <div id="u80_div" class=""></div>
          <div id="u80_text" class="text ">
            <p><span><?php echo e($b35s->league); ?></span></p>
          </div>
        </div>

        <!-- h_gp (Rectangle) -->
        <div id="u81" class="ax_default paragraph" data-label="h_gp">
          <div id="u81_div" class=""></div>
          <div id="u81_text" class="text ">
            <p><span><?php echo e($b35s->h_gp); ?></span></p>
          </div>
        </div>

        <!-- h_fix (Rectangle) -->
        <div id="u82" class="ax_default paragraph" data-label="h_fix">
          <div id="u82_div" class=""></div>
          <div id="u82_text" class="text ">
            <p><span>主勝值博率</span></p>
          </div>
        </div>

        <!-- d_gp (Rectangle) -->
        <div id="u83" class="ax_default paragraph" data-label="d_gp">
          <div id="u83_div" class=""></div>
          <div id="u83_text" class="text ">
            <p><span><?php echo e($b35s->d_gp); ?></span></p>
          </div>
        </div>

        <!-- d_fix (Rectangle) -->
        <div id="u84" class="ax_default paragraph" data-label="d_fix">
          <div id="u84_div" class=""></div>
          <div id="u84_text" class="text ">
            <p><span>和波值博率</span></p>
          </div>
        </div>

        <!-- g_gp (Rectangle) -->
        <div id="u85" class="ax_default paragraph" data-label="g_gp">
          <div id="u85_div" class=""></div>
          <div id="u85_text" class="text ">
            <p><span><?php echo e($b35s->g_gp); ?></span></p>
          </div>
        </div>

        <!-- g_fix (Rectangle) -->
        <div id="u86" class="ax_default paragraph" data-label="g_fix">
          <div id="u86_div" class=""></div>
          <div id="u86_text" class="text ">
            <p><span>容勝值博率</span></p>
          </div>
        </div>
      </div>

      <!-- Date (Group) -->
      <div id="u87" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="28">

        <!-- After_tomorrow (Rectangle) -->
        <div id="u88" class="ax_default label" data-label="After_tomorrow">
          <div id="u88_div" class=""></div>
          <div id="u88_text" class="text ">
            <p><span>後日</span></p>
          </div>
        </div>

        <!-- Tomorrow (Rectangle) -->
        <div id="u89" class="ax_default label" data-label="Tomorrow">
          <div id="u89_div" class=""></div>
          <div id="u89_text" class="text ">
            <p><span>明日</span></p>
          </div>
        </div>

        <!-- Today (Rectangle) -->
        <div id="u90" class="ax_default label" data-label="Today">
          <div id="u90_div" class=""></div>
          <div id="u90_text" class="text ">
            <p><span>今日</span></p>
          </div>
        </div>

        <!-- Match_date (Rectangle) -->
        <div id="u91" class="ax_default label" data-label="Match_date">
          <div id="u91_div" class=""></div>
          <div id="u91_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;Lucida Grande &quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div>
      </div>

      <!-- Logo_Group2 (Group) -->
      <div id="u92" class="ax_default" data-label="Logo_Group2" data-left="372" data-top="856" data-width="651" data-height="224">

        <!-- g_logo (Image) -->
        <div id="u93" class="ax_default image" data-label="g_logo">
          <img id="u93_img" class="img " src="<?php echo e(asset($b34s->g_img)); ?>"/>
          <div id="u93_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- h_logo (Image) -->
        <div id="u94" class="ax_default image" data-label="h_logo">
          <img id="u94_img" class="img " src="<?php echo e(asset($b34s->h_img)); ?>"/>
          <div id="u94_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u95" class="ax_default box_2" data-label="Team_Away">
          <div id="u95_div" class=""></div>
          <div id="u95_text" class="text ">
            <p><span><?php echo e($b34s->guest); ?></span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u96" class="ax_default box_2" data-label="Team_Home">
          <div id="u96_div" class=""></div>
          <div id="u96_text" class="text ">
            <p><span><?php echo e($b34s->host); ?></span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u97" class="ax_default box_2" data-label="Date_Time">
          <div id="u97_div" class=""></div>
          <div id="u97_text" class="text ">
            <p><span><?php echo e(Carbon\Carbon::parse($b34s->date)->diffForHumans()); ?>開波</span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u98" class="ax_default box_2" data-label="Match">
          <div id="u98_div" class=""></div>
          <div id="u98_text" class="text ">
            <p><span><?php echo e($b34s->league); ?></span></p>
          </div>
        </div>

        <!-- h_gp (Rectangle) -->
        <div id="u99" class="ax_default paragraph" data-label="h_gp">
          <div id="u99_div" class=""></div>
          <div id="u99_text" class="text ">
            <p><span><?php echo e($b34s->h_gp); ?></span></p>
          </div>
        </div>

        <!-- h_fix (Rectangle) -->
        <div id="u100" class="ax_default paragraph" data-label="h_fix">
          <div id="u100_div" class=""></div>
          <div id="u100_text" class="text ">
            <p><span>主勝值博率</span></p>
          </div>
        </div>

        <!-- d_gp (Rectangle) -->
        <div id="u101" class="ax_default paragraph" data-label="d_gp">
          <div id="u101_div" class=""></div>
          <div id="u101_text" class="text ">
            <p><span><?php echo e($b34s->d_gp); ?></span></p>
          </div>
        </div>

        <!-- d_fix (Rectangle) -->
        <div id="u102" class="ax_default paragraph" data-label="d_fix">
          <div id="u102_div" class=""></div>
          <div id="u102_text" class="text ">
            <p><span>和波值博率</span></p>
          </div>
        </div>

        <!-- g_gp (Rectangle) -->
        <div id="u103" class="ax_default paragraph" data-label="g_gp">
          <div id="u103_div" class=""></div>
          <div id="u103_text" class="text ">
            <p><span><?php echo e($b34s->g_gp); ?></span></p>
          </div>
        </div>

        <!-- g_fix (Rectangle) -->
        <div id="u104" class="ax_default paragraph" data-label="g_fix">
          <div id="u104_div" class=""></div>
          <div id="u104_text" class="text ">
            <p><span>容勝值博率</span></p>
          </div>
        </div>
      </div>

      <!-- Logo_Group3 (Group) -->
      <div id="u105" class="ax_default" data-label="Logo_Group3" data-left="372" data-top="1129" data-width="651" data-height="224">

        <!-- g_logo (Image) -->
        <div id="u106" class="ax_default image" data-label="g_logo">
          <img id="u106_img" class="img " src="<?php echo e(asset($b33s->g_img)); ?>"/>
          <div id="u106_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- h_logo (Image) -->
        <div id="u107" class="ax_default image" data-label="h_logo">
          <img id="u107_img" class="img " src="<?php echo e(asset($b33s->h_img)); ?>"/>
          <div id="u107_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u108" class="ax_default box_2" data-label="Team_Away">
          <div id="u108_div" class=""></div>
          <div id="u108_text" class="text ">
            <p><span><?php echo e($b33s->guest); ?></span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u109" class="ax_default box_2" data-label="Team_Home">
          <div id="u109_div" class=""></div>
          <div id="u109_text" class="text ">
            <p><span><?php echo e($b33s->host); ?></span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u110" class="ax_default box_2" data-label="Date_Time">
          <div id="u110_div" class=""></div>
          <div id="u110_text" class="text ">
            <p><span><?php echo e(Carbon\Carbon::parse($b33s->date)->diffForHumans()); ?>開波</span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u111" class="ax_default box_2" data-label="Match">
          <div id="u111_div" class=""></div>
          <div id="u111_text" class="text ">
            <p><span><?php echo e($b33s->league); ?></span></p>
          </div>
        </div>

        <!-- h_gp (Rectangle) -->
        <div id="u112" class="ax_default paragraph" data-label="h_gp">
          <div id="u112_div" class=""></div>
          <div id="u112_text" class="text ">
            <p><span><?php echo e($b33s->h_gp); ?></span></p>
          </div>
        </div>

        <!-- h_fix (Rectangle) -->
        <div id="u113" class="ax_default paragraph" data-label="h_fix">
          <div id="u113_div" class=""></div>
          <div id="u113_text" class="text ">
            <p><span>主勝值博率</span></p>
          </div>
        </div>

        <!-- d_gp (Rectangle) -->
        <div id="u114" class="ax_default paragraph" data-label="d_gp">
          <div id="u114_div" class=""></div>
          <div id="u114_text" class="text ">
            <p><span><?php echo e($b33s->d_gp); ?></span></p>
          </div>
        </div>

        <!-- d_fix (Rectangle) -->
        <div id="u115" class="ax_default paragraph" data-label="d_fix">
          <div id="u115_div" class=""></div>
          <div id="u115_text" class="text ">
            <p><span>和波值博率</span></p>
          </div>
        </div>

        <!-- g_gp (Rectangle) -->
        <div id="u116" class="ax_default paragraph" data-label="g_gp">
          <div id="u116_div" class=""></div>
          <div id="u116_text" class="text ">
            <p><span><?php echo e($b33s->g_gp); ?></span></p>
          </div>
        </div>

        <!-- g_fix (Rectangle) -->
        <div id="u117" class="ax_default paragraph" data-label="g_fix">
          <div id="u117_div" class=""></div>
          <div id="u117_text" class="text ">
            <p><span>容勝值博率</span></p>
          </div>
        </div>
      </div>

      <!-- Logo_Group4 (Group) -->
      <div id="u118" class="ax_default" data-label="Logo_Group4" data-left="372" data-top="1402" data-width="651" data-height="224">

        <!-- g_logo (Image) -->
        <div id="u119" class="ax_default image" data-label="g_logo">
          <img id="u119_img" class="img " src="<?php echo e(asset($b32s->g_img)); ?>"/>
          <div id="u119_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- h_logo (Image) -->
        <div id="u120" class="ax_default image" data-label="h_logo">
          <img id="u120_img" class="img " src="<?php echo e(asset($b32s->h_img)); ?>"/>
          <div id="u120_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u121" class="ax_default box_2" data-label="Team_Away">
          <div id="u121_div" class=""></div>
          <div id="u121_text" class="text ">
            <p><span><?php echo e($b32s->guest); ?></span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u122" class="ax_default box_2" data-label="Team_Home">
          <div id="u122_div" class=""></div>
          <div id="u122_text" class="text ">
            <p><span><?php echo e($b32s->host); ?></span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u123" class="ax_default box_2" data-label="Date_Time">
          <div id="u123_div" class=""></div>
          <div id="u123_text" class="text ">
            <p><span><?php echo e(Carbon\Carbon::parse($b32s->date)->diffForHumans()); ?>開波</span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u124" class="ax_default box_2" data-label="Match">
          <div id="u124_div" class=""></div>
          <div id="u124_text" class="text ">
            <p><span><?php echo e($b32s->league); ?></span></p>
          </div>
        </div>

        <!-- h_gp (Rectangle) -->
        <div id="u125" class="ax_default paragraph" data-label="h_gp">
          <div id="u125_div" class=""></div>
          <div id="u125_text" class="text ">
            <p><span><?php echo e($b32s->h_gp); ?></span></p>
          </div>
        </div>

        <!-- h_fix (Rectangle) -->
        <div id="u126" class="ax_default paragraph" data-label="h_fix">
          <div id="u126_div" class=""></div>
          <div id="u126_text" class="text ">
            <p><span>主勝值博率</span></p>
          </div>
        </div>

        <!-- d_gp (Rectangle) -->
        <div id="u127" class="ax_default paragraph" data-label="d_gp">
          <div id="u127_div" class=""></div>
          <div id="u127_text" class="text ">
            <p><span><?php echo e($b32s->d_gp); ?></span></p>
          </div>
        </div>

        <!-- d_fix (Rectangle) -->
        <div id="u128" class="ax_default paragraph" data-label="d_fix">
          <div id="u128_div" class=""></div>
          <div id="u128_text" class="text ">
            <p><span>和波值博率</span></p>
          </div>
        </div>

        <!-- g_gp (Rectangle) -->
        <div id="u129" class="ax_default paragraph" data-label="g_gp">
          <div id="u129_div" class=""></div>
          <div id="u129_text" class="text ">
            <p><span><?php echo e($b32s->g_gp); ?></span></p>
          </div>
        </div>

        <!-- g_fix (Rectangle) -->
        <div id="u130" class="ax_default paragraph" data-label="g_fix">
          <div id="u130_div" class=""></div>
          <div id="u130_text" class="text ">
            <p><span>容勝值博率</span></p>
          </div>
        </div>
      </div>

      <!-- Logo_Group5 (Group) -->
      <div id="u131" class="ax_default" data-label="Logo_Group5" data-left="375" data-top="1675" data-width="651" data-height="224">

        <!-- g_logo (Image) -->
        <div id="u132" class="ax_default image" data-label="g_logo">
          <img id="u132_img" class="img " src="<?php echo e(asset($b3s->g_img)); ?>"/>
          <div id="u132_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- h_logo (Image) -->
        <div id="u133" class="ax_default image" data-label="h_logo">
          <img id="u133_img" class="img " src="<?php echo e(asset($b3s->h_img)); ?>"/>
          <div id="u133_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Team_Away (Rectangle) -->
        <div id="u134" class="ax_default box_2" data-label="Team_Away">
          <div id="u134_div" class=""></div>
          <div id="u134_text" class="text ">
            <p><span><?php echo e($b3s->guest); ?></span></p>
          </div>
        </div>

        <!-- Team_Home (Rectangle) -->
        <div id="u135" class="ax_default box_2" data-label="Team_Home">
          <div id="u135_div" class=""></div>
          <div id="u135_text" class="text ">
            <p><span><?php echo e($b3s->host); ?></span></p>
          </div>
        </div>

        <!-- Date_Time (Rectangle) -->
        <div id="u136" class="ax_default box_2" data-label="Date_Time">
          <div id="u136_div" class=""></div>
          <div id="u136_text" class="text ">
            <p><span><?php echo e(Carbon\Carbon::parse($b3s->date)->diffForHumans()); ?>開波</span></p>
          </div>
        </div>

        <!-- Match (Rectangle) -->
        <div id="u137" class="ax_default box_2" data-label="Match">
          <div id="u137_div" class=""></div>
          <div id="u137_text" class="text ">
            <p><span><?php echo e($b3s->league); ?></span></p>
          </div>
        </div>

        <!-- h_gp (Rectangle) -->
        <div id="u138" class="ax_default paragraph" data-label="h_gp">
          <div id="u138_div" class=""></div>
          <div id="u138_text" class="text ">
            <p><span><?php echo e($b3s->h_gp); ?></span></p>
          </div>
        </div>

        <!-- h_fix (Rectangle) -->
        <div id="u139" class="ax_default paragraph" data-label="h_fix">
          <div id="u139_div" class=""></div>
          <div id="u139_text" class="text ">
            <p><span>主勝值博率</span></p>
          </div>
        </div>

        <!-- d_gp (Rectangle) -->
        <div id="u140" class="ax_default paragraph" data-label="d_gp">
          <div id="u140_div" class=""></div>
          <div id="u140_text" class="text ">
            <p><span><?php echo e($b3s->d_gp); ?></span></p>
          </div>
        </div>

        <!-- d_fix (Rectangle) -->
        <div id="u141" class="ax_default paragraph" data-label="d_fix">
          <div id="u141_div" class=""></div>
          <div id="u141_text" class="text ">
            <p><span>和波值博率</span></p>
          </div>
        </div>

        <!-- g_gp (Rectangle) -->
        <div id="u142" class="ax_default paragraph" data-label="g_gp">
          <div id="u142_div" class=""></div>
          <div id="u142_text" class="text ">
            <p><span><?php echo e($b3s->g_gp); ?></span></p>
          </div>
        </div>

        <!-- g_fix (Rectangle) -->
        <div id="u143" class="ax_default paragraph" data-label="g_fix">
          <div id="u143_div" class=""></div>
          <div id="u143_text" class="text ">
            <p><span>容勝值博率</span></p>
          </div>
        </div>
        
      </div>
      <?php endif; ?>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
    
    <div id="heat" class="heat"></div>

    <div class="pagination">
  <a onclick="window.location='/footballui/public/page_a3';">&laquo;</a>
  <a class="active" onclick="window.location='/footballui/public/page_a3';">1</a>
  <a onclick="window.location='/footballui/public/page_a32b';">2</a>
  <a onclick="window.location='/footballui/public/page_a33c';">3</a>
  <a onclick="window.location='/footballui/public/page_a34d';">4</a>
  <a onclick="window.location='/footballui/public/page_a35e';">5</a>
  <a  onclick="window.location='/footballui/public/page_a36f';">6</a>
  <a onclick="window.location='/footballui/public/page_a36g';">&raquo;</a>
</div>

<div class="space">
  <p> <span></span> </p>
</div>

  </body>
</html>
<?php /**PATH C:\xampp\htdocs\football\resources\views/frontend/page_a3.blade.php ENDPATH**/ ?>