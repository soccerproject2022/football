
<?php $__env->startSection('edita2'); ?>
<div class="col-lg-12">
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong><?php echo e(session('success')); ?></strong>
<button type="button" class="class" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>
            <div class="card-header card-header-border-bottom">
                <h2>Edit a5 data</h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('a5/update/'.$a5s->id)); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >id</label>
                                <input type="hidden" name="id" class="form-control" >
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="host" disabled value="<?php echo e($a5s->host); ?>">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="guest" disabled value="<?php echo e($a5s->guest); ?>">
                            </div>
                        </div>

                        
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊最小範圍</label>
                                <input type="number" name="h_min" class="form-control" placeholder="主隊最小範圍" value="<?php echo e($a5s->h_min); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊最小範圍</label>
                                <input type="number" name="g_min" class="form-control" placeholder="主隊最小範圍" value="<?php echo e($a5s->g_min); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >總最小範圍</label>
                                <input type="number" name="total_min" class="form-control" placeholder="總最小範圍" value="<?php echo e($a5s->total_min); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊最大範圍</label>
                                <input type="number" name="h_max" class="form-control" placeholder="主隊最大範圍" value="<?php echo e($a5s->h_max); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊最大範圍</label>
                                <input type="number" name="g_max" class="form-control" placeholder="主隊最大範圍" value="<?php echo e($a5s->g_max); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >總最大範圍</label>
                                <input type="number" name="total_max" class="form-control" placeholder="總最大範圍" value="<?php echo e($a5s->total_max); ?>" step=any>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >次序</label>
                                <input type="number" name="order" class="form-control" placeholder="次序" value="<?php echo e($a5s->order); ?>" step=any>
                            </div>
                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\football\resources\views/admin/a5/edit.blade.php ENDPATH**/ ?>