<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\football\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>