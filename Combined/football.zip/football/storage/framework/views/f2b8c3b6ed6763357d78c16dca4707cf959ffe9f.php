
<?php $__env->startSection('edita2'); ?>
<div class="col-lg-12">
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong><?php echo e(session('success')); ?></strong>
<button type="button" class="class" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>
            <div class="card-header card-header-border-bottom">
                <h2>Edit a7 data</h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('a7/update/'.$a7s->id)); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >id</label>
                                <input type="hidden" name="id" class="form-control" >
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >主隊</label>
                                <input type="text" name="host" class="form-control" placeholder="host" disabled value="<?php echo e($a7s->host); ?>">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label >客隊</label>
                                <input type="text" name="guest" class="form-control" placeholder="guest" disabled value="<?php echo e($a7s->guest); ?>">
                            </div>
                        </div>
                        
                        <div class="col-sm-2">
                            <div class="form-group">
                            <label for="exampleFormControlSelect4">預測結果</label>
                                <select class="form-control" id="exampleFormControlSelect4" name="ai_opt">
                                    <option disabled selected="">-- ai_opt --</option>
                                    <?php $__currentLoopData = $a7opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($opt->opt); ?>" <?php echo e((isset($opt->opt)|| old('opt'))? "selected":""); ?>>
                                        <?php echo e($opt->opt); ?>   </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\football\resources\views/admin/a7/edit.blade.php ENDPATH**/ ?>