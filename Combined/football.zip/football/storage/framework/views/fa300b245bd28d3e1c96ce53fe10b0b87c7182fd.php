
<?php $__env->startSection('admin'); ?>


<div class="col-lg-12">

<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
    <button type="button" class="class" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

    
        <div class="card-header card-header-border-bottom">
            <h2>a6 database table</h2>
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">主隊</th>
                        <th scope="col">客隊</th>
                        <th scope="col">預測結果</th>
                        
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $a6s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a6datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($a6datum->game_id); ?></td>
                        <td><?php echo e($a6datum->host); ?></td>
                        <td><?php echo e($a6datum->guest); ?></td>
                        <td><?php echo e($a6datum->guess_opt); ?></td>


                        <td><a href="<?php echo e(url('a6/edit/'.$a6datum->game_id)); ?>" class="btn btn-info">Edit</a></td>
                        <td><a href="<?php echo e(url('a6/delete/'.$a6datum->game_id)); ?>" onclick="return confirm('Are you sure to delete?')" class="btn btn-danger">Delete</a></td>
                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
           
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card card-default">
            <div class="card-header card-header-border-bottom">
                <h2></h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('create.a6')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="exampleFormControlSelect2">選擇 game_id</label>
                                <select class="form-control" id="exampleFormControlSelect2" name="game_id">
                                    <option disabled selected="">-- 選擇 game_id --</option>
                                    <?php $__currentLoopData = $a6gameid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gameid->game_id); ?>" <?php echo e((isset($gameid->game_id)|| old('id'))? "selected":""); ?>><?php echo e($gameid->host); ?>| vs | <?php echo e($gameid->guest); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                            <label for="exampleFormControlSelect3">選擇預測結果</label>
                                <select class="form-control" id="exampleFormControlSelect3" name="guess_opt">
                                    <option disabled selected="">-- 選擇 guess_opt --</option>
                                    <?php $__currentLoopData = $a6opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($opt->opt); ?>" <?php echo e((isset($opt->opt)|| old('opt'))? "selected":""); ?>>
                                        <?php echo e($opt->opt); ?>   </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                        
                        </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Create</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\football\resources\views/admin/a6/index.blade.php ENDPATH**/ ?>