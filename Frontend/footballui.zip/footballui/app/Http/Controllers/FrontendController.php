<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\b1;
use App\Models\b2;
use App\Models\b3;
use App\Models\b5;
use App\Models\b7;
use App\Models\b8;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class FrontendController extends Controller
{

    public function ShowFirst(){
        $day1= date('d');
        $b1s = DB::table('b1')->whereDay('date', '=', date($day1))->skip(1)->first();
        $b1ss = DB::table('b1')->get();
        return view ('frontend/first_page', compact('b1s','b1ss'));

    }    

    public function ShowA1(){
        $day= Carbon::today()->day;
        $b1s = DB::table('b1')->whereDay('date', $day)->orderBy('date','asc')->get();
        return view ('frontend/page_a1', compact('b1s'));
    }   

    public function ShowA1d2(){
        $day= Carbon::tomorrow()->day;
        $b1s = DB::table('b1')->whereDay('date', $day)->orderBy('date','asc')->get();
        return view ('frontend/page_a1d2', compact('b1s'));
    }

    public function ShowA1d3(){
        $day= Carbon::today()->addDays(2)->day;
        $b1s = DB::table('b1')->whereDay('date', $day)->orderBy('date','asc')->get();
        return view ('frontend/page_a1d3', compact('b1s'));
    }   

    public function ShowA2(){
        $day= Carbon::today()->day; 
        $b2s = DB::table('b1')->whereDay('date', $day)
        ->join('b2', 'b2.game_id', 'b1.game_id')
        ->select('b1.*', 'b2.*')
        ->orderBy('date','asc')
        ->get();
        return view ('frontend/page_a2', compact('b2s'));
    
    }    

    public function ShowA2d2(){
        $day= Carbon::tomorrow()->day;
        $b2s = DB::table('b1')->whereDay('date', $day)
        ->join('b2', 'b2.game_id', 'b1.game_id')
        ->select('b1.*', 'b2.*')
        ->orderBy('date','asc')
        ->get();
        return view ('frontend/page_a2d2', compact('b2s'));
    
    }  

    public function ShowA2d3(){
        $day= Carbon::today()->addDays(2)->day;
        $b2s = DB::table('b1')->whereDay('date', $day)
        ->join('b2', 'b2.game_id', 'b1.game_id')
        ->select('b1.*', 'b2.*')
        ->orderBy('date','asc')
        ->get();
        return view ('frontend/page_a2d3', compact('b2s'));
    
    }  

    public function ShowA3(){
        $b3s = DB::table('b3')->where('game_id', 1)->first();
        return view ('frontend/page_a3', compact('b3s'));

    }    

    public function ShowA4(){
        $day= Carbon::today()->day;
        $b4s = DB::table('b1')->whereDay('date', $day)->orderBy('date','asc')->get();
        return view ('frontend/page_a4', compact('b4s'));
    }    

    public function ShowA4d2(){
        $day= Carbon::tomorrow()->day;
        $b4s = DB::table('b1')->whereDay('date', $day)->orderBy('date','asc')->get();
        return view ('frontend/page_a4d2', compact('b4s'));
    }


    public function ShowA4d3(){
        $day= Carbon::today()->addDays(2)->day;
        $b4s = DB::table('b1')->whereDay('date', $day)->orderBy('date','asc')->get();
        return view ('frontend/page_a4d3', compact('b4s'));
    }  

    public function ShowA5(){
        
        $b5s = DB::table('b1')->where('id', 1)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b52s = DB::table('b1')->where('id', 2)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b53s = DB::table('b1')->where('id', 3)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b54s = DB::table('b1')->where('id', 4)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b55s = DB::table('b1')->where('id', 5)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b56s = DB::table('b1')->where('id', 6)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b57s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b58s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b59s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b5as = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b511s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b512s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b513s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b514s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b515s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b516s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b517s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b518s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b519s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        $b520s = DB::table('b1')->where('id', 7)
        ->join('b5', 'b1.game_id', 'b5.game_id')
        ->select('b1.*', 'b5.*')
        ->first();
        return view ('frontend/page_a5', compact('b5s','b52s','b53s','b54s','b55s','b56s','b57s','b58s','b59s','b5as','b511s','b512s','b513s','b514s','b515s','b516s','b517s','b518s','b519s','b520s'));

    }    

    public function ShowA6(){
        $b6s = DB::table('b6')->where('game_id', 1)->first();
        return view ('frontend/page_a6', compact('b6s'));

    }    

    public function ShowA7(){
        $b7s = DB::table('b1')->where('id', 1)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b72s = DB::table('b1')->where('id', 2)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b73s = DB::table('b1')->where('id', 3)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b74s = DB::table('b1')->where('id', 4)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b75s = DB::table('b1')->where('id', 5)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b76s = DB::table('b1')->where('id', 6)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b77s = DB::table('b1')->where('id', 7)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b78s = DB::table('b1')->where('id', 8)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b79s = DB::table('b1')->where('id', 9)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        $b7as = DB::table('b1')->where('id', 10)
        ->join('b7', 'b1.game_id', 'b7.game_id')
        ->select('b1.h_img', 'b1.league', 'b1.host', 'b7.opt')
        ->first();
        return view ('frontend/page_a7', compact('b7s','b72s','b73s','b74s','b75s','b76s','b77s','b78s','b79s','b7as'));

    }

    public function ShowA8(){
        $b8s = DB::table('b8')->where('game_id', 1)->first();
        $b1s = DB::table('b1')->where('jc_id', 0)->first();
        return view ('frontend/page_a8', compact('b1s','b8s'));

    }
    
}
