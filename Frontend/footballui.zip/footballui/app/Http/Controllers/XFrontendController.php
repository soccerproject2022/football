<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\a1;
use App\Models\a2;
use App\Models\a5;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class FrontendController extends Controller
{
    /*public function Logout(){
        Auth::logout();
        return Redirect()->route('login')->with('success', 'User Logout');
    }*/

    public function ShowA5(){
        $a5gameid = DB::table('a1')->paginate(5);
        
        $a5s = DB::table('a1')
        ->join('a5s', 'a1.game_id', 'a5s.id')
        ->select('a1.*', 'a5s.id', 'a5s.h_corner', 'a5s.g_corner', 'a5s.total_corner', 'a5s.h_min', 'a5s.g_min', 'a5s.total_min', 'a5s.h_max', 'a5s.g_max', 'a5s.total_max')
        ->paginate(5);


    return view('frontend/a5', compact('a5s', 'a5gameid'));

    

    }

    

    
    
}
