<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class b8 extends Model
{
    use HasFactory;

    protected $fillable = [
        'id',
        'game_id',
        'opt',
        'best_team',
        'point',
        'T2015',
        'T2016',
        'T2017',
        'T2018',
        'T2019',
        'T2020',
        'T2021',
        'p2015',
        'p2016',
        'p2017',
        'p2018',
        'p2019',
        'p2020',
        'p2021',

    ];
}
