﻿<!DOCTYPE html>
<html>
  <head>
    <title>First_Page</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/first_page/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/first_page/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u1227" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u1228" class="ax_default placeholder">
          <img id="u1228_img" class="img " src="images/page_a2/u205.svg"/>
          <div id="u1228_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1229" class="ax_default box_1">
          <div id="u1229_div" class=""></div>
          <div id="u1229_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1230" class="ax_default box_3">
          <div id="u1230_div" class=""></div>
          <div id="u1230_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1231" class="ax_default box_3">
          <div id="u1231_div" class=""></div>
          <div id="u1231_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1232" class="ax_default box_3">
          <div id="u1232_div" class=""></div>
          <div id="u1232_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1233" class="ax_default box_3">
          <div id="u1233_div" class=""></div>
          <div id="u1233_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1234" class="ax_default box_3">
          <div id="u1234_div" class=""></div>
          <div id="u1234_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1235" class="ax_default box_3">
          <div id="u1235_div" class=""></div>
          <div id="u1235_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1236" class="ax_default box_3">
          <div id="u1236_div" class=""></div>
          <div id="u1236_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1237" class="ax_default">
          <div id="u1237_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1237_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u1238" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u1239" class="ax_default box_3">
                  <div id="u1239_div" class=""></div>
                  <div id="u1239_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1240" class="ax_default box_3">
                  <div id="u1240_div" class=""></div>
                  <div id="u1240_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1241" class="ax_default box_3">
                  <div id="u1241_div" class=""></div>
                  <div id="u1241_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1242" class="ax_default box_3">
                  <img id="u1242_img" class="img " src="images/page_a2/u219.svg"/>
                  <div id="u1242_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1243" class="ax_default box_3">
                  <div id="u1243_div" class=""></div>
                  <div id="u1243_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1244" class="ax_default box_3">
                  <div id="u1244_div" class=""></div>
                  <div id="u1244_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1245" class="ax_default box_3">
                  <div id="u1245_div" class=""></div>
                  <div id="u1245_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1246" class="ax_default">
          <div id="u1246_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1246_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u1247" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u1248" class="ax_default box_3">
                  <div id="u1248_div" class=""></div>
                  <div id="u1248_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1249" class="ax_default box_3">
                  <div id="u1249_div" class=""></div>
                  <div id="u1249_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1250" class="ax_default box_3">
                  <div id="u1250_div" class=""></div>
                  <div id="u1250_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1251" class="ax_default box_3">
                  <img id="u1251_img" class="img " src="images/page_a2/u228.svg"/>
                  <div id="u1251_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1252" class="ax_default box_3">
                  <div id="u1252_div" class=""></div>
                  <div id="u1252_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1253" class="ax_default box_3">
                  <div id="u1253_div" class=""></div>
                  <div id="u1253_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1254" class="ax_default">
          <div id="u1254_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1254_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u1255" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u1256" class="ax_default box_3">
                  <div id="u1256_div" class=""></div>
                  <div id="u1256_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1257" class="ax_default box_3">
                  <div id="u1257_div" class=""></div>
                  <div id="u1257_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1258" class="ax_default box_3">
                  <div id="u1258_div" class=""></div>
                  <div id="u1258_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1259" class="ax_default box_3">
                  <img id="u1259_img" class="img " src="images/page_a2/u236.svg"/>
                  <div id="u1259_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u1226" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u1261" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1262" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u1262_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1262_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u1263" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u1264" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u1264_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u1264_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u1265" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1266" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1266_div" class=""></div>
                          <div id="u1266_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1267" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1267_div" class=""></div>
                          <div id="u1267_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1268" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1268_div" class=""></div>
                          <div id="u1268_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1269" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u1269_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u1269_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1270" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1270_div" class=""></div>
                          <div id="u1270_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1271" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1271_div" class=""></div>
                          <div id="u1271_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1272" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1272_div" class=""></div>
                          <div id="u1272_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1273" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u1273_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u1273_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u1274" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u1275" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u1275_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u1275_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u1276" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1277" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1277_div" class=""></div>
                          <div id="u1277_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1278" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u1278_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u1278_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1279" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1279_div" class=""></div>
                          <div id="u1279_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1280" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u1280_img" class="img " src="resources/images/transparent.gif"/>
                          <div id="u1280_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1281" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1281_div" class=""></div>
                          <div id="u1281_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1282" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1282_div" class=""></div>
                          <div id="u1282_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1283" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u1283_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u1283_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u1284" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u1285" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u1285_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u1285_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u1286" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1287" class="ax_default box_3">
                          <div id="u1287_div" class=""></div>
                          <div id="u1287_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1288" class="ax_default box_3">
                          <img id="u1288_img" class="img " src="images/page_a2/u265.svg"/>
                          <div id="u1288_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1289" class="ax_default box_3">
                          <div id="u1289_div" class=""></div>
                          <div id="u1289_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1290" class="ax_default box_3">
                          <img id="u1290_img" class="img " src="images/page_a2/u267.svg"/>
                          <div id="u1290_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1291" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u1291_img" class="img " src="resources/images/transparent.gif"/>
                  <div id="u1291_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1292" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1292_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1292_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1293" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1293_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1293_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1294" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1294_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1294_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1295" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1295_img" class="img " src="resources/images/transparent.gif"/>
                <div id="u1295_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u1296" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u1296_img" class="img " src="resources/images/transparent.gif"/>
          <div id="u1296_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1297" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u1297_div" class=""></div>
          <div id="u1297_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1298" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u1298_div" class=""></div>
          <div id="u1298_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u1260" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
