﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A4</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a4/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a4/styles_1.css" type="text/css" rel="stylesheet"/>

    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a4/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">
    @if(isset($b1s,$b12s,$b13s,$b14s,$b15s));
      <!-- G5 (Group) -->
      <div id="u551" class="ax_default" data-label="G5" data-left="68" data-top="1322" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u552" class="ax_default" data-label="Rate_Group" data-left="68" data-top="1522" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u553" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u553_state0" class="panel_state" data-label="State 1" style="">
              <div id="u553_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u554" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u555" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u555_div" class="selected"></div>
                    <div id="u555_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u556" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u557" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u558" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u558_div" class="selected"></div>
                        <div id="u558_text" class="text ">
                          <p><span>{{ $b15s->g_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u559" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u559_div" class="selected"></div>
                        <div id="u559_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u560" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u560_div" class="selected"></div>
                        <div id="u560_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u561" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u561_div" class="selected"></div>
                        <div id="u561_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u562" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u563" class="ax_default" data-label="TACS_Repeater">
                        <script id="u563_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564" class="ax_default paragraph u564" data-label="bold_3a">
                            <div id="u564_div" class="u564_div"></div>
                            <div id="u564_text" class="text u564_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565" class="ax_default paragraph u565" data-label="bold_2a">
                            <div id="u565_div" class="u565_div"></div>
                            <div id="u565_text" class="text u565_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566" class="ax_default paragraph u566" data-label="bold_1a">
                            <div id="u566_div" class="u566_div"></div>
                            <div id="u566_text" class="text u566_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567" class="ax_default paragraph u567" data-label="bold_0a">
                            <div id="u567_div" class="u567_div"></div>
                            <div id="u567_text" class="text u567_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u563-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-1" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-1_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-1_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-1" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-1_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-1_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-1" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-1_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-1_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-1" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-1_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-1_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-2" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-2_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-2_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-2" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-2_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-2_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-2" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-2_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-2_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-2" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-2_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-2_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-3" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-3_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-3_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-3" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-3_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-3_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-3" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-3_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-3_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-3" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-3_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-3_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-4" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-4_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-4_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-4" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-4_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-4_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-4" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-4_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-4_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-4" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-4_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-4_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-5" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-5_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-5_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-5" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-5_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-5_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-5" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-5_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-5_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-5" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-5_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-5_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-6" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-6_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-6_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-6" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-6_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-6_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-6" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-6_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-6_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-6" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-6_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-6_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-7" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-7_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-7_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-7" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-7_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-7_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-7" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-7_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-7_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-7" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-7_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-7_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-8" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-8_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-8_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-8" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-8_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-8_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-8" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-8_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-8_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-8" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-8_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-8_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-9" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-9_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-9_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-9" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-9_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-9_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-9" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-9_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-9_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-9" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-9_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-9_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-10" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-10_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-10_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-10" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-10_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-10_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-10" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-10_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-10_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-10" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-10_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-10_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-11" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-11_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-11_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-11" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-11_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-11_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-11" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-11_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-11_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-11" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-11_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-11_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-12" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-12_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-12_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-12" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-12_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-12_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-12" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-12_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-12_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-12" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-12_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-12_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u563-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u564-13" class="ax_default paragraph u564" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u564-13_div" class="u564_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u564-13_text" class="text u564_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u565-13" class="ax_default paragraph u565" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u565-13_div" class="u565_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u565-13_text" class="text u565_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u566-13" class="ax_default paragraph u566" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u566-13_div" class="u566_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u566-13_text" class="text u566_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u567-13" class="ax_default paragraph u567" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u567-13_div" class="u567_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u567-13_text" class="text u567_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u568" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u569" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u570" class="ax_default paragraph selected" data-label="Others">
                          <div id="u570_div" class="selected"></div>
                          <div id="u570_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u571" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u571_div" class="selected"></div>
                          <div id="u571_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u572" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u572_div" class="selected"></div>
                          <div id="u572_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u573" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u573_div" class="selected"></div>
                          <div id="u573_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u574" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u574_div" class="selected"></div>
                          <div id="u574_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u575" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u575_div" class="selected"></div>
                          <div id="u575_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u576" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u576_div" class="selected"></div>
                          <div id="u576_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u577" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u577_div" class="selected"></div>
                          <div id="u577_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u578" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u578_div" class="selected"></div>
                          <div id="u578_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u579" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u579_div" class="selected"></div>
                          <div id="u579_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u580" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u580_div" class="selected"></div>
                          <div id="u580_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u581" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u581_div" class="selected"></div>
                          <div id="u581_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u582" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u582_div" class="selected"></div>
                          <div id="u582_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u583" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u583_div" class="selected"></div>
                        <div id="u583_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u584" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u584_div" class="selected"></div>
                        <div id="u584_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u585" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u585_div" class="selected"></div>
                        <div id="u585_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u586" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u586_div" class="selected"></div>
                        <div id="u586_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u587" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u587_div" class="selected"></div>
                        <div id="u587_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u588" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u588_div" class="selected"></div>
                        <div id="u588_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u589" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u590" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u591" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u591_div" class="selected"></div>
                        <div id="u591_text" class="text ">
                          <p><span>{{ $b15s->draw}}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u592" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u592_div" class="selected"></div>
                        <div id="u592_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u593" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u593_div" class="selected"></div>
                        <div id="u593_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u594" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u594_div" class="selected"></div>
                        <div id="u594_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u595" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u596" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u596_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u597" class="ax_default paragraph u597" data-label="bold_3a">
                            <div id="u597_div" class="u597_div"></div>
                            <div id="u597_text" class="text u597_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u598" class="ax_default paragraph u598" data-label="bold_2a">
                            <div id="u598_div" class="u598_div"></div>
                            <div id="u598_text" class="text u598_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u599" class="ax_default paragraph u599" data-label="bold_1a">
                            <div id="u599_div" class="u599_div"></div>
                            <div id="u599_text" class="text u599_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u600" class="ax_default paragraph u600" data-label="bold_0a">
                            <div id="u600_div" class="u600_div"></div>
                            <div id="u600_text" class="text u600_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u596-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u597-1" class="ax_default paragraph u597" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u597-1_div" class="u597_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u597-1_text" class="text u597_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u598-1" class="ax_default paragraph u598" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u598-1_div" class="u598_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u598-1_text" class="text u598_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u599-1" class="ax_default paragraph u599" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u599-1_div" class="u599_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u599-1_text" class="text u599_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u600-1" class="ax_default paragraph u600" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u600-1_div" class="u600_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u600-1_text" class="text u600_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u596-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u597-2" class="ax_default paragraph u597" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u597-2_div" class="u597_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u597-2_text" class="text u597_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u598-2" class="ax_default paragraph u598" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u598-2_div" class="u598_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u598-2_text" class="text u598_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u599-2" class="ax_default paragraph u599" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u599-2_div" class="u599_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u599-2_text" class="text u599_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u600-2" class="ax_default paragraph u600" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u600-2_div" class="u600_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u600-2_text" class="text u600_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u596-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u597-3" class="ax_default paragraph u597" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u597-3_div" class="u597_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u597-3_text" class="text u597_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u598-3" class="ax_default paragraph u598" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u598-3_div" class="u598_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u598-3_text" class="text u598_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u599-3" class="ax_default paragraph u599" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u599-3_div" class="u599_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u599-3_text" class="text u599_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u600-3" class="ax_default paragraph u600" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u600-3_div" class="u600_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u600-3_text" class="text u600_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u596-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u597-4" class="ax_default paragraph u597" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u597-4_div" class="u597_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u597-4_text" class="text u597_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u598-4" class="ax_default paragraph u598" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u598-4_div" class="u598_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u598-4_text" class="text u598_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u599-4" class="ax_default paragraph u599" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u599-4_div" class="u599_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u599-4_text" class="text u599_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u600-4" class="ax_default paragraph u600" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u600-4_div" class="u600_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u600-4_text" class="text u600_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u596-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u597-5" class="ax_default paragraph u597" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u597-5_div" class="u597_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u597-5_text" class="text u597_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u598-5" class="ax_default paragraph u598" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u598-5_div" class="u598_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u598-5_text" class="text u598_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u599-5" class="ax_default paragraph u599" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u599-5_div" class="u599_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u599-5_text" class="text u599_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u600-5" class="ax_default paragraph u600" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u600-5_div" class="u600_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u600-5_text" class="text u600_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u601" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u602" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u603" class="ax_default paragraph selected" data-label="Others">
                          <div id="u603_div" class="selected"></div>
                          <div id="u603_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u604" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u604_div" class="selected"></div>
                          <div id="u604_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u605" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u605_div" class="selected"></div>
                          <div id="u605_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u606" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u606_div" class="selected"></div>
                          <div id="u606_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u607" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u607_div" class="selected"></div>
                          <div id="u607_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u608" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u608_div" class="selected"></div>
                        <div id="u608_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u609" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u609_div" class="selected"></div>
                        <div id="u609_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u610" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u610_div" class="selected"></div>
                        <div id="u610_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u611" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u611_div" class="selected"></div>
                        <div id="u611_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u612" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u612_div" class="selected"></div>
                        <div id="u612_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u613" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u613_div" class="selected"></div>
                        <div id="u613_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u614" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u615" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u616" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u616_div" class="selected"></div>
                        <div id="u616_text" class="text ">
                          <p><span>{{ $b15s->h_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u617" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u617_div" class="selected"></div>
                        <div id="u617_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u618" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u618_div" class="selected"></div>
                        <div id="u618_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u619" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u619_div" class="selected"></div>
                        <div id="u619_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u620" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u621" class="ax_default" data-label="THCS_Repeater">
                        <script id="u621_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622" class="ax_default paragraph u622" data-label="bold_3a">
                            <div id="u622_div" class="u622_div"></div>
                            <div id="u622_text" class="text u622_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623" class="ax_default paragraph u623" data-label="bold_2a">
                            <div id="u623_div" class="u623_div"></div>
                            <div id="u623_text" class="text u623_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624" class="ax_default paragraph u624" data-label="bold_1a">
                            <div id="u624_div" class="u624_div"></div>
                            <div id="u624_text" class="text u624_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625" class="ax_default paragraph u625" data-label="bold_0a">
                            <div id="u625_div" class="u625_div"></div>
                            <div id="u625_text" class="text u625_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u621-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-1" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-1_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-1_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-1" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-1_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-1_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-1" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-1_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-1_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-1" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-1_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-1_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-2" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-2_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-2_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-2" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-2_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-2_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-2" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-2_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-2_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-2" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-2_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-2_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-3" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-3_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-3_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-3" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-3_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-3_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-3" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-3_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-3_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-3" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-3_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-3_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-4" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-4_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-4_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-4" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-4_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-4_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-4" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-4_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-4_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-4" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-4_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-4_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-5" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-5_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-5_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-5" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-5_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-5_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-5" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-5_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-5_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-5" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-5_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-5_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-6" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-6_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-6_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-6" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-6_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-6_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-6" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-6_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-6_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-6" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-6_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-6_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-7" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-7_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-7_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-7" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-7_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-7_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-7" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-7_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-7_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-7" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-7_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-7_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-8" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-8_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-8_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-8" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-8_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-8_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-8" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-8_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-8_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-8" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-8_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-8_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-9" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-9_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-9_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-9" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-9_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-9_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-9" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-9_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-9_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-9" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-9_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-9_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-10" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-10_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-10_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-10" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-10_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-10_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-10" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-10_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-10_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-10" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-10_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-10_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-11" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-11_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-11_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-11" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-11_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-11_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-11" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-11_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-11_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-11" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-11_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-11_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-12" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-12_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-12_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-12" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-12_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-12_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-12" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-12_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-12_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-12" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-12_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-12_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u621-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u622-13" class="ax_default paragraph u622" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u622-13_div" class="u622_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u622-13_text" class="text u622_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u623-13" class="ax_default paragraph u623" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u623-13_div" class="u623_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u623-13_text" class="text u623_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u624-13" class="ax_default paragraph u624" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u624-13_div" class="u624_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u624-13_text" class="text u624_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u625-13" class="ax_default paragraph u625" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u625-13_div" class="u625_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u625-13_text" class="text u625_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u626" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u627" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u628" class="ax_default paragraph selected" data-label="Others">
                          <div id="u628_div" class="selected"></div>
                          <div id="u628_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u629" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u629_div" class="selected"></div>
                          <div id="u629_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u630" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u630_div" class="selected"></div>
                          <div id="u630_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u631" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u631_div" class="selected"></div>
                          <div id="u631_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u632" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u632_div" class="selected"></div>
                          <div id="u632_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u633" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u633_div" class="selected"></div>
                          <div id="u633_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u634" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u634_div" class="selected"></div>
                          <div id="u634_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u635" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u635_div" class="selected"></div>
                          <div id="u635_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u636" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u636_div" class="selected"></div>
                          <div id="u636_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u637" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u637_div" class="selected"></div>
                          <div id="u637_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u638" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u638_div" class="selected"></div>
                          <div id="u638_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u639" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u639_div" class="selected"></div>
                          <div id="u639_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u640" class="ax_default paragraph selected">
                          <div id="u640_div" class="selected"></div>
                          <div id="u640_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u641" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u641_div" class="selected"></div>
                        <div id="u641_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u642" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u642_div" class="selected"></div>
                        <div id="u642_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u643" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u643_div" class="selected"></div>
                        <div id="u643_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u644" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u644_div" class="selected"></div>
                        <div id="u644_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u645" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u645_div" class="selected"></div>
                        <div id="u645_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u646" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u646_div" class="selected"></div>
                        <div id="u646_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u647" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u647_div" class="selected"></div>
                    <div id="u647_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u648" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u648_div" class="selected"></div>
                    <div id="u648_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u649" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u649_div" class="selected"></div>
            <div id="u649_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u650" class="ax_default" data-label="TAW" data-left="783" data-top="1522" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u651" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u651_div" class="selected"></div>
              <div id="u651_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u652" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u652_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u652_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u653" class="ax_default" data-label="THW" data-left="68" data-top="1522" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u654" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u654_div" class="selected"></div>
              <div id="u654_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u655" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u655_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u655_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u656" class="ax_default" data-label="DRAW" data-left="425" data-top="1522" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u657" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u657_div" class="selected"></div>
              <div id="u657_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u658" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u658_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u658.svg"/>
              <div id="u658_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u659" class="ax_default box_3 selected">
            <img id="u659_img" class="img " src="/footballui/public/frontend/images/page_a4/u659_selected.svg"/>
            <div id="u659_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u660" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1322" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u661" class="ax_default image" data-label="TA_G">
            <img id="u661_img" class="img " src="{{ asset($b15s->g_img) }}"/>
            <div id="u661_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u662" class="ax_default image" data-label="TH_G">
            <img id="u662_img" class="img " src="{{ asset($b15s->h_img) }}"/>
            <div id="u662_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u663" class="ax_default box_2" data-label="Team_Away">
            <div id="u663_div" class=""></div>
            <div id="u663_text" class="text ">
              <p><span>{{ $b15s->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u664" class="ax_default box_2" data-label="Team_Home">
            <div id="u664_div" class=""></div>
            <div id="u664_text" class="text ">
              <p><span>{{ $b15s->host }}</span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u665" class="ax_default box_2" data-label="Status">
            <div id="u665_div" class=""></div>
            <div id="u665_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u666" class="ax_default box_2" data-label="Number">
            <div id="u666_div" class=""></div>
            <div id="u666_text" class="text ">
              <p><span>{{ $b15s->jc_id }}</span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u667" class="ax_default box_2" data-label="HKJC">
            <div id="u667_div" class=""></div>
            <div id="u667_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u668" class="ax_default box_2" data-label="Date_Time">
            <div id="u668_div" class=""></div>
            <div id="u668_text" class="text ">
              <p><span>{{ $b15s->date }}</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u669" class="ax_default box_2" data-label="Match">
            <div id="u669_div" class=""></div>
            <div id="u669_text" class="text ">
              <p><span>{{ $b15s->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G4 (Group) -->
      <div id="u670" class="ax_default" data-label="G4" data-left="68" data-top="1024" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u671" class="ax_default" data-label="Rate_Group" data-left="68" data-top="1224" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u672" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u672_state0" class="panel_state" data-label="State 1" style="">
              <div id="u672_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u673" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u674" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u674_div" class="selected"></div>
                    <div id="u674_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u675" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u676" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u677" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u677_div" class="selected"></div>
                        <div id="u677_text" class="text ">
                          <p><span>{{ $b14s->g_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u678" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u678_div" class="selected"></div>
                        <div id="u678_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u679" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u679_div" class="selected"></div>
                        <div id="u679_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u680" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u680_div" class="selected"></div>
                        <div id="u680_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u681" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u682" class="ax_default" data-label="TACS_Repeater">
                        <script id="u682_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683" class="ax_default paragraph u683" data-label="bold_3a">
                            <div id="u683_div" class="u683_div"></div>
                            <div id="u683_text" class="text u683_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684" class="ax_default paragraph u684" data-label="bold_2a">
                            <div id="u684_div" class="u684_div"></div>
                            <div id="u684_text" class="text u684_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685" class="ax_default paragraph u685" data-label="bold_1a">
                            <div id="u685_div" class="u685_div"></div>
                            <div id="u685_text" class="text u685_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686" class="ax_default paragraph u686" data-label="bold_0a">
                            <div id="u686_div" class="u686_div"></div>
                            <div id="u686_text" class="text u686_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u682-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-1" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-1_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-1_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-1" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-1_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-1_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-1" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-1_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-1_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-1" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-1_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-1_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-2" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-2_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-2_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-2" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-2_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-2_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-2" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-2_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-2_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-2" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-2_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-2_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-3" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-3_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-3_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-3" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-3_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-3_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-3" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-3_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-3_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-3" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-3_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-3_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-4" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-4_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-4_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-4" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-4_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-4_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-4" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-4_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-4_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-4" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-4_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-4_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-5" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-5_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-5_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-5" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-5_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-5_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-5" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-5_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-5_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-5" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-5_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-5_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-6" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-6_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-6_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-6" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-6_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-6_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-6" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-6_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-6_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-6" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-6_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-6_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-7" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-7_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-7_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-7" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-7_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-7_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-7" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-7_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-7_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-7" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-7_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-7_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-8" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-8_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-8_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-8" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-8_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-8_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-8" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-8_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-8_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-8" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-8_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-8_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-9" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-9_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-9_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-9" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-9_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-9_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-9" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-9_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-9_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-9" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-9_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-9_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-10" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-10_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-10_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-10" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-10_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-10_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-10" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-10_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-10_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-10" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-10_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-10_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-11" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-11_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-11_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-11" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-11_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-11_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-11" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-11_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-11_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-11" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-11_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-11_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-12" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-12_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-12_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-12" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-12_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-12_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-12" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-12_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-12_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-12" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-12_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-12_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u682-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u683-13" class="ax_default paragraph u683" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u683-13_div" class="u683_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u683-13_text" class="text u683_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u684-13" class="ax_default paragraph u684" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u684-13_div" class="u684_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u684-13_text" class="text u684_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u685-13" class="ax_default paragraph u685" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u685-13_div" class="u685_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u685-13_text" class="text u685_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u686-13" class="ax_default paragraph u686" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u686-13_div" class="u686_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u686-13_text" class="text u686_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u687" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u688" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u689" class="ax_default paragraph selected" data-label="Others">
                          <div id="u689_div" class="selected"></div>
                          <div id="u689_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u690" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u690_div" class="selected"></div>
                          <div id="u690_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u691" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u691_div" class="selected"></div>
                          <div id="u691_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u692" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u692_div" class="selected"></div>
                          <div id="u692_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u693" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u693_div" class="selected"></div>
                          <div id="u693_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u694" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u694_div" class="selected"></div>
                          <div id="u694_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u695" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u695_div" class="selected"></div>
                          <div id="u695_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u696" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u696_div" class="selected"></div>
                          <div id="u696_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u697" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u697_div" class="selected"></div>
                          <div id="u697_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u698" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u698_div" class="selected"></div>
                          <div id="u698_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u699" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u699_div" class="selected"></div>
                          <div id="u699_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u700" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u700_div" class="selected"></div>
                          <div id="u700_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u701" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u701_div" class="selected"></div>
                          <div id="u701_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u702" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u702_div" class="selected"></div>
                        <div id="u702_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u703" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u703_div" class="selected"></div>
                        <div id="u703_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u704" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u704_div" class="selected"></div>
                        <div id="u704_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u705" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u705_div" class="selected"></div>
                        <div id="u705_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u706" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u706_div" class="selected"></div>
                        <div id="u706_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u707" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u707_div" class="selected"></div>
                        <div id="u707_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u708" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u709" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u710" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u710_div" class="selected"></div>
                        <div id="u710_text" class="text ">
                          <p><span>{{ $b14s->draw}}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u711" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u711_div" class="selected"></div>
                        <div id="u711_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u712" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u712_div" class="selected"></div>
                        <div id="u712_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u713" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u713_div" class="selected"></div>
                        <div id="u713_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u714" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u715" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u715_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u716" class="ax_default paragraph u716" data-label="bold_3a">
                            <div id="u716_div" class="u716_div"></div>
                            <div id="u716_text" class="text u716_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u717" class="ax_default paragraph u717" data-label="bold_2a">
                            <div id="u717_div" class="u717_div"></div>
                            <div id="u717_text" class="text u717_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u718" class="ax_default paragraph u718" data-label="bold_1a">
                            <div id="u718_div" class="u718_div"></div>
                            <div id="u718_text" class="text u718_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u719" class="ax_default paragraph u719" data-label="bold_0a">
                            <div id="u719_div" class="u719_div"></div>
                            <div id="u719_text" class="text u719_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u715-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u716-1" class="ax_default paragraph u716" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u716-1_div" class="u716_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u716-1_text" class="text u716_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u717-1" class="ax_default paragraph u717" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u717-1_div" class="u717_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u717-1_text" class="text u717_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u718-1" class="ax_default paragraph u718" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u718-1_div" class="u718_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u718-1_text" class="text u718_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u719-1" class="ax_default paragraph u719" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u719-1_div" class="u719_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u719-1_text" class="text u719_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u715-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u716-2" class="ax_default paragraph u716" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u716-2_div" class="u716_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u716-2_text" class="text u716_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u717-2" class="ax_default paragraph u717" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u717-2_div" class="u717_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u717-2_text" class="text u717_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u718-2" class="ax_default paragraph u718" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u718-2_div" class="u718_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u718-2_text" class="text u718_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u719-2" class="ax_default paragraph u719" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u719-2_div" class="u719_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u719-2_text" class="text u719_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u715-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u716-3" class="ax_default paragraph u716" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u716-3_div" class="u716_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u716-3_text" class="text u716_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u717-3" class="ax_default paragraph u717" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u717-3_div" class="u717_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u717-3_text" class="text u717_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u718-3" class="ax_default paragraph u718" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u718-3_div" class="u718_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u718-3_text" class="text u718_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u719-3" class="ax_default paragraph u719" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u719-3_div" class="u719_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u719-3_text" class="text u719_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u715-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u716-4" class="ax_default paragraph u716" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u716-4_div" class="u716_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u716-4_text" class="text u716_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u717-4" class="ax_default paragraph u717" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u717-4_div" class="u717_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u717-4_text" class="text u717_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u718-4" class="ax_default paragraph u718" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u718-4_div" class="u718_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u718-4_text" class="text u718_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u719-4" class="ax_default paragraph u719" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u719-4_div" class="u719_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u719-4_text" class="text u719_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u715-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u716-5" class="ax_default paragraph u716" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u716-5_div" class="u716_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u716-5_text" class="text u716_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u717-5" class="ax_default paragraph u717" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u717-5_div" class="u717_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u717-5_text" class="text u717_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u718-5" class="ax_default paragraph u718" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u718-5_div" class="u718_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u718-5_text" class="text u718_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u719-5" class="ax_default paragraph u719" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u719-5_div" class="u719_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u719-5_text" class="text u719_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u720" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u721" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u722" class="ax_default paragraph selected" data-label="Others">
                          <div id="u722_div" class="selected"></div>
                          <div id="u722_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u723" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u723_div" class="selected"></div>
                          <div id="u723_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u724" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u724_div" class="selected"></div>
                          <div id="u724_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u725" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u725_div" class="selected"></div>
                          <div id="u725_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u726" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u726_div" class="selected"></div>
                          <div id="u726_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u727" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u727_div" class="selected"></div>
                        <div id="u727_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u728" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u728_div" class="selected"></div>
                        <div id="u728_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u729" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u729_div" class="selected"></div>
                        <div id="u729_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u730" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u730_div" class="selected"></div>
                        <div id="u730_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u731" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u731_div" class="selected"></div>
                        <div id="u731_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u732" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u732_div" class="selected"></div>
                        <div id="u732_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u733" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u734" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u735" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u735_div" class="selected"></div>
                        <div id="u735_text" class="text ">
                          <p><span>{{ $b14s->h_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u736" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u736_div" class="selected"></div>
                        <div id="u736_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u737" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u737_div" class="selected"></div>
                        <div id="u737_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u738" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u738_div" class="selected"></div>
                        <div id="u738_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u739" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u740" class="ax_default" data-label="THCS_Repeater">
                        <script id="u740_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741" class="ax_default paragraph u741" data-label="bold_3a">
                            <div id="u741_div" class="u741_div"></div>
                            <div id="u741_text" class="text u741_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742" class="ax_default paragraph u742" data-label="bold_2a">
                            <div id="u742_div" class="u742_div"></div>
                            <div id="u742_text" class="text u742_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743" class="ax_default paragraph u743" data-label="bold_1a">
                            <div id="u743_div" class="u743_div"></div>
                            <div id="u743_text" class="text u743_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744" class="ax_default paragraph u744" data-label="bold_0a">
                            <div id="u744_div" class="u744_div"></div>
                            <div id="u744_text" class="text u744_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u740-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-1" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-1_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-1_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-1" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-1_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-1_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-1" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-1_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-1_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-1" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-1_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-1_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-2" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-2_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-2_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-2" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-2_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-2_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-2" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-2_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-2_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-2" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-2_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-2_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-3" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-3_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-3_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-3" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-3_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-3_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-3" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-3_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-3_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-3" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-3_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-3_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-4" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-4_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-4_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-4" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-4_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-4_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-4" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-4_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-4_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-4" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-4_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-4_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-5" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-5_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-5_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-5" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-5_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-5_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-5" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-5_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-5_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-5" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-5_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-5_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-6" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-6_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-6_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-6" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-6_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-6_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-6" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-6_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-6_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-6" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-6_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-6_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-7" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-7_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-7_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-7" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-7_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-7_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-7" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-7_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-7_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-7" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-7_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-7_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-8" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-8_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-8_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-8" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-8_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-8_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-8" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-8_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-8_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-8" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-8_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-8_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-9" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-9_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-9_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-9" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-9_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-9_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-9" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-9_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-9_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-9" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-9_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-9_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-10" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-10_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-10_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-10" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-10_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-10_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-10" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-10_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-10_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-10" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-10_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-10_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-11" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-11_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-11_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-11" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-11_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-11_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-11" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-11_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-11_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-11" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-11_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-11_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-12" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-12_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-12_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-12" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-12_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-12_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-12" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-12_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-12_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-12" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-12_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-12_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u740-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u741-13" class="ax_default paragraph u741" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u741-13_div" class="u741_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u741-13_text" class="text u741_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u742-13" class="ax_default paragraph u742" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u742-13_div" class="u742_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u742-13_text" class="text u742_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u743-13" class="ax_default paragraph u743" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u743-13_div" class="u743_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u743-13_text" class="text u743_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u744-13" class="ax_default paragraph u744" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u744-13_div" class="u744_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u744-13_text" class="text u744_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u745" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u746" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u747" class="ax_default paragraph selected" data-label="Others">
                          <div id="u747_div" class="selected"></div>
                          <div id="u747_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u748" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u748_div" class="selected"></div>
                          <div id="u748_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u749" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u749_div" class="selected"></div>
                          <div id="u749_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u750" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u750_div" class="selected"></div>
                          <div id="u750_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u751" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u751_div" class="selected"></div>
                          <div id="u751_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u752" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u752_div" class="selected"></div>
                          <div id="u752_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u753" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u753_div" class="selected"></div>
                          <div id="u753_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u754" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u754_div" class="selected"></div>
                          <div id="u754_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u755" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u755_div" class="selected"></div>
                          <div id="u755_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u756" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u756_div" class="selected"></div>
                          <div id="u756_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u757" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u757_div" class="selected"></div>
                          <div id="u757_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u758" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u758_div" class="selected"></div>
                          <div id="u758_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u759" class="ax_default paragraph selected">
                          <div id="u759_div" class="selected"></div>
                          <div id="u759_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u760" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u760_div" class="selected"></div>
                        <div id="u760_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u761" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u761_div" class="selected"></div>
                        <div id="u761_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u762" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u762_div" class="selected"></div>
                        <div id="u762_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u763" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u763_div" class="selected"></div>
                        <div id="u763_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u764" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u764_div" class="selected"></div>
                        <div id="u764_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u765" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u765_div" class="selected"></div>
                        <div id="u765_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u766" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u766_div" class="selected"></div>
                    <div id="u766_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u767" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u767_div" class="selected"></div>
                    <div id="u767_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u768" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u768_div" class="selected"></div>
            <div id="u768_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u769" class="ax_default" data-label="TAW" data-left="783" data-top="1224" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u770" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u770_div" class="selected"></div>
              <div id="u770_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u771" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u771_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u771_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u772" class="ax_default" data-label="THW" data-left="68" data-top="1224" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u773" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u773_div" class="selected"></div>
              <div id="u773_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u774" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u774_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u774_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u775" class="ax_default" data-label="DRAW" data-left="425" data-top="1224" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u776" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u776_div" class="selected"></div>
              <div id="u776_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u777" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u777_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u658.svg"/>
              <div id="u777_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u778" class="ax_default box_3 selected">
            <img id="u778_img" class="img " src="/footballui/public/frontend/images/page_a4/u659_selected.svg"/>
            <div id="u778_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u779" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1024" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u780" class="ax_default image" data-label="TA_G">
            <img id="u780_img" class="img " src="{{ asset($b14s->g_img) }}"/>
            <div id="u780_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u781" class="ax_default image" data-label="TH_G">
            <img id="u781_img" class="img " src="{{ asset($b14s->h_img) }}"/>
            <div id="u781_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u782" class="ax_default box_2" data-label="Team_Away">
            <div id="u782_div" class=""></div>
            <div id="u782_text" class="text ">
              <p><span>{{ $b14s->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u783" class="ax_default box_2" data-label="Team_Home">
            <div id="u783_div" class=""></div>
            <div id="u783_text" class="text ">
              <p><span>{{ $b14s->host }}</span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u784" class="ax_default box_2" data-label="Status">
            <div id="u784_div" class=""></div>
            <div id="u784_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u785" class="ax_default box_2" data-label="Number">
            <div id="u785_div" class=""></div>
            <div id="u785_text" class="text ">
              <p><span>{{ $b14s->jc_id }}</span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u786" class="ax_default box_2" data-label="HKJC">
            <div id="u786_div" class=""></div>
            <div id="u786_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u787" class="ax_default box_2" data-label="Date_Time">
            <div id="u787_div" class=""></div>
            <div id="u787_text" class="text ">
              <p><span>{{ $b14s->date }}</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u788" class="ax_default box_2" data-label="Match">
            <div id="u788_div" class=""></div>
            <div id="u788_text" class="text ">
              <p><span>{{ $b14s->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G3 (Group) -->
      <div id="u789" class="ax_default" data-label="G3" data-left="68" data-top="726" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u790" class="ax_default" data-label="Rate_Group" data-left="68" data-top="926" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u791" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u791_state0" class="panel_state" data-label="State 1" style="">
              <div id="u791_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u792" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u793" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u793_div" class="selected"></div>
                    <div id="u793_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u794" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u795" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u796" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u796_div" class="selected"></div>
                        <div id="u796_text" class="text ">
                          <p><span>{{ $b13s->g_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u797" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u797_div" class="selected"></div>
                        <div id="u797_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u798" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u798_div" class="selected"></div>
                        <div id="u798_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u799" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u799_div" class="selected"></div>
                        <div id="u799_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u800" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u801" class="ax_default" data-label="TACS_Repeater">
                        <script id="u801_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802" class="ax_default paragraph u802" data-label="bold_3a">
                            <div id="u802_div" class="u802_div"></div>
                            <div id="u802_text" class="text u802_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803" class="ax_default paragraph u803" data-label="bold_2a">
                            <div id="u803_div" class="u803_div"></div>
                            <div id="u803_text" class="text u803_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804" class="ax_default paragraph u804" data-label="bold_1a">
                            <div id="u804_div" class="u804_div"></div>
                            <div id="u804_text" class="text u804_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805" class="ax_default paragraph u805" data-label="bold_0a">
                            <div id="u805_div" class="u805_div"></div>
                            <div id="u805_text" class="text u805_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u801-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-1" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-1_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-1_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-1" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-1_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-1_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-1" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-1_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-1_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-1" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-1_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-1_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-2" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-2_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-2_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-2" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-2_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-2_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-2" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-2_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-2_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-2" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-2_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-2_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-3" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-3_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-3_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-3" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-3_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-3_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-3" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-3_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-3_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-3" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-3_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-3_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-4" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-4_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-4_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-4" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-4_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-4_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-4" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-4_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-4_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-4" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-4_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-4_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-5" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-5_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-5_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-5" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-5_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-5_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-5" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-5_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-5_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-5" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-5_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-5_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-6" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-6_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-6_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-6" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-6_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-6_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-6" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-6_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-6_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-6" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-6_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-6_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-7" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-7_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-7_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-7" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-7_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-7_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-7" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-7_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-7_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-7" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-7_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-7_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-8" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-8_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-8_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-8" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-8_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-8_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-8" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-8_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-8_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-8" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-8_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-8_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-9" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-9_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-9_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-9" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-9_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-9_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-9" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-9_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-9_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-9" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-9_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-9_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-10" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-10_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-10_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-10" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-10_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-10_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-10" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-10_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-10_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-10" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-10_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-10_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-11" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-11_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-11_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-11" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-11_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-11_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-11" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-11_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-11_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-11" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-11_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-11_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-12" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-12_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-12_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-12" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-12_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-12_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-12" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-12_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-12_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-12" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-12_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-12_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u801-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u802-13" class="ax_default paragraph u802" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u802-13_div" class="u802_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u802-13_text" class="text u802_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u803-13" class="ax_default paragraph u803" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u803-13_div" class="u803_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u803-13_text" class="text u803_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u804-13" class="ax_default paragraph u804" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u804-13_div" class="u804_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u804-13_text" class="text u804_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u805-13" class="ax_default paragraph u805" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u805-13_div" class="u805_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u805-13_text" class="text u805_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u806" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u807" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u808" class="ax_default paragraph selected" data-label="Others">
                          <div id="u808_div" class="selected"></div>
                          <div id="u808_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u809" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u809_div" class="selected"></div>
                          <div id="u809_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u810" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u810_div" class="selected"></div>
                          <div id="u810_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u811" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u811_div" class="selected"></div>
                          <div id="u811_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u812" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u812_div" class="selected"></div>
                          <div id="u812_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u813" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u813_div" class="selected"></div>
                          <div id="u813_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u814" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u814_div" class="selected"></div>
                          <div id="u814_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u815" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u815_div" class="selected"></div>
                          <div id="u815_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u816" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u816_div" class="selected"></div>
                          <div id="u816_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u817" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u817_div" class="selected"></div>
                          <div id="u817_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u818" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u818_div" class="selected"></div>
                          <div id="u818_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u819" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u819_div" class="selected"></div>
                          <div id="u819_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u820" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u820_div" class="selected"></div>
                          <div id="u820_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u821" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u821_div" class="selected"></div>
                        <div id="u821_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u822" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u822_div" class="selected"></div>
                        <div id="u822_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u823" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u823_div" class="selected"></div>
                        <div id="u823_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u824" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u824_div" class="selected"></div>
                        <div id="u824_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u825" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u825_div" class="selected"></div>
                        <div id="u825_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u826" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u826_div" class="selected"></div>
                        <div id="u826_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u827" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u828" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u829" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u829_div" class="selected"></div>
                        <div id="u829_text" class="text ">
                          <p><span>{{ $b13s->draw}}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u830" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u830_div" class="selected"></div>
                        <div id="u830_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u831" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u831_div" class="selected"></div>
                        <div id="u831_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u832" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u832_div" class="selected"></div>
                        <div id="u832_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u833" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u834" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u834_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u835" class="ax_default paragraph u835" data-label="bold_3a">
                            <div id="u835_div" class="u835_div"></div>
                            <div id="u835_text" class="text u835_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u836" class="ax_default paragraph u836" data-label="bold_2a">
                            <div id="u836_div" class="u836_div"></div>
                            <div id="u836_text" class="text u836_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u837" class="ax_default paragraph u837" data-label="bold_1a">
                            <div id="u837_div" class="u837_div"></div>
                            <div id="u837_text" class="text u837_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u838" class="ax_default paragraph u838" data-label="bold_0a">
                            <div id="u838_div" class="u838_div"></div>
                            <div id="u838_text" class="text u838_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u834-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u835-1" class="ax_default paragraph u835" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u835-1_div" class="u835_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u835-1_text" class="text u835_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u836-1" class="ax_default paragraph u836" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u836-1_div" class="u836_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u836-1_text" class="text u836_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u837-1" class="ax_default paragraph u837" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u837-1_div" class="u837_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u837-1_text" class="text u837_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u838-1" class="ax_default paragraph u838" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u838-1_div" class="u838_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u838-1_text" class="text u838_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u834-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u835-2" class="ax_default paragraph u835" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u835-2_div" class="u835_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u835-2_text" class="text u835_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u836-2" class="ax_default paragraph u836" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u836-2_div" class="u836_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u836-2_text" class="text u836_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u837-2" class="ax_default paragraph u837" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u837-2_div" class="u837_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u837-2_text" class="text u837_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u838-2" class="ax_default paragraph u838" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u838-2_div" class="u838_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u838-2_text" class="text u838_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u834-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u835-3" class="ax_default paragraph u835" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u835-3_div" class="u835_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u835-3_text" class="text u835_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u836-3" class="ax_default paragraph u836" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u836-3_div" class="u836_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u836-3_text" class="text u836_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u837-3" class="ax_default paragraph u837" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u837-3_div" class="u837_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u837-3_text" class="text u837_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u838-3" class="ax_default paragraph u838" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u838-3_div" class="u838_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u838-3_text" class="text u838_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u834-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u835-4" class="ax_default paragraph u835" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u835-4_div" class="u835_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u835-4_text" class="text u835_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u836-4" class="ax_default paragraph u836" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u836-4_div" class="u836_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u836-4_text" class="text u836_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u837-4" class="ax_default paragraph u837" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u837-4_div" class="u837_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u837-4_text" class="text u837_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u838-4" class="ax_default paragraph u838" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u838-4_div" class="u838_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u838-4_text" class="text u838_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u834-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u835-5" class="ax_default paragraph u835" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u835-5_div" class="u835_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u835-5_text" class="text u835_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u836-5" class="ax_default paragraph u836" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u836-5_div" class="u836_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u836-5_text" class="text u836_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u837-5" class="ax_default paragraph u837" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u837-5_div" class="u837_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u837-5_text" class="text u837_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u838-5" class="ax_default paragraph u838" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u838-5_div" class="u838_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u838-5_text" class="text u838_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u839" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u840" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u841" class="ax_default paragraph selected" data-label="Others">
                          <div id="u841_div" class="selected"></div>
                          <div id="u841_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u842" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u842_div" class="selected"></div>
                          <div id="u842_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u843" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u843_div" class="selected"></div>
                          <div id="u843_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u844" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u844_div" class="selected"></div>
                          <div id="u844_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u845" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u845_div" class="selected"></div>
                          <div id="u845_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u846" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u846_div" class="selected"></div>
                        <div id="u846_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u847" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u847_div" class="selected"></div>
                        <div id="u847_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u848" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u848_div" class="selected"></div>
                        <div id="u848_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u849" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u849_div" class="selected"></div>
                        <div id="u849_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u850" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u850_div" class="selected"></div>
                        <div id="u850_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u851" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u851_div" class="selected"></div>
                        <div id="u851_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u852" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u853" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u854" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u854_div" class="selected"></div>
                        <div id="u854_text" class="text ">
                          <p><span>{{ $b13s->h_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u855" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u855_div" class="selected"></div>
                        <div id="u855_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u856" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u856_div" class="selected"></div>
                        <div id="u856_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u857" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u857_div" class="selected"></div>
                        <div id="u857_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u858" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u859" class="ax_default" data-label="THCS_Repeater">
                        <script id="u859_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860" class="ax_default paragraph u860" data-label="bold_3a">
                            <div id="u860_div" class="u860_div"></div>
                            <div id="u860_text" class="text u860_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861" class="ax_default paragraph u861" data-label="bold_2a">
                            <div id="u861_div" class="u861_div"></div>
                            <div id="u861_text" class="text u861_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862" class="ax_default paragraph u862" data-label="bold_1a">
                            <div id="u862_div" class="u862_div"></div>
                            <div id="u862_text" class="text u862_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863" class="ax_default paragraph u863" data-label="bold_0a">
                            <div id="u863_div" class="u863_div"></div>
                            <div id="u863_text" class="text u863_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u859-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-1" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-1_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-1_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-1" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-1_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-1_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-1" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-1_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-1_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-1" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-1_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-1_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-2" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-2_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-2_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-2" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-2_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-2_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-2" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-2_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-2_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-2" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-2_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-2_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-3" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-3_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-3_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-3" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-3_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-3_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-3" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-3_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-3_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-3" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-3_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-3_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-4" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-4_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-4_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-4" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-4_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-4_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-4" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-4_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-4_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-4" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-4_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-4_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-5" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-5_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-5_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-5" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-5_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-5_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-5" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-5_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-5_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-5" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-5_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-5_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-6" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-6_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-6_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-6" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-6_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-6_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-6" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-6_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-6_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-6" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-6_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-6_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-7" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-7_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-7_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-7" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-7_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-7_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-7" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-7_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-7_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-7" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-7_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-7_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-8" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-8_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-8_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-8" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-8_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-8_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-8" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-8_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-8_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-8" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-8_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-8_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-9" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-9_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-9_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-9" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-9_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-9_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-9" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-9_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-9_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-9" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-9_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-9_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-10" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-10_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-10_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-10" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-10_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-10_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-10" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-10_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-10_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-10" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-10_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-10_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-11" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-11_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-11_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-11" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-11_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-11_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-11" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-11_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-11_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-11" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-11_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-11_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-12" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-12_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-12_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-12" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-12_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-12_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-12" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-12_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-12_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-12" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-12_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-12_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u859-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u860-13" class="ax_default paragraph u860" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u860-13_div" class="u860_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u860-13_text" class="text u860_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u861-13" class="ax_default paragraph u861" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u861-13_div" class="u861_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u861-13_text" class="text u861_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u862-13" class="ax_default paragraph u862" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u862-13_div" class="u862_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u862-13_text" class="text u862_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u863-13" class="ax_default paragraph u863" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u863-13_div" class="u863_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u863-13_text" class="text u863_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u864" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u865" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u866" class="ax_default paragraph selected" data-label="Others">
                          <div id="u866_div" class="selected"></div>
                          <div id="u866_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u867" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u867_div" class="selected"></div>
                          <div id="u867_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u868" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u868_div" class="selected"></div>
                          <div id="u868_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u869" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u869_div" class="selected"></div>
                          <div id="u869_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u870" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u870_div" class="selected"></div>
                          <div id="u870_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u871" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u871_div" class="selected"></div>
                          <div id="u871_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u872" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u872_div" class="selected"></div>
                          <div id="u872_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u873" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u873_div" class="selected"></div>
                          <div id="u873_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u874" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u874_div" class="selected"></div>
                          <div id="u874_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u875" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u875_div" class="selected"></div>
                          <div id="u875_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u876" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u876_div" class="selected"></div>
                          <div id="u876_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u877" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u877_div" class="selected"></div>
                          <div id="u877_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u878" class="ax_default paragraph selected">
                          <div id="u878_div" class="selected"></div>
                          <div id="u878_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u879" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u879_div" class="selected"></div>
                        <div id="u879_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u880" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u880_div" class="selected"></div>
                        <div id="u880_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u881" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u881_div" class="selected"></div>
                        <div id="u881_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u882" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u882_div" class="selected"></div>
                        <div id="u882_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u883" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u883_div" class="selected"></div>
                        <div id="u883_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u884" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u884_div" class="selected"></div>
                        <div id="u884_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u885" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u885_div" class="selected"></div>
                    <div id="u885_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u886" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u886_div" class="selected"></div>
                    <div id="u886_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u887" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u887_div" class="selected"></div>
            <div id="u887_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u888" class="ax_default" data-label="TAW" data-left="783" data-top="926" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u889" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u889_div" class="selected"></div>
              <div id="u889_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u890" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u890_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u890_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u891" class="ax_default" data-label="THW" data-left="68" data-top="926" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u892" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u892_div" class="selected"></div>
              <div id="u892_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u893" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u893_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u893_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u894" class="ax_default" data-label="DRAW" data-left="425" data-top="926" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u895" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u895_div" class="selected"></div>
              <div id="u895_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u896" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u896_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u658.svg"/>
              <div id="u896_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u897" class="ax_default box_3 selected">
            <img id="u897_img" class="img " src="/footballui/public/frontend/images/page_a4/u659_selected.svg"/>
            <div id="u897_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u898" class="ax_default" data-label="Logo_Group" data-left="352" data-top="726" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u899" class="ax_default image" data-label="TA_G">
            <img id="u899_img" class="img " src="{{ asset($b13s->g_img) }}"/>
            <div id="u899_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u900" class="ax_default image" data-label="TH_G">
            <img id="u900_img" class="img " src="{{ asset($b13s->h_img) }}"/>
            <div id="u900_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u901" class="ax_default box_2" data-label="Team_Away">
            <div id="u901_div" class=""></div>
            <div id="u901_text" class="text ">
              <p><span>{{ $b13s->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u902" class="ax_default box_2" data-label="Team_Home">
            <div id="u902_div" class=""></div>
            <div id="u902_text" class="text ">
              <p><span>{{ $b13s->host }}</span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u903" class="ax_default box_2" data-label="Status">
            <div id="u903_div" class=""></div>
            <div id="u903_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u904" class="ax_default box_2" data-label="Number">
            <div id="u904_div" class=""></div>
            <div id="u904_text" class="text ">
              <p><span>{{ $b13s->jc_id }}</span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u905" class="ax_default box_2" data-label="HKJC">
            <div id="u905_div" class=""></div>
            <div id="u905_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u906" class="ax_default box_2" data-label="Date_Time">
            <div id="u906_div" class=""></div>
            <div id="u906_text" class="text ">
              <p><span>{{ $b13s->date }}</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u907" class="ax_default box_2" data-label="Match">
            <div id="u907_div" class=""></div>
            <div id="u907_text" class="text ">
              <p><span>{{ $b13s->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G2 (Group) -->
      <div id="u908" class="ax_default" data-label="G2" data-left="68" data-top="428" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u909" class="ax_default" data-label="Rate_Group" data-left="68" data-top="628" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u910" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u910_state0" class="panel_state" data-label="State 1" style="">
              <div id="u910_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u911" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u912" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u912_div" class="selected"></div>
                    <div id="u912_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u913" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u914" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u915" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u915_div" class="selected"></div>
                        <div id="u915_text" class="text ">
                          <p><span>{{ $b12s->g_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u916" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u916_div" class="selected"></div>
                        <div id="u916_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u917" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u917_div" class="selected"></div>
                        <div id="u917_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u918" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u918_div" class="selected"></div>
                        <div id="u918_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u919" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u920" class="ax_default" data-label="TACS_Repeater">
                        <script id="u920_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921" class="ax_default paragraph u921" data-label="bold_3a">
                            <div id="u921_div" class="u921_div"></div>
                            <div id="u921_text" class="text u921_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922" class="ax_default paragraph u922" data-label="bold_2a">
                            <div id="u922_div" class="u922_div"></div>
                            <div id="u922_text" class="text u922_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923" class="ax_default paragraph u923" data-label="bold_1a">
                            <div id="u923_div" class="u923_div"></div>
                            <div id="u923_text" class="text u923_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924" class="ax_default paragraph u924" data-label="bold_0a">
                            <div id="u924_div" class="u924_div"></div>
                            <div id="u924_text" class="text u924_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u920-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-1" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-1_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-1_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-1" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-1_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-1_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-1" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-1_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-1_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-1" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-1_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-1_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-2" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-2_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-2_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-2" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-2_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-2_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-2" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-2_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-2_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-2" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-2_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-2_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-3" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-3_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-3_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-3" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-3_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-3_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-3" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-3_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-3_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-3" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-3_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-3_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-4" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-4_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-4_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-4" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-4_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-4_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-4" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-4_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-4_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-4" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-4_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-4_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-5" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-5_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-5_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-5" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-5_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-5_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-5" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-5_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-5_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-5" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-5_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-5_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-6" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-6_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-6_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-6" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-6_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-6_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-6" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-6_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-6_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-6" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-6_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-6_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-7" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-7_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-7_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-7" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-7_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-7_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-7" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-7_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-7_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-7" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-7_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-7_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-8" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-8_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-8_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-8" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-8_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-8_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-8" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-8_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-8_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-8" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-8_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-8_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-9" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-9_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-9_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-9" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-9_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-9_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-9" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-9_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-9_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-9" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-9_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-9_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-10" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-10_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-10_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-10" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-10_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-10_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-10" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-10_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-10_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-10" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-10_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-10_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-11" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-11_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-11_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-11" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-11_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-11_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-11" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-11_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-11_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-11" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-11_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-11_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-12" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-12_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-12_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-12" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-12_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-12_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-12" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-12_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-12_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-12" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-12_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-12_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u920-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u921-13" class="ax_default paragraph u921" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u921-13_div" class="u921_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u921-13_text" class="text u921_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u922-13" class="ax_default paragraph u922" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u922-13_div" class="u922_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u922-13_text" class="text u922_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u923-13" class="ax_default paragraph u923" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u923-13_div" class="u923_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u923-13_text" class="text u923_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u924-13" class="ax_default paragraph u924" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u924-13_div" class="u924_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u924-13_text" class="text u924_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u925" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u926" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u927" class="ax_default paragraph selected" data-label="Others">
                          <div id="u927_div" class="selected"></div>
                          <div id="u927_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u928" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u928_div" class="selected"></div>
                          <div id="u928_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u929" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u929_div" class="selected"></div>
                          <div id="u929_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u930" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u930_div" class="selected"></div>
                          <div id="u930_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u931" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u931_div" class="selected"></div>
                          <div id="u931_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u932" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u932_div" class="selected"></div>
                          <div id="u932_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u933" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u933_div" class="selected"></div>
                          <div id="u933_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u934" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u934_div" class="selected"></div>
                          <div id="u934_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u935" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u935_div" class="selected"></div>
                          <div id="u935_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u936" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u936_div" class="selected"></div>
                          <div id="u936_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u937" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u937_div" class="selected"></div>
                          <div id="u937_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u938" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u938_div" class="selected"></div>
                          <div id="u938_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u939" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u939_div" class="selected"></div>
                          <div id="u939_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u940" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u940_div" class="selected"></div>
                        <div id="u940_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u941" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u941_div" class="selected"></div>
                        <div id="u941_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u942" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u942_div" class="selected"></div>
                        <div id="u942_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u943" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u943_div" class="selected"></div>
                        <div id="u943_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u944" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u944_div" class="selected"></div>
                        <div id="u944_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u945" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u945_div" class="selected"></div>
                        <div id="u945_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u946" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u947" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u948" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u948_div" class="selected"></div>
                        <div id="u948_text" class="text ">
                          <p><span>{{ $b12s->draw}}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u949" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u949_div" class="selected"></div>
                        <div id="u949_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u950" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u950_div" class="selected"></div>
                        <div id="u950_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u951" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u951_div" class="selected"></div>
                        <div id="u951_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u952" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u953" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u953_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u954" class="ax_default paragraph u954" data-label="bold_3a">
                            <div id="u954_div" class="u954_div"></div>
                            <div id="u954_text" class="text u954_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u955" class="ax_default paragraph u955" data-label="bold_2a">
                            <div id="u955_div" class="u955_div"></div>
                            <div id="u955_text" class="text u955_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u956" class="ax_default paragraph u956" data-label="bold_1a">
                            <div id="u956_div" class="u956_div"></div>
                            <div id="u956_text" class="text u956_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u957" class="ax_default paragraph u957" data-label="bold_0a">
                            <div id="u957_div" class="u957_div"></div>
                            <div id="u957_text" class="text u957_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u953-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u954-1" class="ax_default paragraph u954" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u954-1_div" class="u954_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u954-1_text" class="text u954_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u955-1" class="ax_default paragraph u955" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u955-1_div" class="u955_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u955-1_text" class="text u955_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u956-1" class="ax_default paragraph u956" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u956-1_div" class="u956_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u956-1_text" class="text u956_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u957-1" class="ax_default paragraph u957" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u957-1_div" class="u957_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u957-1_text" class="text u957_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u953-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u954-2" class="ax_default paragraph u954" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u954-2_div" class="u954_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u954-2_text" class="text u954_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u955-2" class="ax_default paragraph u955" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u955-2_div" class="u955_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u955-2_text" class="text u955_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u956-2" class="ax_default paragraph u956" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u956-2_div" class="u956_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u956-2_text" class="text u956_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u957-2" class="ax_default paragraph u957" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u957-2_div" class="u957_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u957-2_text" class="text u957_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u953-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u954-3" class="ax_default paragraph u954" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u954-3_div" class="u954_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u954-3_text" class="text u954_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u955-3" class="ax_default paragraph u955" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u955-3_div" class="u955_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u955-3_text" class="text u955_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u956-3" class="ax_default paragraph u956" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u956-3_div" class="u956_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u956-3_text" class="text u956_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u957-3" class="ax_default paragraph u957" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u957-3_div" class="u957_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u957-3_text" class="text u957_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u953-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u954-4" class="ax_default paragraph u954" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u954-4_div" class="u954_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u954-4_text" class="text u954_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u955-4" class="ax_default paragraph u955" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u955-4_div" class="u955_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u955-4_text" class="text u955_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u956-4" class="ax_default paragraph u956" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u956-4_div" class="u956_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u956-4_text" class="text u956_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u957-4" class="ax_default paragraph u957" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u957-4_div" class="u957_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u957-4_text" class="text u957_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u953-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u954-5" class="ax_default paragraph u954" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u954-5_div" class="u954_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u954-5_text" class="text u954_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u955-5" class="ax_default paragraph u955" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u955-5_div" class="u955_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u955-5_text" class="text u955_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u956-5" class="ax_default paragraph u956" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u956-5_div" class="u956_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u956-5_text" class="text u956_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u957-5" class="ax_default paragraph u957" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u957-5_div" class="u957_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u957-5_text" class="text u957_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u958" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u959" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u960" class="ax_default paragraph selected" data-label="Others">
                          <div id="u960_div" class="selected"></div>
                          <div id="u960_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u961" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u961_div" class="selected"></div>
                          <div id="u961_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u962" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u962_div" class="selected"></div>
                          <div id="u962_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u963" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u963_div" class="selected"></div>
                          <div id="u963_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u964" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u964_div" class="selected"></div>
                          <div id="u964_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u965" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u965_div" class="selected"></div>
                        <div id="u965_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u966" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u966_div" class="selected"></div>
                        <div id="u966_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u967" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u967_div" class="selected"></div>
                        <div id="u967_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u968" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u968_div" class="selected"></div>
                        <div id="u968_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u969" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u969_div" class="selected"></div>
                        <div id="u969_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u970" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u970_div" class="selected"></div>
                        <div id="u970_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u971" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u972" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u973" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u973_div" class="selected"></div>
                        <div id="u973_text" class="text ">
                          <p><span>{{ $b12s->h_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u974" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u974_div" class="selected"></div>
                        <div id="u974_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u975" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u975_div" class="selected"></div>
                        <div id="u975_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u976" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u976_div" class="selected"></div>
                        <div id="u976_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u977" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u978" class="ax_default" data-label="THCS_Repeater">
                        <script id="u978_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979" class="ax_default paragraph u979" data-label="bold_3a">
                            <div id="u979_div" class="u979_div"></div>
                            <div id="u979_text" class="text u979_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980" class="ax_default paragraph u980" data-label="bold_2a">
                            <div id="u980_div" class="u980_div"></div>
                            <div id="u980_text" class="text u980_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981" class="ax_default paragraph u981" data-label="bold_1a">
                            <div id="u981_div" class="u981_div"></div>
                            <div id="u981_text" class="text u981_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982" class="ax_default paragraph u982" data-label="bold_0a">
                            <div id="u982_div" class="u982_div"></div>
                            <div id="u982_text" class="text u982_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u978-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-1" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-1_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-1_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-1" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-1_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-1_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-1" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-1_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-1_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-1" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-1_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-1_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-2" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-2_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-2_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-2" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-2_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-2_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-2" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-2_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-2_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-2" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-2_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-2_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-3" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-3_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-3_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-3" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-3_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-3_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-3" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-3_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-3_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-3" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-3_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-3_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-4" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-4_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-4_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-4" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-4_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-4_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-4" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-4_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-4_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-4" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-4_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-4_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-5" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-5_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-5_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-5" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-5_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-5_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-5" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-5_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-5_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-5" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-5_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-5_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-6" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-6_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-6_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-6" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-6_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-6_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-6" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-6_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-6_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-6" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-6_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-6_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-7" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-7_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-7_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-7" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-7_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-7_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-7" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-7_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-7_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-7" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-7_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-7_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-8" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-8_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-8_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-8" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-8_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-8_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-8" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-8_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-8_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-8" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-8_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-8_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-9" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-9_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-9_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-9" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-9_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-9_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-9" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-9_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-9_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-9" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-9_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-9_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-10" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-10_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-10_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-10" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-10_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-10_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-10" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-10_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-10_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-10" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-10_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-10_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-11" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-11_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-11_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-11" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-11_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-11_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-11" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-11_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-11_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-11" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-11_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-11_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-12" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-12_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-12_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-12" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-12_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-12_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-12" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-12_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-12_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-12" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-12_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-12_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u978-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u979-13" class="ax_default paragraph u979" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u979-13_div" class="u979_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u979-13_text" class="text u979_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u980-13" class="ax_default paragraph u980" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u980-13_div" class="u980_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u980-13_text" class="text u980_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u981-13" class="ax_default paragraph u981" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u981-13_div" class="u981_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u981-13_text" class="text u981_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u982-13" class="ax_default paragraph u982" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u982-13_div" class="u982_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u982-13_text" class="text u982_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u983" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u984" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u985" class="ax_default paragraph selected" data-label="Others">
                          <div id="u985_div" class="selected"></div>
                          <div id="u985_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u986" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u986_div" class="selected"></div>
                          <div id="u986_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u987" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u987_div" class="selected"></div>
                          <div id="u987_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u988" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u988_div" class="selected"></div>
                          <div id="u988_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u989" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u989_div" class="selected"></div>
                          <div id="u989_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u990" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u990_div" class="selected"></div>
                          <div id="u990_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u991" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u991_div" class="selected"></div>
                          <div id="u991_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u992" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u992_div" class="selected"></div>
                          <div id="u992_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u993" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u993_div" class="selected"></div>
                          <div id="u993_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u994" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u994_div" class="selected"></div>
                          <div id="u994_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u995" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u995_div" class="selected"></div>
                          <div id="u995_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u996" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u996_div" class="selected"></div>
                          <div id="u996_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u997" class="ax_default paragraph selected">
                          <div id="u997_div" class="selected"></div>
                          <div id="u997_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u998" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u998_div" class="selected"></div>
                        <div id="u998_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u999" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u999_div" class="selected"></div>
                        <div id="u999_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u1000" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u1000_div" class="selected"></div>
                        <div id="u1000_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u1001" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u1001_div" class="selected"></div>
                        <div id="u1001_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u1002" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u1002_div" class="selected"></div>
                        <div id="u1002_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u1003" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u1003_div" class="selected"></div>
                        <div id="u1003_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u1004" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u1004_div" class="selected"></div>
                    <div id="u1004_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u1005" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u1005_div" class="selected"></div>
                    <div id="u1005_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u1006" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u1006_div" class="selected"></div>
            <div id="u1006_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u1007" class="ax_default" data-label="TAW" data-left="783" data-top="628" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u1008" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u1008_div" class="selected"></div>
              <div id="u1008_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u1009" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u1009_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u1009_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u1010" class="ax_default" data-label="THW" data-left="68" data-top="628" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u1011" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u1011_div" class="selected"></div>
              <div id="u1011_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u1012" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u1012_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u1012_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u1013" class="ax_default" data-label="DRAW" data-left="425" data-top="628" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u1014" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u1014_div" class="selected"></div>
              <div id="u1014_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u1015" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u1015_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u658.svg"/>
              <div id="u1015_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u1016" class="ax_default box_3 selected">
            <img id="u1016_img" class="img " src="/footballui/public/frontend/images/page_a4/u659_selected.svg"/>
            <div id="u1016_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u1017" class="ax_default" data-label="Logo_Group" data-left="352" data-top="428" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u1018" class="ax_default image" data-label="TA_G">
            <img id="u1018_img" class="img " src="{{ asset($b12s->g_img) }}"/>
            <div id="u1018_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u1019" class="ax_default image" data-label="TH_G">
            <img id="u1019_img" class="img " src="{{ asset($b12s->h_img) }}"/>
            <div id="u1019_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u1020" class="ax_default box_2" data-label="Team_Away">
            <div id="u1020_div" class=""></div>
            <div id="u1020_text" class="text ">
              <p><span>{{ $b12s->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u1021" class="ax_default box_2" data-label="Team_Home">
            <div id="u1021_div" class=""></div>
            <div id="u1021_text" class="text ">
              <p><span>{{ $b12s->host }}</span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u1022" class="ax_default box_2" data-label="Status">
            <div id="u1022_div" class=""></div>
            <div id="u1022_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u1023" class="ax_default box_2" data-label="Number">
            <div id="u1023_div" class=""></div>
            <div id="u1023_text" class="text ">
              <p><span>{{ $b12s->jc_id }}</span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u1024" class="ax_default box_2" data-label="HKJC">
            <div id="u1024_div" class=""></div>
            <div id="u1024_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u1025" class="ax_default box_2" data-label="Date_Time">
            <div id="u1025_div" class=""></div>
            <div id="u1025_text" class="text ">
              <p><span>{{ $b12s->date }}</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u1026" class="ax_default box_2" data-label="Match">
            <div id="u1026_div" class=""></div>
            <div id="u1026_text" class="text ">
              <p><span>{{ $b12s->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G1 (Group) -->
      <div id="u1027" class="ax_default" data-label="G1" data-left="68" data-top="140" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u1028" class="ax_default" data-label="Rate_Group" data-left="68" data-top="340" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u1029" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u1029_state0" class="panel_state" data-label="State 1" style="">
              <div id="u1029_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u1030" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u1031" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u1031_div" class="selected"></div>
                    <div id="u1031_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u1032" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u1033" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u1034" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u1034_div" class="selected"></div>
                        <div id="u1034_text" class="text ">
                          <p><span>{{ $b1s->g_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u1035" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u1035_div" class="selected"></div>
                        <div id="u1035_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u1036" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u1036_div" class="selected"></div>
                        <div id="u1036_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u1037" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u1037_div" class="selected"></div>
                        <div id="u1037_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u1038" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u1039" class="ax_default" data-label="TACS_Repeater">
                        <script id="u1039_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040" class="ax_default paragraph u1040" data-label="bold_3a">
                            <div id="u1040_div" class="u1040_div"></div>
                            <div id="u1040_text" class="text u1040_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041" class="ax_default paragraph u1041" data-label="bold_2a">
                            <div id="u1041_div" class="u1041_div"></div>
                            <div id="u1041_text" class="text u1041_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042" class="ax_default paragraph u1042" data-label="bold_1a">
                            <div id="u1042_div" class="u1042_div"></div>
                            <div id="u1042_text" class="text u1042_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043" class="ax_default paragraph u1043" data-label="bold_0a">
                            <div id="u1043_div" class="u1043_div"></div>
                            <div id="u1043_text" class="text u1043_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u1039-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-1" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-1_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-1_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-1" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-1_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-1_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-1" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-1_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-1_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-1" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-1_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-1_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-2" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-2_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-2_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-2" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-2_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-2_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-2" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-2_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-2_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-2" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-2_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-2_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-3" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-3_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-3_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-3" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-3_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-3_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-3" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-3_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-3_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-3" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-3_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-3_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-4" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-4_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-4_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-4" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-4_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-4_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-4" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-4_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-4_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-4" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-4_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-4_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-5" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-5_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-5_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-5" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-5_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-5_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-5" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-5_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-5_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-5" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-5_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-5_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-6" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-6_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-6_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-6" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-6_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-6_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-6" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-6_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-6_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-6" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-6_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-6_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-7" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-7_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-7_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-7" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-7_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-7_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-7" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-7_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-7_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-7" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-7_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-7_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-8" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-8_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-8_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-8" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-8_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-8_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-8" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-8_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-8_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-8" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-8_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-8_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-9" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-9_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-9_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-9" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-9_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-9_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-9" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-9_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-9_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-9" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-9_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-9_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-10" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-10_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-10_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-10" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-10_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-10_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-10" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-10_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-10_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-10" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-10_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-10_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-11" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-11_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-11_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-11" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-11_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-11_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-11" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-11_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-11_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-11" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-11_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-11_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-12" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-12_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-12_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-12" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-12_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-12_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-12" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-12_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-12_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-12" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-12_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-12_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1039-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1040-13" class="ax_default paragraph u1040" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1040-13_div" class="u1040_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1040-13_text" class="text u1040_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1041-13" class="ax_default paragraph u1041" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1041-13_div" class="u1041_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1041-13_text" class="text u1041_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1042-13" class="ax_default paragraph u1042" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1042-13_div" class="u1042_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1042-13_text" class="text u1042_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1043-13" class="ax_default paragraph u1043" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1043-13_div" class="u1043_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1043-13_text" class="text u1043_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u1044" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u1045" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u1046" class="ax_default paragraph selected" data-label="Others">
                          <div id="u1046_div" class="selected"></div>
                          <div id="u1046_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u1047" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u1047_div" class="selected"></div>
                          <div id="u1047_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u1048" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u1048_div" class="selected"></div>
                          <div id="u1048_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u1049" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u1049_div" class="selected"></div>
                          <div id="u1049_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u1050" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u1050_div" class="selected"></div>
                          <div id="u1050_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u1051" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u1051_div" class="selected"></div>
                          <div id="u1051_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u1052" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u1052_div" class="selected"></div>
                          <div id="u1052_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u1053" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u1053_div" class="selected"></div>
                          <div id="u1053_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u1054" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u1054_div" class="selected"></div>
                          <div id="u1054_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u1055" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u1055_div" class="selected"></div>
                          <div id="u1055_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u1056" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u1056_div" class="selected"></div>
                          <div id="u1056_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u1057" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u1057_div" class="selected"></div>
                          <div id="u1057_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u1058" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u1058_div" class="selected"></div>
                          <div id="u1058_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u1059" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u1059_div" class="selected"></div>
                        <div id="u1059_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u1060" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u1060_div" class="selected"></div>
                        <div id="u1060_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u1061" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u1061_div" class="selected"></div>
                        <div id="u1061_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u1062" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u1062_div" class="selected"></div>
                        <div id="u1062_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u1063" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u1063_div" class="selected"></div>
                        <div id="u1063_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u1064" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u1064_div" class="selected"></div>
                        <div id="u1064_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u1065" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u1066" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u1067" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u1067_div" class="selected"></div>
                        <div id="u1067_text" class="text ">
                          <p><span>{{ $b1s->draw}}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u1068" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u1068_div" class="selected"></div>
                        <div id="u1068_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u1069" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u1069_div" class="selected"></div>
                        <div id="u1069_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u1070" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u1070_div" class="selected"></div>
                        <div id="u1070_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u1071" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u1072" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u1072_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1073" class="ax_default paragraph u1073" data-label="bold_3a">
                            <div id="u1073_div" class="u1073_div"></div>
                            <div id="u1073_text" class="text u1073_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1074" class="ax_default paragraph u1074" data-label="bold_2a">
                            <div id="u1074_div" class="u1074_div"></div>
                            <div id="u1074_text" class="text u1074_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1075" class="ax_default paragraph u1075" data-label="bold_1a">
                            <div id="u1075_div" class="u1075_div"></div>
                            <div id="u1075_text" class="text u1075_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1076" class="ax_default paragraph u1076" data-label="bold_0a">
                            <div id="u1076_div" class="u1076_div"></div>
                            <div id="u1076_text" class="text u1076_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u1072-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1073-1" class="ax_default paragraph u1073" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1073-1_div" class="u1073_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1073-1_text" class="text u1073_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1074-1" class="ax_default paragraph u1074" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1074-1_div" class="u1074_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1074-1_text" class="text u1074_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1075-1" class="ax_default paragraph u1075" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1075-1_div" class="u1075_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1075-1_text" class="text u1075_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1076-1" class="ax_default paragraph u1076" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1076-1_div" class="u1076_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1076-1_text" class="text u1076_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1072-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1073-2" class="ax_default paragraph u1073" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1073-2_div" class="u1073_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1073-2_text" class="text u1073_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1074-2" class="ax_default paragraph u1074" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1074-2_div" class="u1074_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1074-2_text" class="text u1074_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1075-2" class="ax_default paragraph u1075" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1075-2_div" class="u1075_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1075-2_text" class="text u1075_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1076-2" class="ax_default paragraph u1076" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1076-2_div" class="u1076_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1076-2_text" class="text u1076_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1072-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1073-3" class="ax_default paragraph u1073" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1073-3_div" class="u1073_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1073-3_text" class="text u1073_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1074-3" class="ax_default paragraph u1074" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1074-3_div" class="u1074_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1074-3_text" class="text u1074_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1075-3" class="ax_default paragraph u1075" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1075-3_div" class="u1075_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1075-3_text" class="text u1075_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1076-3" class="ax_default paragraph u1076" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1076-3_div" class="u1076_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1076-3_text" class="text u1076_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1072-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1073-4" class="ax_default paragraph u1073" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1073-4_div" class="u1073_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1073-4_text" class="text u1073_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1074-4" class="ax_default paragraph u1074" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1074-4_div" class="u1074_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1074-4_text" class="text u1074_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1075-4" class="ax_default paragraph u1075" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1075-4_div" class="u1075_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1075-4_text" class="text u1075_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1076-4" class="ax_default paragraph u1076" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1076-4_div" class="u1076_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1076-4_text" class="text u1076_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1072-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1073-5" class="ax_default paragraph u1073" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1073-5_div" class="u1073_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1073-5_text" class="text u1073_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1074-5" class="ax_default paragraph u1074" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1074-5_div" class="u1074_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1074-5_text" class="text u1074_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1075-5" class="ax_default paragraph u1075" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1075-5_div" class="u1075_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1075-5_text" class="text u1075_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1076-5" class="ax_default paragraph u1076" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1076-5_div" class="u1076_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1076-5_text" class="text u1076_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u1077" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u1078" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u1079" class="ax_default paragraph selected" data-label="Others">
                          <div id="u1079_div" class="selected"></div>
                          <div id="u1079_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u1080" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u1080_div" class="selected"></div>
                          <div id="u1080_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u1081" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u1081_div" class="selected"></div>
                          <div id="u1081_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u1082" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u1082_div" class="selected"></div>
                          <div id="u1082_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u1083" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u1083_div" class="selected"></div>
                          <div id="u1083_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u1084" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u1084_div" class="selected"></div>
                        <div id="u1084_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u1085" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u1085_div" class="selected"></div>
                        <div id="u1085_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u1086" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u1086_div" class="selected"></div>
                        <div id="u1086_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u1087" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u1087_div" class="selected"></div>
                        <div id="u1087_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u1088" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u1088_div" class="selected"></div>
                        <div id="u1088_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u1089" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u1089_div" class="selected"></div>
                        <div id="u1089_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u1090" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u1091" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u1092" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u1092_div" class="selected"></div>
                        <div id="u1092_text" class="text ">
                          <p><span>{{ $b1s->h_win }}%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u1093" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u1093_div" class="selected"></div>
                        <div id="u1093_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u1094" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u1094_div" class="selected"></div>
                        <div id="u1094_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u1095" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u1095_div" class="selected"></div>
                        <div id="u1095_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u1096" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u1097" class="ax_default" data-label="THCS_Repeater">
                        <script id="u1097_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098" class="ax_default paragraph u1098" data-label="bold_3a">
                            <div id="u1098_div" class="u1098_div"></div>
                            <div id="u1098_text" class="text u1098_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099" class="ax_default paragraph u1099" data-label="bold_2a">
                            <div id="u1099_div" class="u1099_div"></div>
                            <div id="u1099_text" class="text u1099_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100" class="ax_default paragraph u1100" data-label="bold_1a">
                            <div id="u1100_div" class="u1100_div"></div>
                            <div id="u1100_text" class="text u1100_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101" class="ax_default paragraph u1101" data-label="bold_0a">
                            <div id="u1101_div" class="u1101_div"></div>
                            <div id="u1101_text" class="text u1101_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u1097-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-1" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-1_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-1_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-1" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-1_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-1_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-1" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-1_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-1_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-1" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-1_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-1_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-2" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-2_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-2_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-2" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-2_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-2_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-2" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-2_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-2_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-2" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-2_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-2_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-3" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-3_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-3_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-3" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-3_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-3_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-3" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-3_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-3_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-3" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-3_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-3_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-4" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-4_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-4_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-4" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-4_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-4_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-4" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-4_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-4_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-4" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-4_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-4_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-5" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-5_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-5_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-5" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-5_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-5_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-5" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-5_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-5_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-5" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-5_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-5_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-6" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-6_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-6_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-6" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-6_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-6_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-6" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-6_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-6_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-6" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-6_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-6_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-7" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-7_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-7_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-7" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-7_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-7_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-7" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-7_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-7_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-7" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-7_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-7_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-8" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-8_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-8_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-8" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-8_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-8_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-8" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-8_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-8_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-8" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-8_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-8_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-9" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-9_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-9_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-9" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-9_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-9_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-9" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-9_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-9_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-9" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-9_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-9_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-10" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-10_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-10_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-10" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-10_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-10_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-10" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-10_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-10_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-10" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-10_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-10_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-11" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-11_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-11_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-11" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-11_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-11_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-11" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-11_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-11_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-11" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-11_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-11_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-12" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-12_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-12_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-12" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-12_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-12_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-12" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-12_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-12_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-12" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-12_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-12_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u1097-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u1098-13" class="ax_default paragraph u1098" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u1098-13_div" class="u1098_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1098-13_text" class="text u1098_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u1099-13" class="ax_default paragraph u1099" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u1099-13_div" class="u1099_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1099-13_text" class="text u1099_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u1100-13" class="ax_default paragraph u1100" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u1100-13_div" class="u1100_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1100-13_text" class="text u1100_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u1101-13" class="ax_default paragraph u1101" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u1101-13_div" class="u1101_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u1101-13_text" class="text u1101_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u1102" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u1103" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u1104" class="ax_default paragraph selected" data-label="Others">
                          <div id="u1104_div" class="selected"></div>
                          <div id="u1104_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u1105" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u1105_div" class="selected"></div>
                          <div id="u1105_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u1106" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u1106_div" class="selected"></div>
                          <div id="u1106_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u1107" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u1107_div" class="selected"></div>
                          <div id="u1107_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u1108" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u1108_div" class="selected"></div>
                          <div id="u1108_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u1109" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u1109_div" class="selected"></div>
                          <div id="u1109_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u1110" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u1110_div" class="selected"></div>
                          <div id="u1110_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u1111" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u1111_div" class="selected"></div>
                          <div id="u1111_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u1112" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u1112_div" class="selected"></div>
                          <div id="u1112_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u1113" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u1113_div" class="selected"></div>
                          <div id="u1113_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u1114" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u1114_div" class="selected"></div>
                          <div id="u1114_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u1115" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u1115_div" class="selected"></div>
                          <div id="u1115_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1116" class="ax_default paragraph selected">
                          <div id="u1116_div" class="selected"></div>
                          <div id="u1116_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u1117" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u1117_div" class="selected"></div>
                        <div id="u1117_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u1118" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u1118_div" class="selected"></div>
                        <div id="u1118_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u1119" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u1119_div" class="selected"></div>
                        <div id="u1119_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u1120" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u1120_div" class="selected"></div>
                        <div id="u1120_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u1121" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u1121_div" class="selected"></div>
                        <div id="u1121_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u1122" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u1122_div" class="selected"></div>
                        <div id="u1122_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u1123" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u1123_div" class="selected"></div>
                    <div id="u1123_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u1124" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u1124_div" class="selected"></div>
                    <div id="u1124_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u1125" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u1125_div" class="selected"></div>
            <div id="u1125_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u1126" class="ax_default" data-label="TAW" data-left="783" data-top="340" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u1127" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u1127_div" class="selected"></div>
              <div id="u1127_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u1128" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u1128_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u1128_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u1129" class="ax_default" data-label="THW" data-left="68" data-top="340" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u1130" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u1130_div" class="selected"></div>
              <div id="u1130_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u1131" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u1131_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u1131_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u1132" class="ax_default" data-label="DRAW" data-left="425" data-top="340" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u1133" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u1133_div" class="selected"></div>
              <div id="u1133_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u1134" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u1134_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u658.svg"/>
              <div id="u1134_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u1135" class="ax_default box_3 selected">
            <img id="u1135_img" class="img " src="/footballui/public/frontend/images/page_a4/u659_selected.svg"/>
            <div id="u1135_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u1136" class="ax_default" data-label="Logo_Group" data-left="352" data-top="140" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u1137" class="ax_default image" data-label="TA_G">
            <img id="u1137_img" class="img " src="{{ asset($b1s->g_img) }}"/>
            <div id="u1137_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u1138" class="ax_default image" data-label="TH_G">
            <img id="u1138_img" class="img " src="{{ asset($b1s->h_img) }}"/>
            <div id="u1138_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u1139" class="ax_default box_2" data-label="Team_Away">
            <div id="u1139_div" class=""></div>
            <div id="u1139_text" class="text ">
              <p><span>{{ $b1s->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u1140" class="ax_default box_2" data-label="Team_Home">
            <div id="u1140_div" class=""></div>
            <div id="u1140_text" class="text ">
              <p><span>{{ $b1s->host }}</span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u1141" class="ax_default box_2" data-label="Status">
            <div id="u1141_div" class=""></div>
            <div id="u1141_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u1142" class="ax_default box_2" data-label="Number">
            <div id="u1142_div" class=""></div>
            <div id="u1142_text" class="text ">
              <p><span>{{ $b1s->jc_id }}</span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u1143" class="ax_default box_2" data-label="HKJC">
            <div id="u1143_div" class=""></div>
            <div id="u1143_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u1144" class="ax_default box_2" data-label="Date_Time">
            <div id="u1144_div" class=""></div>
            <div id="u1144_text" class="text ">
              <p><span>{{ $b1s->date }}</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u1145" class="ax_default box_2" data-label="Match">
            <div id="u1145_div" class=""></div>
            <div id="u1145_text" class="text ">
              <p><span>{{ $b1s->league }}</span></p>
            </div>
          </div>
        </div>
      </div>
    @endif
      <!-- Date (Group) -->
      <div id="u1146" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="30">

        <!-- Unnamed (Rectangle) -->
        <div id="u1147" class="ax_default box_1">
          <div id="u1147_div" class=""></div>
          <div id="u1147_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- After_tomorrow (Rectangle) -->
        <div id="u1148" class="ax_default label" data-label="">
          <div id="u1148_div" class=""></div>
          <div id="u1148_text" class="text " onclick="window.location='/footballui/public/page_a4d3';">
            <p><span>後日</span></p>
          </div>
        </div>

        <!-- Tomorrow (Rectangle) -->
        <div id="u1149" class="ax_default label" data-label="">
          <div id="u1149_div" class=""></div>
          <div id="u1149_text" class="text " onclick="window.location='/footballui/public/page_a4d2';">
            <p><span>明日</span></p>
          </div>
        </div>

        <!-- Today (Rectangle) -->
        <div id="u1150" class="ax_default label" data-label="" style="background-color:#5D5D5D">
          <div id="u1150_div" class=""></div>
          <div id="u1150_text" class="text " style="color:white">
            <p><span>今日</span></p>
          </div>
        </div>

        <!-- Match_date (Rectangle) -->
        <div id="u1151" class="ax_default label" data-label="Match_date">
          <div id="u1151_div" class=""></div>
          <div id="u1151_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div>
      </div>

      <!-- Header (Rectangle) -->
      <div id="u1152" class="ax_default box_2" data-label="Header">
        <div id="u1152_div" class=""></div>
        <div id="u1152_text" class="text ">
          <p><span>AI模組波膽分析</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u1154" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u1155" class="ax_default placeholder">
          <img id="u1155_img" class="img " src="/footballui/public/frontend/images/page_a2/u205.svg"/>
          <div id="u1155_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1156" class="ax_default box_1">
          <div id="u1156_div" class=""></div>
          <div id="u1156_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1157" class="ax_default box_3">
          <div id="u1157_div" class=""></div>
          <div id="u1157_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1158" class="ax_default box_3">
          <div id="u1158_div" class=""></div>
          <div id="u1158_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1159" class="ax_default box_3">
          <div id="u1159_div" class=""></div>
          <div id="u1159_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1160" class="ax_default box_3">
          <div id="u1160_div" class=""></div>
          <div id="u1160_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1161" class="ax_default box_3">
          <div id="u1161_div" class=""></div>
          <div id="u1161_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1162" class="ax_default box_3">
          <div id="u1162_div" class=""></div>
          <div id="u1162_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1163" class="ax_default box_3">
          <div id="u1163_div" class=""></div>
          <div id="u1163_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1164" class="ax_default">
          <div id="u1164_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1164_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u1165" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u1166" class="ax_default box_3">
                  <div id="u1166_div" class=""></div>
                  <div id="u1166_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1167" class="ax_default box_3">
                  <div id="u1167_div" class=""></div>
                  <div id="u1167_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1168" class="ax_default box_3">
                  <div id="u1168_div" class=""></div>
                  <div id="u1168_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1169" class="ax_default box_3">
                  <img id="u1169_img" class="img " src="/footballui/public/frontend/images/page_a2/u219.svg"/>
                  <div id="u1169_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1170" class="ax_default box_3">
                  <div id="u1170_div" class=""></div>
                  <div id="u1170_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1171" class="ax_default box_3">
                  <div id="u1171_div" class=""></div>
                  <div id="u1171_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1172" class="ax_default box_3">
                  <div id="u1172_div" class=""></div>
                  <div id="u1172_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1173" class="ax_default">
          <div id="u1173_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1173_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u1174" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u1175" class="ax_default box_3">
                  <div id="u1175_div" class=""></div>
                  <div id="u1175_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1176" class="ax_default box_3">
                  <div id="u1176_div" class=""></div>
                  <div id="u1176_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1177" class="ax_default box_3">
                  <div id="u1177_div" class=""></div>
                  <div id="u1177_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1178" class="ax_default box_3">
                  <img id="u1178_img" class="img " src="/footballui/public/frontend/images/page_a2/u228.svg"/>
                  <div id="u1178_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1179" class="ax_default box_3">
                  <div id="u1179_div" class=""></div>
                  <div id="u1179_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1180" class="ax_default box_3">
                  <div id="u1180_div" class=""></div>
                  <div id="u1180_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1181" class="ax_default">
          <div id="u1181_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1181_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u1182" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u1183" class="ax_default box_3">
                  <div id="u1183_div" class=""></div>
                  <div id="u1183_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1184" class="ax_default box_3">
                  <div id="u1184_div" class=""></div>
                  <div id="u1184_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u1185" class="ax_default box_3">
                  <div id="u1185_div" class=""></div>
                  <div id="u1185_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1186" class="ax_default box_3">
                  <img id="u1186_img" class="img " src="/footballui/public/frontend/images/page_a2/u236.svg"/>
                  <div id="u1186_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u1153" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u1188" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="2" data-top="-5" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u1189" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u1189_state0" class="panel_state" data-label="State 1" style="">
            <div id="u1189_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u1190" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u1191" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u1191_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u1191_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u1192" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1193" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1193_div" class=""></div>
                          <div id="u1193_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1194" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1194_div" class=""></div>
                          <div id="u1194_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1195" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1195_div" class=""></div>
                          <div id="u1195_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1196" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u1196_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u1196_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1197" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1197_div" class=""></div>
                          <div id="u1197_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1198" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1198_div" class=""></div>
                          <div id="u1198_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1199" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1199_div" class=""></div>
                          <div id="u1199_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1200" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u1200_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u1200_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u1201" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u1202" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u1202_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u1202_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u1203" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1204" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1204_div" class=""></div>
                          <div id="u1204_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1205" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u1205_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u1205_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1206" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1206_div" class=""></div>
                          <div id="u1206_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1207" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u1207_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u1207_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1208" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1208_div" class=""></div>
                          <div id="u1208_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1209" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u1209_div" class=""></div>
                          <div id="u1209_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1210" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u1210_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u1210_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u1211" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u1212" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u1212_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u1212_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u1213" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1214" class="ax_default box_3">
                          <div id="u1214_div" class=""></div>
                          <div id="u1214_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1215" class="ax_default box_3">
                          <img id="u1215_img" class="img " src="/footballui/public/frontend/images/page_a2/u265.svg"/>
                          <div id="u1215_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u1216" class="ax_default box_3">
                          <div id="u1216_div" class=""></div>
                          <div id="u1216_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u1217" class="ax_default box_3">
                          <img id="u1217_img" class="img " src="/footballui/public/frontend/images/page_a2/u267.svg"/>
                          <div id="u1217_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u1218" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u1218_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u1218_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1219" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1219_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u1219_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1220" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1220_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u1220_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1221" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1221_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u1221_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u1222" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u1222_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u1222_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u1223" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u1223_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u1223_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1224" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u1224_div" class=""></div>
          <div id="u1224_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u1225" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u1225_div" class=""></div>
          <div id="u1225_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u1187" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
