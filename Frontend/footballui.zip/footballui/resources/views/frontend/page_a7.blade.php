﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A7</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a7/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a7/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Chart_bg (Rectangle) -->
      <div id="u0" class="ax_default box_2" data-label="Chart_bg">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Upset_G (Image) -->
      <div id="u1" class="ax_default image" data-label="Upset_G">
        <img id="u1_img" class="img " src="/footballui/public/frontend/images/page_a7/upset_g_u1.png"/>
        <div id="u1_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Button (Group) -->
      <div id="u2" class="ax_default" data-label="Button" data-left="828" data-top="631" data-width="262" data-height="40">

        <!-- AI_Button (Rectangle) -->
        <div id="u3" class="ax_default box_3" data-label="AI_Button">
          <div id="u3_div" class=""></div>
          <div id="u3_text" class="text ">
            <p><span>足球AI模組分析 &gt;&gt;&gt;</span></p>
          </div>
        </div>

        <!-- Button_HotSpot (Hot Spot) -->
        <div id="u4" class="ax_default" data-label="Button_HotSpot">
        </div>
      </div>

      <!-- Table_rtg (Rectangle) -->
      <div id="u5" class="ax_default box_2" data-label="Table_rtg">
        <div id="u5_div" class=""></div>
        <div id="u5_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Upset_db (Group) -->
      <div id="u6" class="ax_default" data-label="Upset_db" data-left="245" data-top="271" data-width="430" data-height="400">

        <!-- Upset_Repeater (Repeater) -->
        <div id="u7" class="ax_default" data-label="Upset_Repeater">
          <script id="u7_script" type="axure-repeater-template" data-label="Upset_Repeater">

            <!-- bold_1a (Rectangle) -->
            <div id="u8" class="ax_default box_1 u8" data-label="bold_1a">
              <div id="u8_div" class="u8_div"></div>
              <div id="u8_text" class="text u8_text">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9" class="ax_default paragraph u9" data-label="bold_0a">
              <div id="u9_div" class="u9_div"></div>
              <div id="u9_text" class="text u9_text">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </script>
          <div id="u7-1" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-1" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-1_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-1_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-1" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-1_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-1_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-2" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-2" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-2_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-2_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-2" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-2_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-2_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-3" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-3" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-3_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-3_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-3" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-3_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-3_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-4" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-4" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-4_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-4_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-4" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-4_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-4_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-5" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-5" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-5_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-5_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-5" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-5_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-5_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-6" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-6" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-6_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-6_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-6" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-6_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-6_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-7" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-7" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-7_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-7_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-7" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-7_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-7_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-8" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-8" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-8_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-8_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-8" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-8_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-8_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-9" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-9" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-9_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-9_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-9" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-9_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-9_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u7-10" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u8-10" class="ax_default box_1 u8" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u8-10_div" class="u8_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u8-10_text" class="text u8_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u9-10" class="ax_default paragraph u9" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u9-10_div" class="u9_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u9-10_text" class="text u9_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Upset (Group) -->
      <div id="u10" class="ax_default" data-label="Upset" data-left="150" data-top="231" data-width="525" data-height="440">

        <!-- Items_Group (Group) -->
        <div id="u11" class="ax_default" data-label="Items_Group" data-left="150" data-top="271" data-width="95" data-height="400">

          <!-- 10 (Rectangle) -->
          <div id="u12" class="ax_default paragraph" data-label="10">
            <div id="u12_div" class=""></div>
            <div id="u12_text" class="text ">
              <p><span>10</span></p>
            </div>
          </div>

          <!-- 9 (Rectangle) -->
          <div id="u13" class="ax_default paragraph" data-label="9">
            <div id="u13_div" class=""></div>
            <div id="u13_text" class="text ">
              <p><span>9</span></p>
            </div>
          </div>

          <!-- 8 (Rectangle) -->
          <div id="u14" class="ax_default paragraph" data-label="8">
            <div id="u14_div" class=""></div>
            <div id="u14_text" class="text ">
              <p><span>8</span></p>
            </div>
          </div>

          <!-- 7 (Rectangle) -->
          <div id="u15" class="ax_default paragraph" data-label="7">
            <div id="u15_div" class=""></div>
            <div id="u15_text" class="text ">
              <p><span>7</span></p>
            </div>
          </div>

          <!-- 6 (Rectangle) -->
          <div id="u16" class="ax_default paragraph" data-label="6">
            <div id="u16_div" class=""></div>
            <div id="u16_text" class="text ">
              <p><span>6</span></p>
            </div>
          </div>

          <!-- 5 (Rectangle) -->
          <div id="u17" class="ax_default paragraph" data-label="5">
            <div id="u17_div" class=""></div>
            <div id="u17_text" class="text ">
              <p><span>5</span></p>
            </div>
          </div>

          <!-- 4 (Rectangle) -->
          <div id="u18" class="ax_default paragraph" data-label="4">
            <div id="u18_div" class=""></div>
            <div id="u18_text" class="text ">
              <p><span>4</span></p>
            </div>
          </div>

          <!-- 3 (Rectangle) -->
          <div id="u19" class="ax_default paragraph" data-label="3">
            <div id="u19_div" class=""></div>
            <div id="u19_text" class="text ">
              <p><span>3</span></p>
            </div>
          </div>

          <!-- 2 (Rectangle) -->
          <div id="u20" class="ax_default paragraph" data-label="2">
            <div id="u20_div" class=""></div>
            <div id="u20_text" class="text ">
              <p><span>2</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u21" class="ax_default paragraph">
            <div id="u21_div" class=""></div>
            <div id="u21_text" class="text ">
              <p><span>1</span></p>
            </div>
          </div>
        </div>

        <!-- Items_rtg (Rectangle) -->
        <div id="u22" class="ax_default box_3" data-label="Items_rtg">
          <div id="u22_div" class=""></div>
          <div id="u22_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Predict (Rectangle) -->
        <div id="u23" class="ax_default paragraph" data-label="Predict">
          <div id="u23_div" class=""></div>
          <div id="u23_text" class="text ">
            <p><span>預測結果</span></p>
          </div>
        </div>

        <!-- Game (Rectangle) -->
        <div id="u24" class="ax_default paragraph" data-label="Game">
          <div id="u24_div" class=""></div>
          <div id="u24_text" class="text ">
            <p><span>比賽場次</span></p>
          </div>
        </div>

        <!-- Items (Rectangle) -->
        <div id="u25" class="ax_default paragraph" data-label="Items">
          <div id="u25_div" class=""></div>
          <div id="u25_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Team_G (Image) -->
      <div id="u26" class="ax_default image" data-label="Team_G">
        <img id="u26_img" class="img " src="/footballui/public/frontend/images/page_a7/team_g_u26.png"/>
        <div id="u26_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Header_team (Rectangle) -->
      <div id="u27" class="ax_default box_2" data-label="Header_team">
        <div id="u27_div" class=""></div>
        <div id="u27_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Header (Rectangle) -->
      <div id="u28" class="ax_default box_2" data-label="Header">
        <div id="u28_div" class=""></div>
        <div id="u28_text" class="text ">
          <p><span>AI模組爆冷精選</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u30" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Rectangle) -->
        <div id="u31" class="ax_default box_1">
          <div id="u31_div" class=""></div>
          <div id="u31_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u32" class="ax_default box_3">
          <div id="u32_div" class=""></div>
          <div id="u32_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u33" class="ax_default box_3">
          <div id="u33_div" class=""></div>
          <div id="u33_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u34" class="ax_default box_3">
          <div id="u34_div" class=""></div>
          <div id="u34_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u35" class="ax_default box_3">
          <div id="u35_div" class=""></div>
          <div id="u35_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u36" class="ax_default box_3">
          <div id="u36_div" class=""></div>
          <div id="u36_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u37" class="ax_default box_3">
          <div id="u37_div" class=""></div>
          <div id="u37_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u38" class="ax_default box_3">
          <div id="u38_div" class=""></div>
          <div id="u38_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u39" class="ax_default">
          <div id="u39_state0" class="panel_state" data-label="State 1" style="">
            <div id="u39_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u40" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u41" class="ax_default box_3">
                  <div id="u41_div" class=""></div>
                  <div id="u41_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u42" class="ax_default box_3">
                  <div id="u42_div" class=""></div>
                  <div id="u42_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u43" class="ax_default box_3">
                  <div id="u43_div" class=""></div>
                  <div id="u43_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u44" class="ax_default box_3">
                  <img id="u44_img" class="img " src="/footballui/public/frontend/images/page_a7/u44.svg"/>
                  <div id="u44_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u45" class="ax_default box_3">
                  <div id="u45_div" class=""></div>
                  <div id="u45_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u46" class="ax_default box_3">
                  <div id="u46_div" class=""></div>
                  <div id="u46_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u47" class="ax_default box_3">
                  <div id="u47_div" class=""></div>
                  <div id="u47_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u48" class="ax_default">
          <div id="u48_state0" class="panel_state" data-label="State 1" style="">
            <div id="u48_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u49" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u50" class="ax_default box_3">
                  <div id="u50_div" class=""></div>
                  <div id="u50_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u51" class="ax_default box_3">
                  <div id="u51_div" class=""></div>
                  <div id="u51_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u52" class="ax_default box_3">
                  <div id="u52_div" class=""></div>
                  <div id="u52_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u53" class="ax_default box_3">
                  <img id="u53_img" class="img " src="/footballui/public/frontend/images/page_a7/u53.svg"/>
                  <div id="u53_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u54" class="ax_default box_3">
                  <div id="u54_div" class=""></div>
                  <div id="u54_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u55" class="ax_default box_3">
                  <div id="u55_div" class=""></div>
                  <div id="u55_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u56" class="ax_default">
          <div id="u56_state0" class="panel_state" data-label="State 1" style="">
            <div id="u56_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u57" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u58" class="ax_default box_3">
                  <div id="u58_div" class=""></div>
                  <div id="u58_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u59" class="ax_default box_3">
                  <div id="u59_div" class=""></div>
                  <div id="u59_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u60" class="ax_default box_3">
                  <div id="u60_div" class=""></div>
                  <div id="u60_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u61" class="ax_default box_3">
                  <img id="u61_img" class="img " src="/footballui/public/frontend/images/page_a7/u61.svg"/>
                  <div id="u61_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Image) -->
        <div id="u62" class="ax_default image">
          <img id="u62_img" class="img " src="/footballui/public/frontend/images/page_a7/u62.jpg"/>
          <div id="u62_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>
      <div id="u29" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u64" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="2" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u65" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u65_state0" class="panel_state" data-label="State 1" style="">
            <div id="u65_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u66" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u67" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u67_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u67_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u68" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u69" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u69_div" class=""></div>
                          <div id="u69_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u70" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u70_div" class=""></div>
                          <div id="u70_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u71" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u71_div" class=""></div>
                          <div id="u71_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u72" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u72_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u72_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u73" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u73_div" class=""></div>
                          <div id="u73_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u74" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u74_div" class=""></div>
                          <div id="u74_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u75" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u75_div" class=""></div>
                          <div id="u75_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u76" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u76_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u76_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u77" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u78" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u78_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u78_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u79" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u80" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u80_div" class=""></div>
                          <div id="u80_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u81" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u81_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u81_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u82" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u82_div" class=""></div>
                          <div id="u82_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u83" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u83_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u83_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u84" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u84_div" class=""></div>
                          <div id="u84_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u85" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u85_div" class=""></div>
                          <div id="u85_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u86" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u86_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u86_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u87" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u88" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u88_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u88_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u89" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u90" class="ax_default box_3">
                          <div id="u90_div" class=""></div>
                          <div id="u90_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u91" class="ax_default box_3">
                          <img id="u91_img" class="img " src="/footballui/public/frontend/images/page_a7/u91.svg"/>
                          <div id="u91_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u92" class="ax_default box_3">
                          <div id="u92_div" class=""></div>
                          <div id="u92_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u93" class="ax_default box_3">
                          <img id="u93_img" class="img " src="/footballui/public/frontend/images/page_a7/u93.svg"/>
                          <div id="u93_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u94" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u94_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u94_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u95" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u95_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u95_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u96" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u96_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u96_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u97" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u97_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u97_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u98" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u98_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u98_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u99" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u99_div" class=""></div>
          <div id="u99_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u100" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u100_div" class=""></div>
          <div id="u100_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>

        <!-- Unnamed (Image) -->
        <div id="u101" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u101_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u101_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>
      <div id="u63" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
