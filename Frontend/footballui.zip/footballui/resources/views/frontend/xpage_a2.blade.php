﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A2</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a2/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a2/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Update_time (Rectangle) -->
      <div id="u0" class="ax_default label" data-label="Update_time">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!--@if(isset($b2s))

      @if(isset($b1s))-->
      @foreach($b1s as $b1datum)
      @foreach($b2s as $b2datum)


      <!-- Vote_5 (Group) -->
      <div id="u1" class="ax_default" data-label="Vote_5" data-left="114" data-top="1896" data-width="1144" data-height="430">

        <!-- Unnamed (Rectangle) -->
        <div id="u2" class="ax_default box_1">
          <div id="u2_div" class=""></div>
          <div id="u2_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Rate_table (Group) -->
        <div id="u3" class="ax_default" data-label="Rate_table" data-left="332" data-top="2206" data-width="716" data-height="80">

          <!-- TAW_rtg (Rectangle) -->
          <div id="u4" class="ax_default box_2" data-label="TAW_rtg">
            <div id="u4_div" class=""></div>
            <div id="u4_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_rprv (Rectangle) -->
          <div id="u5" class="ax_default paragraph" data-label="TAW_rprv">
            <div id="u5_div" class=""></div>
            <div id="u5_text" class="text ">
              <p><span>{{ $b1datum->g_win }}%</span></p>
            </div>
          </div>

          <!-- TAW_rpr (Rectangle) -->
          <div id="u6" class="ax_default paragraph" data-label="TAW_rpr">
            <div id="u6_div" class=""></div>
            <div id="u6_text" class="text ">
              <p><span>客隊勝率</span></p>
            </div>
          </div>

          <!-- TAW_rv (Rectangle) -->
          <div id="u7" class="ax_default paragraph" data-label="TAW_rv">
            <div id="u7_div" class=""></div>
            <div id="u7_text" class="text ">
              <p><span>{{ $b2datum->g_gress }}</span></p>
            </div>
          </div>

          <!-- TAW_r (Rectangle) -->
          <div id="u8" class="ax_default paragraph" data-label="TAW_r">
            <div id="u8_div" class=""></div>
            <div id="u8_text" class="text ">
              <p><span>客隊票數</span></p>
            </div>
          </div>

          <!-- DR_rtg (Rectangle) -->
          <div id="u9" class="ax_default box_2" data-label="DR_rtg">
            <div id="u9_div" class=""></div>
            <div id="u9_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DR_rprv (Rectangle) -->
          <div id="u10" class="ax_default paragraph" data-label="DR_rprv">
            <div id="u10_div" class=""></div>
            <div id="u10_text" class="text ">
              <p><span>{{ $b1datum->draw }}%</span></p>
            </div>
          </div>

          <!-- DR_rpr (Rectangle) -->
          <div id="u11" class="ax_default paragraph" data-label="DR_rpr">
            <div id="u11_div" class=""></div>
            <div id="u11_text" class="text ">
              <p><span>和波機率</span></p>
            </div>
          </div>

          <!-- DR_rv (Rectangle) -->
          <div id="u12" class="ax_default paragraph" data-label="DR_rv">
            <div id="u12_div" class=""></div>
            <div id="u12_text" class="text ">
              <p><span>{{ $b2datum->d_gress }}</span></p>
            </div>
          </div>

          <!-- DR_r (Rectangle) -->
          <div id="u13" class="ax_default paragraph" data-label="DR_r">
            <div id="u13_div" class=""></div>
            <div id="u13_text" class="text ">
              <p><span>和波票數</span></p>
            </div>
          </div>

          <!-- THW_rtg (Rectangle) -->
          <div id="u14" class="ax_default box_2" data-label="THW_rtg">
            <div id="u14_div" class=""></div>
            <div id="u14_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_rprv (Rectangle) -->
          <div id="u15" class="ax_default paragraph" data-label="THW_rprv">
            <div id="u15_div" class=""></div>
            <div id="u15_text" class="text ">
              <p><span>{{ $b1datum->h_win }}%</span></p>
            </div>
          </div>

          <!-- THW_rpr (Rectangle) -->
          <div id="u16" class="ax_default paragraph" data-label="THW_rpr">
            <div id="u16_div" class=""></div>
            <div id="u16_text" class="text ">
              <p><span>主隊勝率</span></p>
            </div>
          </div>

          <!-- THW_rv (Rectangle) -->
          <div id="u17" class="ax_default paragraph" data-label="THW_rv">
            <div id="u17_div" class=""></div>
            <div id="u17_text" class="text ">
              <p><span>{{ $b2datum->h_gress }}</span></p>
            </div>
          </div>

          <!-- THW_r (Rectangle) -->
          <div id="u18" class="ax_default paragraph" data-label="THW_r">
            <div id="u18_div" class=""></div>
            <div id="u18_text" class="text ">
              <p><span>主隊票數</span></p>
            </div>
          </div>
        </div>

        <!-- Rate_Group (Group) -->
        <div id="u19" class="ax_default" data-label="Rate_Group" data-left="150" data-top="2066" data-width="1072" data-height="81">

          <!-- Rate_bar (Rectangle) -->
          <div id="u20" class="ax_default box_1" data-label="Rate_bar">
            <div id="u20_div" class=""></div>
            <div id="u20_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u21" class="ax_default" data-label="TAW" data-left="632" data-top="2066" data-width="590" data-height="80">

            <!-- TAW_D (Rectangle) -->
            <div id="u22" class="ax_default box_1" data-label="TAW_D">
              <div id="u22_div" class=""></div>
              <div id="u22_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u23" class="ax_default box_1" data-label="TAW_Dt">
              <img id="u23_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u23_text" class="text ">
                <p><span>客勝 55%</span></p>
              </div>
            </div>

            <!-- TAW_U (Rectangle) -->
            <div id="u24" class="ax_default box_1" data-label="TAW_U">
              <img id="u24_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_u_u24.svg"/>
              <div id="u24_text" class="text ">
                <p><span>7000</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u25" class="ax_default" data-label="THW" data-left="150" data-top="2067" data-width="257" data-height="80">

            <!-- THW_D (Rectangle) -->
            <div id="u26" class="ax_default box_1" data-label="THW_D">
              <div id="u26_div" class=""></div>
              <div id="u26_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u27" class="ax_default box_1" data-label="THW_Dt">
              <img id="u27_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u27_text" class="text ">
                <p><span>主勝 24%</span></p>
              </div>
            </div>

            <!-- THW_U (Rectangle) -->
            <div id="u28" class="ax_default box_1" data-label="THW_U">
              <img id="u28_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_u_u28.svg"/>
              <div id="u28_text" class="text ">
                <p><span>3000</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u29" class="ax_default" data-label="DRAW" data-left="407" data-top="2066" data-width="225" data-height="80">

            <!-- DRAW_D (Rectangle) -->
            <div id="u30" class="ax_default box_1" data-label="DRAW_D">
              <div id="u30_div" class=""></div>
              <div id="u30_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u31" class="ax_default box_1" data-label="DRAW_Dt">
              <img id="u31_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_dt_u31.svg"/>
              <div id="u31_text" class="text ">
                <p><span>和 21%</span></p>
              </div>
            </div>

            <!-- DRAW_U (Rectangle) -->
            <div id="u32" class="ax_default box_1" data-label="DRAW_U">
              <img id="u32_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_u_u32.svg"/>
              <div id="u32_text" class="text ">
                <p><span>2600</span></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u33" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1900" data-width="680" data-height="140">

          <!-- TA_G (Image) -->
          <div id="u34" class="ax_default image" data-label="TA_G">
            <img id="u34_img" class="img " src="{{ asset($b1datum->g_img) }}"/>
            <div id="u34_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u35" class="ax_default image" data-label="TH_G">
            <img id="u35_img" class="img " src="{{ asset($b1datum->h_img) }}"/>
            <div id="u35_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u36" class="ax_default box_2" data-label="Team_Away">
            <div id="u36_div" class=""></div>
            <div id="u36_text" class="text ">
              <p><span>{{ $b1datum->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u37" class="ax_default box_2" data-label="Team_Home">
            <div id="u37_div" class=""></div>
            <div id="u37_text" class="text ">
              <p><span>{{ $b1datum->host }}</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u38" class="ax_default box_2" data-label="Date_Time">
            <div id="u38_div" class=""></div>
            <div id="u38_text" class="text ">
              <p><span>{{ Carbon\Carbon::parse($b1datum->date)->diffForHumans() }}開波</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u39" class="ax_default box_2" data-label="Match">
            <div id="u39_div" class=""></div>
            <div id="u39_text" class="text ">
              <p><span>{{ $b1datum->league }}</span></p>
            </div>
          </div>
        </div>
      </div>



      <!-- Vote_4 (Group) -->
      <div id="u40" class="ax_default" data-label="Vote_4" data-left="114" data-top="1456" data-width="1144" data-height="430">

        <!-- Unnamed (Rectangle) -->
        <div id="u41" class="ax_default box_1">
          <div id="u41_div" class=""></div>
          <div id="u41_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Rate_table (Group) -->
        <div id="u42" class="ax_default" data-label="Rate_table" data-left="332" data-top="1766" data-width="716" data-height="80">

          <!-- TAW_rtg (Rectangle) -->
          <div id="u43" class="ax_default box_2" data-label="TAW_rtg">
            <div id="u43_div" class=""></div>
            <div id="u43_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_rprv (Rectangle) -->
          <div id="u44" class="ax_default paragraph" data-label="TAW_rprv">
            <div id="u44_div" class=""></div>
            <div id="u44_text" class="text ">
              <p><span>{{ $b1datum->g_win }}%</span></p>
            </div>
          </div>

          <!-- TAW_rpr (Rectangle) -->
          <div id="u45" class="ax_default paragraph" data-label="TAW_rpr">
            <div id="u45_div" class=""></div>
            <div id="u45_text" class="text ">
              <p><span>客隊勝率</span></p>
            </div>
          </div>

          <!-- TAW_rv (Rectangle) -->
          <div id="u46" class="ax_default paragraph" data-label="TAW_rv">
            <div id="u46_div" class=""></div>
            <div id="u46_text" class="text ">
              <p><span>{{ $b2datum->g_gress }}</span></p>
            </div>
          </div>

          <!-- TAW_r (Rectangle) -->
          <div id="u47" class="ax_default paragraph" data-label="TAW_r">
            <div id="u47_div" class=""></div>
            <div id="u47_text" class="text ">
              <p><span>客隊票數</span></p>
            </div>
          </div>

          <!-- DR_rtg (Rectangle) -->
          <div id="u48" class="ax_default box_2" data-label="DR_rtg">
            <div id="u48_div" class=""></div>
            <div id="u48_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DR_rprv (Rectangle) -->
          <div id="u49" class="ax_default paragraph" data-label="DR_rprv">
            <div id="u49_div" class=""></div>
            <div id="u49_text" class="text ">
              <p><span>{{ $b1datum->draw }}%</span></p>
            </div>
          </div>

          <!-- DR_rpr (Rectangle) -->
          <div id="u50" class="ax_default paragraph" data-label="DR_rpr">
            <div id="u50_div" class=""></div>
            <div id="u50_text" class="text ">
              <p><span>和波機率</span></p>
            </div>
          </div>

          <!-- DR_rv (Rectangle) -->
          <div id="u51" class="ax_default paragraph" data-label="DR_rv">
            <div id="u51_div" class=""></div>
            <div id="u51_text" class="text ">
              <p><span>{{ $b2datum->d_gress }}</span></p>
            </div>
          </div>

          <!-- DR_r (Rectangle) -->
          <div id="u52" class="ax_default paragraph" data-label="DR_r">
            <div id="u52_div" class=""></div>
            <div id="u52_text" class="text ">
              <p><span>和波票數</span></p>
            </div>
          </div>

          <!-- THW_rtg (Rectangle) -->
          <div id="u53" class="ax_default box_2" data-label="THW_rtg">
            <div id="u53_div" class=""></div>
            <div id="u53_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_rprv (Rectangle) -->
          <div id="u54" class="ax_default paragraph" data-label="THW_rprv">
            <div id="u54_div" class=""></div>
            <div id="u54_text" class="text ">
              <p><span>{{ $b1datum->h_win }}%</span></p>
            </div>
          </div>

          <!-- THW_rpr (Rectangle) -->
          <div id="u55" class="ax_default paragraph" data-label="THW_rpr">
            <div id="u55_div" class=""></div>
            <div id="u55_text" class="text ">
              <p><span>主隊勝率</span></p>
            </div>
          </div>

          <!-- THW_rv (Rectangle) -->
          <div id="u56" class="ax_default paragraph" data-label="THW_rv">
            <div id="u56_div" class=""></div>
            <div id="u56_text" class="text ">
              <p><span>{{ $b2datum->h_gress }}</span></p>
            </div>
          </div>

          <!-- THW_r (Rectangle) -->
          <div id="u57" class="ax_default paragraph" data-label="THW_r">
            <div id="u57_div" class=""></div>
            <div id="u57_text" class="text ">
              <p><span>主隊票數</span></p>
            </div>
          </div>
        </div>

        <!-- Rate_Group (Group) -->
        <div id="u58" class="ax_default" data-label="Rate_Group" data-left="150" data-top="1626" data-width="1072" data-height="81">

          <!-- Rate_bar (Rectangle) -->
          <div id="u59" class="ax_default box_1" data-label="Rate_bar">
            <div id="u59_div" class=""></div>
            <div id="u59_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u60" class="ax_default" data-label="TAW" data-left="632" data-top="1626" data-width="590" data-height="80">

            <!-- TAW_D (Rectangle) -->
            <div id="u61" class="ax_default box_1" data-label="TAW_D">
              <div id="u61_div" class=""></div>
              <div id="u61_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u62" class="ax_default box_1" data-label="TAW_Dt">
              <img id="u62_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u62_text" class="text ">
                <p><span>客勝 55%</span></p>
              </div>
            </div>

            <!-- TAW_U (Rectangle) -->
            <div id="u63" class="ax_default box_1" data-label="TAW_U">
              <img id="u63_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_u_u24.svg"/>
              <div id="u63_text" class="text ">
                <p><span>7000</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u64" class="ax_default" data-label="THW" data-left="150" data-top="1627" data-width="257" data-height="80">

            <!-- THW_D (Rectangle) -->
            <div id="u65" class="ax_default box_1" data-label="THW_D">
              <div id="u65_div" class=""></div>
              <div id="u65_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u66" class="ax_default box_1" data-label="THW_Dt">
              <img id="u66_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u66_text" class="text ">
                <p><span>主勝 24%</span></p>
              </div>
            </div>

            <!-- THW_U (Rectangle) -->
            <div id="u67" class="ax_default box_1" data-label="THW_U">
              <img id="u67_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_u_u28.svg"/>
              <div id="u67_text" class="text ">
                <p><span>3000</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u68" class="ax_default" data-label="DRAW" data-left="407" data-top="1626" data-width="225" data-height="80">

            <!-- DRAW_D (Rectangle) -->
            <div id="u69" class="ax_default box_1" data-label="DRAW_D">
              <div id="u69_div" class=""></div>
              <div id="u69_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u70" class="ax_default box_1" data-label="DRAW_Dt">
              <img id="u70_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_dt_u31.svg"/>
              <div id="u70_text" class="text ">
                <p><span>和 21%</span></p>
              </div>
            </div>

            <!-- DRAW_U (Rectangle) -->
            <div id="u71" class="ax_default box_1" data-label="DRAW_U">
              <img id="u71_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_u_u32.svg"/>
              <div id="u71_text" class="text ">
                <p><span>2600</span></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u72" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1460" data-width="680" data-height="140">

          <!-- TA_G (Image) -->
          <div id="u73" class="ax_default image" data-label="TA_G">
            <img id="u73_img" class="img " src="{{ asset($b1datum->g_img) }}"/>
            <div id="u73_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u74" class="ax_default image" data-label="TH_G">
            <img id="u74_img" class="img " src="{{ asset($b1datum->h_img) }}"/>
            <div id="u74_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u75" class="ax_default box_2" data-label="Team_Away">
            <div id="u75_div" class=""></div>
            <div id="u75_text" class="text ">
              <p><span>{{ $b1datum->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u76" class="ax_default box_2" data-label="Team_Home">
            <div id="u76_div" class=""></div>
            <div id="u76_text" class="text ">
              <p><span>{{ $b1datum->host }}</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u77" class="ax_default box_2" data-label="Date_Time">
            <div id="u77_div" class=""></div>
            <div id="u77_text" class="text ">
              <p><span>{{ Carbon\Carbon::parse($b1datum->date)->diffForHumans() }}開波</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u78" class="ax_default box_2" data-label="Match">
            <div id="u78_div" class=""></div>
            <div id="u78_text" class="text ">
              <p><span>{{ $b1datum->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Vote_3 (Group) -->
      <div id="u79" class="ax_default" data-label="Vote_3" data-left="114" data-top="1016" data-width="1144" data-height="430">

        <!-- Unnamed (Rectangle) -->
        <div id="u80" class="ax_default box_1">
          <div id="u80_div" class=""></div>
          <div id="u80_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Rate_table (Group) -->
        <div id="u81" class="ax_default" data-label="Rate_table" data-left="332" data-top="1326" data-width="716" data-height="80">

          <!-- TAW_rtg (Rectangle) -->
          <div id="u82" class="ax_default box_2" data-label="TAW_rtg">
            <div id="u82_div" class=""></div>
            <div id="u82_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_rprv (Rectangle) -->
          <div id="u83" class="ax_default paragraph" data-label="TAW_rprv">
            <div id="u83_div" class=""></div>
            <div id="u83_text" class="text ">
              <p><span>{{ $b1datum->g_win }}%</span></p>
            </div>
          </div>

          <!-- TAW_rpr (Rectangle) -->
          <div id="u84" class="ax_default paragraph" data-label="TAW_rpr">
            <div id="u84_div" class=""></div>
            <div id="u84_text" class="text ">
              <p><span>客隊勝率</span></p>
            </div>
          </div>

          <!-- TAW_rv (Rectangle) -->
          <div id="u85" class="ax_default paragraph" data-label="TAW_rv">
            <div id="u85_div" class=""></div>
            <div id="u85_text" class="text ">
              <p><span>{{ $b2datum->g_gress }}</span></p>
            </div>
          </div>

          <!-- TAW_r (Rectangle) -->
          <div id="u86" class="ax_default paragraph" data-label="TAW_r">
            <div id="u86_div" class=""></div>
            <div id="u86_text" class="text ">
              <p><span>客隊票數</span></p>
            </div>
          </div>

          <!-- DR_rtg (Rectangle) -->
          <div id="u87" class="ax_default box_2" data-label="DR_rtg">
            <div id="u87_div" class=""></div>
            <div id="u87_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DR_rprv (Rectangle) -->
          <div id="u88" class="ax_default paragraph" data-label="DR_rprv">
            <div id="u88_div" class=""></div>
            <div id="u88_text" class="text ">
              <p><span>{{ $b1datum->draw }}%<</span></p>
            </div>
          </div>

          <!-- DR_rpr (Rectangle) -->
          <div id="u89" class="ax_default paragraph" data-label="DR_rpr">
            <div id="u89_div" class=""></div>
            <div id="u89_text" class="text ">
              <p><span>和波機率</span></p>
            </div>
          </div>

          <!-- DR_rv (Rectangle) -->
          <div id="u90" class="ax_default paragraph" data-label="DR_rv">
            <div id="u90_div" class=""></div>
            <div id="u90_text" class="text ">
              <p><span>{{ $b2datum->d_gress }}</span></p>
            </div>
          </div>

          <!-- DR_r (Rectangle) -->
          <div id="u91" class="ax_default paragraph" data-label="DR_r">
            <div id="u91_div" class=""></div>
            <div id="u91_text" class="text ">
              <p><span>和波票數</span></p>
            </div>
          </div>

          <!-- THW_rtg (Rectangle) -->
          <div id="u92" class="ax_default box_2" data-label="THW_rtg">
            <div id="u92_div" class=""></div>
            <div id="u92_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_rprv (Rectangle) -->
          <div id="u93" class="ax_default paragraph" data-label="THW_rprv">
            <div id="u93_div" class=""></div>
            <div id="u93_text" class="text ">
              <p><span>{{ $b1datum->h_win }}%</span></p>
            </div>
          </div>

          <!-- THW_rpr (Rectangle) -->
          <div id="u94" class="ax_default paragraph" data-label="THW_rpr">
            <div id="u94_div" class=""></div>
            <div id="u94_text" class="text ">
              <p><span>主隊勝率</span></p>
            </div>
          </div>

          <!-- THW_rv (Rectangle) -->
          <div id="u95" class="ax_default paragraph" data-label="THW_rv">
            <div id="u95_div" class=""></div>
            <div id="u95_text" class="text ">
              <p><span>{{ $b2datum->h_gress }}</span></p>
            </div>
          </div>

          <!-- THW_r (Rectangle) -->
          <div id="u96" class="ax_default paragraph" data-label="THW_r">
            <div id="u96_div" class=""></div>
            <div id="u96_text" class="text ">
              <p><span>主隊票數</span></p>
            </div>
          </div>
        </div>

        <!-- Rate_Group (Group) -->
        <div id="u97" class="ax_default" data-label="Rate_Group" data-left="150" data-top="1186" data-width="1072" data-height="81">

          <!-- Rate_bar (Rectangle) -->
          <div id="u98" class="ax_default box_1" data-label="Rate_bar">
            <div id="u98_div" class=""></div>
            <div id="u98_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u99" class="ax_default" data-label="TAW" data-left="632" data-top="1186" data-width="590" data-height="80">

            <!-- TAW_D (Rectangle) -->
            <div id="u100" class="ax_default box_1" data-label="TAW_D">
              <div id="u100_div" class=""></div>
              <div id="u100_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u101" class="ax_default box_1" data-label="TAW_Dt">
              <img id="u101_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u101_text" class="text ">
                <p><span>客勝 55%</span></p>
              </div>
            </div>

            <!-- TAW_U (Rectangle) -->
            <div id="u102" class="ax_default box_1" data-label="TAW_U">
              <img id="u102_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_u_u24.svg"/>
              <div id="u102_text" class="text ">
                <p><span>7000</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u103" class="ax_default" data-label="THW" data-left="150" data-top="1187" data-width="257" data-height="80">

            <!-- THW_D (Rectangle) -->
            <div id="u104" class="ax_default box_1" data-label="THW_D">
              <div id="u104_div" class=""></div>
              <div id="u104_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u105" class="ax_default box_1" data-label="THW_Dt">
              <img id="u105_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u105_text" class="text ">
                <p><span>主勝 24%</span></p>
              </div>
            </div>

            <!-- THW_U (Rectangle) -->
            <div id="u106" class="ax_default box_1" data-label="THW_U">
              <img id="u106_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_u_u28.svg"/>
              <div id="u106_text" class="text ">
                <p><span>3000</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u107" class="ax_default" data-label="DRAW" data-left="407" data-top="1186" data-width="225" data-height="80">

            <!-- DRAW_D (Rectangle) -->
            <div id="u108" class="ax_default box_1" data-label="DRAW_D">
              <div id="u108_div" class=""></div>
              <div id="u108_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u109" class="ax_default box_1" data-label="DRAW_Dt">
              <img id="u109_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_dt_u31.svg"/>
              <div id="u109_text" class="text ">
                <p><span>和 21%</span></p>
              </div>
            </div>

            <!-- DRAW_U (Rectangle) -->
            <div id="u110" class="ax_default box_1" data-label="DRAW_U">
              <img id="u110_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_u_u32.svg"/>
              <div id="u110_text" class="text ">
                <p><span>2600</span></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u111" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1020" data-width="680" data-height="140">

          <!-- TA_G (Image) -->
          <div id="u112" class="ax_default image" data-label="TA_G">
            <img id="u112_img" class="img " src="{{ asset($b1datum->g_img) }}"/>
            <div id="u112_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u113" class="ax_default image" data-label="TH_G">
            <img id="u113_img" class="img " src="{{ asset($b1datum->h_img) }}"/>
            <div id="u113_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u114" class="ax_default box_2" data-label="Team_Away">
            <div id="u114_div" class=""></div>
            <div id="u114_text" class="text ">
              <p><span>{{ $b1datum->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u115" class="ax_default box_2" data-label="Team_Home">
            <div id="u115_div" class=""></div>
            <div id="u115_text" class="text ">
              <p><span>{{ $b1datum->host }}</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u116" class="ax_default box_2" data-label="Date_Time">
            <div id="u116_div" class=""></div>
            <div id="u116_text" class="text ">
              <p><span>{{ Carbon\Carbon::parse($b1datum->date)->diffForHumans() }}開波</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u117" class="ax_default box_2" data-label="Match">
            <div id="u117_div" class=""></div>
            <div id="u117_text" class="text ">
              <p><span>{{ $b1datum->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Vote_2 (Group) -->
      <div id="u118" class="ax_default" data-label="Vote_2" data-left="114" data-top="576" data-width="1144" data-height="430">

        <!-- Unnamed (Rectangle) -->
        <div id="u119" class="ax_default box_1">
          <div id="u119_div" class=""></div>
          <div id="u119_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Rate_table (Group) -->
        <div id="u120" class="ax_default" data-label="Rate_table" data-left="332" data-top="886" data-width="716" data-height="80">

          <!-- TAW_rtg (Rectangle) -->
          <div id="u121" class="ax_default box_2" data-label="TAW_rtg">
            <div id="u121_div" class=""></div>
            <div id="u121_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_rprv (Rectangle) -->
          <div id="u122" class="ax_default paragraph" data-label="TAW_rprv">
            <div id="u122_div" class=""></div>
            <div id="u122_text" class="text ">
              <p><span>{{ $b1datum->g_win }}%</span></p>
            </div>
          </div>

          <!-- TAW_rpr (Rectangle) -->
          <div id="u123" class="ax_default paragraph" data-label="TAW_rpr">
            <div id="u123_div" class=""></div>
            <div id="u123_text" class="text ">
              <p><span>客隊勝率</span></p>
            </div>
          </div>

          <!-- TAW_rv (Rectangle) -->
          <div id="u124" class="ax_default paragraph" data-label="TAW_rv">
            <div id="u124_div" class=""></div>
            <div id="u124_text" class="text ">
              <p><span>{{ $b2datum->g_gress }}</span></p>
            </div>
          </div>

          <!-- TAW_r (Rectangle) -->
          <div id="u125" class="ax_default paragraph" data-label="TAW_r">
            <div id="u125_div" class=""></div>
            <div id="u125_text" class="text ">
              <p><span>客隊票數</span></p>
            </div>
          </div>

          <!-- DR_rtg (Rectangle) -->
          <div id="u126" class="ax_default box_2" data-label="DR_rtg">
            <div id="u126_div" class=""></div>
            <div id="u126_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DR_rprv (Rectangle) -->
          <div id="u127" class="ax_default paragraph" data-label="DR_rprv">
            <div id="u127_div" class=""></div>
            <div id="u127_text" class="text ">
              <p><span>{{ $b1datum->draw }}%</span></p>
            </div>
          </div>

          <!-- DR_rpr (Rectangle) -->
          <div id="u128" class="ax_default paragraph" data-label="DR_rpr">
            <div id="u128_div" class=""></div>
            <div id="u128_text" class="text ">
              <p><span>和波機率</span></p>
            </div>
          </div>

          <!-- DR_rv (Rectangle) -->
          <div id="u129" class="ax_default paragraph" data-label="DR_rv">
            <div id="u129_div" class=""></div>
            <div id="u129_text" class="text ">
              <p><span>{{ $b2datum->d_gress }}</span></p>
            </div>
          </div>

          <!-- DR_r (Rectangle) -->
          <div id="u130" class="ax_default paragraph" data-label="DR_r">
            <div id="u130_div" class=""></div>
            <div id="u130_text" class="text ">
              <p><span>和波票數</span></p>
            </div>
          </div>

          <!-- THW_rtg (Rectangle) -->
          <div id="u131" class="ax_default box_2" data-label="THW_rtg">
            <div id="u131_div" class=""></div>
            <div id="u131_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_rprv (Rectangle) -->
          <div id="u132" class="ax_default paragraph" data-label="THW_rprv">
            <div id="u132_div" class=""></div>
            <div id="u132_text" class="text ">
              <p><span>{{ $b1datum->h_win }}%</span></p>
            </div>
          </div>

          <!-- THW_rpr (Rectangle) -->
          <div id="u133" class="ax_default paragraph" data-label="THW_rpr">
            <div id="u133_div" class=""></div>
            <div id="u133_text" class="text ">
              <p><span>主隊勝率</span></p>
            </div>
          </div>

          <!-- THW_rv (Rectangle) -->
          <div id="u134" class="ax_default paragraph" data-label="THW_rv">
            <div id="u134_div" class=""></div>
            <div id="u134_text" class="text ">
              <p><span>{{ $b2datum->h_gress }}</span></p>
            </div>
          </div>

          <!-- THW_r (Rectangle) -->
          <div id="u135" class="ax_default paragraph" data-label="THW_r">
            <div id="u135_div" class=""></div>
            <div id="u135_text" class="text ">
              <p><span>主隊票數</span></p>
            </div>
          </div>
        </div>

        <!-- Rate_Group (Group) -->
        <div id="u136" class="ax_default" data-label="Rate_Group" data-left="150" data-top="746" data-width="1072" data-height="81">

          <!-- Rate_bar (Rectangle) -->
          <div id="u137" class="ax_default box_1" data-label="Rate_bar">
            <div id="u137_div" class=""></div>
            <div id="u137_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u138" class="ax_default" data-label="TAW" data-left="632" data-top="746" data-width="590" data-height="80">

            <!-- TAW_D (Rectangle) -->
            <div id="u139" class="ax_default box_1" data-label="TAW_D">
              <div id="u139_div" class=""></div>
              <div id="u139_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u140" class="ax_default box_1" data-label="TAW_Dt">
              <img id="u140_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u140.svg"/>
              <div id="u140_text" class="text ">
                <p><span>客勝55%</span></p>
              </div>
            </div>

            <!-- TAW_U (Rectangle) -->
            <div id="u141" class="ax_default box_1" data-label="TAW_U">
              <img id="u141_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_u_u24.svg"/>
              <div id="u141_text" class="text ">
                <p><span>7000</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u142" class="ax_default" data-label="THW" data-left="150" data-top="747" data-width="257" data-height="80">

            <!-- THW_D (Rectangle) -->
            <div id="u143" class="ax_default box_1" data-label="THW_D">
              <div id="u143_div" class=""></div>
              <div id="u143_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u144" class="ax_default box_1" data-label="THW_Dt">
              <img id="u144_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u144_text" class="text ">
                <p><span>主勝 24%</span></p>
              </div>
            </div>

            <!-- THW_U (Rectangle) -->
            <div id="u145" class="ax_default box_1" data-label="THW_U">
              <img id="u145_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_u_u28.svg"/>
              <div id="u145_text" class="text ">
                <p><span>3000</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u146" class="ax_default" data-label="DRAW" data-left="407" data-top="746" data-width="225" data-height="80">

            <!-- DRAW_D (Rectangle) -->
            <div id="u147" class="ax_default box_1" data-label="DRAW_D">
              <div id="u147_div" class=""></div>
              <div id="u147_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u148" class="ax_default box_1" data-label="DRAW_Dt">
              <img id="u148_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_dt_u31.svg"/>
              <div id="u148_text" class="text ">
                <p><span>和 21%</span></p>
              </div>
            </div>

            <!-- DRAW_U (Rectangle) -->
            <div id="u149" class="ax_default box_1" data-label="DRAW_U">
              <img id="u149_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_u_u32.svg"/>
              <div id="u149_text" class="text ">
                <p><span>2600</span></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u150" class="ax_default" data-label="Logo_Group" data-left="352" data-top="580" data-width="680" data-height="140">

          <!-- TA_G (Image) -->
          <div id="u151" class="ax_default image" data-label="TA_G">
            <img id="u151_img" class="img " src="{{ asset($b1datum->g_img) }}"/>
            <div id="u151_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u152" class="ax_default image" data-label="TH_G">
            <img id="u152_img" class="img " src="{{ asset($b1datum->h_img) }}"/>
            <div id="u152_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u153" class="ax_default box_2" data-label="Team_Away">
            <div id="u153_div" class=""></div>
            <div id="u153_text" class="text ">
              <p><span>{{ $b1datum->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u154" class="ax_default box_2" data-label="Team_Home">
            <div id="u154_div" class=""></div>
            <div id="u154_text" class="text ">
              <p><span>{{ $b1datum->host }}</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u155" class="ax_default box_2" data-label="Date_Time">
            <div id="u155_div" class=""></div>
            <div id="u155_text" class="text ">
              <p><span>{{ Carbon\Carbon::parse($b1datum->date)->diffForHumans() }}開波</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u156" class="ax_default box_2" data-label="Match">
            <div id="u156_div" class=""></div>
            <div id="u156_text" class="text ">
              <p><span>{{ $b1datum->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Vote_1 (Group) -->
      <div id="u157" class="ax_default" data-label="Vote_1" data-left="114" data-top="136" data-width="1144" data-height="430">

        <!-- Unnamed (Rectangle) -->
        <div id="u158" class="ax_default box_1">
          <div id="u158_div" class=""></div>
          <div id="u158_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Rate_table (Group) -->
        <div id="u159" class="ax_default" data-label="Rate_table" data-left="332" data-top="446" data-width="716" data-height="80">

          <!-- TAW_rtg (Rectangle) -->
          <div id="u160" class="ax_default box_2" data-label="TAW_rtg">
            <div id="u160_div" class=""></div>
            <div id="u160_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_rprv (Rectangle) -->
          <div id="u161" class="ax_default paragraph" data-label="TAW_rprv">
            <div id="u161_div" class=""></div>
            <div id="u161_text" class="text ">
              <p><span>{{ $b1datum->g_win }}%</span></p>
            </div>
          </div>

          <!-- TAW_rpr (Rectangle) -->
          <div id="u162" class="ax_default paragraph" data-label="TAW_rpr">
            <div id="u162_div" class=""></div>
            <div id="u162_text" class="text ">
              <p><span>客隊勝率</span></p>
            </div>
          </div>

          <!-- TAW_rv (Rectangle) -->
          <div id="u163" class="ax_default paragraph" data-label="TAW_rv">
            <div id="u163_div" class=""></div>
            <div id="u163_text" class="text ">
              <p><span>{{ $b2datum->g_gress }}</span></p>
            </div>
          </div>

          <!-- TAW_r (Rectangle) -->
          <div id="u164" class="ax_default paragraph" data-label="TAW_r">
            <div id="u164_div" class=""></div>
            <div id="u164_text" class="text ">
              <p><span>客隊票數</span></p>
            </div>
          </div>

          <!-- DR_rtg (Rectangle) -->
          <div id="u165" class="ax_default box_2" data-label="DR_rtg">
            <div id="u165_div" class=""></div>
            <div id="u165_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DR_rprv (Rectangle) -->
          <div id="u166" class="ax_default paragraph" data-label="DR_rprv">
            <div id="u166_div" class=""></div>
            <div id="u166_text" class="text ">
              <p><span>{{ $b1datum->draw }}%</span></p>
            </div>
          </div>

          <!-- DR_rpr (Rectangle) -->
          <div id="u167" class="ax_default paragraph" data-label="DR_rpr">
            <div id="u167_div" class=""></div>
            <div id="u167_text" class="text ">
              <p><span>和波機率</span></p>
            </div>
          </div>

          <!-- DR_rv (Rectangle) -->
          <div id="u168" class="ax_default paragraph" data-label="DR_rv">
            <div id="u168_div" class=""></div>
            <div id="u168_text" class="text ">
              <p><span>{{ $b2datum->d_gress }}</span></p>
            </div>
          </div>

          <!-- DR_r (Rectangle) -->
          <div id="u169" class="ax_default paragraph" data-label="DR_r">
            <div id="u169_div" class=""></div>
            <div id="u169_text" class="text ">
              <p><span>和波票數</span></p>
            </div>
          </div>

          <!-- THW_rtg (Rectangle) -->
          <div id="u170" class="ax_default box_2" data-label="THW_rtg">
            <div id="u170_div" class=""></div>
            <div id="u170_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_rprv (Rectangle) -->
          <div id="u171" class="ax_default paragraph" data-label="THW_rprv">
            <div id="u171_div" class=""></div>
            <div id="u171_text" class="text ">
              <p><span>{{ $b1datum->h_win }}%</span></p>
            </div>
          </div>

          <!-- THW_rpr (Rectangle) -->
          <div id="u172" class="ax_default paragraph" data-label="THW_rpr">
            <div id="u172_div" class=""></div>
            <div id="u172_text" class="text ">
              <p><span>主隊勝率</span></p>
            </div>
          </div>

          <!-- THW_rv (Rectangle) -->
          <div id="u173" class="ax_default paragraph" data-label="THW_rv">
            <div id="u173_div" class=""></div>
            <div id="u173_text" class="text ">
              <p><span>{{ $b2datum->h_gress }}</span></p>
            </div>
          </div>

          <!-- THW_r (Rectangle) -->
          <div id="u174" class="ax_default paragraph" data-label="THW_r">
            <div id="u174_div" class=""></div>
            <div id="u174_text" class="text ">
              <p><span>主隊票數</span></p>
            </div>
          </div>
        </div>

        <!-- Rate_Group (Group) -->
        <div id="u175" class="ax_default" data-label="Rate_Group" data-left="150" data-top="306" data-width="1072" data-height="81">

          <!-- Rate_bar (Rectangle) -->
          <div id="u176" class="ax_default box_1" data-label="Rate_bar">
            <div id="u176_div" class=""></div>
            <div id="u176_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u177" class="ax_default" data-label="TAW" data-left="632" data-top="306" data-width="590" data-height="80">

            <!-- TAW_D (Rectangle) -->
            <div id="u178" class="ax_default box_1" data-label="TAW_D">
              <div id="u178_div" class=""></div>
              <div id="u178_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u179" class="ax_default box_1" data-label="TAW_Dt">
              <img id="u179_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u179_text" class="text ">
                <p><span>客勝 55%</span></p>
              </div>
            </div>

            <!-- TAW_U (Rectangle) -->
            <div id="u180" class="ax_default box_1" data-label="TAW_U">
              <img id="u180_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_u_u24.svg"/>
              <div id="u180_text" class="text ">
                <p><span>7000</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u181" class="ax_default" data-label="THW" data-left="150" data-top="307" data-width="257" data-height="80">

            <!-- THW_D (Rectangle) -->
            <div id="u182" class="ax_default box_1" data-label="THW_D">
              <div id="u182_div" class=""></div>
              <div id="u182_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u183" class="ax_default box_1" data-label="THW_Dt">
              <img id="u183_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u183_text" class="text ">
                <p><span>主勝 24%</span></p>
              </div>
            </div>

            <!-- THW_U (Rectangle) -->
            <div id="u184" class="ax_default box_1" data-label="THW_U">
              <img id="u184_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_u_u28.svg"/>
              <div id="u184_text" class="text ">
                <p><span>3000</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u185" class="ax_default" data-label="DRAW" data-left="407" data-top="306" data-width="225" data-height="80">

            <!-- DRAW_D (Rectangle) -->
            <div id="u186" class="ax_default box_1" data-label="DRAW_D">
              <div id="u186_div" class=""></div>
              <div id="u186_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u187" class="ax_default box_1" data-label="DRAW_Dt">
              <img id="u187_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_dt_u31.svg"/>
              <div id="u187_text" class="text ">
                <p><span>和 21%</span></p>
              </div>
            </div>

            <!-- DRAW_U (Rectangle) -->
            <div id="u188" class="ax_default box_1" data-label="DRAW_U">
              <img id="u188_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_u_u32.svg"/>
              <div id="u188_text" class="text ">
                <p><span>2600</span></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u189" class="ax_default" data-label="Logo_Group" data-left="352" data-top="140" data-width="680" data-height="140">

          <!-- TA_G (Image) -->
          <div id="u190" class="ax_default image" data-label="TA_G">
            <img id="u190_img" class="img " src="{{ asset($b1datum->g_img) }}"/>
            <div id="u190_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u191" class="ax_default image" data-label="TH_G">
            <img id="u191_img" class="img " src="{{ asset($b1datum->h_img) }}"/>
            <div id="u191_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u192" class="ax_default box_2" data-label="Team_Away">
            <div id="u192_div" class=""></div>
            <div id="u192_text" class="text ">
              <p><span>{{ $b1datum->guest }}</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u193" class="ax_default box_2" data-label="Team_Home">
            <div id="u193_div" class=""></div>
            <div id="u193_text" class="text ">
              <p><span>{{ $b1datum->host }}</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u194" class="ax_default box_2" data-label="Date_Time">
            <div id="u194_div" class=""></div>
            <div id="u194_text" class="text ">
              <p><span>{{ Carbon\Carbon::parse($b1datum->date)->diffForHumans() }}開波</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u195" class="ax_default box_2" data-label="Match">
            <div id="u195_div" class=""></div>
            <div id="u195_text" class="text ">
              <p><span>{{ $b1datum->league }}</span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- Date (Group) -->
      <div id="u196" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="30">

        <!-- Unnamed (Rectangle) -->
        <div id="u197" class="ax_default box_1">
          <div id="u197_div" class=""></div>
          <div id="u197_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- After_tomorrow (Rectangle) -->
        <div id="u198" class="ax_default label" data-label="After_tomorrow">
          <div id="u198_div" class=""></div>
          <div id="u198_text" class="text ">
            <p><span>後日</span></p>
          </div>
        </div>

        <!-- Tomorrow (Rectangle) -->
        <div id="u199" class="ax_default label" data-label="Tomorrow">
          <div id="u199_div" class=""></div>
          <div id="u199_text" class="text ">
            <p><span>明日</span></p>
          </div>
        </div>

        <!-- Today (Rectangle) -->
        <div id="u200" class="ax_default label" data-label="Today">
          <div id="u200_div" class=""></div>
          <div id="u200_text" class="text ">
            <p><span>今日</span></p>
          </div>
        </div>

        <!-- Match_date (Rectangle) -->
        <div id="u201" class="ax_default label" data-label="Match_date">
          <div id="u201_div" class=""></div>
          <div id="u201_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div>
      </div>

      @endforeach
      @endforeach
      <!--@endif
      @endif-->

      <!-- Header (Rectangle) -->
      <div id="u202" class="ax_default heading_1" data-label="Header">
        <div id="u202_div" class=""></div>
        <div id="u202_text" class="text ">
          <p style="font-size:14px;"><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-size:16px;">綜合網民數據結果 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;">►</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-size:16px;"> 主 &#149; 和 &#149; 客 投票機率</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u204" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u205" class="ax_default placeholder">
          <img id="u205_img" class="img " src="/footballui/public/frontend/images/page_a2/u205.svg"/>
          <div id="u205_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u206" class="ax_default box_1">
          <div id="u206_div" class=""></div>
          <div id="u206_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u207" class="ax_default box_3">
          <div id="u207_div" class=""></div>
          <div id="u207_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u208" class="ax_default box_3">
          <div id="u208_div" class=""></div>
          <div id="u208_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u209" class="ax_default box_3">
          <div id="u209_div" class=""></div>
          <div id="u209_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u210" class="ax_default box_3">
          <div id="u210_div" class=""></div>
          <div id="u210_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u211" class="ax_default box_3">
          <div id="u211_div" class=""></div>
          <div id="u211_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u212" class="ax_default box_3">
          <div id="u212_div" class=""></div>
          <div id="u212_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u213" class="ax_default box_3">
          <div id="u213_div" class=""></div>
          <div id="u213_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u214" class="ax_default">
          <div id="u214_state0" class="panel_state" data-label="State 1" style="">
            <div id="u214_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u215" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u216" class="ax_default box_3">
                  <div id="u216_div" class=""></div>
                  <div id="u216_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u217" class="ax_default box_3">
                  <div id="u217_div" class=""></div>
                  <div id="u217_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u218" class="ax_default box_3">
                  <div id="u218_div" class=""></div>
                  <div id="u218_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u219" class="ax_default box_3">
                  <img id="u219_img" class="img " src="/footballui/public/frontend/images/page_a2/u219.svg"/>
                  <div id="u219_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u220" class="ax_default box_3">
                  <div id="u220_div" class=""></div>
                  <div id="u220_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u221" class="ax_default box_3">
                  <div id="u221_div" class=""></div>
                  <div id="u221_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u222" class="ax_default box_3">
                  <div id="u222_div" class=""></div>
                  <div id="u222_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u223" class="ax_default">
          <div id="u223_state0" class="panel_state" data-label="State 1" style="">
            <div id="u223_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u224" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u225" class="ax_default box_3">
                  <div id="u225_div" class=""></div>
                  <div id="u225_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u226" class="ax_default box_3">
                  <div id="u226_div" class=""></div>
                  <div id="u226_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u227" class="ax_default box_3">
                  <div id="u227_div" class=""></div>
                  <div id="u227_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u228" class="ax_default box_3">
                  <img id="u228_img" class="img " src="/footballui/public/frontend/images/page_a2/u228.svg"/>
                  <div id="u228_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u229" class="ax_default box_3">
                  <div id="u229_div" class=""></div>
                  <div id="u229_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u230" class="ax_default box_3">
                  <div id="u230_div" class=""></div>
                  <div id="u230_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u231" class="ax_default">
          <div id="u231_state0" class="panel_state" data-label="State 1" style="">
            <div id="u231_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u232" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u233" class="ax_default box_3">
                  <div id="u233_div" class=""></div>
                  <div id="u233_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u234" class="ax_default box_3">
                  <div id="u234_div" class=""></div>
                  <div id="u234_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u235" class="ax_default box_3">
                  <div id="u235_div" class=""></div>
                  <div id="u235_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u236" class="ax_default box_3">
                  <img id="u236_img" class="img " src="/footballui/public/frontend/images/page_a2/u236.svg"/>
                  <div id="u236_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u203" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u238" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="2" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u239" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u239_state0" class="panel_state" data-label="State 1" style="">
            <div id="u239_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u240" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u241" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u241_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u241_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u242" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u243" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u243_div" class=""></div>
                          <div id="u243_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u244" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u244_div" class=""></div>
                          <div id="u244_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u245" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u245_div" class=""></div>
                          <div id="u245_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u246" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u246_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u246_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u247" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u247_div" class=""></div>
                          <div id="u247_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u248" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u248_div" class=""></div>
                          <div id="u248_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u249" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u249_div" class=""></div>
                          <div id="u249_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u250" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u250_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u250_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u251" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u252" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u252_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u252_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u253" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u254" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u254_div" class=""></div>
                          <div id="u254_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u255" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u255_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u255_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u256" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u256_div" class=""></div>
                          <div id="u256_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u257" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u257_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u257_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u258" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u258_div" class=""></div>
                          <div id="u258_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u259" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u259_div" class=""></div>
                          <div id="u259_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u260" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u260_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u260_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u261" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u262" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u262_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u262_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u263" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u264" class="ax_default box_3">
                          <div id="u264_div" class=""></div>
                          <div id="u264_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u265" class="ax_default box_3">
                          <img id="u265_img" class="img " src="/footballui/public/frontend/images/page_a2/u265.svg"/>
                          <div id="u265_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u266" class="ax_default box_3">
                          <div id="u266_div" class=""></div>
                          <div id="u266_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u267" class="ax_default box_3">
                          <img id="u267_img" class="img " src="/footballui/public/frontend/images/page_a2/u267.svg"/>
                          <div id="u267_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u268" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u268_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u268_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u269" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u269_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u269_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u270" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u270_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u270_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u271" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u271_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u271_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u272" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u272_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u272_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u273" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u273_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u273_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u274" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u274_div" class=""></div>
          <div id="u274_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u275" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u275_div" class=""></div>
          <div id="u275_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u237" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
