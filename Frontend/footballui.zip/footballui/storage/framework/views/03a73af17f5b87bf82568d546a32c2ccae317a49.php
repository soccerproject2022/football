﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A1</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a1/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a1/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">
      









      <div class="col-lg-12">
        <div class="card-header card-header-border-bottom">
        </div>
        <div class="card-body">
            <p class="mb-5"></a></p>
            <table class="table table-hover " cellspacing=5 style="text-align:center; margin-top:140px; margin-left:100px;">
                <thead>
                    <tr>
                        <th scope="col" width="50">#</th>
                        <th scope="col" width="180">賽事類別</th>
                        <th scope="col" width="180">開賽時間</th>
                        <th scope="col"></th>
                        <th scope="col" width="180">主隊</th>
                        <th scope="col"></th>
                        <th scope="col" width="180">客隊</th>
                        <th scope="col">主勝</th>
                        <th scope="col">和率</th>
                        <th scope="col">客勝</th>
                        <th scope="col">主回率</th>
                        <th scope="col">和回率</th>
                        <th scope="col">客回率</th>
                        
                        
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $b1ss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b1datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($b1datum->jc_id); ?></td>
                        <td><?php echo e($b1datum->league); ?></td>
                        <td><?php echo e($b1datum->date); ?></td>
                        <td><img src="<?php echo e(asset($b1datum->h_img)); ?>" style="width:40px"></td>
                        <td><?php echo e($b1datum->host); ?></td>
                        <td><img src="<?php echo e(asset($b1datum->g_img)); ?>" style="width:40px"></td>
                        <td><?php echo e($b1datum->guest); ?></td>
                        <td><?php echo e($b1datum->h_win); ?></td>
                        <td><?php echo e($b1datum->draw); ?></td>
                        <td><?php echo e($b1datum->g_win); ?></td>
                        <td><?php echo e($b1datum->h_return); ?></td>
                        <td><?php echo e($b1datum->d_return); ?></td>
                        <td><?php echo e($b1datum->g_return); ?></td>
                        
                        
                        
                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>


      <!-- Date (Group) -->
      <div id="u195" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="30">

        <!-- Unnamed (Rectangle) -->
        <div id="u196" class="ax_default box_1">
          <div id="u196_div" class=""></div>
          <div id="u196_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- After_tomorrow (Rectangle) -->
        <div id="u197" class="ax_default label" data-label="">
          <div id="u197_div" class=""></div>
          <div id="u197_text" class="text " onclick="window.location='/footballui/public/page_first';">
            <p><span>後日</span></p>
          </div>
        </div>

        <!-- Tomorrow (Rectangle) -->
        <div id="u198" class="ax_default label" data-label="">
          <div id="u198_div" class=""></div>
          <div id="u198_text" class="text " onclick="window.location='/footballui/public/page_first';">
            <p><span>明日</span></p>
          </div>
        </div>

        <!-- Today (Rectangle) -->
        <div id="u199" class="ax_default label" data-label="" style="background-color:#5D5D5D">
          <div id="u199_div" class=""></div>
          <div id="u199_text" class="text " style="color:white">
            <p><span>今日</span></p>
          </div>
        </div>

        <!-- Match_date (Rectangle) -->
        <div id="u200" class="ax_default label" data-label="Match_date">
          <div id="u200_div" class=""></div>
          <div id="u200_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div>
      </div>

      <!-- Header (Rectangle) -->
      <div id="u201" class="ax_default heading_1" data-label="Header">
        <div id="u201_div" class=""></div>
        <div id="u201_text" class="text ">
          <p style="font-size:14px;"><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-size:16px;">對戰列表 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;">►►►</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-size:16px;"></span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u203" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u204" class="ax_default placeholder">
          <img id="u204_img" class="img " src="/footballui/public/frontend/images/page_a1/u204.svg"/>
          <div id="u204_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u205" class="ax_default box_1">
          <div id="u205_div" class=""></div>
          <div id="u205_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u206" class="ax_default box_3">
          <div id="u206_div" class=""></div>
          <div id="u206_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u207" class="ax_default box_3">
          <div id="u207_div" class=""></div>
          <div id="u207_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u208" class="ax_default box_3">
          <div id="u208_div" class=""></div>
          <div id="u208_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u209" class="ax_default box_3">
          <div id="u209_div" class=""></div>
          <div id="u209_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u210" class="ax_default box_3">
          <div id="u210_div" class=""></div>
          <div id="u210_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u211" class="ax_default box_3">
          <div id="u211_div" class=""></div>
          <div id="u211_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u212" class="ax_default box_3">
          <div id="u212_div" class=""></div>
          <div id="u212_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u213" class="ax_default">
          <div id="u213_state0" class="panel_state" data-label="State 1" style="">
            <div id="u213_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u214" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u215" class="ax_default box_3">
                  <div id="u215_div" class=""></div>
                  <div id="u215_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u216" class="ax_default box_3">
                  <div id="u216_div" class=""></div>
                  <div id="u216_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u217" class="ax_default box_3">
                  <div id="u217_div" class=""></div>
                  <div id="u217_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u218" class="ax_default box_3">
                  <img id="u218_img" class="img " src="/footballui/public/frontend/images/page_a1/u218.svg"/>
                  <div id="u218_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u219" class="ax_default box_3">
                  <div id="u219_div" class=""></div>
                  <div id="u219_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u220" class="ax_default box_3">
                  <div id="u220_div" class=""></div>
                  <div id="u220_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u221" class="ax_default box_3">
                  <div id="u221_div" class=""></div>
                  <div id="u221_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u222" class="ax_default">
          <div id="u222_state0" class="panel_state" data-label="State 1" style="">
            <div id="u222_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u223" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u224" class="ax_default box_3">
                  <div id="u224_div" class=""></div>
                  <div id="u224_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u225" class="ax_default box_3">
                  <div id="u225_div" class=""></div>
                  <div id="u225_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u226" class="ax_default box_3">
                  <div id="u226_div" class=""></div>
                  <div id="u226_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u227" class="ax_default box_3">
                  <img id="u227_img" class="img " src="/footballui/public/frontend/images/page_a1/u227.svg"/>
                  <div id="u227_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u228" class="ax_default box_3">
                  <div id="u228_div" class=""></div>
                  <div id="u228_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u229" class="ax_default box_3">
                  <div id="u229_div" class=""></div>
                  <div id="u229_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u230" class="ax_default">
          <div id="u230_state0" class="panel_state" data-label="State 1" style="">
            <div id="u230_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u231" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u232" class="ax_default box_3">
                  <div id="u232_div" class=""></div>
                  <div id="u232_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u233" class="ax_default box_3">
                  <div id="u233_div" class=""></div>
                  <div id="u233_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u234" class="ax_default box_3">
                  <div id="u234_div" class=""></div>
                  <div id="u234_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u235" class="ax_default box_3">
                  <img id="u235_img" class="img " src="/footballui/public/frontend/images/page_a1/u235.svg"/>
                  <div id="u235_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u202" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u237" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u238" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u238_state0" class="panel_state" data-label="State 1" style="">
            <div id="u238_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u239" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u240" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u240_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u240_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u241" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u242" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u242_div" class=""></div>
                          <div id="u242_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u243" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u243_div" class=""></div>
                          <div id="u243_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u244" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u244_div" class=""></div>
                          <div id="u244_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u245" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u245_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u245_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u246" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u246_div" class=""></div>
                          <div id="u246_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u247" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u247_div" class=""></div>
                          <div id="u247_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u248" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u248_div" class=""></div>
                          <div id="u248_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u249" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u249_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u249_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u250" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u251" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u251_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u251_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u252" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u253" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u253_div" class=""></div>
                          <div id="u253_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u254" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u254_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u254_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u255" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u255_div" class=""></div>
                          <div id="u255_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u256" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u256_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u256_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u257" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u257_div" class=""></div>
                          <div id="u257_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u258" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u258_div" class=""></div>
                          <div id="u258_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u259" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u259_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u259_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u260" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u261" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u261_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u261_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u262" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u263" class="ax_default box_3">
                          <div id="u263_div" class=""></div>
                          <div id="u263_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u264" class="ax_default box_3">
                          <img id="u264_img" class="img " src="/footballui/public/frontend/images/page_a1/u264.svg"/>
                          <div id="u264_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u265" class="ax_default box_3">
                          <div id="u265_div" class=""></div>
                          <div id="u265_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u266" class="ax_default box_3">
                          <img id="u266_img" class="img " src="/footballui/public/frontend/images/page_a1/u266.svg"/>
                          <div id="u266_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u267" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u267_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u267_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u268" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u268_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u268_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u269" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u269_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u269_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u270" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u270_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u270_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u271" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u271_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u271_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u272" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u272_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u272_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u273" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u273_div" class=""></div>
          <div id="u273_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u274" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u274_div" class=""></div>
          <div id="u274_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u236" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/footballui/resources/views/frontend/first_page.blade.php ENDPATH**/ ?>