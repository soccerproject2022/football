﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A7</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/page_a7/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/page_a7/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Chart_bg (Rectangle) -->
      <div id="u240" class="ax_default box_2" data-label="Chart_bg">
        <div id="u240_div" class=""></div>
        <div id="u240_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Upset_G (Image) -->
      <div id="u241" class="ax_default image" data-label="Upset_G">
        <img id="u241_img" class="img " src="images/page_a7/upset_g_u241.png"/>
        <div id="u241_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Button (Group) -->
      <div id="u242" class="ax_default" data-label="Button" data-left="828" data-top="631" data-width="262" data-height="40">

        <!-- AI_Button (Rectangle) -->
        <div id="u243" class="ax_default box_3" data-label="AI_Button">
          <div id="u243_div" class=""></div>
          <div id="u243_text" class="text ">
            <p><span>足球AI模組分析 &gt;&gt;&gt;</span></p>
          </div>
        </div>

        <!-- Button_HotSpot (Hot Spot) -->
        <div id="u244" class="ax_default" data-label="Button_HotSpot">
        </div>
      </div>

      <!-- Table_rtg (Rectangle) -->
      <div id="u245" class="ax_default box_2" data-label="Table_rtg">
        <div id="u245_div" class=""></div>
        <div id="u245_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Upset_db (Group) -->
      <div id="u246" class="ax_default" data-label="Upset_db" data-left="245" data-top="271" data-width="430" data-height="400">

        <!-- Upset_Repeater (Repeater) -->
        <div id="u247" class="ax_default" data-label="Upset_Repeater">
          <script id="u247_script" type="axure-repeater-template" data-label="Upset_Repeater">

            <!-- bold_1a (Rectangle) -->
            <div id="u248" class="ax_default box_1 u248" data-label="bold_1a">
              <div id="u248_div" class="u248_div"></div>
              <div id="u248_text" class="text u248_text">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249" class="ax_default paragraph u249" data-label="bold_0a">
              <div id="u249_div" class="u249_div"></div>
              <div id="u249_text" class="text u249_text">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </script>
          <div id="u247-1" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-1" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-1_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-1_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-1" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-1_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-1_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-2" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-2" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-2_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-2_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-2" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-2_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-2_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-3" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-3" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-3_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-3_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-3" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-3_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-3_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-4" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-4" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-4_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-4_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-4" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-4_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-4_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-5" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-5" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-5_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-5_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-5" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-5_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-5_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-6" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-6" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-6_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-6_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-6" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-6_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-6_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-7" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-7" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-7_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-7_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-7" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-7_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-7_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-8" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-8" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-8_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-8_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-8" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-8_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-8_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-9" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-9" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-9_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-9_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-9" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-9_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-9_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
          <div id="u247-10" class="preeval" style="width: 430px; height: 40px;">

            <!-- bold_1a (Rectangle) -->
            <div id="u248-10" class="ax_default box_1 u248" data-label="bold_1a" style="width: 170px; height: 40px; left: 260px; top: 0px;visibility: inherit">
              <div id="u248-10_div" class="u248_div" style="width: 170px; height: 40px;visibility: inherit"></div>
              <div id="u248-10_text" class="text u248_text" style="visibility: inherit">
                <p><span>讓球主客和(主隊勝)</span></p>
              </div>
            </div>

            <!-- bold_0a (Rectangle) -->
            <div id="u249-10" class="ax_default paragraph u249" data-label="bold_0a" style="width: 260px; height: 40px; left: 0px; top: 0px;visibility: inherit">
              <div id="u249-10_div" class="u249_div" style="width: 260px; height: 40px;visibility: inherit"></div>
              <div id="u249-10_text" class="text u249_text" style="visibility: inherit">
                <p><span>羅斯托夫PFC索契</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Upset (Group) -->
      <div id="u250" class="ax_default" data-label="Upset" data-left="150" data-top="231" data-width="525" data-height="440">

        <!-- Items_Group (Group) -->
        <div id="u251" class="ax_default" data-label="Items_Group" data-left="150" data-top="271" data-width="95" data-height="400">

          <!-- 10 (Rectangle) -->
          <div id="u252" class="ax_default paragraph" data-label="10">
            <div id="u252_div" class=""></div>
            <div id="u252_text" class="text ">
              <p><span>10</span></p>
            </div>
          </div>

          <!-- 9 (Rectangle) -->
          <div id="u253" class="ax_default paragraph" data-label="9">
            <div id="u253_div" class=""></div>
            <div id="u253_text" class="text ">
              <p><span>9</span></p>
            </div>
          </div>

          <!-- 8 (Rectangle) -->
          <div id="u254" class="ax_default paragraph" data-label="8">
            <div id="u254_div" class=""></div>
            <div id="u254_text" class="text ">
              <p><span>8</span></p>
            </div>
          </div>

          <!-- 7 (Rectangle) -->
          <div id="u255" class="ax_default paragraph" data-label="7">
            <div id="u255_div" class=""></div>
            <div id="u255_text" class="text ">
              <p><span>7</span></p>
            </div>
          </div>

          <!-- 6 (Rectangle) -->
          <div id="u256" class="ax_default paragraph" data-label="6">
            <div id="u256_div" class=""></div>
            <div id="u256_text" class="text ">
              <p><span>6</span></p>
            </div>
          </div>

          <!-- 5 (Rectangle) -->
          <div id="u257" class="ax_default paragraph" data-label="5">
            <div id="u257_div" class=""></div>
            <div id="u257_text" class="text ">
              <p><span>5</span></p>
            </div>
          </div>

          <!-- 4 (Rectangle) -->
          <div id="u258" class="ax_default paragraph" data-label="4">
            <div id="u258_div" class=""></div>
            <div id="u258_text" class="text ">
              <p><span>4</span></p>
            </div>
          </div>

          <!-- 3 (Rectangle) -->
          <div id="u259" class="ax_default paragraph" data-label="3">
            <div id="u259_div" class=""></div>
            <div id="u259_text" class="text ">
              <p><span>3</span></p>
            </div>
          </div>

          <!-- 2 (Rectangle) -->
          <div id="u260" class="ax_default paragraph" data-label="2">
            <div id="u260_div" class=""></div>
            <div id="u260_text" class="text ">
              <p><span>2</span></p>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u261" class="ax_default paragraph">
            <div id="u261_div" class=""></div>
            <div id="u261_text" class="text ">
              <p><span>1</span></p>
            </div>
          </div>
        </div>

        <!-- Items_rtg (Rectangle) -->
        <div id="u262" class="ax_default box_3" data-label="Items_rtg">
          <div id="u262_div" class=""></div>
          <div id="u262_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Predict (Rectangle) -->
        <div id="u263" class="ax_default paragraph" data-label="Predict">
          <div id="u263_div" class=""></div>
          <div id="u263_text" class="text ">
            <p><span>預測結果</span></p>
          </div>
        </div>

        <!-- Game (Rectangle) -->
        <div id="u264" class="ax_default paragraph" data-label="Game">
          <div id="u264_div" class=""></div>
          <div id="u264_text" class="text ">
            <p><span>比賽場次</span></p>
          </div>
        </div>

        <!-- Items (Rectangle) -->
        <div id="u265" class="ax_default paragraph" data-label="Items">
          <div id="u265_div" class=""></div>
          <div id="u265_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Team_G (Image) -->
      <div id="u266" class="ax_default image" data-label="Team_G">
        <img id="u266_img" class="img " src="images/page_a4/ta_g_u110.png"/>
        <div id="u266_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Header_team (Rectangle) -->
      <div id="u267" class="ax_default box_2" data-label="Header_team">
        <div id="u267_div" class=""></div>
        <div id="u267_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Header (Rectangle) -->
      <div id="u268" class="ax_default box_2" data-label="Header">
        <div id="u268_div" class=""></div>
        <div id="u268_text" class="text ">
          <p><span>AI模組爆冷精選</span></p>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/footballui/resources/views/frontend/page_a7.blade.php ENDPATH**/ ?>