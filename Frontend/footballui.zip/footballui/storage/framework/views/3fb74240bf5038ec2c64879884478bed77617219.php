<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="./styles1.css" type="text/css" rel="stylesheet"/>
    <style>
#myDIV {
  border-width:1px;
  border-style:solid;
  border-color:red;
  position:absolute;
  left:150px;
  top:76px;
  height:100px;
  width:300px;
  display:table;
  background-color:#FFFFFF;
}
.bluediv {
  border-width:1px;
  border-style:solid;
  border-color:rgba(121, 121, 121, 1);
  height:50px;
  width:100px;
  background-color:lightblue;
  display:table-cell;
  word-wrap: break-word;
}
</style>
</head>
<body>
<div id="u20s" class="">
            <div id="u26" class="" style="width:1%">1000</div>
            <div id="u30" class="" style="width:1%">2000</div>
            <div id="u22" class="" style="width:98%">3000</div>
            </div>
<div id="myDIV">
  <div class="bluediv">
    <div class="bluediv">
    <p>prettyveryveryvery</p>
    </div>
    <div class="bluediv">
    <div>prettyveryveryvery</div>
    </div>
  </div>
</div>
<div id="myDIV" style="top:180px;"></div>
<div class="bluediv"></div>

</body>
</html><?php /**PATH /Applications/MAMP/htdocs/footballui/resources/views/test.blade.php ENDPATH**/ ?>