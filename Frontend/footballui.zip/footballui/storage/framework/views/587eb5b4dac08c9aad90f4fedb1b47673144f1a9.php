﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A2</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a2/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a2/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Update_time (Rectangle) -->
      <div id="u0" class="ax_default label" data-label="Update_time">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>


      <!-- Vote_5 (Group) -->
      <div id="u1" class="ax_default" data-label="Vote_5" data-left="114" data-top="1896" data-width="1144" data-height="430">

        <!-- Unnamed (Rectangle) -->
        <div id="u2" class="ax_default box_1">
          <div id="u2_div" class=""></div>
          <div id="u2_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Rate_table (Group) -->
        <div id="u3" class="ax_default" data-label="Rate_table" data-left="332" data-top="2206" data-width="716" data-height="80">

          <!-- TAW_rtg (Rectangle) -->
          <div id="u4" class="ax_default box_2" data-label="TAW_rtg">
            <div id="u4_div" class=""></div>
            <div id="u4_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW_rprv (Rectangle) -->
          <div id="u5" class="ax_default paragraph" data-label="TAW_rprv">
            <div id="u5_div" class=""></div>
            <div id="u5_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- TAW_rpr (Rectangle) -->
          <div id="u6" class="ax_default paragraph" data-label="TAW_rpr">
            <div id="u6_div" class=""></div>
            <div id="u6_text" class="text ">
              <p><span>客隊勝率</span></p>
            </div>
          </div>

          <!-- TAW_rv (Rectangle) -->
          <div id="u7" class="ax_default paragraph" data-label="TAW_rv">
            <div id="u7_div" class=""></div>
            <div id="u7_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- TAW_r (Rectangle) -->
          <div id="u8" class="ax_default paragraph" data-label="TAW_r">
            <div id="u8_div" class=""></div>
            <div id="u8_text" class="text ">
              <p><span>客隊票數</span></p>
            </div>
          </div>

          <!-- DR_rtg (Rectangle) -->
          <div id="u9" class="ax_default box_2" data-label="DR_rtg">
            <div id="u9_div" class=""></div>
            <div id="u9_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- DR_rprv (Rectangle) -->
          <div id="u10" class="ax_default paragraph" data-label="DR_rprv">
            <div id="u10_div" class=""></div>
            <div id="u10_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- DR_rpr (Rectangle) -->
          <div id="u11" class="ax_default paragraph" data-label="DR_rpr">
            <div id="u11_div" class=""></div>
            <div id="u11_text" class="text ">
              <p><span>和波機率</span></p>
            </div>
          </div>

          <!-- DR_rv (Rectangle) -->
          <div id="u12" class="ax_default paragraph" data-label="DR_rv">
            <div id="u12_div" class=""></div>
            <div id="u12_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- DR_r (Rectangle) -->
          <div id="u13" class="ax_default paragraph" data-label="DR_r">
            <div id="u13_div" class=""></div>
            <div id="u13_text" class="text ">
              <p><span>和波票數</span></p>
            </div>
          </div>

          <!-- THW_rtg (Rectangle) -->
          <div id="u14" class="ax_default box_2" data-label="THW_rtg">
            <div id="u14_div" class=""></div>
            <div id="u14_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- THW_rprv (Rectangle) -->
          <div id="u15" class="ax_default paragraph" data-label="THW_rprv">
            <div id="u15_div" class=""></div>
            <div id="u15_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- THW_rpr (Rectangle) -->
          <div id="u16" class="ax_default paragraph" data-label="THW_rpr">
            <div id="u16_div" class=""></div>
            <div id="u16_text" class="text ">
              <p><span>主隊勝率</span></p>
            </div>
          </div>

          <!-- THW_rv (Rectangle) -->
          <div id="u17" class="ax_default paragraph" data-label="THW_rv">
            <div id="u17_div" class=""></div>
            <div id="u17_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- THW_r (Rectangle) -->
          <div id="u18" class="ax_default paragraph" data-label="THW_r">
            <div id="u18_div" class=""></div>
            <div id="u18_text" class="text ">
              <p><span>主隊票數</span></p>
            </div>
          </div>
        </div>

        <!-- Rate_Group (Group) -->
        <div id="u19" class="ax_default" data-label="Rate_Group" data-left="150" data-top="2066" data-width="1072" data-height="81">

          <!-- Rate_bar (Rectangle) -->
          <div id="u20" class="ax_default box_1" data-label="Rate_bar">
            <div id="u20_div" class=""></div>
            <div id="u20_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u21" class="ax_default" data-label="TAW" data-left="632" data-top="2066" data-width="590" data-height="80">

            <!-- TAW_D (Rectangle) -->
            <div id="u22" class="ax_default box_1" data-label="TAW_D">
              <div id="u22_div" class=""></div>
              <div id="u22_text" class="text " style="display:none; visibility: hidden">
                <p>xx</p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u23" class="ax_default box_1" data-label="TAW_Dt">
              <img id="u23_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_dt_u23.svg"/>
              <div id="u23_text" class="text ">
                <p><span>客勝 55%</span></p>
              </div>
            </div>

            <!-- TAW_U (Rectangle) -->
            <div id="u24" class="ax_default box_1" data-label="TAW_U">
              <img id="u24_img" class="img " src="/footballui/public/frontend/images/page_a2/taw_u_u24.svg"/>
              <div id="u24_text" class="text ">
                <p><span>7000</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u25" class="ax_default" data-label="THW" data-left="150" data-top="2067" data-width="257" data-height="80">

            <!-- THW_D (Rectangle) -->
            <div id="u26" class="ax_default box_1" data-label="THW_D">
              <div id="u26_div" class=""></div>
              <div id="u26_text" class="text " style="display:none; visibility: hidden">
                <p>xx</p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u27" class="ax_default box_1" data-label="THW_Dt">
              <img id="u27_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_dt_u27.svg"/>
              <div id="u27_text" class="text ">
                <p><span>主勝 24%</span></p>
              </div>
            </div>

            <!-- THW_U (Rectangle) -->
            <div id="u28" class="ax_default box_1" data-label="THW_U">
              <img id="u28_img" class="img " src="/footballui/public/frontend/images/page_a2/thw_u_u28.svg"/>
              <div id="u28_text" class="text ">
                <p><span>3000</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u29" class="ax_default" data-label="DRAW" data-left="407" data-top="2066" data-width="225" data-height="80">

            <!-- DRAW_D (Rectangle) -->
            <div id="u30" class="ax_default box_1" data-label="DRAW_D">
              <div id="u30_div" class=""></div>
              <div id="u30_text" class="text " style="display:none; visibility: hidden">
                <p>xx</p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u31" class="ax_default box_1" data-label="DRAW_Dt">
              <img id="u31_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_dt_u31.svg"/>
              <div id="u31_text" class="text ">
                <p><span>和 21%</span></p>
              </div>
            </div>

            <!-- DRAW_U (Rectangle) -->
            <div id="u32" class="ax_default box_1" data-label="DRAW_U">
              <img id="u32_img" class="img " src="/footballui/public/frontend/images/page_a2/draw_u_u32.svg"/>
              <div id="u32_text" class="text ">
                <p><span>2600</span></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u33" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1900" data-width="680" data-height="140">

          <!-- TA_G (Image) -->
          <div id="u34" class="ax_default image" data-label="TA_G">
            <img id="u34_img" class="img " src=""/>
            <div id="u34_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u35" class="ax_default image" data-label="TH_G">
            <img id="u35_img" class="img " src=""/>
            <div id="u35_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u36" class="ax_default box_2" data-label="Team_Away">
            <div id="u36_div" class=""></div>
            <div id="u36_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u37" class="ax_default box_2" data-label="Team_Home">
            <div id="u37_div" class=""></div>
            <div id="u37_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u38" class="ax_default box_2" data-label="Date_Time">
            <div id="u38_div" class=""></div>
            <div id="u38_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u39" class="ax_default box_2" data-label="Match">
            <div id="u39_div" class=""></div>
            <div id="u39_text" class="text ">
              <p><span>xx</span></p>
            </div>
          </div>
        </div>
      </div>




      <!-- Date (Group) -->
      <div id="u196" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="30">

        <!-- Unnamed (Rectangle) -->
        <div id="u197" class="ax_default box_1">
          <div id="u197_div" class=""></div>
          <div id="u197_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- After_tomorrow (Rectangle) -->
        <div id="u198" class="ax_default label" data-label="After_tomorrow">
          <div id="u198_div" class=""></div>
          <div id="u198_text" class="text ">
            <p><span>後日</span></p>
          </div>
        </div>

        <!-- Tomorrow (Rectangle) -->
        <div id="u199" class="ax_default label" data-label="Tomorrow">
          <div id="u199_div" class=""></div>
          <div id="u199_text" class="text ">
            <p><span>明日</span></p>
          </div>
        </div>

        <!-- Today (Rectangle) -->
        <div id="u200" class="ax_default label" data-label="Today">
          <div id="u200_div" class=""></div>
          <div id="u200_text" class="text ">
            <p><span>今日</span></p>
          </div>
        </div>

        <!-- Match_date (Rectangle) -->
        <div id="u201" class="ax_default label" data-label="Match_date">
          <div id="u201_div" class=""></div>
          <div id="u201_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div>
      </div>

      <!-- Header (Rectangle) -->
      <div id="u202" class="ax_default heading_1" data-label="Header">
        <div id="u202_div" class=""></div>
        <div id="u202_text" class="text ">
          <p style="font-size:14px;"><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-size:16px;">綜合網民數據結果 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;">►</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-size:16px;"> 主 &#149; 和 &#149; 客 投票機率</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u204" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Placeholder) -->
        <div id="u205" class="ax_default placeholder">
          <img id="u205_img" class="img " src="/footballui/public/frontend/images/page_a2/u205.svg"/>
          <div id="u205_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u206" class="ax_default box_1">
          <div id="u206_div" class=""></div>
          <div id="u206_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u207" class="ax_default box_3">
          <div id="u207_div" class=""></div>
          <div id="u207_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u208" class="ax_default box_3">
          <div id="u208_div" class=""></div>
          <div id="u208_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u209" class="ax_default box_3">
          <div id="u209_div" class=""></div>
          <div id="u209_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u210" class="ax_default box_3">
          <div id="u210_div" class=""></div>
          <div id="u210_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u211" class="ax_default box_3">
          <div id="u211_div" class=""></div>
          <div id="u211_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u212" class="ax_default box_3">
          <div id="u212_div" class=""></div>
          <div id="u212_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u213" class="ax_default box_3">
          <div id="u213_div" class=""></div>
          <div id="u213_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u214" class="ax_default">
          <div id="u214_state0" class="panel_state" data-label="State 1" style="">
            <div id="u214_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u215" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u216" class="ax_default box_3">
                  <div id="u216_div" class=""></div>
                  <div id="u216_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u217" class="ax_default box_3">
                  <div id="u217_div" class=""></div>
                  <div id="u217_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u218" class="ax_default box_3">
                  <div id="u218_div" class=""></div>
                  <div id="u218_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u219" class="ax_default box_3">
                  <img id="u219_img" class="img " src="/footballui/public/frontend/images/page_a2/u219.svg"/>
                  <div id="u219_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u220" class="ax_default box_3">
                  <div id="u220_div" class=""></div>
                  <div id="u220_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u221" class="ax_default box_3">
                  <div id="u221_div" class=""></div>
                  <div id="u221_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u222" class="ax_default box_3">
                  <div id="u222_div" class=""></div>
                  <div id="u222_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u223" class="ax_default">
          <div id="u223_state0" class="panel_state" data-label="State 1" style="">
            <div id="u223_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u224" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u225" class="ax_default box_3">
                  <div id="u225_div" class=""></div>
                  <div id="u225_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u226" class="ax_default box_3">
                  <div id="u226_div" class=""></div>
                  <div id="u226_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u227" class="ax_default box_3">
                  <div id="u227_div" class=""></div>
                  <div id="u227_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u228" class="ax_default box_3">
                  <img id="u228_img" class="img " src="/footballui/public/frontend/images/page_a2/u228.svg"/>
                  <div id="u228_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u229" class="ax_default box_3">
                  <div id="u229_div" class=""></div>
                  <div id="u229_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u230" class="ax_default box_3">
                  <div id="u230_div" class=""></div>
                  <div id="u230_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u231" class="ax_default">
          <div id="u231_state0" class="panel_state" data-label="State 1" style="">
            <div id="u231_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u232" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u233" class="ax_default box_3">
                  <div id="u233_div" class=""></div>
                  <div id="u233_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u234" class="ax_default box_3">
                  <div id="u234_div" class=""></div>
                  <div id="u234_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u235" class="ax_default box_3">
                  <div id="u235_div" class=""></div>
                  <div id="u235_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u236" class="ax_default box_3">
                  <img id="u236_img" class="img " src="/footballui/public/frontend/images/page_a2/u236.svg"/>
                  <div id="u236_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="u203" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u238" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="2" data-top="0" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u239" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u239_state0" class="panel_state" data-label="State 1" style="">
            <div id="u239_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u240" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u241" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u241_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u241_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u242" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u243" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u243_div" class=""></div>
                          <div id="u243_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u244" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u244_div" class=""></div>
                          <div id="u244_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u245" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u245_div" class=""></div>
                          <div id="u245_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u246" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u246_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u246_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u247" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u247_div" class=""></div>
                          <div id="u247_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u248" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u248_div" class=""></div>
                          <div id="u248_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u249" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u249_div" class=""></div>
                          <div id="u249_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u250" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u250_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u250_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u251" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u252" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u252_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u252_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u253" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u254" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u254_div" class=""></div>
                          <div id="u254_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u255" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u255_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u255_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u256" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u256_div" class=""></div>
                          <div id="u256_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u257" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u257_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u257_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u258" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u258_div" class=""></div>
                          <div id="u258_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u259" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u259_div" class=""></div>
                          <div id="u259_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u260" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u260_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u260_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u261" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u262" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u262_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u262_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u263" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u264" class="ax_default box_3">
                          <div id="u264_div" class=""></div>
                          <div id="u264_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u265" class="ax_default box_3">
                          <img id="u265_img" class="img " src="/footballui/public/frontend/images/page_a2/u265.svg"/>
                          <div id="u265_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u266" class="ax_default box_3">
                          <div id="u266_div" class=""></div>
                          <div id="u266_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u267" class="ax_default box_3">
                          <img id="u267_img" class="img " src="/footballui/public/frontend/images/page_a2/u267.svg"/>
                          <div id="u267_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u268" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u268_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u268_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u269" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u269_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u269_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u270" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u270_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u270_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u271" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u271_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u271_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u272" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u272_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u272_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Placeholder) -->
        <div id="u273" class="ax_default placeholder ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u273_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u273_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u274" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u274_div" class=""></div>
          <div id="u274_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u275" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u275_div" class=""></div>
          <div id="u275_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>
      </div>
      <div id="u237" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/footballui/resources/views/frontend/foreach_page_a2.blade.php ENDPATH**/ ?>