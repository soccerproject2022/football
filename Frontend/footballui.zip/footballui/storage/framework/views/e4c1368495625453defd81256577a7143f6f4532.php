﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A4</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="/footballui/public/frontend/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a4/styles.css" type="text/css" rel="stylesheet"/>
    <link href="/footballui/public/frontend/files/page_a4/styles_1.css" type="text/css" rel="stylesheet"/>

    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="/footballui/public/frontend/resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/globals.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axutils.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/annotation.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/axQuery.std.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/doc.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/messagecenter.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/events.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/recording.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/action.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/expr.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/geometry.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/flyout.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/model.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/repeater.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/sto.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/utils.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/variables.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/drag.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/move.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/visibility.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/style.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/adaptive.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/tree.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/init.temp.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/legacy.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/viewer.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/math.js"></script>
    <script src="/footballui/public/frontend/resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="/footballui/public/frontend/data/document.js"></script>
    <script src="/footballui/public/frontend/files/page_a4/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '/footballui/public/frontend/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '/footballui/public/frontend/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '/footballui/public/frontend/resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">
    <?php if(isset($b1s,$b12s,$b13s,$b14s,$b15s)): ?>;
      <!-- G5 (Group) -->
      <div id="u0" class="ax_default" data-label="G5" data-left="68" data-top="1322" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u1" class="ax_default" data-label="Rate_Group" data-left="68" data-top="1522" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u2" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u2_state0" class="panel_state" data-label="State 1" style="">
              <div id="u2_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u3" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u4" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u4_div" class="selected"></div>
                    <div id="u4_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u5" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u6" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u7" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u7_div" class="selected"></div>
                        <div id="u7_text" class="text ">
                          <p><span><?php echo e($b15s->g_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u8" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u8_div" class="selected"></div>
                        <div id="u8_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u9" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u9_div" class="selected"></div>
                        <div id="u9_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u10" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u10_div" class="selected"></div>
                        <div id="u10_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u11" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u12" class="ax_default" data-label="TACS_Repeater">
                        <script id="u12_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13" class="ax_default paragraph u13" data-label="bold_3a">
                            <div id="u13_div" class="u13_div"></div>
                            <div id="u13_text" class="text u13_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14" class="ax_default paragraph u14" data-label="bold_2a">
                            <div id="u14_div" class="u14_div"></div>
                            <div id="u14_text" class="text u14_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15" class="ax_default paragraph u15" data-label="bold_1a">
                            <div id="u15_div" class="u15_div"></div>
                            <div id="u15_text" class="text u15_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16" class="ax_default paragraph u16" data-label="bold_0a">
                            <div id="u16_div" class="u16_div"></div>
                            <div id="u16_text" class="text u16_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u12-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-1" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-1_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-1_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-1" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-1_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-1_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-1" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-1_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-1_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-1" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-1_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-1_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-2" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-2_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-2_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-2" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-2_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-2_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-2" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-2_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-2_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-2" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-2_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-2_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-3" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-3_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-3_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-3" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-3_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-3_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-3" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-3_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-3_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-3" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-3_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-3_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-4" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-4_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-4_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-4" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-4_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-4_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-4" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-4_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-4_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-4" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-4_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-4_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-5" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-5_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-5_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-5" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-5_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-5_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-5" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-5_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-5_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-5" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-5_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-5_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-6" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-6_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-6_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-6" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-6_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-6_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-6" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-6_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-6_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-6" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-6_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-6_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-7" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-7_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-7_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-7" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-7_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-7_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-7" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-7_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-7_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-7" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-7_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-7_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-8" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-8_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-8_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-8" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-8_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-8_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-8" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-8_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-8_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-8" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-8_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-8_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-9" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-9_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-9_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-9" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-9_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-9_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-9" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-9_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-9_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-9" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-9_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-9_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-10" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-10_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-10_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-10" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-10_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-10_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-10" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-10_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-10_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-10" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-10_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-10_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-11" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-11_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-11_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-11" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-11_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-11_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-11" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-11_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-11_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-11" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-11_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-11_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-12" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-12_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-12_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-12" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-12_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-12_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-12" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-12_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-12_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-12" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-12_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-12_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u12-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u13-13" class="ax_default paragraph u13" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u13-13_div" class="u13_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u13-13_text" class="text u13_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u14-13" class="ax_default paragraph u14" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u14-13_div" class="u14_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u14-13_text" class="text u14_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u15-13" class="ax_default paragraph u15" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u15-13_div" class="u15_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u15-13_text" class="text u15_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u16-13" class="ax_default paragraph u16" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u16-13_div" class="u16_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u16-13_text" class="text u16_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u17" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u18" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u19" class="ax_default paragraph selected" data-label="Others">
                          <div id="u19_div" class="selected"></div>
                          <div id="u19_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u20" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u20_div" class="selected"></div>
                          <div id="u20_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u21" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u21_div" class="selected"></div>
                          <div id="u21_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u22" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u22_div" class="selected"></div>
                          <div id="u22_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u23" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u23_div" class="selected"></div>
                          <div id="u23_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u24" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u24_div" class="selected"></div>
                          <div id="u24_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u25" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u25_div" class="selected"></div>
                          <div id="u25_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u26" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u26_div" class="selected"></div>
                          <div id="u26_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u27" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u27_div" class="selected"></div>
                          <div id="u27_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u28" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u28_div" class="selected"></div>
                          <div id="u28_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u29" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u29_div" class="selected"></div>
                          <div id="u29_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u30" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u30_div" class="selected"></div>
                          <div id="u30_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u31" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u31_div" class="selected"></div>
                          <div id="u31_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u32" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u32_div" class="selected"></div>
                        <div id="u32_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u33" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u33_div" class="selected"></div>
                        <div id="u33_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u34" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u34_div" class="selected"></div>
                        <div id="u34_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u35" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u35_div" class="selected"></div>
                        <div id="u35_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u36" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u36_div" class="selected"></div>
                        <div id="u36_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u37" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u37_div" class="selected"></div>
                        <div id="u37_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u38" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u39" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u40" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u40_div" class="selected"></div>
                        <div id="u40_text" class="text ">
                          <p><span><?php echo e($b15s->draw); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u41" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u41_div" class="selected"></div>
                        <div id="u41_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u42" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u42_div" class="selected"></div>
                        <div id="u42_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u43" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u43_div" class="selected"></div>
                        <div id="u43_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u44" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u45" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u45_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u46" class="ax_default paragraph u46" data-label="bold_3a">
                            <div id="u46_div" class="u46_div"></div>
                            <div id="u46_text" class="text u46_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u47" class="ax_default paragraph u47" data-label="bold_2a">
                            <div id="u47_div" class="u47_div"></div>
                            <div id="u47_text" class="text u47_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u48" class="ax_default paragraph u48" data-label="bold_1a">
                            <div id="u48_div" class="u48_div"></div>
                            <div id="u48_text" class="text u48_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u49" class="ax_default paragraph u49" data-label="bold_0a">
                            <div id="u49_div" class="u49_div"></div>
                            <div id="u49_text" class="text u49_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u45-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u46-1" class="ax_default paragraph u46" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u46-1_div" class="u46_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u46-1_text" class="text u46_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u47-1" class="ax_default paragraph u47" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u47-1_div" class="u47_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u47-1_text" class="text u47_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u48-1" class="ax_default paragraph u48" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u48-1_div" class="u48_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u48-1_text" class="text u48_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u49-1" class="ax_default paragraph u49" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u49-1_div" class="u49_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u49-1_text" class="text u49_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u45-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u46-2" class="ax_default paragraph u46" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u46-2_div" class="u46_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u46-2_text" class="text u46_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u47-2" class="ax_default paragraph u47" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u47-2_div" class="u47_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u47-2_text" class="text u47_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u48-2" class="ax_default paragraph u48" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u48-2_div" class="u48_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u48-2_text" class="text u48_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u49-2" class="ax_default paragraph u49" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u49-2_div" class="u49_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u49-2_text" class="text u49_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u45-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u46-3" class="ax_default paragraph u46" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u46-3_div" class="u46_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u46-3_text" class="text u46_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u47-3" class="ax_default paragraph u47" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u47-3_div" class="u47_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u47-3_text" class="text u47_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u48-3" class="ax_default paragraph u48" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u48-3_div" class="u48_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u48-3_text" class="text u48_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u49-3" class="ax_default paragraph u49" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u49-3_div" class="u49_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u49-3_text" class="text u49_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u45-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u46-4" class="ax_default paragraph u46" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u46-4_div" class="u46_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u46-4_text" class="text u46_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u47-4" class="ax_default paragraph u47" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u47-4_div" class="u47_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u47-4_text" class="text u47_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u48-4" class="ax_default paragraph u48" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u48-4_div" class="u48_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u48-4_text" class="text u48_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u49-4" class="ax_default paragraph u49" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u49-4_div" class="u49_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u49-4_text" class="text u49_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u45-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u46-5" class="ax_default paragraph u46" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u46-5_div" class="u46_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u46-5_text" class="text u46_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u47-5" class="ax_default paragraph u47" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u47-5_div" class="u47_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u47-5_text" class="text u47_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u48-5" class="ax_default paragraph u48" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u48-5_div" class="u48_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u48-5_text" class="text u48_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u49-5" class="ax_default paragraph u49" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u49-5_div" class="u49_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u49-5_text" class="text u49_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u50" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u51" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u52" class="ax_default paragraph selected" data-label="Others">
                          <div id="u52_div" class="selected"></div>
                          <div id="u52_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u53" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u53_div" class="selected"></div>
                          <div id="u53_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u54" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u54_div" class="selected"></div>
                          <div id="u54_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u55" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u55_div" class="selected"></div>
                          <div id="u55_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u56" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u56_div" class="selected"></div>
                          <div id="u56_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u57" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u57_div" class="selected"></div>
                        <div id="u57_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u58" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u58_div" class="selected"></div>
                        <div id="u58_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u59" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u59_div" class="selected"></div>
                        <div id="u59_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u60" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u60_div" class="selected"></div>
                        <div id="u60_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u61" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u61_div" class="selected"></div>
                        <div id="u61_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u62" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u62_div" class="selected"></div>
                        <div id="u62_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u63" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u64" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u65" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u65_div" class="selected"></div>
                        <div id="u65_text" class="text ">
                          <p><span><?php echo e($b15s->h_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u66" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u66_div" class="selected"></div>
                        <div id="u66_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u67" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u67_div" class="selected"></div>
                        <div id="u67_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u68" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u68_div" class="selected"></div>
                        <div id="u68_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u69" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u70" class="ax_default" data-label="THCS_Repeater">
                        <script id="u70_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71" class="ax_default paragraph u71" data-label="bold_3a">
                            <div id="u71_div" class="u71_div"></div>
                            <div id="u71_text" class="text u71_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72" class="ax_default paragraph u72" data-label="bold_2a">
                            <div id="u72_div" class="u72_div"></div>
                            <div id="u72_text" class="text u72_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73" class="ax_default paragraph u73" data-label="bold_1a">
                            <div id="u73_div" class="u73_div"></div>
                            <div id="u73_text" class="text u73_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74" class="ax_default paragraph u74" data-label="bold_0a">
                            <div id="u74_div" class="u74_div"></div>
                            <div id="u74_text" class="text u74_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u70-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-1" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-1_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-1_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-1" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-1_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-1_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-1" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-1_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-1_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-1" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-1_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-1_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-2" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-2_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-2_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-2" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-2_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-2_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-2" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-2_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-2_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-2" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-2_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-2_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-3" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-3_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-3_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-3" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-3_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-3_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-3" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-3_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-3_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-3" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-3_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-3_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-4" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-4_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-4_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-4" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-4_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-4_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-4" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-4_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-4_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-4" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-4_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-4_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-5" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-5_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-5_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-5" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-5_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-5_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-5" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-5_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-5_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-5" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-5_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-5_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-6" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-6_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-6_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-6" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-6_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-6_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-6" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-6_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-6_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-6" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-6_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-6_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-7" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-7_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-7_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-7" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-7_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-7_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-7" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-7_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-7_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-7" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-7_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-7_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-8" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-8_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-8_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-8" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-8_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-8_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-8" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-8_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-8_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-8" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-8_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-8_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-9" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-9_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-9_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-9" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-9_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-9_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-9" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-9_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-9_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-9" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-9_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-9_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-10" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-10_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-10_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-10" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-10_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-10_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-10" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-10_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-10_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-10" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-10_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-10_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-11" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-11_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-11_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-11" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-11_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-11_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-11" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-11_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-11_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-11" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-11_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-11_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-12" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-12_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-12_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-12" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-12_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-12_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-12" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-12_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-12_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-12" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-12_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-12_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u70-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u71-13" class="ax_default paragraph u71" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u71-13_div" class="u71_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u71-13_text" class="text u71_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u72-13" class="ax_default paragraph u72" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u72-13_div" class="u72_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u72-13_text" class="text u72_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u73-13" class="ax_default paragraph u73" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u73-13_div" class="u73_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u73-13_text" class="text u73_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u74-13" class="ax_default paragraph u74" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u74-13_div" class="u74_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u74-13_text" class="text u74_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u75" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u76" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u77" class="ax_default paragraph selected" data-label="Others">
                          <div id="u77_div" class="selected"></div>
                          <div id="u77_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u78" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u78_div" class="selected"></div>
                          <div id="u78_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u79" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u79_div" class="selected"></div>
                          <div id="u79_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u80" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u80_div" class="selected"></div>
                          <div id="u80_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u81" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u81_div" class="selected"></div>
                          <div id="u81_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u82" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u82_div" class="selected"></div>
                          <div id="u82_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u83" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u83_div" class="selected"></div>
                          <div id="u83_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u84" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u84_div" class="selected"></div>
                          <div id="u84_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u85" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u85_div" class="selected"></div>
                          <div id="u85_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u86" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u86_div" class="selected"></div>
                          <div id="u86_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u87" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u87_div" class="selected"></div>
                          <div id="u87_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u88" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u88_div" class="selected"></div>
                          <div id="u88_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u89" class="ax_default paragraph selected">
                          <div id="u89_div" class="selected"></div>
                          <div id="u89_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u90" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u90_div" class="selected"></div>
                        <div id="u90_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u91" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u91_div" class="selected"></div>
                        <div id="u91_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u92" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u92_div" class="selected"></div>
                        <div id="u92_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u93" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u93_div" class="selected"></div>
                        <div id="u93_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u94" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u94_div" class="selected"></div>
                        <div id="u94_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u95" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u95_div" class="selected"></div>
                        <div id="u95_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u96" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u96_div" class="selected"></div>
                    <div id="u96_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u97" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u97_div" class="selected"></div>
                    <div id="u97_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u98" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u98_div" class="selected"></div>
            <div id="u98_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u99" class="ax_default" data-label="TAW" data-left="783" data-top="1522" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u100" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u100_div" class="selected"></div>
              <div id="u100_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u101" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u101_img" class="img " src="/footballui/public/frontend/images/page_a4/taw_dt_u101.svg"/>
              <div id="u101_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u102" class="ax_default" data-label="THW" data-left="68" data-top="1522" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u103" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u103_div" class="selected"></div>
              <div id="u103_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u104" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u104_img" class="img " src="/footballui/public/frontend/images/page_a4/thw_dt_u104.svg"/>
              <div id="u104_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u105" class="ax_default" data-label="DRAW" data-left="425" data-top="1522" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u106" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u106_div" class="selected"></div>
              <div id="u106_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u107" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u107_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u107.svg"/>
              <div id="u107_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u108" class="ax_default box_3 selected">
            <img id="u108_img" class="img " src="/footballui/public/frontend/images/page_a4/u108_selected.svg"/>
            <div id="u108_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u109" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1322" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u110" class="ax_default image" data-label="TA_G">
            <img id="u110_img" class="img " src="<?php echo e(asset($b15s->g_img)); ?>"/>
            <div id="u110_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u111" class="ax_default image" data-label="TH_G">
            <img id="u111_img" class="img " src="<?php echo e(asset($b15s->h_img)); ?>"/>
            <div id="u111_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u112" class="ax_default box_2" data-label="Team_Away">
            <div id="u112_div" class=""></div>
            <div id="u112_text" class="text ">
              <p><span><?php echo e($b15s->guest); ?></span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u113" class="ax_default box_2" data-label="Team_Home">
            <div id="u113_div" class=""></div>
            <div id="u113_text" class="text ">
              <p><span><?php echo e($b15s->host); ?></span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u114" class="ax_default box_2" data-label="Status">
            <div id="u114_div" class=""></div>
            <div id="u114_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u115" class="ax_default box_2" data-label="Number">
            <div id="u115_div" class=""></div>
            <div id="u115_text" class="text ">
              <p><span><?php echo e($b15s->jc_id); ?></span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u116" class="ax_default box_2" data-label="HKJC">
            <div id="u116_div" class=""></div>
            <div id="u116_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u117" class="ax_default box_2" data-label="Date_Time">
            <div id="u117_div" class=""></div>
            <div id="u117_text" class="text ">
              <p><span><?php echo e($b15s->date); ?></span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u118" class="ax_default box_2" data-label="Match">
            <div id="u118_div" class=""></div>
            <div id="u118_text" class="text ">
              <p><span><?php echo e($b15s->league); ?></span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G4 (Group) -->
      <div id="u119" class="ax_default" data-label="G4" data-left="68" data-top="1024" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u120" class="ax_default" data-label="Rate_Group" data-left="68" data-top="1224" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u121" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u121_state0" class="panel_state" data-label="State 1" style="">
              <div id="u121_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u122" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u123" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u123_div" class="selected"></div>
                    <div id="u123_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u124" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u125" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u126" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u126_div" class="selected"></div>
                        <div id="u126_text" class="text ">
                          <p><span><?php echo e($b14s->g_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u127" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u127_div" class="selected"></div>
                        <div id="u127_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u128" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u128_div" class="selected"></div>
                        <div id="u128_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u129" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u129_div" class="selected"></div>
                        <div id="u129_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u130" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u131" class="ax_default" data-label="TACS_Repeater">
                        <script id="u131_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132" class="ax_default paragraph u132" data-label="bold_3a">
                            <div id="u132_div" class="u132_div"></div>
                            <div id="u132_text" class="text u132_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133" class="ax_default paragraph u133" data-label="bold_2a">
                            <div id="u133_div" class="u133_div"></div>
                            <div id="u133_text" class="text u133_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134" class="ax_default paragraph u134" data-label="bold_1a">
                            <div id="u134_div" class="u134_div"></div>
                            <div id="u134_text" class="text u134_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135" class="ax_default paragraph u135" data-label="bold_0a">
                            <div id="u135_div" class="u135_div"></div>
                            <div id="u135_text" class="text u135_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u131-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-1" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-1_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-1_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-1" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-1_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-1_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-1" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-1_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-1_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-1" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-1_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-1_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-2" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-2_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-2_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-2" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-2_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-2_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-2" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-2_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-2_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-2" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-2_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-2_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-3" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-3_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-3_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-3" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-3_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-3_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-3" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-3_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-3_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-3" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-3_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-3_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-4" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-4_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-4_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-4" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-4_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-4_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-4" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-4_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-4_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-4" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-4_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-4_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-5" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-5_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-5_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-5" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-5_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-5_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-5" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-5_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-5_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-5" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-5_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-5_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-6" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-6_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-6_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-6" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-6_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-6_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-6" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-6_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-6_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-6" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-6_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-6_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-7" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-7_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-7_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-7" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-7_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-7_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-7" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-7_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-7_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-7" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-7_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-7_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-8" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-8_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-8_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-8" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-8_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-8_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-8" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-8_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-8_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-8" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-8_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-8_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-9" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-9_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-9_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-9" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-9_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-9_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-9" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-9_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-9_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-9" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-9_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-9_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-10" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-10_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-10_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-10" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-10_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-10_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-10" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-10_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-10_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-10" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-10_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-10_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-11" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-11_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-11_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-11" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-11_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-11_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-11" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-11_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-11_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-11" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-11_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-11_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-12" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-12_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-12_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-12" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-12_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-12_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-12" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-12_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-12_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-12" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-12_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-12_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u131-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u132-13" class="ax_default paragraph u132" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u132-13_div" class="u132_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u132-13_text" class="text u132_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u133-13" class="ax_default paragraph u133" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u133-13_div" class="u133_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u133-13_text" class="text u133_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u134-13" class="ax_default paragraph u134" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u134-13_div" class="u134_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u134-13_text" class="text u134_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u135-13" class="ax_default paragraph u135" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u135-13_div" class="u135_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u135-13_text" class="text u135_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u136" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u137" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u138" class="ax_default paragraph selected" data-label="Others">
                          <div id="u138_div" class="selected"></div>
                          <div id="u138_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u139" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u139_div" class="selected"></div>
                          <div id="u139_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u140" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u140_div" class="selected"></div>
                          <div id="u140_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u141" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u141_div" class="selected"></div>
                          <div id="u141_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u142" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u142_div" class="selected"></div>
                          <div id="u142_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u143" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u143_div" class="selected"></div>
                          <div id="u143_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u144" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u144_div" class="selected"></div>
                          <div id="u144_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u145" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u145_div" class="selected"></div>
                          <div id="u145_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u146" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u146_div" class="selected"></div>
                          <div id="u146_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u147" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u147_div" class="selected"></div>
                          <div id="u147_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u148" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u148_div" class="selected"></div>
                          <div id="u148_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u149" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u149_div" class="selected"></div>
                          <div id="u149_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u150" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u150_div" class="selected"></div>
                          <div id="u150_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u151" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u151_div" class="selected"></div>
                        <div id="u151_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u152" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u152_div" class="selected"></div>
                        <div id="u152_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u153" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u153_div" class="selected"></div>
                        <div id="u153_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u154" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u154_div" class="selected"></div>
                        <div id="u154_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u155" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u155_div" class="selected"></div>
                        <div id="u155_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u156" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u156_div" class="selected"></div>
                        <div id="u156_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u157" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u158" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u159" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u159_div" class="selected"></div>
                        <div id="u159_text" class="text ">
                          <p><span><?php echo e($b14s->draw); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u160" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u160_div" class="selected"></div>
                        <div id="u160_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u161" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u161_div" class="selected"></div>
                        <div id="u161_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u162" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u162_div" class="selected"></div>
                        <div id="u162_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u163" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u164" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u164_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u165" class="ax_default paragraph u165" data-label="bold_3a">
                            <div id="u165_div" class="u165_div"></div>
                            <div id="u165_text" class="text u165_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u166" class="ax_default paragraph u166" data-label="bold_2a">
                            <div id="u166_div" class="u166_div"></div>
                            <div id="u166_text" class="text u166_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u167" class="ax_default paragraph u167" data-label="bold_1a">
                            <div id="u167_div" class="u167_div"></div>
                            <div id="u167_text" class="text u167_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u168" class="ax_default paragraph u168" data-label="bold_0a">
                            <div id="u168_div" class="u168_div"></div>
                            <div id="u168_text" class="text u168_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u164-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u165-1" class="ax_default paragraph u165" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u165-1_div" class="u165_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u165-1_text" class="text u165_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u166-1" class="ax_default paragraph u166" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u166-1_div" class="u166_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u166-1_text" class="text u166_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u167-1" class="ax_default paragraph u167" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u167-1_div" class="u167_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u167-1_text" class="text u167_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u168-1" class="ax_default paragraph u168" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u168-1_div" class="u168_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u168-1_text" class="text u168_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u164-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u165-2" class="ax_default paragraph u165" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u165-2_div" class="u165_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u165-2_text" class="text u165_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u166-2" class="ax_default paragraph u166" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u166-2_div" class="u166_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u166-2_text" class="text u166_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u167-2" class="ax_default paragraph u167" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u167-2_div" class="u167_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u167-2_text" class="text u167_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u168-2" class="ax_default paragraph u168" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u168-2_div" class="u168_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u168-2_text" class="text u168_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u164-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u165-3" class="ax_default paragraph u165" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u165-3_div" class="u165_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u165-3_text" class="text u165_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u166-3" class="ax_default paragraph u166" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u166-3_div" class="u166_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u166-3_text" class="text u166_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u167-3" class="ax_default paragraph u167" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u167-3_div" class="u167_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u167-3_text" class="text u167_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u168-3" class="ax_default paragraph u168" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u168-3_div" class="u168_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u168-3_text" class="text u168_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u164-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u165-4" class="ax_default paragraph u165" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u165-4_div" class="u165_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u165-4_text" class="text u165_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u166-4" class="ax_default paragraph u166" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u166-4_div" class="u166_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u166-4_text" class="text u166_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u167-4" class="ax_default paragraph u167" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u167-4_div" class="u167_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u167-4_text" class="text u167_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u168-4" class="ax_default paragraph u168" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u168-4_div" class="u168_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u168-4_text" class="text u168_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u164-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u165-5" class="ax_default paragraph u165" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u165-5_div" class="u165_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u165-5_text" class="text u165_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u166-5" class="ax_default paragraph u166" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u166-5_div" class="u166_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u166-5_text" class="text u166_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u167-5" class="ax_default paragraph u167" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u167-5_div" class="u167_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u167-5_text" class="text u167_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u168-5" class="ax_default paragraph u168" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u168-5_div" class="u168_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u168-5_text" class="text u168_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u169" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u170" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u171" class="ax_default paragraph selected" data-label="Others">
                          <div id="u171_div" class="selected"></div>
                          <div id="u171_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u172" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u172_div" class="selected"></div>
                          <div id="u172_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u173" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u173_div" class="selected"></div>
                          <div id="u173_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u174" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u174_div" class="selected"></div>
                          <div id="u174_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u175" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u175_div" class="selected"></div>
                          <div id="u175_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u176" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u176_div" class="selected"></div>
                        <div id="u176_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u177" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u177_div" class="selected"></div>
                        <div id="u177_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u178" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u178_div" class="selected"></div>
                        <div id="u178_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u179" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u179_div" class="selected"></div>
                        <div id="u179_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u180" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u180_div" class="selected"></div>
                        <div id="u180_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u181" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u181_div" class="selected"></div>
                        <div id="u181_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u182" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u183" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u184" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u184_div" class="selected"></div>
                        <div id="u184_text" class="text ">
                          <p><span><?php echo e($b14s->h_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u185" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u185_div" class="selected"></div>
                        <div id="u185_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u186" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u186_div" class="selected"></div>
                        <div id="u186_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u187" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u187_div" class="selected"></div>
                        <div id="u187_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u188" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u189" class="ax_default" data-label="THCS_Repeater">
                        <script id="u189_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190" class="ax_default paragraph u190" data-label="bold_3a">
                            <div id="u190_div" class="u190_div"></div>
                            <div id="u190_text" class="text u190_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191" class="ax_default paragraph u191" data-label="bold_2a">
                            <div id="u191_div" class="u191_div"></div>
                            <div id="u191_text" class="text u191_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192" class="ax_default paragraph u192" data-label="bold_1a">
                            <div id="u192_div" class="u192_div"></div>
                            <div id="u192_text" class="text u192_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193" class="ax_default paragraph u193" data-label="bold_0a">
                            <div id="u193_div" class="u193_div"></div>
                            <div id="u193_text" class="text u193_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u189-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-1" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-1_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-1_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-1" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-1_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-1_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-1" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-1_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-1_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-1" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-1_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-1_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-2" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-2_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-2_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-2" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-2_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-2_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-2" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-2_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-2_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-2" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-2_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-2_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-3" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-3_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-3_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-3" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-3_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-3_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-3" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-3_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-3_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-3" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-3_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-3_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-4" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-4_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-4_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-4" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-4_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-4_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-4" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-4_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-4_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-4" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-4_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-4_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-5" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-5_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-5_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-5" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-5_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-5_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-5" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-5_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-5_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-5" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-5_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-5_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-6" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-6_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-6_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-6" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-6_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-6_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-6" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-6_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-6_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-6" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-6_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-6_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-7" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-7_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-7_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-7" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-7_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-7_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-7" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-7_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-7_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-7" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-7_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-7_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-8" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-8_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-8_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-8" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-8_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-8_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-8" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-8_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-8_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-8" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-8_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-8_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-9" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-9_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-9_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-9" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-9_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-9_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-9" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-9_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-9_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-9" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-9_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-9_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-10" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-10_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-10_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-10" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-10_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-10_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-10" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-10_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-10_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-10" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-10_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-10_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-11" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-11_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-11_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-11" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-11_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-11_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-11" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-11_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-11_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-11" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-11_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-11_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-12" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-12_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-12_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-12" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-12_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-12_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-12" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-12_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-12_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-12" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-12_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-12_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u189-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u190-13" class="ax_default paragraph u190" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u190-13_div" class="u190_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u190-13_text" class="text u190_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u191-13" class="ax_default paragraph u191" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u191-13_div" class="u191_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u191-13_text" class="text u191_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u192-13" class="ax_default paragraph u192" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u192-13_div" class="u192_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u192-13_text" class="text u192_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u193-13" class="ax_default paragraph u193" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u193-13_div" class="u193_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u193-13_text" class="text u193_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u194" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u195" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u196" class="ax_default paragraph selected" data-label="Others">
                          <div id="u196_div" class="selected"></div>
                          <div id="u196_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u197" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u197_div" class="selected"></div>
                          <div id="u197_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u198" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u198_div" class="selected"></div>
                          <div id="u198_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u199" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u199_div" class="selected"></div>
                          <div id="u199_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u200" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u200_div" class="selected"></div>
                          <div id="u200_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u201" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u201_div" class="selected"></div>
                          <div id="u201_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u202" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u202_div" class="selected"></div>
                          <div id="u202_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u203" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u203_div" class="selected"></div>
                          <div id="u203_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u204" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u204_div" class="selected"></div>
                          <div id="u204_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u205" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u205_div" class="selected"></div>
                          <div id="u205_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u206" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u206_div" class="selected"></div>
                          <div id="u206_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u207" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u207_div" class="selected"></div>
                          <div id="u207_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u208" class="ax_default paragraph selected">
                          <div id="u208_div" class="selected"></div>
                          <div id="u208_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u209" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u209_div" class="selected"></div>
                        <div id="u209_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u210" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u210_div" class="selected"></div>
                        <div id="u210_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u211" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u211_div" class="selected"></div>
                        <div id="u211_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u212" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u212_div" class="selected"></div>
                        <div id="u212_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u213" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u213_div" class="selected"></div>
                        <div id="u213_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u214" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u214_div" class="selected"></div>
                        <div id="u214_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u215" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u215_div" class="selected"></div>
                    <div id="u215_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u216" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u216_div" class="selected"></div>
                    <div id="u216_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u217" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u217_div" class="selected"></div>
            <div id="u217_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u218" class="ax_default" data-label="TAW" data-left="783" data-top="1224" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u219" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u219_div" class="selected"></div>
              <div id="u219_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u220" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u220_img" class="img " src="/footballui/public/frontend/images/page_a4/taw_dt_u101.svg"/>
              <div id="u220_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u221" class="ax_default" data-label="THW" data-left="68" data-top="1224" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u222" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u222_div" class="selected"></div>
              <div id="u222_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u223" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u223_img" class="img " src="/footballui/public/frontend/images/page_a4/thw_dt_u104.svg"/>
              <div id="u223_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u224" class="ax_default" data-label="DRAW" data-left="425" data-top="1224" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u225" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u225_div" class="selected"></div>
              <div id="u225_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u226" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u226_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u107.svg"/>
              <div id="u226_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u227" class="ax_default box_3 selected">
            <img id="u227_img" class="img " src="/footballui/public/frontend/images/page_a4/u108_selected.svg"/>
            <div id="u227_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u228" class="ax_default" data-label="Logo_Group" data-left="352" data-top="1024" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u229" class="ax_default image" data-label="TA_G">
            <img id="u229_img" class="img " src="<?php echo e(asset($b14s->g_img)); ?>"/>
            <div id="u229_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u230" class="ax_default image" data-label="TH_G">
            <img id="u230_img" class="img " src="<?php echo e(asset($b14s->h_img)); ?>"/>
            <div id="u230_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u231" class="ax_default box_2" data-label="Team_Away">
            <div id="u231_div" class=""></div>
            <div id="u231_text" class="text ">
              <p><span><?php echo e($b14s->guest); ?></span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u232" class="ax_default box_2" data-label="Team_Home">
            <div id="u232_div" class=""></div>
            <div id="u232_text" class="text ">
              <p><span><?php echo e($b14s->host); ?></span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u233" class="ax_default box_2" data-label="Status">
            <div id="u233_div" class=""></div>
            <div id="u233_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u234" class="ax_default box_2" data-label="Number">
            <div id="u234_div" class=""></div>
            <div id="u234_text" class="text ">
              <p><span><?php echo e($b14s->jc_id); ?></span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u235" class="ax_default box_2" data-label="HKJC">
            <div id="u235_div" class=""></div>
            <div id="u235_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u236" class="ax_default box_2" data-label="Date_Time">
            <div id="u236_div" class=""></div>
            <div id="u236_text" class="text ">
              <p><span><?php echo e($b14s->date); ?></span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u237" class="ax_default box_2" data-label="Match">
            <div id="u237_div" class=""></div>
            <div id="u237_text" class="text ">
              <p><span><?php echo e($b14s->league); ?></span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G3 (Group) -->
      <div id="u238" class="ax_default" data-label="G3" data-left="68" data-top="726" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u239" class="ax_default" data-label="Rate_Group" data-left="68" data-top="926" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u240" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u240_state0" class="panel_state" data-label="State 1" style="">
              <div id="u240_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u241" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u242" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u242_div" class="selected"></div>
                    <div id="u242_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u243" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u244" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u245" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u245_div" class="selected"></div>
                        <div id="u245_text" class="text ">
                          <p><span><?php echo e($b13s->g_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u246" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u246_div" class="selected"></div>
                        <div id="u246_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u247" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u247_div" class="selected"></div>
                        <div id="u247_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u248" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u248_div" class="selected"></div>
                        <div id="u248_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u249" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u250" class="ax_default" data-label="TACS_Repeater">
                        <script id="u250_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251" class="ax_default paragraph u251" data-label="bold_3a">
                            <div id="u251_div" class="u251_div"></div>
                            <div id="u251_text" class="text u251_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252" class="ax_default paragraph u252" data-label="bold_2a">
                            <div id="u252_div" class="u252_div"></div>
                            <div id="u252_text" class="text u252_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253" class="ax_default paragraph u253" data-label="bold_1a">
                            <div id="u253_div" class="u253_div"></div>
                            <div id="u253_text" class="text u253_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254" class="ax_default paragraph u254" data-label="bold_0a">
                            <div id="u254_div" class="u254_div"></div>
                            <div id="u254_text" class="text u254_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u250-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-1" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-1_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-1_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-1" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-1_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-1_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-1" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-1_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-1_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-1" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-1_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-1_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-2" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-2_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-2_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-2" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-2_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-2_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-2" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-2_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-2_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-2" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-2_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-2_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-3" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-3_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-3_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-3" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-3_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-3_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-3" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-3_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-3_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-3" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-3_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-3_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-4" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-4_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-4_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-4" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-4_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-4_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-4" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-4_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-4_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-4" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-4_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-4_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-5" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-5_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-5_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-5" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-5_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-5_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-5" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-5_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-5_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-5" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-5_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-5_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-6" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-6_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-6_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-6" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-6_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-6_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-6" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-6_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-6_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-6" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-6_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-6_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-7" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-7_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-7_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-7" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-7_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-7_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-7" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-7_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-7_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-7" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-7_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-7_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-8" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-8_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-8_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-8" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-8_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-8_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-8" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-8_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-8_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-8" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-8_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-8_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-9" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-9_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-9_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-9" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-9_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-9_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-9" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-9_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-9_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-9" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-9_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-9_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-10" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-10_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-10_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-10" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-10_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-10_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-10" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-10_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-10_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-10" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-10_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-10_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-11" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-11_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-11_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-11" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-11_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-11_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-11" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-11_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-11_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-11" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-11_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-11_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-12" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-12_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-12_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-12" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-12_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-12_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-12" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-12_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-12_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-12" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-12_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-12_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u250-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u251-13" class="ax_default paragraph u251" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u251-13_div" class="u251_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u251-13_text" class="text u251_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u252-13" class="ax_default paragraph u252" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u252-13_div" class="u252_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u252-13_text" class="text u252_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u253-13" class="ax_default paragraph u253" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u253-13_div" class="u253_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u253-13_text" class="text u253_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u254-13" class="ax_default paragraph u254" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u254-13_div" class="u254_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u254-13_text" class="text u254_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u255" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u256" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u257" class="ax_default paragraph selected" data-label="Others">
                          <div id="u257_div" class="selected"></div>
                          <div id="u257_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u258" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u258_div" class="selected"></div>
                          <div id="u258_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u259" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u259_div" class="selected"></div>
                          <div id="u259_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u260" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u260_div" class="selected"></div>
                          <div id="u260_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u261" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u261_div" class="selected"></div>
                          <div id="u261_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u262" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u262_div" class="selected"></div>
                          <div id="u262_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u263" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u263_div" class="selected"></div>
                          <div id="u263_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u264" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u264_div" class="selected"></div>
                          <div id="u264_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u265" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u265_div" class="selected"></div>
                          <div id="u265_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u266" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u266_div" class="selected"></div>
                          <div id="u266_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u267" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u267_div" class="selected"></div>
                          <div id="u267_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u268" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u268_div" class="selected"></div>
                          <div id="u268_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u269" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u269_div" class="selected"></div>
                          <div id="u269_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u270" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u270_div" class="selected"></div>
                        <div id="u270_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u271" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u271_div" class="selected"></div>
                        <div id="u271_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u272" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u272_div" class="selected"></div>
                        <div id="u272_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u273" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u273_div" class="selected"></div>
                        <div id="u273_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u274" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u274_div" class="selected"></div>
                        <div id="u274_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u275" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u275_div" class="selected"></div>
                        <div id="u275_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u276" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u277" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u278" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u278_div" class="selected"></div>
                        <div id="u278_text" class="text ">
                          <p><span><?php echo e($b13s->draw); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u279" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u279_div" class="selected"></div>
                        <div id="u279_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u280" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u280_div" class="selected"></div>
                        <div id="u280_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u281" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u281_div" class="selected"></div>
                        <div id="u281_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u282" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u283" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u283_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u284" class="ax_default paragraph u284" data-label="bold_3a">
                            <div id="u284_div" class="u284_div"></div>
                            <div id="u284_text" class="text u284_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u285" class="ax_default paragraph u285" data-label="bold_2a">
                            <div id="u285_div" class="u285_div"></div>
                            <div id="u285_text" class="text u285_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u286" class="ax_default paragraph u286" data-label="bold_1a">
                            <div id="u286_div" class="u286_div"></div>
                            <div id="u286_text" class="text u286_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u287" class="ax_default paragraph u287" data-label="bold_0a">
                            <div id="u287_div" class="u287_div"></div>
                            <div id="u287_text" class="text u287_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u283-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u284-1" class="ax_default paragraph u284" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u284-1_div" class="u284_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u284-1_text" class="text u284_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u285-1" class="ax_default paragraph u285" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u285-1_div" class="u285_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u285-1_text" class="text u285_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u286-1" class="ax_default paragraph u286" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u286-1_div" class="u286_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u286-1_text" class="text u286_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u287-1" class="ax_default paragraph u287" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u287-1_div" class="u287_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u287-1_text" class="text u287_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u283-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u284-2" class="ax_default paragraph u284" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u284-2_div" class="u284_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u284-2_text" class="text u284_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u285-2" class="ax_default paragraph u285" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u285-2_div" class="u285_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u285-2_text" class="text u285_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u286-2" class="ax_default paragraph u286" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u286-2_div" class="u286_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u286-2_text" class="text u286_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u287-2" class="ax_default paragraph u287" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u287-2_div" class="u287_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u287-2_text" class="text u287_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u283-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u284-3" class="ax_default paragraph u284" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u284-3_div" class="u284_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u284-3_text" class="text u284_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u285-3" class="ax_default paragraph u285" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u285-3_div" class="u285_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u285-3_text" class="text u285_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u286-3" class="ax_default paragraph u286" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u286-3_div" class="u286_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u286-3_text" class="text u286_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u287-3" class="ax_default paragraph u287" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u287-3_div" class="u287_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u287-3_text" class="text u287_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u283-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u284-4" class="ax_default paragraph u284" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u284-4_div" class="u284_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u284-4_text" class="text u284_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u285-4" class="ax_default paragraph u285" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u285-4_div" class="u285_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u285-4_text" class="text u285_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u286-4" class="ax_default paragraph u286" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u286-4_div" class="u286_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u286-4_text" class="text u286_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u287-4" class="ax_default paragraph u287" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u287-4_div" class="u287_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u287-4_text" class="text u287_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u283-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u284-5" class="ax_default paragraph u284" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u284-5_div" class="u284_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u284-5_text" class="text u284_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u285-5" class="ax_default paragraph u285" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u285-5_div" class="u285_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u285-5_text" class="text u285_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u286-5" class="ax_default paragraph u286" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u286-5_div" class="u286_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u286-5_text" class="text u286_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u287-5" class="ax_default paragraph u287" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u287-5_div" class="u287_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u287-5_text" class="text u287_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u288" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u289" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u290" class="ax_default paragraph selected" data-label="Others">
                          <div id="u290_div" class="selected"></div>
                          <div id="u290_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u291" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u291_div" class="selected"></div>
                          <div id="u291_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u292" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u292_div" class="selected"></div>
                          <div id="u292_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u293" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u293_div" class="selected"></div>
                          <div id="u293_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u294" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u294_div" class="selected"></div>
                          <div id="u294_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u295" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u295_div" class="selected"></div>
                        <div id="u295_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u296" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u296_div" class="selected"></div>
                        <div id="u296_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u297" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u297_div" class="selected"></div>
                        <div id="u297_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u298" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u298_div" class="selected"></div>
                        <div id="u298_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u299" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u299_div" class="selected"></div>
                        <div id="u299_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u300" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u300_div" class="selected"></div>
                        <div id="u300_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u301" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u302" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u303" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u303_div" class="selected"></div>
                        <div id="u303_text" class="text ">
                          <p><span><?php echo e($b13s->h_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u304" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u304_div" class="selected"></div>
                        <div id="u304_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u305" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u305_div" class="selected"></div>
                        <div id="u305_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u306" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u306_div" class="selected"></div>
                        <div id="u306_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u307" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u308" class="ax_default" data-label="THCS_Repeater">
                        <script id="u308_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309" class="ax_default paragraph u309" data-label="bold_3a">
                            <div id="u309_div" class="u309_div"></div>
                            <div id="u309_text" class="text u309_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310" class="ax_default paragraph u310" data-label="bold_2a">
                            <div id="u310_div" class="u310_div"></div>
                            <div id="u310_text" class="text u310_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311" class="ax_default paragraph u311" data-label="bold_1a">
                            <div id="u311_div" class="u311_div"></div>
                            <div id="u311_text" class="text u311_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312" class="ax_default paragraph u312" data-label="bold_0a">
                            <div id="u312_div" class="u312_div"></div>
                            <div id="u312_text" class="text u312_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u308-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-1" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-1_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-1_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-1" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-1_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-1_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-1" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-1_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-1_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-1" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-1_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-1_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-2" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-2_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-2_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-2" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-2_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-2_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-2" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-2_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-2_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-2" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-2_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-2_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-3" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-3_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-3_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-3" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-3_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-3_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-3" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-3_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-3_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-3" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-3_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-3_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-4" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-4_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-4_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-4" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-4_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-4_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-4" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-4_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-4_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-4" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-4_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-4_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-5" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-5_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-5_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-5" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-5_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-5_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-5" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-5_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-5_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-5" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-5_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-5_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-6" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-6_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-6_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-6" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-6_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-6_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-6" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-6_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-6_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-6" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-6_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-6_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-7" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-7_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-7_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-7" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-7_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-7_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-7" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-7_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-7_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-7" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-7_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-7_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-8" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-8_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-8_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-8" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-8_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-8_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-8" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-8_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-8_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-8" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-8_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-8_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-9" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-9_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-9_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-9" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-9_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-9_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-9" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-9_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-9_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-9" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-9_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-9_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-10" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-10_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-10_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-10" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-10_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-10_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-10" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-10_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-10_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-10" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-10_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-10_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-11" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-11_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-11_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-11" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-11_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-11_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-11" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-11_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-11_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-11" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-11_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-11_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-12" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-12_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-12_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-12" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-12_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-12_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-12" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-12_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-12_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-12" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-12_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-12_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u308-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u309-13" class="ax_default paragraph u309" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u309-13_div" class="u309_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u309-13_text" class="text u309_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u310-13" class="ax_default paragraph u310" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u310-13_div" class="u310_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u310-13_text" class="text u310_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u311-13" class="ax_default paragraph u311" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u311-13_div" class="u311_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u311-13_text" class="text u311_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u312-13" class="ax_default paragraph u312" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u312-13_div" class="u312_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u312-13_text" class="text u312_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u313" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u314" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u315" class="ax_default paragraph selected" data-label="Others">
                          <div id="u315_div" class="selected"></div>
                          <div id="u315_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u316" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u316_div" class="selected"></div>
                          <div id="u316_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u317" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u317_div" class="selected"></div>
                          <div id="u317_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u318" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u318_div" class="selected"></div>
                          <div id="u318_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u319" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u319_div" class="selected"></div>
                          <div id="u319_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u320" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u320_div" class="selected"></div>
                          <div id="u320_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u321" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u321_div" class="selected"></div>
                          <div id="u321_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u322" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u322_div" class="selected"></div>
                          <div id="u322_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u323" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u323_div" class="selected"></div>
                          <div id="u323_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u324" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u324_div" class="selected"></div>
                          <div id="u324_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u325" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u325_div" class="selected"></div>
                          <div id="u325_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u326" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u326_div" class="selected"></div>
                          <div id="u326_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u327" class="ax_default paragraph selected">
                          <div id="u327_div" class="selected"></div>
                          <div id="u327_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u328" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u328_div" class="selected"></div>
                        <div id="u328_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u329" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u329_div" class="selected"></div>
                        <div id="u329_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u330" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u330_div" class="selected"></div>
                        <div id="u330_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u331" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u331_div" class="selected"></div>
                        <div id="u331_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u332" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u332_div" class="selected"></div>
                        <div id="u332_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u333" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u333_div" class="selected"></div>
                        <div id="u333_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u334" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u334_div" class="selected"></div>
                    <div id="u334_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u335" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u335_div" class="selected"></div>
                    <div id="u335_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u336" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u336_div" class="selected"></div>
            <div id="u336_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u337" class="ax_default" data-label="TAW" data-left="783" data-top="926" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u338" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u338_div" class="selected"></div>
              <div id="u338_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u339" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u339_img" class="img " src="/footballui/public/frontend/images/page_a4/taw_dt_u101.svg"/>
              <div id="u339_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u340" class="ax_default" data-label="THW" data-left="68" data-top="926" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u341" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u341_div" class="selected"></div>
              <div id="u341_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u342" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u342_img" class="img " src="/footballui/public/frontend/images/page_a4/thw_dt_u104.svg"/>
              <div id="u342_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u343" class="ax_default" data-label="DRAW" data-left="425" data-top="926" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u344" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u344_div" class="selected"></div>
              <div id="u344_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u345" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u345_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u107.svg"/>
              <div id="u345_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u346" class="ax_default box_3 selected">
            <img id="u346_img" class="img " src="/footballui/public/frontend/images/page_a4/u108_selected.svg"/>
            <div id="u346_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u347" class="ax_default" data-label="Logo_Group" data-left="352" data-top="726" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u348" class="ax_default image" data-label="TA_G">
            <img id="u348_img" class="img " src="<?php echo e(asset($b13s->g_img)); ?>"/>
            <div id="u348_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u349" class="ax_default image" data-label="TH_G">
            <img id="u349_img" class="img " src="<?php echo e(asset($b13s->h_img)); ?>"/>
            <div id="u349_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u350" class="ax_default box_2" data-label="Team_Away">
            <div id="u350_div" class=""></div>
            <div id="u350_text" class="text ">
              <p><span><?php echo e($b13s->guest); ?></span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u351" class="ax_default box_2" data-label="Team_Home">
            <div id="u351_div" class=""></div>
            <div id="u351_text" class="text ">
              <p><span><?php echo e($b13s->host); ?></span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u352" class="ax_default box_2" data-label="Status">
            <div id="u352_div" class=""></div>
            <div id="u352_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u353" class="ax_default box_2" data-label="Number">
            <div id="u353_div" class=""></div>
            <div id="u353_text" class="text ">
              <p><span><?php echo e($b13s->jc_id); ?></span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u354" class="ax_default box_2" data-label="HKJC">
            <div id="u354_div" class=""></div>
            <div id="u354_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u355" class="ax_default box_2" data-label="Date_Time">
            <div id="u355_div" class=""></div>
            <div id="u355_text" class="text ">
              <p><span><?php echo e($b13s->date); ?></span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u356" class="ax_default box_2" data-label="Match">
            <div id="u356_div" class=""></div>
            <div id="u356_text" class="text ">
              <p><span><?php echo e($b13s->league); ?></span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G2 (Group) -->
      <div id="u357" class="ax_default" data-label="G2" data-left="68" data-top="428" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u358" class="ax_default" data-label="Rate_Group" data-left="68" data-top="628" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u359" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u359_state0" class="panel_state" data-label="State 1" style="">
              <div id="u359_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u360" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u361" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u361_div" class="selected"></div>
                    <div id="u361_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u362" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u363" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u364" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u364_div" class="selected"></div>
                        <div id="u364_text" class="text ">
                          <p><span><?php echo e($b12s->g_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u365" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u365_div" class="selected"></div>
                        <div id="u365_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u366" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u366_div" class="selected"></div>
                        <div id="u366_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u367" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u367_div" class="selected"></div>
                        <div id="u367_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u368" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u369" class="ax_default" data-label="TACS_Repeater">
                        <script id="u369_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370" class="ax_default paragraph u370" data-label="bold_3a">
                            <div id="u370_div" class="u370_div"></div>
                            <div id="u370_text" class="text u370_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371" class="ax_default paragraph u371" data-label="bold_2a">
                            <div id="u371_div" class="u371_div"></div>
                            <div id="u371_text" class="text u371_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372" class="ax_default paragraph u372" data-label="bold_1a">
                            <div id="u372_div" class="u372_div"></div>
                            <div id="u372_text" class="text u372_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373" class="ax_default paragraph u373" data-label="bold_0a">
                            <div id="u373_div" class="u373_div"></div>
                            <div id="u373_text" class="text u373_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u369-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-1" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-1_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-1_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-1" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-1_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-1_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-1" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-1_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-1_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-1" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-1_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-1_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-2" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-2_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-2_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-2" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-2_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-2_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-2" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-2_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-2_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-2" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-2_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-2_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-3" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-3_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-3_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-3" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-3_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-3_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-3" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-3_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-3_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-3" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-3_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-3_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-4" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-4_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-4_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-4" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-4_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-4_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-4" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-4_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-4_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-4" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-4_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-4_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-5" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-5_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-5_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-5" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-5_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-5_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-5" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-5_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-5_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-5" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-5_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-5_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-6" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-6_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-6_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-6" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-6_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-6_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-6" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-6_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-6_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-6" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-6_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-6_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-7" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-7_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-7_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-7" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-7_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-7_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-7" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-7_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-7_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-7" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-7_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-7_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-8" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-8_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-8_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-8" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-8_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-8_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-8" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-8_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-8_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-8" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-8_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-8_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-9" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-9_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-9_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-9" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-9_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-9_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-9" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-9_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-9_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-9" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-9_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-9_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-10" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-10_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-10_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-10" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-10_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-10_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-10" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-10_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-10_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-10" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-10_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-10_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-11" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-11_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-11_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-11" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-11_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-11_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-11" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-11_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-11_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-11" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-11_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-11_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-12" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-12_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-12_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-12" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-12_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-12_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-12" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-12_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-12_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-12" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-12_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-12_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u369-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u370-13" class="ax_default paragraph u370" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u370-13_div" class="u370_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u370-13_text" class="text u370_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u371-13" class="ax_default paragraph u371" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u371-13_div" class="u371_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u371-13_text" class="text u371_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u372-13" class="ax_default paragraph u372" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u372-13_div" class="u372_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u372-13_text" class="text u372_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u373-13" class="ax_default paragraph u373" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u373-13_div" class="u373_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u373-13_text" class="text u373_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u374" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u375" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u376" class="ax_default paragraph selected" data-label="Others">
                          <div id="u376_div" class="selected"></div>
                          <div id="u376_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u377" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u377_div" class="selected"></div>
                          <div id="u377_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u378" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u378_div" class="selected"></div>
                          <div id="u378_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u379" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u379_div" class="selected"></div>
                          <div id="u379_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u380" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u380_div" class="selected"></div>
                          <div id="u380_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u381" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u381_div" class="selected"></div>
                          <div id="u381_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u382" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u382_div" class="selected"></div>
                          <div id="u382_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u383" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u383_div" class="selected"></div>
                          <div id="u383_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u384" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u384_div" class="selected"></div>
                          <div id="u384_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u385" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u385_div" class="selected"></div>
                          <div id="u385_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u386" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u386_div" class="selected"></div>
                          <div id="u386_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u387" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u387_div" class="selected"></div>
                          <div id="u387_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u388" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u388_div" class="selected"></div>
                          <div id="u388_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u389" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u389_div" class="selected"></div>
                        <div id="u389_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u390" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u390_div" class="selected"></div>
                        <div id="u390_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u391" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u391_div" class="selected"></div>
                        <div id="u391_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u392" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u392_div" class="selected"></div>
                        <div id="u392_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u393" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u393_div" class="selected"></div>
                        <div id="u393_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u394" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u394_div" class="selected"></div>
                        <div id="u394_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u395" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u396" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u397" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u397_div" class="selected"></div>
                        <div id="u397_text" class="text ">
                          <p><span><?php echo e($b12s->draw); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u398" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u398_div" class="selected"></div>
                        <div id="u398_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u399" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u399_div" class="selected"></div>
                        <div id="u399_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u400" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u400_div" class="selected"></div>
                        <div id="u400_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u401" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u402" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u402_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u403" class="ax_default paragraph u403" data-label="bold_3a">
                            <div id="u403_div" class="u403_div"></div>
                            <div id="u403_text" class="text u403_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u404" class="ax_default paragraph u404" data-label="bold_2a">
                            <div id="u404_div" class="u404_div"></div>
                            <div id="u404_text" class="text u404_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u405" class="ax_default paragraph u405" data-label="bold_1a">
                            <div id="u405_div" class="u405_div"></div>
                            <div id="u405_text" class="text u405_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u406" class="ax_default paragraph u406" data-label="bold_0a">
                            <div id="u406_div" class="u406_div"></div>
                            <div id="u406_text" class="text u406_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u402-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u403-1" class="ax_default paragraph u403" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u403-1_div" class="u403_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u403-1_text" class="text u403_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u404-1" class="ax_default paragraph u404" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u404-1_div" class="u404_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u404-1_text" class="text u404_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u405-1" class="ax_default paragraph u405" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u405-1_div" class="u405_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u405-1_text" class="text u405_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u406-1" class="ax_default paragraph u406" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u406-1_div" class="u406_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u406-1_text" class="text u406_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u402-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u403-2" class="ax_default paragraph u403" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u403-2_div" class="u403_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u403-2_text" class="text u403_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u404-2" class="ax_default paragraph u404" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u404-2_div" class="u404_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u404-2_text" class="text u404_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u405-2" class="ax_default paragraph u405" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u405-2_div" class="u405_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u405-2_text" class="text u405_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u406-2" class="ax_default paragraph u406" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u406-2_div" class="u406_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u406-2_text" class="text u406_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u402-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u403-3" class="ax_default paragraph u403" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u403-3_div" class="u403_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u403-3_text" class="text u403_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u404-3" class="ax_default paragraph u404" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u404-3_div" class="u404_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u404-3_text" class="text u404_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u405-3" class="ax_default paragraph u405" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u405-3_div" class="u405_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u405-3_text" class="text u405_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u406-3" class="ax_default paragraph u406" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u406-3_div" class="u406_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u406-3_text" class="text u406_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u402-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u403-4" class="ax_default paragraph u403" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u403-4_div" class="u403_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u403-4_text" class="text u403_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u404-4" class="ax_default paragraph u404" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u404-4_div" class="u404_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u404-4_text" class="text u404_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u405-4" class="ax_default paragraph u405" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u405-4_div" class="u405_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u405-4_text" class="text u405_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u406-4" class="ax_default paragraph u406" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u406-4_div" class="u406_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u406-4_text" class="text u406_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u402-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u403-5" class="ax_default paragraph u403" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u403-5_div" class="u403_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u403-5_text" class="text u403_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u404-5" class="ax_default paragraph u404" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u404-5_div" class="u404_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u404-5_text" class="text u404_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u405-5" class="ax_default paragraph u405" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u405-5_div" class="u405_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u405-5_text" class="text u405_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u406-5" class="ax_default paragraph u406" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u406-5_div" class="u406_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u406-5_text" class="text u406_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u407" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u408" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u409" class="ax_default paragraph selected" data-label="Others">
                          <div id="u409_div" class="selected"></div>
                          <div id="u409_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u410" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u410_div" class="selected"></div>
                          <div id="u410_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u411" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u411_div" class="selected"></div>
                          <div id="u411_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u412" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u412_div" class="selected"></div>
                          <div id="u412_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u413" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u413_div" class="selected"></div>
                          <div id="u413_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u414" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u414_div" class="selected"></div>
                        <div id="u414_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u415" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u415_div" class="selected"></div>
                        <div id="u415_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u416" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u416_div" class="selected"></div>
                        <div id="u416_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u417" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u417_div" class="selected"></div>
                        <div id="u417_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u418" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u418_div" class="selected"></div>
                        <div id="u418_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u419" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u419_div" class="selected"></div>
                        <div id="u419_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u420" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u421" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u422" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u422_div" class="selected"></div>
                        <div id="u422_text" class="text ">
                          <p><span><?php echo e($b12s->h_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u423" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u423_div" class="selected"></div>
                        <div id="u423_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u424" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u424_div" class="selected"></div>
                        <div id="u424_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u425" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u425_div" class="selected"></div>
                        <div id="u425_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u426" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u427" class="ax_default" data-label="THCS_Repeater">
                        <script id="u427_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428" class="ax_default paragraph u428" data-label="bold_3a">
                            <div id="u428_div" class="u428_div"></div>
                            <div id="u428_text" class="text u428_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429" class="ax_default paragraph u429" data-label="bold_2a">
                            <div id="u429_div" class="u429_div"></div>
                            <div id="u429_text" class="text u429_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430" class="ax_default paragraph u430" data-label="bold_1a">
                            <div id="u430_div" class="u430_div"></div>
                            <div id="u430_text" class="text u430_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431" class="ax_default paragraph u431" data-label="bold_0a">
                            <div id="u431_div" class="u431_div"></div>
                            <div id="u431_text" class="text u431_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u427-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-1" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-1_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-1_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-1" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-1_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-1_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-1" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-1_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-1_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-1" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-1_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-1_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-2" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-2_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-2_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-2" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-2_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-2_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-2" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-2_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-2_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-2" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-2_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-2_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-3" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-3_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-3_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-3" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-3_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-3_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-3" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-3_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-3_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-3" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-3_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-3_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-4" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-4_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-4_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-4" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-4_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-4_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-4" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-4_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-4_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-4" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-4_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-4_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-5" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-5_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-5_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-5" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-5_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-5_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-5" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-5_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-5_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-5" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-5_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-5_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-6" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-6_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-6_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-6" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-6_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-6_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-6" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-6_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-6_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-6" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-6_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-6_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-7" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-7_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-7_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-7" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-7_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-7_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-7" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-7_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-7_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-7" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-7_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-7_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-8" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-8_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-8_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-8" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-8_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-8_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-8" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-8_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-8_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-8" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-8_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-8_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-9" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-9_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-9_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-9" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-9_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-9_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-9" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-9_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-9_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-9" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-9_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-9_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-10" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-10_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-10_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-10" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-10_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-10_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-10" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-10_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-10_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-10" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-10_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-10_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-11" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-11_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-11_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-11" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-11_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-11_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-11" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-11_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-11_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-11" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-11_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-11_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-12" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-12_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-12_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-12" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-12_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-12_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-12" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-12_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-12_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-12" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-12_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-12_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u427-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u428-13" class="ax_default paragraph u428" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u428-13_div" class="u428_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u428-13_text" class="text u428_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u429-13" class="ax_default paragraph u429" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u429-13_div" class="u429_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u429-13_text" class="text u429_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u430-13" class="ax_default paragraph u430" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u430-13_div" class="u430_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u430-13_text" class="text u430_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u431-13" class="ax_default paragraph u431" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u431-13_div" class="u431_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u431-13_text" class="text u431_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u432" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u433" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u434" class="ax_default paragraph selected" data-label="Others">
                          <div id="u434_div" class="selected"></div>
                          <div id="u434_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u435" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u435_div" class="selected"></div>
                          <div id="u435_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u436" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u436_div" class="selected"></div>
                          <div id="u436_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u437" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u437_div" class="selected"></div>
                          <div id="u437_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u438" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u438_div" class="selected"></div>
                          <div id="u438_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u439" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u439_div" class="selected"></div>
                          <div id="u439_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u440" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u440_div" class="selected"></div>
                          <div id="u440_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u441" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u441_div" class="selected"></div>
                          <div id="u441_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u442" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u442_div" class="selected"></div>
                          <div id="u442_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u443" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u443_div" class="selected"></div>
                          <div id="u443_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u444" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u444_div" class="selected"></div>
                          <div id="u444_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u445" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u445_div" class="selected"></div>
                          <div id="u445_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u446" class="ax_default paragraph selected">
                          <div id="u446_div" class="selected"></div>
                          <div id="u446_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u447" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u447_div" class="selected"></div>
                        <div id="u447_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u448" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u448_div" class="selected"></div>
                        <div id="u448_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u449" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u449_div" class="selected"></div>
                        <div id="u449_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u450" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u450_div" class="selected"></div>
                        <div id="u450_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u451" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u451_div" class="selected"></div>
                        <div id="u451_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u452" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u452_div" class="selected"></div>
                        <div id="u452_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u453" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u453_div" class="selected"></div>
                    <div id="u453_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u454" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u454_div" class="selected"></div>
                    <div id="u454_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u455" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u455_div" class="selected"></div>
            <div id="u455_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u456" class="ax_default" data-label="TAW" data-left="783" data-top="628" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u457" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u457_div" class="selected"></div>
              <div id="u457_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u458" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u458_img" class="img " src="/footballui/public/frontend/images/page_a4/taw_dt_u101.svg"/>
              <div id="u458_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u459" class="ax_default" data-label="THW" data-left="68" data-top="628" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u460" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u460_div" class="selected"></div>
              <div id="u460_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u461" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u461_img" class="img " src="/footballui/public/frontend/images/page_a4/thw_dt_u104.svg"/>
              <div id="u461_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u462" class="ax_default" data-label="DRAW" data-left="425" data-top="628" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u463" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u463_div" class="selected"></div>
              <div id="u463_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u464" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u464_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u107.svg"/>
              <div id="u464_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u465" class="ax_default box_3 selected">
            <img id="u465_img" class="img " src="/footballui/public/frontend/images/page_a4/u108_selected.svg"/>
            <div id="u465_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u466" class="ax_default" data-label="Logo_Group" data-left="352" data-top="428" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u467" class="ax_default image" data-label="TA_G">
            <img id="u467_img" class="img " src="<?php echo e(asset($b12s->g_img)); ?>"/>
            <div id="u467_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u468" class="ax_default image" data-label="TH_G">
            <img id="u468_img" class="img " src="<?php echo e(asset($b12s->h_img)); ?>"/>
            <div id="u468_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u469" class="ax_default box_2" data-label="Team_Away">
            <div id="u469_div" class=""></div>
            <div id="u469_text" class="text ">
              <p><span><?php echo e($b12s->guest); ?></span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u470" class="ax_default box_2" data-label="Team_Home">
            <div id="u470_div" class=""></div>
            <div id="u470_text" class="text ">
              <p><span><?php echo e($b12s->host); ?></span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u471" class="ax_default box_2" data-label="Status">
            <div id="u471_div" class=""></div>
            <div id="u471_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u472" class="ax_default box_2" data-label="Number">
            <div id="u472_div" class=""></div>
            <div id="u472_text" class="text ">
              <p><span><?php echo e($b12s->jc_id); ?></span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u473" class="ax_default box_2" data-label="HKJC">
            <div id="u473_div" class=""></div>
            <div id="u473_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u474" class="ax_default box_2" data-label="Date_Time">
            <div id="u474_div" class=""></div>
            <div id="u474_text" class="text ">
              <p><span><?php echo e($b12s->date); ?></span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u475" class="ax_default box_2" data-label="Match">
            <div id="u475_div" class=""></div>
            <div id="u475_text" class="text ">
              <p><span><?php echo e($b12s->league); ?></span></p>
            </div>
          </div>
        </div>
      </div>

      <!-- G1 (Group) -->
      <div id="u476" class="ax_default" data-label="G1" data-left="68" data-top="140" data-width="1230" data-height="240">

        <!-- Rate_Group (Group) -->
        <div id="u477" class="ax_default" data-label="Rate_Group" data-left="68" data-top="340" data-width="1230" data-height="40">

          <!-- Unnamed (Dynamic Panel) -->
          <div id="u478" class="ax_default ax_default_hidden" style="display:none; visibility: hidden">
            <div id="u478_state0" class="panel_state" data-label="State 1" style="">
              <div id="u478_state0_content" class="panel_state_content">

                <!-- CS_table (Group) -->
                <div id="u479" class="ax_default" data-label="CS_table" data-left="0" data-top="0" data-width="1282" data-height="690">

                  <!-- Foot_bar (Rectangle) -->
                  <div id="u480" class="ax_default box_1 selected" data-label="Foot_bar">
                    <div id="u480_div" class="selected"></div>
                    <div id="u480_text" class="text " style="display:none; visibility: hidden">
                      <p></p>
                    </div>
                  </div>

                  <!-- TACS (Group) -->
                  <div id="u481" class="ax_default" data-label="TACS" data-left="882" data-top="91" data-width="400" data-height="480">

                    <!-- TACS_total (Group) -->
                    <div id="u482" class="ax_default" data-label="TACS_total" data-left="962" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u483" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u483_div" class="selected"></div>
                        <div id="u483_text" class="text ">
                          <p><span><?php echo e($b1s->g_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u484" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u484_div" class="selected"></div>
                        <div id="u484_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u485" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u485_div" class="selected"></div>
                        <div id="u485_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u486" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u486_div" class="selected"></div>
                        <div id="u486_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_DB (Group) -->
                    <div id="u487" class="ax_default" data-label="TACS_DB" data-left="962" data-top="123" data-width="320" data-height="416">

                      <!-- TACS_Repeater (Repeater) -->
                      <div id="u488" class="ax_default" data-label="TACS_Repeater">
                        <script id="u488_script" type="axure-repeater-template" data-label="TACS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489" class="ax_default paragraph u489" data-label="bold_3a">
                            <div id="u489_div" class="u489_div"></div>
                            <div id="u489_text" class="text u489_text">
                              <p><span>59%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490" class="ax_default paragraph u490" data-label="bold_2a">
                            <div id="u490_div" class="u490_div"></div>
                            <div id="u490_text" class="text u490_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491" class="ax_default paragraph u491" data-label="bold_1a">
                            <div id="u491_div" class="u491_div"></div>
                            <div id="u491_text" class="text u491_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492" class="ax_default paragraph u492" data-label="bold_0a">
                            <div id="u492_div" class="u492_div"></div>
                            <div id="u492_text" class="text u492_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u488-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-1" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-1_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-1_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-1" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-1_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-1_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-1" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-1_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-1_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-1" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-1_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-1_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-2" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-2_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-2_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-2" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-2_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-2_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-2" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-2_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-2_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.190</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-2" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-2_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-2_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.170</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-3" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-3_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-3_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-3" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-3_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-3_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.230</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-3" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-3_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-3_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-3" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-3_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-3_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.210</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-4" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-4_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-4_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-4" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-4_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-4_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-4" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-4_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-4_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-4" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-4_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-4_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-5" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-5_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-5_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-5" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-5_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-5_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.095</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-5" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-5_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-5_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-5" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-5_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-5_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.075</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-6" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-6_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-6_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-6" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-6_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-6_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-6" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-6_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-6_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-6" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-6_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-6_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.055</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-7" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-7_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-7_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-7" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-7_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-7_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-7" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-7_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-7_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-7" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-7_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-7_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-8" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-8_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-8_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-8" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-8_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-8_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-8" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-8_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-8_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-8" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-8_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-8_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-9" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-9_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-9_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-9" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-9_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-9_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-9" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-9_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-9_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-9" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-9_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-9_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-10" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-10_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-10_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-10" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-10_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-10_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-10" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-10_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-10_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-10" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-10_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-10_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-11" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-11_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-11_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-11" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-11_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-11_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-11" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-11_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-11_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-11" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-11_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-11_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-12" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-12_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-12_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-12" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-12_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-12_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-12" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-12_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-12_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-12" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-12_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-12_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u488-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u489-13" class="ax_default paragraph u489" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u489-13_div" class="u489_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u489-13_text" class="text u489_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u490-13" class="ax_default paragraph u490" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u490-13_div" class="u490_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u490-13_text" class="text u490_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u491-13" class="ax_default paragraph u491" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u491-13_div" class="u491_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u491-13_text" class="text u491_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u492-13" class="ax_default paragraph u492" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u492-13_div" class="u492_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u492-13_text" class="text u492_text" style="visibility: inherit">
                              <p><span>0.080</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TACS_Group (Group) -->
                    <div id="u493" class="ax_default" data-label="TACS_Group" data-left="882" data-top="91" data-width="400" data-height="448">

                      <!-- TAMR_Group (Group) -->
                      <div id="u494" class="ax_default" data-label="TAMR_Group" data-left="882" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u495" class="ax_default paragraph selected" data-label="Others">
                          <div id="u495_div" class="selected"></div>
                          <div id="u495_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 2 - 5 (Rectangle) -->
                        <div id="u496" class="ax_default paragraph selected" data-label="2 - 5">
                          <div id="u496_div" class="selected"></div>
                          <div id="u496_text" class="text ">
                            <p><span>2 - 5</span></p>
                          </div>
                        </div>

                        <!-- 1 - 5 (Rectangle) -->
                        <div id="u497" class="ax_default paragraph selected" data-label="1 - 5">
                          <div id="u497_div" class="selected"></div>
                          <div id="u497_text" class="text ">
                            <p><span>1 - 5</span></p>
                          </div>
                        </div>

                        <!-- 0 - 5 (Rectangle) -->
                        <div id="u498" class="ax_default paragraph selected" data-label="0 - 5">
                          <div id="u498_div" class="selected"></div>
                          <div id="u498_text" class="text ">
                            <p><span>0 - 5</span></p>
                          </div>
                        </div>

                        <!-- 2 - 4 (Rectangle) -->
                        <div id="u499" class="ax_default paragraph selected" data-label="2 - 4">
                          <div id="u499_div" class="selected"></div>
                          <div id="u499_text" class="text ">
                            <p><span>2 - 4</span></p>
                          </div>
                        </div>

                        <!-- 1 - 4 (Rectangle) -->
                        <div id="u500" class="ax_default paragraph selected" data-label="1 - 4">
                          <div id="u500_div" class="selected"></div>
                          <div id="u500_text" class="text ">
                            <p><span>1 - 4</span></p>
                          </div>
                        </div>

                        <!-- 0 - 4 (Rectangle) -->
                        <div id="u501" class="ax_default paragraph selected" data-label="0 - 4">
                          <div id="u501_div" class="selected"></div>
                          <div id="u501_text" class="text ">
                            <p><span>0 - 4</span></p>
                          </div>
                        </div>

                        <!-- 2 - 3 (Rectangle) -->
                        <div id="u502" class="ax_default paragraph selected" data-label="2 - 3">
                          <div id="u502_div" class="selected"></div>
                          <div id="u502_text" class="text ">
                            <p><span>2 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 3 (Rectangle) -->
                        <div id="u503" class="ax_default paragraph selected" data-label="1 - 3">
                          <div id="u503_div" class="selected"></div>
                          <div id="u503_text" class="text ">
                            <p><span>1 - 3</span></p>
                          </div>
                        </div>

                        <!-- 0 - 3 (Rectangle) -->
                        <div id="u504" class="ax_default paragraph selected" data-label="0 - 3">
                          <div id="u504_div" class="selected"></div>
                          <div id="u504_text" class="text ">
                            <p><span>0 - 3</span></p>
                          </div>
                        </div>

                        <!-- 1 - 2 (Rectangle) -->
                        <div id="u505" class="ax_default paragraph selected" data-label="1 - 2">
                          <div id="u505_div" class="selected"></div>
                          <div id="u505_text" class="text ">
                            <p><span>1 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 2 (Rectangle) -->
                        <div id="u506" class="ax_default paragraph selected" data-label="0 - 2">
                          <div id="u506_div" class="selected"></div>
                          <div id="u506_text" class="text ">
                            <p><span>0 - 2</span></p>
                          </div>
                        </div>

                        <!-- 0 - 1 (Rectangle) -->
                        <div id="u507" class="ax_default paragraph selected" data-label="0 - 1">
                          <div id="u507_div" class="selected"></div>
                          <div id="u507_text" class="text ">
                            <p><span>0 - 1</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u508" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u508_div" class="selected"></div>
                        <div id="u508_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u509" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u509_div" class="selected"></div>
                        <div id="u509_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u510" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u510_div" class="selected"></div>
                        <div id="u510_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u511" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u511_div" class="selected"></div>
                        <div id="u511_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u512" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u512_div" class="selected"></div>
                        <div id="u512_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- TACS_b (Rectangle) -->
                      <div id="u513" class="ax_default paragraph selected" data-label="TACS_b">
                        <div id="u513_div" class="selected"></div>
                        <div id="u513_text" class="text ">
                          <p><span>客隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- DRCS (Group) -->
                  <div id="u514" class="ax_default" data-label="DRCS" data-left="442" data-top="91" data-width="400" data-height="224">

                    <!-- DRCS_total (Group) -->
                    <div id="u515" class="ax_default" data-label="DRCS_total" data-left="522" data-top="283" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u516" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u516_div" class="selected"></div>
                        <div id="u516_text" class="text ">
                          <p><span><?php echo e($b1s->draw); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u517" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u517_div" class="selected"></div>
                        <div id="u517_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u518" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u518_div" class="selected"></div>
                        <div id="u518_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u519" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u519_div" class="selected"></div>
                        <div id="u519_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_DB (Group) -->
                    <div id="u520" class="ax_default" data-label="DRCS_DB" data-left="522" data-top="123" data-width="320" data-height="160">

                      <!-- DRCS_Repeater (Repeater) -->
                      <div id="u521" class="ax_default" data-label="DRCS_Repeater">
                        <script id="u521_script" type="axure-repeater-template" data-label="DRCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u522" class="ax_default paragraph u522" data-label="bold_3a">
                            <div id="u522_div" class="u522_div"></div>
                            <div id="u522_text" class="text u522_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u523" class="ax_default paragraph u523" data-label="bold_2a">
                            <div id="u523_div" class="u523_div"></div>
                            <div id="u523_text" class="text u523_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u524" class="ax_default paragraph u524" data-label="bold_1a">
                            <div id="u524_div" class="u524_div"></div>
                            <div id="u524_text" class="text u524_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u525" class="ax_default paragraph u525" data-label="bold_0a">
                            <div id="u525_div" class="u525_div"></div>
                            <div id="u525_text" class="text u525_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u521-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u522-1" class="ax_default paragraph u522" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u522-1_div" class="u522_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u522-1_text" class="text u522_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u523-1" class="ax_default paragraph u523" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u523-1_div" class="u523_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u523-1_text" class="text u523_text" style="visibility: inherit">
                              <p><span>0.280</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u524-1" class="ax_default paragraph u524" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u524-1_div" class="u524_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u524-1_text" class="text u524_text" style="visibility: inherit">
                              <p><span>0.270</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u525-1" class="ax_default paragraph u525" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u525-1_div" class="u525_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u525-1_text" class="text u525_text" style="visibility: inherit">
                              <p><span>0.250</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u521-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u522-2" class="ax_default paragraph u522" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u522-2_div" class="u522_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u522-2_text" class="text u522_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u523-2" class="ax_default paragraph u523" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u523-2_div" class="u523_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u523-2_text" class="text u523_text" style="visibility: inherit">
                              <p><span>0.430</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u524-2" class="ax_default paragraph u524" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u524-2_div" class="u524_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u524-2_text" class="text u524_text" style="visibility: inherit">
                              <p><span>0.410</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u525-2" class="ax_default paragraph u525" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u525-2_div" class="u525_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u525-2_text" class="text u525_text" style="visibility: inherit">
                              <p><span>0.400</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u521-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u522-3" class="ax_default paragraph u522" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u522-3_div" class="u522_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u522-3_text" class="text u522_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u523-3" class="ax_default paragraph u523" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u523-3_div" class="u523_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u523-3_text" class="text u523_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u524-3" class="ax_default paragraph u524" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u524-3_div" class="u524_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u524-3_text" class="text u524_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u525-3" class="ax_default paragraph u525" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u525-3_div" class="u525_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u525-3_text" class="text u525_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u521-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u522-4" class="ax_default paragraph u522" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u522-4_div" class="u522_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u522-4_text" class="text u522_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u523-4" class="ax_default paragraph u523" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u523-4_div" class="u523_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u523-4_text" class="text u523_text" style="visibility: inherit">
                              <p><span>0.120</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u524-4" class="ax_default paragraph u524" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u524-4_div" class="u524_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u524-4_text" class="text u524_text" style="visibility: inherit">
                              <p><span>0.110</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u525-4" class="ax_default paragraph u525" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u525-4_div" class="u525_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u525-4_text" class="text u525_text" style="visibility: inherit">
                              <p><span>0.100</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u521-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u522-5" class="ax_default paragraph u522" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u522-5_div" class="u522_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u522-5_text" class="text u522_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u523-5" class="ax_default paragraph u523" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u523-5_div" class="u523_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u523-5_text" class="text u523_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u524-5" class="ax_default paragraph u524" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u524-5_div" class="u524_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u524-5_text" class="text u524_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u525-5" class="ax_default paragraph u525" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u525-5_div" class="u525_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u525-5_text" class="text u525_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- DRCS_Group (Group) -->
                    <div id="u526" class="ax_default" data-label="DRCS_Group" data-left="442" data-top="91" data-width="400" data-height="192">

                      <!-- DRMR_Group (Group) -->
                      <div id="u527" class="ax_default" data-label="DRMR_Group" data-left="442" data-top="123" data-width="80" data-height="160">

                        <!-- Others (Rectangle) -->
                        <div id="u528" class="ax_default paragraph selected" data-label="Others">
                          <div id="u528_div" class="selected"></div>
                          <div id="u528_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 3 - 3 (Rectangle) -->
                        <div id="u529" class="ax_default paragraph selected" data-label="3 - 3">
                          <div id="u529_div" class="selected"></div>
                          <div id="u529_text" class="text ">
                            <p><span>3 - 3</span></p>
                          </div>
                        </div>

                        <!-- 2 - 2 (Rectangle) -->
                        <div id="u530" class="ax_default paragraph selected" data-label="2 - 2">
                          <div id="u530_div" class="selected"></div>
                          <div id="u530_text" class="text ">
                            <p><span>2 - 2</span></p>
                          </div>
                        </div>

                        <!-- 1 - 1 (Rectangle) -->
                        <div id="u531" class="ax_default paragraph selected" data-label="1 - 1">
                          <div id="u531_div" class="selected"></div>
                          <div id="u531_text" class="text ">
                            <p><span>1 - 1</span></p>
                          </div>
                        </div>

                        <!-- 0 - 0 (Rectangle) -->
                        <div id="u532" class="ax_default paragraph selected" data-label="0 - 0">
                          <div id="u532_div" class="selected"></div>
                          <div id="u532_text" class="text ">
                            <p><span>0 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u533" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u533_div" class="selected"></div>
                        <div id="u533_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u534" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u534_div" class="selected"></div>
                        <div id="u534_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u535" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u535_div" class="selected"></div>
                        <div id="u535_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u536" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u536_div" class="selected"></div>
                        <div id="u536_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u537" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u537_div" class="selected"></div>
                        <div id="u537_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- DRCS_b (Rectangle) -->
                      <div id="u538" class="ax_default paragraph selected" data-label="DRCS_b">
                        <div id="u538_div" class="selected"></div>
                        <div id="u538_text" class="text ">
                          <p><span>和局</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- THCS (Group) -->
                  <div id="u539" class="ax_default" data-label="THCS" data-left="0" data-top="91" data-width="400" data-height="480">

                    <!-- THCS_total (Group) -->
                    <div id="u540" class="ax_default" data-label="THCS_total" data-left="80" data-top="539" data-width="320" data-height="32">

                      <!-- bold_3b (Rectangle) -->
                      <div id="u541" class="ax_default paragraph selected" data-label="bold_3b">
                        <div id="u541_div" class="selected"></div>
                        <div id="u541_text" class="text ">
                          <p><span><?php echo e($b1s->h_win); ?>%</span></p>
                        </div>
                      </div>

                      <!-- bold_2b (Rectangle) -->
                      <div id="u542" class="ax_default paragraph selected" data-label="bold_2b">
                        <div id="u542_div" class="selected"></div>
                        <div id="u542_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_1b (Rectangle) -->
                      <div id="u543" class="ax_default paragraph selected" data-label="bold_1b">
                        <div id="u543_div" class="selected"></div>
                        <div id="u543_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>

                      <!-- bold_0b (Rectangle) -->
                      <div id="u544" class="ax_default paragraph selected" data-label="bold_0b">
                        <div id="u544_div" class="selected"></div>
                        <div id="u544_text" class="text ">
                          <p><span>100%</span></p>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_DB (Group) -->
                    <div id="u545" class="ax_default" data-label="THCS_DB" data-left="80" data-top="123" data-width="320" data-height="416">

                      <!-- THCS_Repeater (Repeater) -->
                      <div id="u546" class="ax_default" data-label="THCS_Repeater">
                        <script id="u546_script" type="axure-repeater-template" data-label="THCS_Repeater">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547" class="ax_default paragraph u547" data-label="bold_3a">
                            <div id="u547_div" class="u547_div"></div>
                            <div id="u547_text" class="text u547_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548" class="ax_default paragraph u548" data-label="bold_2a">
                            <div id="u548_div" class="u548_div"></div>
                            <div id="u548_text" class="text u548_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549" class="ax_default paragraph u549" data-label="bold_1a">
                            <div id="u549_div" class="u549_div"></div>
                            <div id="u549_text" class="text u549_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550" class="ax_default paragraph u550" data-label="bold_0a">
                            <div id="u550_div" class="u550_div"></div>
                            <div id="u550_text" class="text u550_text" style="display:none; visibility: hidden">
                              <p></p>
                            </div>
                          </div>
                        </script>
                        <div id="u546-1" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-1" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-1_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-1_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-1" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-1_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-1_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-1" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-1_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-1_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.160</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-1" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-1_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-1_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.150</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-2" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-2" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-2_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-2_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-2" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-2_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-2_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-2" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-2_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-2_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.200</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-2" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-2_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-2_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.180</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-3" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-3" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-3_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-3_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-3" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-3_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-3_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.260</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-3" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-3_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-3_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.240</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-3" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-3_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-3_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.220</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-4" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-4" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-4_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-4_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-4" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-4_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-4_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-4" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-4_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-4_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-4" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-4_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-4_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-5" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-5" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-5_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-5_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-5" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-5_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-5_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.105</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-5" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-5_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-5_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.085</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-5" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-5_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-5_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-6" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-6" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-6_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-6_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-6" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-6_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-6_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-6" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-6_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-6_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.045</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-6" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-6_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-6_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.065</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-7" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-7" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-7_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-7_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-7" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-7_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-7_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-7" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-7_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-7_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-7" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-7_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-7_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-8" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-8" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-8_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-8_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-8" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-8_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-8_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-8" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-8_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-8_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-8" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-8_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-8_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.035</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-9" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-9" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-9_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-9_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-9" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-9_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-9_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-9" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-9_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-9_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-9" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-9_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-9_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-10" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-10" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-10_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-10_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-10" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-10_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-10_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.015</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-10" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-10_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-10_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.020</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-10" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-10_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-10_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.040</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-11" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-11" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-11_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-11_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-11" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-11_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-11_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-11" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-11_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-11_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.030</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-11" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-11_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-11_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.025</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-12" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-12" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-12_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-12_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-12" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-12_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-12_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-12" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-12_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-12_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-12" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-12_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-12_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.010</span></p>
                            </div>
                          </div>
                        </div>
                        <div id="u546-13" class="preeval" style="width: 320px; height: 32px;">

                          <!-- bold_3a (Rectangle) -->
                          <div id="u547-13" class="ax_default paragraph u547" data-label="bold_3a" style="width: 80px; height: 32px; left: 240px; top: 0px;visibility: inherit">
                            <div id="u547-13_div" class="u547_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u547-13_text" class="text u547_text" style="visibility: inherit">
                              <p><span>0%</span></p>
                            </div>
                          </div>

                          <!-- bold_2a (Rectangle) -->
                          <div id="u548-13" class="ax_default paragraph u548" data-label="bold_2a" style="width: 80px; height: 32px; left: 160px; top: 0px;visibility: inherit">
                            <div id="u548-13_div" class="u548_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u548-13_text" class="text u548_text" style="visibility: inherit">
                              <p><span>0.050</span></p>
                            </div>
                          </div>

                          <!-- bold_1a (Rectangle) -->
                          <div id="u549-13" class="ax_default paragraph u549" data-label="bold_1a" style="width: 80px; height: 32px; left: 80px; top: 0px;visibility: inherit">
                            <div id="u549-13_div" class="u549_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u549-13_text" class="text u549_text" style="visibility: inherit">
                              <p><span>0.070</span></p>
                            </div>
                          </div>

                          <!-- bold_0a (Rectangle) -->
                          <div id="u550-13" class="ax_default paragraph u550" data-label="bold_0a" style="width: 80px; height: 32px; left: 0px; top: 0px;visibility: inherit">
                            <div id="u550-13_div" class="u550_div" style="width: 80px; height: 32px;visibility: inherit"></div>
                            <div id="u550-13_text" class="text u550_text" style="visibility: inherit">
                              <p><span>0.060</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- THCS_Group (Group) -->
                    <div id="u551" class="ax_default" data-label="THCS_Group" data-left="0" data-top="91" data-width="400" data-height="448">

                      <!-- THMR_Group (Group) -->
                      <div id="u552" class="ax_default" data-label="THMR_Group" data-left="0" data-top="123" data-width="80" data-height="416">

                        <!-- Others (Rectangle) -->
                        <div id="u553" class="ax_default paragraph selected" data-label="Others">
                          <div id="u553_div" class="selected"></div>
                          <div id="u553_text" class="text ">
                            <p><span>其他</span></p>
                          </div>
                        </div>

                        <!-- 5 - 2 (Rectangle) -->
                        <div id="u554" class="ax_default paragraph selected" data-label="5 - 2">
                          <div id="u554_div" class="selected"></div>
                          <div id="u554_text" class="text ">
                            <p><span>5 - 2</span></p>
                          </div>
                        </div>

                        <!-- 5 - 1 (Rectangle) -->
                        <div id="u555" class="ax_default paragraph selected" data-label="5 - 1">
                          <div id="u555_div" class="selected"></div>
                          <div id="u555_text" class="text ">
                            <p><span>5 - 1</span></p>
                          </div>
                        </div>

                        <!-- 5 - 0 (Rectangle) -->
                        <div id="u556" class="ax_default paragraph selected" data-label="5 - 0">
                          <div id="u556_div" class="selected"></div>
                          <div id="u556_text" class="text ">
                            <p><span>5 - 0</span></p>
                          </div>
                        </div>

                        <!-- 4 - 2 (Rectangle) -->
                        <div id="u557" class="ax_default paragraph selected" data-label="4 - 2">
                          <div id="u557_div" class="selected"></div>
                          <div id="u557_text" class="text ">
                            <p><span>4 - 2</span></p>
                          </div>
                        </div>

                        <!-- 4 - 1 (Rectangle) -->
                        <div id="u558" class="ax_default paragraph selected" data-label="4 - 1">
                          <div id="u558_div" class="selected"></div>
                          <div id="u558_text" class="text ">
                            <p><span>4 - 1</span></p>
                          </div>
                        </div>

                        <!-- 4 - 0 (Rectangle) -->
                        <div id="u559" class="ax_default paragraph selected" data-label="4 - 0">
                          <div id="u559_div" class="selected"></div>
                          <div id="u559_text" class="text ">
                            <p><span>4 - 0</span></p>
                          </div>
                        </div>

                        <!-- 3 - 2 (Rectangle) -->
                        <div id="u560" class="ax_default paragraph selected" data-label="3 - 2">
                          <div id="u560_div" class="selected"></div>
                          <div id="u560_text" class="text ">
                            <p><span>3 - 2</span></p>
                          </div>
                        </div>

                        <!-- 3 - 1 (Rectangle) -->
                        <div id="u561" class="ax_default paragraph selected" data-label="3 - 1">
                          <div id="u561_div" class="selected"></div>
                          <div id="u561_text" class="text ">
                            <p><span>3 - 1</span></p>
                          </div>
                        </div>

                        <!-- 3 - 0 (Rectangle) -->
                        <div id="u562" class="ax_default paragraph selected" data-label="3 - 0">
                          <div id="u562_div" class="selected"></div>
                          <div id="u562_text" class="text ">
                            <p><span>3 - 0</span></p>
                          </div>
                        </div>

                        <!-- 2 - 1 (Rectangle) -->
                        <div id="u563" class="ax_default paragraph selected" data-label="2 - 1">
                          <div id="u563_div" class="selected"></div>
                          <div id="u563_text" class="text ">
                            <p><span>2 - 1</span></p>
                          </div>
                        </div>

                        <!-- 2 - 0 (Rectangle) -->
                        <div id="u564" class="ax_default paragraph selected" data-label="2 - 0">
                          <div id="u564_div" class="selected"></div>
                          <div id="u564_text" class="text ">
                            <p><span>2 - 0</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u565" class="ax_default paragraph selected">
                          <div id="u565_div" class="selected"></div>
                          <div id="u565_text" class="text ">
                            <p><span>1 - 0</span></p>
                          </div>
                        </div>
                      </div>

                      <!-- CS_rtg (Rectangle) -->
                      <div id="u566" class="ax_default box_3 selected" data-label="CS_rtg">
                        <div id="u566_div" class="selected"></div>
                        <div id="u566_text" class="text " style="display:none; visibility: hidden">
                          <p></p>
                        </div>
                      </div>

                      <!-- CS_r (Rectangle) -->
                      <div id="u567" class="ax_default paragraph selected" data-label="CS_r">
                        <div id="u567_div" class="selected"></div>
                        <div id="u567_text" class="text ">
                          <p><span>波膽機率</span></p>
                        </div>
                      </div>

                      <!-- Series3 (Rectangle) -->
                      <div id="u568" class="ax_default paragraph selected" data-label="Series3">
                        <div id="u568_div" class="selected"></div>
                        <div id="u568_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">3</span></p>
                        </div>
                      </div>

                      <!-- Series2 (Rectangle) -->
                      <div id="u569" class="ax_default paragraph selected" data-label="Series2">
                        <div id="u569_div" class="selected"></div>
                        <div id="u569_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">2</span></p>
                        </div>
                      </div>

                      <!-- Series1 (Rectangle) -->
                      <div id="u570" class="ax_default paragraph selected" data-label="Series1">
                        <div id="u570_div" class="selected"></div>
                        <div id="u570_text" class="text ">
                          <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">系數</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">1</span></p>
                        </div>
                      </div>

                      <!-- THCS_b (Rectangle) -->
                      <div id="u571" class="ax_default paragraph selected" data-label="THCS_b">
                        <div id="u571_div" class="selected"></div>
                        <div id="u571_text" class="text ">
                          <p><span>主隊波膽</span></p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- CS_text (Rectangle) -->
                  <div id="u572" class="ax_default paragraph selected" data-label="CS_text">
                    <div id="u572_div" class="selected"></div>
                    <div id="u572_text" class="text ">
                      <p><span>以下波膽之系數1，系數2，系數3及波膽機率，使用了歷年來過千場相關賽事的往績紀錄，主隊近年主場賽事往績及客隊近年作客賽場往績作出精細統計並以AI大數據方法分析，只供參考！</span></p>
                    </div>
                  </div>

                  <!-- CS_title (Rectangle) -->
                  <div id="u573" class="ax_default heading_3 selected" data-label="CS_title">
                    <div id="u573_div" class="selected"></div>
                    <div id="u573_text" class="text ">
                      <p><span>波膽</span><span>數據預測</span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Rate_bar (Rectangle) -->
          <div id="u574" class="ax_default box_1 selected" data-label="Rate_bar">
            <div id="u574_div" class="selected"></div>
            <div id="u574_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TAW (Group) -->
          <div id="u575" class="ax_default" data-label="TAW" data-left="783" data-top="340" data-width="357" data-height="40">

            <!-- TAW_D (Rectangle) -->
            <div id="u576" class="ax_default box_1 selected" data-label="TAW_D">
              <div id="u576_div" class="selected"></div>
              <div id="u576_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- TAW_Dt (Rectangle) -->
            <div id="u577" class="ax_default box_1 selected" data-label="TAW_Dt">
              <img id="u577_img" class="img " src="/footballui/public/frontend/images/page_a4/taw_dt_u101.svg"/>
              <div id="u577_text" class="text ">
                <p><span>客勝 59%</span></p>
              </div>
            </div>
          </div>

          <!-- THW (Group) -->
          <div id="u578" class="ax_default" data-label="THW" data-left="68" data-top="340" data-width="357" data-height="40">

            <!-- THW_D (Rectangle) -->
            <div id="u579" class="ax_default box_1 selected" data-label="THW_D">
              <div id="u579_div" class="selected"></div>
              <div id="u579_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- THW_Dt (Rectangle) -->
            <div id="u580" class="ax_default box_1 selected" data-label="THW_Dt">
              <img id="u580_img" class="img " src="/footballui/public/frontend/images/page_a4/thw_dt_u104.svg"/>
              <div id="u580_text" class="text ">
                <p><span>主勝 30%</span></p>
              </div>
            </div>
          </div>

          <!-- DRAW (Group) -->
          <div id="u581" class="ax_default" data-label="DRAW" data-left="425" data-top="340" data-width="358" data-height="40">

            <!-- DRAW_D (Rectangle) -->
            <div id="u582" class="ax_default box_1 selected" data-label="DRAW_D">
              <div id="u582_div" class="selected"></div>
              <div id="u582_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- DRAW_Dt (Rectangle) -->
            <div id="u583" class="ax_default box_1 selected" data-label="DRAW_Dt">
              <img id="u583_img" class="img " src="/footballui/public/frontend/images/page_a4/draw_dt_u107.svg"/>
              <div id="u583_text" class="text ">
                <p><span>和波 11%</span></p>
              </div>
            </div>
          </div>

          <!-- Unnamed (Rectangle) -->
          <div id="u584" class="ax_default box_3 selected">
            <img id="u584_img" class="img " src="/footballui/public/frontend/images/page_a4/u108_selected.svg"/>
            <div id="u584_text" class="text ">
              <p><span>波膽分析</span></p>
            </div>
          </div>
        </div>

        <!-- Logo_Group (Group) -->
        <div id="u585" class="ax_default" data-label="Logo_Group" data-left="352" data-top="140" data-width="680" data-height="146">

          <!-- TA_G (Image) -->
          <div id="u586" class="ax_default image" data-label="TA_G">
            <img id="u586_img" class="img " src="<?php echo e(asset($b1s->g_img)); ?>"/>
            <div id="u586_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- TH_G (Image) -->
          <div id="u587" class="ax_default image" data-label="TH_G">
            <img id="u587_img" class="img " src="<?php echo e(asset($b1s->h_img)); ?>"/>
            <div id="u587_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Team_Away (Rectangle) -->
          <div id="u588" class="ax_default box_2" data-label="Team_Away">
            <div id="u588_div" class=""></div>
            <div id="u588_text" class="text ">
              <p><span><?php echo e($b1s->guest); ?></span></p>
            </div>
          </div>

          <!-- Team_Home (Rectangle) -->
          <div id="u589" class="ax_default box_2" data-label="Team_Home">
            <div id="u589_div" class=""></div>
            <div id="u589_text" class="text ">
              <p><span><?php echo e($b1s->host); ?></span></p>
            </div>
          </div>

          <!-- Status (Rectangle) -->
          <div id="u590" class="ax_default box_2" data-label="Status">
            <div id="u590_div" class=""></div>
            <div id="u590_text" class="text ">
              <p><span>&nbsp;&nbsp; &nbsp;&nbsp; </span></p>
            </div>
          </div>

          <!-- Number (Rectangle) -->
          <div id="u591" class="ax_default box_2" data-label="Number">
            <div id="u591_div" class=""></div>
            <div id="u591_text" class="text ">
              <p><span><?php echo e($b1s->jc_id); ?></span></p>
            </div>
          </div>

          <!-- HKJC (Rectangle) -->
          <div id="u592" class="ax_default box_2" data-label="HKJC">
            <div id="u592_div" class=""></div>
            <div id="u592_text" class="text ">
              <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">球賽編號 </span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">#</span></p>
            </div>
          </div>

          <!-- Date_Time (Rectangle) -->
          <div id="u593" class="ax_default box_2" data-label="Date_Time">
            <div id="u593_div" class=""></div>
            <div id="u593_text" class="text ">
              <p><span><?php echo e($b1s->date); ?></span></p>
            </div>
          </div>

          <!-- Match (Rectangle) -->
          <div id="u594" class="ax_default box_2" data-label="Match">
            <div id="u594_div" class=""></div>
            <div id="u594_text" class="text ">
              <p><span><?php echo e($b1s->league); ?></span></p>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <!-- Date (Group) -->
      <div id="u595" class="ax_default" data-label="Date" data-left="896" data-top="98" data-width="320" data-height="30">

        <!-- Unnamed (Rectangle) -->
        <div id="u596" class="ax_default box_1">
          <div id="u596_div" class=""></div>
          <div id="u596_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- After_tomorrow (Rectangle) -->
        <div id="u597" class="ax_default label" data-label="After_tomorrow">
          <div id="u597_div" class=""></div>
          <div id="u597_text" class="text " onclick="window.location='/footballui/public/page_a4d3';">
            <p><span>後日</span></p>
          </div>
        </div>

        <!-- Tomorrow (Rectangle) -->
        <div id="u598" class="ax_default label" data-label="Tomorrow"  style="background-color:#5D5D5D">
          <div id="u598_div" class=""></div>
          <div id="u598_text" class="text " style="color:white">
            <p><span>明日</span></p>
          </div>
        </div>

        <!-- Today (Rectangle) -->
        <div id="u599" class="ax_default label" data-label="Today">
          <div id="u599_div" class=""></div>
          <div id="u599_text" class="text " onclick="window.location='/footballui/public/page_a4';">
            <p><span>今日</span></p>
          </div>
        </div>

        <!-- Match_date (Rectangle) -->
        <div id="u600" class="ax_default label" data-label="Match_date">
          <div id="u600_div" class=""></div>
          <div id="u600_text" class="text ">
            <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">賽程 </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;color:#000000;">►</span></p>
          </div>
        </div>
      </div>

      <!-- Header (Rectangle) -->
      <div id="u601" class="ax_default box_2" data-label="Header">
        <div id="u601_div" class=""></div>
        <div id="u601_text" class="text ">
          <p><span>AI模組波膽分析</span></p>
        </div>
      </div>

      <!-- Unnamed (NAVIGATION BAR) -->

      <!-- NAVIGATION BAR (Group) -->
      <div id="u603" class="ax_default" data-label="NAVIGATION BAR" data-left="0" data-top="0" data-width="1366" data-height="209">

        <!-- Unnamed (Rectangle) -->
        <div id="u604" class="ax_default box_1">
          <div id="u604_div" class=""></div>
          <div id="u604_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u605" class="ax_default box_3">
          <div id="u605_div" class=""></div>
          <div id="u605_text" class="text ">
            <p><span>首頁</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u606" class="ax_default box_3">
          <div id="u606_div" class=""></div>
          <div id="u606_text" class="text ">
            <p><span>足球AI模組分析</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u607" class="ax_default box_3">
          <div id="u607_div" class=""></div>
          <div id="u607_text" class="text ">
            <p><span>Futra是日精選</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u608" class="ax_default box_3">
          <div id="u608_div" class=""></div>
          <div id="u608_text" class="text ">
            <p><span>為何我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u609" class="ax_default box_3">
          <div id="u609_div" class=""></div>
          <div id="u609_text" class="text ">
            <p><span>聯絡我們</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u610" class="ax_default box_3">
          <div id="u610_div" class=""></div>
          <div id="u610_text" class="text ">
            <p><span>會員中心</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u611" class="ax_default box_3">
          <div id="u611_div" class=""></div>
          <div id="u611_text" class="text ">
            <p><span>登入</span></p>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u612" class="ax_default">
          <div id="u612_state0" class="panel_state" data-label="State 1" style="">
            <div id="u612_state0_content" class="panel_state_content">

              <!-- HOME_SUBMENU (Group) -->
              <div id="u613" class="ax_default ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="104" data-height="168">

                <!-- Unnamed (Rectangle) -->
                <div id="u614" class="ax_default box_3">
                  <div id="u614_div" class=""></div>
                  <div id="u614_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u615" class="ax_default box_3">
                  <div id="u615_div" class=""></div>
                  <div id="u615_text" class="text ">
                    <p><span>簡介</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u616" class="ax_default box_3">
                  <div id="u616_div" class=""></div>
                  <div id="u616_text" class="text ">
                    <p><span>如何應用</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u617" class="ax_default box_3">
                  <img id="u617_img" class="img " src="/footballui/public/frontend/images/page_a4/u617.svg"/>
                  <div id="u617_text" class="text ">
                    <p><span>為何我們</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u618" class="ax_default box_3">
                  <div id="u618_div" class=""></div>
                  <div id="u618_text" class="text ">
                    <p><span>馬上註冊</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u619" class="ax_default box_3">
                  <div id="u619_div" class=""></div>
                  <div id="u619_text" class="text ">
                    <p><span>用戶推薦</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u620" class="ax_default box_3">
                  <div id="u620_div" class=""></div>
                  <div id="u620_text" class="text ">
                    <p><span>風險披露</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u621" class="ax_default">
          <div id="u621_state0" class="panel_state" data-label="State 1" style="">
            <div id="u621_state0_content" class="panel_state_content">

              <!-- AI_SUBMENU (Group) -->
              <div id="u622" class="ax_default ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="120" data-height="140">

                <!-- Unnamed (Rectangle) -->
                <div id="u623" class="ax_default box_3">
                  <div id="u623_div" class=""></div>
                  <div id="u623_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u624" class="ax_default box_3">
                  <div id="u624_div" class=""></div>
                  <div id="u624_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u625" class="ax_default box_3">
                  <div id="u625_div" class=""></div>
                  <div id="u625_text" class="text ">
                    <p><span>綜合網民數據結果</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u626" class="ax_default box_3">
                  <img id="u626_img" class="img " src="/footballui/public/frontend/images/page_a4/u626.svg"/>
                  <div id="u626_text" class="text ">
                    <p><span>值博率模組分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u627" class="ax_default box_3">
                  <div id="u627_div" class=""></div>
                  <div id="u627_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u628" class="ax_default box_3">
                  <div id="u628_div" class=""></div>
                  <div id="u628_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u629" class="ax_default">
          <div id="u629_state0" class="panel_state" data-label="State 1" style="">
            <div id="u629_state0_content" class="panel_state_content">

              <!-- Futra_SUBMENU (Group) -->
              <div id="u630" class="ax_default ax_default_hidden" data-label="Futra_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="136" data-height="84">

                <!-- Unnamed (Rectangle) -->
                <div id="u631" class="ax_default box_3">
                  <div id="u631_div" class=""></div>
                  <div id="u631_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u632" class="ax_default box_3">
                  <div id="u632_div" class=""></div>
                  <div id="u632_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u633" class="ax_default box_3">
                  <div id="u633_div" class=""></div>
                  <div id="u633_text" class="text ">
                    <p><span>爆冷精選</span></p>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u634" class="ax_default box_3">
                  <img id="u634_img" class="img " src="/footballui/public/frontend/images/page_a4/u634.svg"/>
                  <div id="u634_text" class="text ">
                    <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Image) -->
        <div id="u635" class="ax_default image">
          <img id="u635_img" class="img " src="/footballui/public/frontend/images/page_a4/u635.jpg"/>
          <div id="u635_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>
      <div id="u602" style="display:none; visibility:hidden;"></div>

      <!-- Unnamed (Top Menu) -->

      <!-- Top Menu_M (Group) -->
      <div id="u637" class="ax_default ax_default_unplaced" data-label="Top Menu_M" style="display:none; visibility: hidden" data-left="2" data-top="-5" data-width="0" data-height="0">

        <!-- Unnamed (Dynamic Panel) -->
        <div id="u638" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u638_state0" class="panel_state" data-label="State 1" style="">
            <div id="u638_state0_content" class="panel_state_content">

              <!-- 1ST SUB (Group) -->
              <div id="u639" class="ax_default ax_default_unplaced" data-label="1ST SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u640" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u640_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u640_state0_content" class="panel_state_content">

                      <!-- HOME_SUBMENU (Group) -->
                      <div id="u641" class="ax_default ax_default_unplaced ax_default_hidden" data-label="HOME_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u642" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u642_div" class=""></div>
                          <div id="u642_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u643" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u643_div" class=""></div>
                          <div id="u643_text" class="text ">
                            <p><span>簡介</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u644" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u644_div" class=""></div>
                          <div id="u644_text" class="text ">
                            <p><span>如何應用</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u645" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u645_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u645_text" class="text ">
                            <p><span>為何我們</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u646" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u646_div" class=""></div>
                          <div id="u646_text" class="text ">
                            <p><span>馬上註冊</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u647" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u647_div" class=""></div>
                          <div id="u647_text" class="text ">
                            <p><span>用戶推薦</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u648" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u648_div" class=""></div>
                          <div id="u648_text" class="text ">
                            <p><span>風險披露</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u649" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u649_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u649_text" class="text ">
                    <p><span>首頁</span></p>
                  </div>
                </div>
              </div>

              <!-- 2ND SUB (Group) -->
              <div id="u650" class="ax_default ax_default_unplaced" data-label="2ND SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u651" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u651_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u651_state0_content" class="panel_state_content">

                      <!-- AI_SUBMENU (Group) -->
                      <div id="u652" class="ax_default ax_default_unplaced ax_default_hidden" data-label="AI_SUBMENU" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u653" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u653_div" class=""></div>
                          <div id="u653_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u654" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u654_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u654_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組賽果預測</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u655" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u655_div" class=""></div>
                          <div id="u655_text" class="text ">
                            <p><span>綜合網民數據結果</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u656" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <img id="u656_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                          <div id="u656_text" class="text ">
                            <p><span>值博率模組分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u657" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u657_div" class=""></div>
                          <div id="u657_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組波膽分析</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u658" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                          <div id="u658_div" class=""></div>
                          <div id="u658_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析大小角</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u659" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u659_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u659_text" class="text ">
                    <p><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">足球</span><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組分析</span></p>
                  </div>
                </div>
              </div>

              <!-- 3RD SUB (Group) -->
              <div id="u660" class="ax_default ax_default_unplaced" data-label="3RD SUB" style="display:none; visibility: hidden" data-left="0" data-top="0" data-width="0" data-height="0">

                <!-- Unnamed (Dynamic Panel) -->
                <div id="u661" class="ax_default ax_default_unplaced" style="display:none; visibility: hidden">
                  <div id="u661_state0" class="panel_state" data-label="State 1" style="">
                    <div id="u661_state0_content" class="panel_state_content">

                      <!-- FUTRA_SUBMENU (Group) -->
                      <div id="u662" class="ax_default" data-label="FUTRA_SUBMENU" data-left="0" data-top="0" data-width="390" data-height="144">

                        <!-- Unnamed (Rectangle) -->
                        <div id="u663" class="ax_default box_3">
                          <div id="u663_div" class=""></div>
                          <div id="u663_text" class="text " style="display:none; visibility: hidden">
                            <p></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u664" class="ax_default box_3">
                          <img id="u664_img" class="img " src="/footballui/public/frontend/images/page_a4/u664.svg"/>
                          <div id="u664_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">Futra</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">是日精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Rectangle) -->
                        <div id="u665" class="ax_default box_3">
                          <div id="u665_div" class=""></div>
                          <div id="u665_text" class="text ">
                            <p><span>爆冷精選</span></p>
                          </div>
                        </div>

                        <!-- Unnamed (Shape) -->
                        <div id="u666" class="ax_default box_3">
                          <img id="u666_img" class="img " src="/footballui/public/frontend/images/page_a4/u666.svg"/>
                          <div id="u666_text" class="text ">
                            <p><span style="font-family:&quot;ArialMT&quot;, &quot;Arial&quot;, sans-serif;">AI</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;">模組嚴選最高分隊</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Unnamed (Shape) -->
                <div id="u667" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                  <img id="u667_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                  <div id="u667_text" class="text ">
                    <p><span>Futra是日精選</span></p>
                  </div>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u668" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u668_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u668_text" class="text ">
                  <p><span>為何我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u669" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u669_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u669_text" class="text ">
                  <p><span>聯絡我們</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u670" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u670_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u670_text" class="text ">
                  <p><span>會員中心</span></p>
                </div>
              </div>

              <!-- Unnamed (Shape) -->
              <div id="u671" class="ax_default box_3 ax_default_unplaced" style="display:none; visibility: hidden">
                <img id="u671_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
                <div id="u671_text" class="text ">
                  <p><span>登入</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u672" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u672_div" class=""></div>
          <div id="u672_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u673" class="ax_default box_1 ax_default_unplaced" style="display:none; visibility: hidden">
          <div id="u673_div" class=""></div>
          <div id="u673_text" class="text ">
            <p><span>MENU</span></p>
          </div>
        </div>

        <!-- Unnamed (Image) -->
        <div id="u674" class="ax_default image ax_default_unplaced" style="display:none; visibility: hidden">
          <img id="u674_img" class="img " src="/footballui/public/frontend/resources/images/transparent.gif"/>
          <div id="u674_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>
      <div id="u636" style="display:none; visibility:hidden;"></div>
    </div>
    <script src="/footballui/public/frontend/resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/footballui/resources/views/frontend/page_a4d2.blade.php ENDPATH**/ ?>