﻿<!DOCTYPE html>
<html>
  <head>
    <title>page A8</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/page_a8/styles.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Source+Code+Pro" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/page_a8/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Chart_bg (Rectangle) -->
      <div id="u222" class="ax_default box_2" data-label="Chart_bg">
        <div id="u222_div" class=""></div>
        <div id="u222_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Button (Group) -->
      <div id="u223" class="ax_default" data-label="Button" data-left="828" data-top="560" data-width="262" data-height="40">

        <!-- AI_Button (Rectangle) -->
        <div id="u224" class="ax_default box_3" data-label="AI_Button">
          <div id="u224_div" class=""></div>
          <div id="u224_text" class="text ">
            <p><span>足球AI模組分析 &gt;&gt;&gt;</span></p>
          </div>
        </div>

        <!-- Button_HotSpot (Hot Spot) -->
        <div id="u225" class="ax_default" data-label="Button_HotSpot">
        </div>
      </div>

      <!-- Best (Group) -->
      <div id="u226" class="ax_default" data-label="Best" data-left="150" data-top="231" data-width="525" data-height="80">

        <!-- Table_rtg (Rectangle) -->
        <div id="u227" class="ax_default box_2" data-label="Table_rtg">
          <div id="u227_div" class=""></div>
          <div id="u227_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Predict_content (Rectangle) -->
        <div id="u228" class="ax_default paragraph" data-label="Predict_content">
          <div id="u228_div" class=""></div>
          <div id="u228_text" class="text ">
            <p><span>預測結果選擇</span></p>
          </div>
        </div>

        <!-- Game_content (Rectangle) -->
        <div id="u229" class="ax_default paragraph" data-label="Game_content">
          <div id="u229_div" class=""></div>
          <div id="u229_text" class="text ">
            <p><span>俄羅斯超級聯賽羅斯托夫PFC索契</span></p>
          </div>
        </div>

        <!-- Icon (Group) -->
        <div id="u230" class="ax_default" data-label="Icon" data-left="150" data-top="271" data-width="95" data-height="40">

          <!-- Icon_rtg (Rectangle) -->
          <div id="u231" class="ax_default paragraph" data-label="Icon_rtg">
            <div id="u231_div" class=""></div>
            <div id="u231_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Medal_icon (Shape) -->
          <div id="u232" class="ax_default icon" data-label="Medal_icon">
            <img id="u232_img" class="img " src="images/page_a8/medal_icon_u232.svg"/>
            <div id="u232_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>
        </div>

        <!-- Items_rtg (Rectangle) -->
        <div id="u233" class="ax_default box_3" data-label="Items_rtg">
          <div id="u233_div" class=""></div>
          <div id="u233_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>

        <!-- Predict (Rectangle) -->
        <div id="u234" class="ax_default paragraph" data-label="Predict">
          <div id="u234_div" class=""></div>
          <div id="u234_text" class="text ">
            <p><span>預測結果</span></p>
          </div>
        </div>

        <!-- Game (Rectangle) -->
        <div id="u235" class="ax_default paragraph" data-label="Game">
          <div id="u235_div" class=""></div>
          <div id="u235_text" class="text ">
            <p><span>比賽場次</span></p>
          </div>
        </div>

        <!-- Items (Rectangle) -->
        <div id="u236" class="ax_default paragraph" data-label="Items">
          <div id="u236_div" class=""></div>
          <div id="u236_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Team_G (Image) -->
      <div id="u237" class="ax_default image" data-label="Team_G">
        <img id="u237_img" class="img " src="images/page_a4/ta_g_u110.png"/>
        <div id="u237_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Header_team (Rectangle) -->
      <div id="u238" class="ax_default box_2" data-label="Header_team">
        <div id="u238_div" class=""></div>
        <div id="u238_text" class="text ">
          <p><span>羅斯托夫PFC索契</span></p>
        </div>
      </div>

      <!-- Header (Rectangle) -->
      <div id="u239" class="ax_default box_2" data-label="Header">
        <div id="u239_div" class=""></div>
        <div id="u239_text" class="text ">
          <p style="font-size:14px;"><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;font-size:16px;">AI模組嚴選最高分球隊</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;"> </span><span style="font-family:&quot;LucidaGrande&quot;, &quot;Lucida Grande&quot;, sans-serif;">►</span><span style="font-family:&quot;PingFangHK-Regular&quot;, &quot;PingFang HK&quot;, sans-serif;"> </span></p>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/footballui/resources/views/frontend/page_a8.blade.php ENDPATH**/ ?>